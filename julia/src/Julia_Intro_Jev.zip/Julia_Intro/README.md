# Introduction-to-Julia
Learn the language basics in this 10-part course
