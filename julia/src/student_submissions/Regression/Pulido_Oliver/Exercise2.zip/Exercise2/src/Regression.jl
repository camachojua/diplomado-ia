# -------------------------------------------------------------- PAQUETES ----------------------------------------------------------------------

# Comenzamos importando los paquetes
using Pkg
#Pkg.add("CSV")
#Pkg.add("DataFrames")
#Pkg.add("Statistics")
#Pkg.add("Plots")
#Pkg.add("StatsPlots")
#Pkg.add("GLM")
#Pkg.add("Random")
#Pkg.add("Distributions")
#Pkg.add("StatsModels")

using CSV, DataFrames, Statistics, Plots, StatsPlots, GLM, Random, Distributions, StatsModels


# ----------------------------------------------------------- Cargando Datos ------------------------------------------------------------------

bottle = CSV.read("bottle_EDA.csv", DataFrame)

# Creamos primero una copia del Dataframe para no alterar el original:
df = copy(bottle)

# Ahora barajeamos las filas:

Random.seed!(1234)                     # Semilla para reproducibilidad
df = df[randperm(nrow(df)), :]

n = floor(Int, 0.9 * nrow(df))           # Tomamos el 90%, el cálculo redondea hacia abajo
train_df = df[1:n, :]                    # Almacenamos nuestro 90%
test_df = df[n+1:end, :]                 # Almacenamos nuestro 10%


# ------------------------------------------------------ Hallando el mejor Modelo --------------------------------------------------------------

#Comenzamos con el modelo Y = beta_0
ols0 = lm(@formula(T_degC ~ 1), train_df)       # Función de GLM que hace la regresión lineal directa
#println(r2(ols0))

# Hacemos regresiones independientes y calculamos el RSS de cada uno:
ols1 = lm(@formula(T_degC ~ 1 + Depthm), train_df)
ols2 = lm(@formula(T_degC ~ 1 + Salnty), train_df)
ols3 = lm(@formula(T_degC ~ 1 + STheta), train_df)
ols4 = lm(@formula(T_degC ~ 1 + Sta_ID_Encoded), train_df)

regs = [ols1, ols2, ols3, ols4]                                          # Almacenamos cada regresión
predictores = ["Depthm", "Salnty", "STheta", "Sta_ID_Encoded"]
RSS = []

for i in 1:4
    predicciones = predict(regs[i], test_df)
    residuos = test_df.T_degC .- predicciones
    rss = sum(residuos.^2)
    push!(RSS, rss)
    println("El RSS de la regresión lineal entre T_degC y ", predictores[i], " es: ", rss)
end

#println("\nEl RSS menor es: ", minimum(RSS))

# Mostramos la R^2 del modelo con menor RSS
#println(r2(ols3))


# Repetimos el proceso viendo las demás regresiones
ols1 = lm(@formula(T_degC ~ STheta + Depthm), train_df)
ols2 = lm(@formula(T_degC ~ STheta + Salnty), train_df)
ols4 = lm(@formula(T_degC ~ STheta + Sta_ID_Encoded), train_df)

regs = [ols1, ols2, ols4]
predictores = ["Depthm", "Salnty", "Sta_ID_Encoded"]
RSS = []

for i in 1:3
    predicciones = predict(regs[i], test_df)
    residuos = test_df.T_degC .- predicciones
    rss = sum(residuos.^2)
    push!(RSS, rss)
    println("El RSS de la regresión lineal con ", predictores[i], " es: ", rss)
end

#println("\nEl RSS menor es: ", minimum(RSS))
#println(r2(ols4))



# Repetimos el proceso
ols1 = lm(@formula(T_degC ~ STheta + Sta_ID_Encoded + Depthm), train_df)
ols2 = lm(@formula(T_degC ~ STheta + Sta_ID_Encoded + Salnty), train_df)

regs = [ols1, ols2]
predictores = ["Depthm", "Salnty"]
RSS = []

for i in 1:2
    predicciones = predict(regs[i], test_df)
    residuos = test_df.T_degC .- predicciones
    rss = sum(residuos.^2)
    push!(RSS, rss)
    println("El RSS de la regresión lineal con ", predictores[i], " es: ", rss)
end

#println("\nEl RSS menor es: ", minimum(RSS))
#println(r2(ols1))

# -------------------------------------------------------- La mejor Combinación ----------------------------------------------------------------

ols = lm(@formula(T_degC ~ Salnty + Salnty * Depthm + Depthm * STheta + STheta * Salnty), train_df)
r2(ols)

# --------------------------------------------------------------- Prueba F ---------------------------------------------------------------------

n = nrow(train_df)                    # Número de observaciones
k = length(coef(ols)) - 1             # Grados de libertad del numerador (número de predictores)
rss = deviance(ols)                   # Residual Sum of Squares (RSS)
tss = sum((train_df.T_degC .- mean(train_df.T_degC)).^2)  # Total Sum of Squares (TSS)

# Estadístico F
f_statistic = ((tss - rss) / k) / (rss / (n - k - 1))

# P-valor del estadístico F
p_value_f = 1 - cdf(FDist(k, n - k - 1), f_statistic)

# Mostramos resultados
println("F-Statistic: $f_statistic")
println("P-Value (F-Statistic): $p_value_f")


# ------------------------------------------------------------ PREDICCIONES --------------------------------------------------------------------

predicciones = predict(ols, test_df)                                # Realizamos predicciones en los datos de prueba

residuos = test_df.T_degC .- predicciones                           # Calculamos los residuos en los datos de prueba

mse_test = mean((residuos).^2)                                      # Calculamos el Error Cuadrático Medio (MSE) en los datos de prueba
println("Error Cuadrático Medio (MSE) en prueba: ", mse_test)
 
mae_test = mean(abs.(residuos))                                     # Calculamos el Error Absoluto Medio (MAE) en los datos de prueba
println("Error Absoluto Medio (MAE) en prueba: ", mae_test)

# Calculamos el coeficiente de determinación R² en los datos de prueba
ss_tot = sum((test_df.T_degC .- mean(test_df.T_degC)).^2)
ss_res = sum(residuos.^2)
r2_test = 1 - (ss_res / ss_tot)
println("Coeficiente de determinación (R²) en prueba: ", r2_test)

# --------------------------------------------------------- VISUALIZACIONES --------------------------------------------------------------------

# Gráfico de Residuos
scatter(predicciones, residuos, xlabel="Valores Predichos", ylabel="Residuos", title="Gráfico de Residuos")

# Gráfico de Valores Reales vs. Valores Predichos
T = test_df.T_degC
scatter(T, predicciones, xlabel="Valores Reales de T_degC", ylabel="Valores Predichos de T_degC", title="Valores Reales vs Valores Predichos")
plot!([minimum(T), maximum(T)], [minimum(T), maximum(T)], lw=2, lc=:red, label="y=x")