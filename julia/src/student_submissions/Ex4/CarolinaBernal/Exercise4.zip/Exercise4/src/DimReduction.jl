#=
1. Get a collection of 5 to 10 images of at least [512,512] pixels to do dimensionality reduction. 
2. You can use photos from your family, friends, pets, etc.
3. Use PCA/SVD in Go or in Julia.
4. You will get bonus points if you do it in both, Go and Julia
5. If you submit in Julia and in Go, do so as separated submissions with the following names:
    a. Exercise4JL
    b. Exercise4GO
6.Submit your project following the submission guidelines

=#


#=
Acording to SVD doc in Julia, SVD() compute the singular value decomposition (SVD) of A and return an SVD object.
U, S, V and Vt can be obtained from the factorization 
F with F.U, F.S, F.V and F.Vt, such that A = U * Diagonal(S) * Vt.
The algorithm produces Vt and hence Vt is more efficient to extract than V. 
The singular values in S are sorted in descending order.
=#

#=
To sucessfully execute this code you need to have the following libraries:
    fig
     > original_img  
        img1_input.jpeg
        ...
        img5_input.jpeg
    > output_img
        > output_graphs
            >k=5
            >k=10
            >k=50
            >k=100
        > output_gray_original
        > output_gray_resize
        > output_k
            >k=5
            >k=10
            >k=50
            >k=100        
        > output_resize

=#

import Pkg; 
using Pkg
Pkg.add(["FileIO","Plots", "Images","Distributions","GLM","ImageView"]); 


using Images
using Plots
using FileIO
using Distributions
using LinearAlgebra
using Statistics
using GLM
using ImageView
using ImageTransformations
using ColorTypes


#=  loadInputImages(...)
    
    the  function uses this Julia func to load the images  
    we have stored in original_img_path with the key_word:  input (original)
    or resized (util for reshaped images) , this func retrieves two arrays 
    with the original img paths and the images loaded
    In Julia :     
    `load(filename)` loads the contents of a formatted file, trying to infer
    the format from `filename` and/or magic bytes in the file
      
=#
function loadInputImages(img_cnt::Int64, original_img_path::String, key_word::String)

    img_arr = []
    img_path_final = []
    load_img_arr = []
    
    for i in 1:img_cnt

        img_i = "img" * string(i) * "_" * key_word *  ".jpeg"
        img_i_path = string(original_img_path,img_i)
        img_path_fn = img_i_path
        load_i = load(img_i_path)
        push!(img_arr, img_i)  
        push!(load_img_arr,load_i)  
        push!(img_path_final,img_path_fn )
    end 

    return img_path_final, load_img_arr
end

#= reSizeInputImg(...) 
    the function resizes the images with (nPix , nPix) stored on 
    the original path and save the reshaped images on the output file 
    with the "resize" name
=# 
function reSizeInputImg(img_cnt::Int64,  nPix::Int64 , original_img_path::String , output_file::String, outword::String)
    
    img_path_final , img_load = loadInputImages(img_cnt,original_img_path,key_word)
    #resize_load = []
    resize_path_arr = []

    for i in 1:img_cnt

        img_i_resize = ImageTransformations.imresize(img_load[i],(nPix,nPix))
        img_output = "img" * string(i)  * "_" * outword *  ".jpeg"
        resize_path = string(output_file,img_output)
        #load_i = load(resize_path)
        save(resize_path,img_i_resize)
        push!(resize_path_arr, resize_path)
        #push!(resize_load,load_i)
        
    end

    println("Created " , img_cnt," new images with the new size ",nPix,"x" , nPix, " from the original images: ",img_path_final )
    
    return  resize_path_arr #, resize_load
end

#= GrayScaleImg(...) apply Gray.(...) for the original and rescale images , save the img output 
    and retieve the gray original and resize arrays
    `Gray` is a grayscale object. You can extract its value with `gray(c)`.
     We need to convert the original image from RGB to gray scale 
=#
function GrayScaleImg(load_img_o::Vector,load_img_r::Vector, img_cnt::Int64, output_file::String)

    output_o_gray = string(output_file,"output_gray_original/")
    output_r_gray = string(output_file,"output_gray_resize/")
    gray_img_arr = []
    gray_r_arr = []

    for i in 1:img_cnt

        Gray_i = Gray.(load_img_o[i])
        Gray_r_i = Gray.(load_img_r[i])

        img_gray = "img" * string(i) * "_gray_o"  *  ".jpeg"
        img_gray_path = string(output_o_gray,img_gray)

        img_gray_r = "img" * string(i) * "_gray_r"  *  ".jpeg"
        img_gray_path_r = string(output_r_gray,img_gray_r)


        push!(gray_img_arr,Gray_i)
        push!(gray_r_arr, Gray_r_i)

        save(img_gray_path,Gray_i)
        save(img_gray_path_r,Gray_r_i)
    end

    return gray_img_arr, gray_r_arr
end

## Find SVD of modified and images that had a reduction from their original size
#= FindSVD(...) and FindApproxImg(...)

    Find the SVD of the matrix M::Matrix.  The function Calls
    LinearAlgebrea.svd(M) which returns F, a factorization object.
    F contains U,S,V and Vt, such that M = F.U * Diagonal( F.S ) * F.Vt.
    I found that this formula works better:
    M = F.U[:, 1:k] * Diagonal(F.S[1:k]) * (F.V[:, 1:k])'   # the ' is an operator calling LinearAlgebra.adjoint()     
    M = F.U[:, 1:k] * Diagonal(F.S[1:k]) * adjoint(F.V[:, 1:k])
    The singular values in S are sorted in descending order

FindSVD(...) and  FindApproxImg(...) functions use the logic described above
Note: For SVD we're using the gray and reduced image
=#
function FindSVD( gray_r::Vector)

   SVD_arr = []

   for i in 1:length(gray_r)

    imgi = gray_r[i]
    
    nRows = length(imgi)
    img_size = size(imgi)
    nPixeles = img_size[1]

    M = Matrix{Float64}(undef, nRows, nRows)
    M = convert(Array{Float64}, imgi)
    F = svd( M ) 

    push!(SVD_arr,F)

   end

    return SVD_arr
end


function FindApproxImg(gray_r::Vector, k::Int64, output_img_path::String)

    SVD_arr = FindSVD(gray_r)
    #M_arr = []

    output_file = string(output_img_path,"output_k/")
    m = string(k)
    output_file_k = output_file * "k=" * m

    for i in 1:length(gray_r)
     
    img_i = "/img" * string(i) *  ".jpeg" 
    final_path_k = string(output_file_k, img_i)   

    Fi = SVD_arr[i]
    Mi = Fi.U[:, 1:k] * Diagonal(Fi.S[1:k]) * Fi.V[:, 1:k]'
    Mi = abs.( Mi .* 0.99)

    println("M Info:" , " Img:", i ,  "  Type = ", typeof(Mi), "  size=", size(Mi), " K=" , k)
    save(final_path_k, Mi)
    #push!(M_arr, Mi)

    end 

    #return M_arr

end

## The PrintSVDInfo(...) retrieves useful info of the SVD from each image
function PrintSVDInfo( SVD_arr::Vector )

    for i in 1:length(SVD_arr)

    F = SVD_arr[i]    
    println("PrintSVDInfo for image ", i)
    println("F.U  Info: Type = ", typeof(F.U),  "  size=", size(F.U))
    println("F.S  Info: Type = ", typeof(F.S),  "  size=", size(F.S))
    println("F.V  Info: Type = ", typeof(F.V),  "  size=", size(F.V))
    println("F.Vt Info: Type = ", typeof(F.Vt), "  size=", size(F.Vt))
    println("")

    end

end

# FindNormalizedSum(...) 
function FindNormalizedSum(v::Vector{Float64})
   
    nn = length(v)
    svx = 0.0
    sv = Vector{Float64}(undef, nn)

    for i in 1:nn
        svx += v[i]
    end    

    svx = svx / nn 
    sum = 0.0

    for i in 1:nn 
        sv[i] = v[i] / (svx*nn)
        sum += sv[i]
    end 

    return sum, sv

end

# PlotNormalizedSum(...) 
function PlotNormalizedSum(SVD_arr::Vector, output_img_path::String, k::Int64)


    m = string(k)
    output_file_k =  "k=" * m
    

    for j in 1:length(SVD_arr)

        graph_path  = output_img_path * "output_graphs/" * output_file_k * "/plot_img" * string(j) * ".png"

        F = SVD_arr[j]
        S = convert( Vector{Float64}, F.S) 
        println("Image" , j , " info: ")
        println("The size of the vector is: ", length(S))
        sum, normSum = FindNormalizedSum(S)
        n = length(normSum)
        println("Sum = ", sum, "  size n: ", n)
        println("")

        # Select the first k items to compare the normalized sum
        if k!= 0 
            n = k
        end     

        y = Vector{Float64}(undef, n)
        x = Vector{Float64}(undef, n)

        for i in 1:n
        
            y[i] = i
            x[i] = 1.0 - normSum[i]

         end
    
    p = plot(y, x)
    savefig(p, graph_path)

    end

end


##### Here we go ! :) We're going to use the functions we created 

println("")
println("Here we go ! :)")

cd("/Users/carolinabernal/Documents/DiplomadoExercises")

original_img_path  =  "Exercise4/fig/original_img/"
output_img_path  =  "Exercise4/fig/output_img/"


key_word = "input"
arr, load_img = loadInputImages(5,original_img_path,key_word)
#@show arr


out_word = "resize"
output_file = string(output_img_path,"output_resize/")
reSizeInputImg(5,300,original_img_path,output_file,"resize")
arr_rsz, load_img_rsz = loadInputImages(5,output_file,out_word)


output_file_gray = "Exercise4/fig/output_img/"   
# GrayScaleImg(load_img_o::Vector,load_img_r::Vector, img_cnt::Int64, output_file::String)
gray_o, gray_r = GrayScaleImg(load_img, load_img_rsz, 5,output_file_gray)



SVD_arr = FindSVD(gray_r)


output_img_path  =  "Exercise4/fig/output_img/"

## Images 

k = 5
M_arr_5 = FindApproxImg(gray_r, k, output_img_path)


k = 10
M_arr_10 = FindApproxImg(gray_r, k, output_img_path)


k = 50
M_arr_50 = FindApproxImg(gray_r, k, output_img_path)

k = 100
M_arr_100 = FindApproxImg(gray_r, k, output_img_path)

## SVD info 

PrintSVDInfo( SVD_arr )

println(output_img_path) 


## Plots
k = 5
PlotNormalizedSum(SVD_arr, output_img_path, k)

k = 10
PlotNormalizedSum(SVD_arr, output_img_path, 10)

k = 50
PlotNormalizedSum(SVD_arr, output_img_path, 50)

k = 100
PlotNormalizedSum(SVD_arr, output_img_path, 100)



