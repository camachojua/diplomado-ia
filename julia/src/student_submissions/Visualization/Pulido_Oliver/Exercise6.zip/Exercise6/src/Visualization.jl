# -------------------------------------------------------------- PAQUETES ---------------------------------------------------------------------
using Pkg

#Pkg.add("CairoMakie")
#Pkg.add("Graphs")
#Pkg.add("Random")

using Graphs, Random, CairoMakie

# ------------------------------------------ GENERANDO EL GRAFO CON GRAPHS ---------------------------------------------------------------------

G = SimpleGraph(200)                          # Generamos un grafo No Dirigido con 200 Nodos

posicion = [(rand(), rand()) for _ in 1:200]  # Creamos una lista de 200 pares ordenados cuyos elementos son aleatorios

# Determinamos el umbral
umbral = 0.125

# La variable posicion tiene dos elementos, la posición en x y en y:
for i in 1:200
    for j in i+1:200                     # Con el doble for nos aseguramos de tomar por pares a los nodos
        # Calculamos la distancia
        x2_x1_cuad = (posicion[i][1] - posicion[j][1]) ^ 2
        y2_y1_cuad = (posicion[i][2] - posicion[j][2]) ^ 2
        suma = x2_x1_cuad + y2_y1_cuad
        dij = sqrt( suma )
        if dij <= umbral
            add_edge!(G, i, j)            # Agregamos una arista entre los nodos i y j en el grafo G
        end
    end
end

#La siguiente función se creó para no tener problemas con las variables dmin y ncenter, puesto que Julia se confunde con el scope
function encontrar_centro(posicion)
    dmin = 1
    ncenter = 0
    for n in eachindex(posicion)                 # Cambia la sintaxis en Julia para acceder a las posiciones
        x, y = posicion[n]
        d = (x - 0.5)^2 + (y - 0.5)^2            # Calculamos la distancia al centro (0.5, 0.5)
        if d < dmin
            ncenter = n                          # Al final ncenter será el nodo más cercano y por tanto el nodo central
            dmin = d
        end
    end
    return ncenter
end

ncenter = encontrar_centro(posicion)


distancias = dijkstra_shortest_paths(G, ncenter).dists   # Extraemos las distancias más cortas al nodo central, pero devuelve un vector
p = Dict(i => distancias[i] for i in 1:length(distancias))  # Ahora obtenemos un diccionario como en Python

# --------------------------------------------- GENERAMOS LA IMAGEN DEL GRAFO ------------------------------------------------------------------

fig = CairoMakie.Figure(size = (800, 800))        # Creamos un Lienzo de tamaño 800 x 800
ax = CairoMakie.Axis(fig[1, 1], aspect = 1)       # Creamos el eje con las mismas unidades

# Establecemos límites de los ejes
CairoMakie.xlims!(ax, -0.05, 1.05)
CairoMakie.ylims!(ax, -0.05, 1.05)

# Desactivamos los ejes
CairoMakie.hidespines!(ax)         # Ocultamos las líneas del plano
CairoMakie.hidedecorations!(ax)    # Ocultamos las marcas y números de los ejes

# Dibujamos las aristas del grafo
for i in edges(G)                                                # Iteramos sobre todas las aristas
    nodo_origen = src(i)                                         # Extraemos el nodo de origen
    nodo_destino = dst(i)                                        # Obtenemos el nodo de destino
    xs = [posicion[nodo_origen][1], posicion[nodo_destino][1]]   # Accedemos a las coordenadas del nodo de origen
    ys = [posicion[nodo_origen][2], posicion[nodo_destino][2]]   # Accedemos a las coordenadas del nodo de destino
    CairoMakie.lines!(ax, xs, ys, color = :gray, alpha = 0.4)    # Pintamos líneas grises desde los nodos de origen hasta los nodos de destino 
end

# Dibujamos los nodos del grafo
color_nodo = [p[i] for i in 1:200]      # Generamos una lista con las distancias más cortas de los 200 nodos
CairoMakie.scatter!(ax, [posicion[i][1] for i in 1:200], [posicion[i][2] for i in 1:200],  # Graficamos los nodos como puntos 
         markersize = 18,                # El tamaño del nodo
         color = color_nodo,            # Asignamos un color a cada nodo 
         colormap = :reds)               # Hacemos que los nodos más cercanos al nodo central tengan un color más oscuro


# --------------------------------------------- MOSTRAMOS Y GUARDAMOS LA FIGURA ---------------------------------------------------------------

# Mostrar la figura
CairoMakie.display(fig)

#Guardamos la imagen
#CairoMakie.save("random_generic_graph.png", fig)