import Pkg

Pkg.add("StatsBase")
Pkg.add("Plots")
Pkg.add("GLMakie")
Pkg.add("Clustering")
Pkg.add("CairoMakie")

using DataFrames
using CSV
using StatsBase
using GLMakie
using CairoMakie
using Clustering

using Printf

### Leading the Data

# Load the dataset
# Build the file path dynamically
file_path = joinpath(@__DIR__, "../dat/bottle.csv")
calcofi_data = CSV.read(file_path, DataFrame)

# Get the shape of the dataset
n_rows, n_cols = size(calcofi_data)
println("The dataset has $n_rows rows and $n_cols columns.")

# Get the data types of each column
println("\nColumn Data Types:")
for (col_name, col_type) in zip(names(calcofi_data), eltype.(eachcol(calcofi_data)))
    @printf("%-20s | %-13s\n", col_name, col_type)
end

### Missing Values

function count_missing(df::DataFrame)
    # Calculate the number of missing values for each column
    missing_values = map(col -> count(ismissing, col), eachcol(df))
    return missing_values
end

function data_missing_percentage(df::DataFrame)
    # Calculate the percentage of missing values for each column
    missing_values = map(col -> count(ismissing, col), eachcol(df))
    missing_percentages = missing_values ./ n_rows .* 100
    return missing_percentages
end

missing_values = count_missing(calcofi_data)
missing_percentages = data_missing_percentage(calcofi_data)

function print_missing_values(calcofi_data, missing_values, missing_percentages)
    println("Column               | Missing Count | Missing Percentage")
    c = 0
    for (col_name, missing_count, missing_pct) in zip(names(calcofi_data), missing_values, missing_percentages)
        @printf("%-20s | %-13d | %-10.2f%%\n", col_name, missing_count, missing_pct)
        c += 1

        if c == 10
            println("-" ^ 57)
        end
    end
end

print_missing_values(calcofi_data, missing_values, missing_percentages)

### Data Cleaning

function delete_columns(df::DataFrame, threshold::Float64)
    # Get missing percentages
    missing_percentages = data_missing_percentage(df)

    # Identify columns to drop based on missing percentage threshold
    cols_to_drop = names(df)[missing_percentages .> threshold]

    # Drop the identified columns 
    cleaned_data = select(df, Not(cols_to_drop))
    return cleaned_data
end

# Threshold for missing values
threshold = 10.0

# Identify columns to drop based on missing percentage threshold
cleaned_data = delete_columns(calcofi_data, threshold)
println(first(cleaned_data, 5))

### Correlation

function calculate_correlation(df::DataFrame)
    num_cols = ncol(df)
    matrix = zeros(Float64, num_cols, num_cols)

    for (i, target_col) in enumerate(names(df))
        for (j, col) in enumerate(names(df))
            indices = findall(row -> !ismissing(row[target_col]) && !ismissing(row[col]), eachrow(df))
            if length(indices) > 1  # Ensure enough valid rows for correlation
                temp_df = df[indices, :]
                matrix[i, j] = cor(temp_df[:, target_col], temp_df[:, col])
            else
                matrix[i, j] = NaN  # Not enough data for correlation
            end
        end
    end

    return matrix
end

# Drop non numeric columns
columns_to_drop = [:Sta_ID, :Depth_ID]
cleaned_numeric_data = select(cleaned_data, Not(columns_to_drop))

# Calculate Correlation Matrix
correlation_matrix = calculate_correlation(cleaned_numeric_data)

function display_correlation(correlation_matrix::Matrix{Float64})
    fig = Figure(size=(800,600), backgroundcolor = :black)  # Create a figure with specified resolution
    ax = Axis(fig[1, 1],
        title = "Correlation Matrix",
        xlabel = "Column Number",
        ylabel = "Column Number",
        aspect = 1,
        titlecolor = :white,  
        xlabelcolor = :white, 
        ylabelcolor = :white, 
        xticklabelcolor = :white, 
        yticklabelcolor = :white  
    )

    # Add the heatmap
    heatmap!(
        ax,
        correlation_matrix;
        colormap = :viridis,  
        colorrange = (-1, 1),  # Correlation values range from -1 to 1
    )

    # Add a colorbar
    Colorbar(fig[1, 2], limits = (-1, 1), colormap = :viridis, highclip = :cyan, lowclip = :red, label = "Correlation", labelcolor = :white, ticklabelcolor = :white)
    
    # Return figure ready to display
    return fig
    
end

fig = display_correlation(correlation_matrix)
display(fig)  # Display the figure

save_path = joinpath(@__DIR__, "../fig/Correlations.png")
save(save_path, fig)  # Save as PNG

### Outlier Handling

function remove_outliers_IQR(df::DataFrame)
    outlier_indices = Set{Int}()  # Set to store indices of rows to remove

    #Calculate IQR and bounds for each numeric column
    for col in names(df)
        if eltype(df[!, col]) <: Real  # Check if column is numeric
            Q1 = quantile(skipmissing(df[!, col]), 0.25)
            Q3 = quantile(skipmissing(df[!, col]), 0.75)
            IQR = Q3 - Q1
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR

            # Identify outlier indices for this column
            for (i, value) in enumerate(df[!, col])
                if !ismissing(value) && (value < lower_bound || value > upper_bound)
                    push!(outlier_indices, i)
                end
            end
        end
    end

    # Remove rows with indices in the outlier set
    cleaned_df = df[setdiff(1:nrow(df), collect(outlier_indices)), :]
    return cleaned_df
end

cleaned_data = remove_outliers_IQR(cleaned_numeric_data)

### Handling Missing Values

# Function to delete rows with null values for a specific column
function delete_null_by_row(df::DataFrame, col::String)
    if col in names(df)
        df = filter(row -> !ismissing(row[col]), df)
    else
        println("Column $col does not exist in the dataset.")
    end
    return df
end

column_to_clean = "T_degC" 

original_missing_vals = count(ismissing, cleaned_numeric_data[!, column_to_clean ])
println("Original missing values: $original_missing_vals")

cleaned_data = delete_null_by_row(cleaned_numeric_data, column_to_clean)

original_row_count = nrow(cleaned_numeric_data)
clean_row_count = nrow(cleaned_data)
println("Original rows: $original_row_count\nClean rows: $clean_row_count")

### Handling Irrelevant Data

function delete_columns_by_correlation(df::DataFrame, target_col::String, threshold::Float64)
    # Calculate correlations with the target column
    correlations = Dict{String, Float64}()
    for col in names(df)
        if col != target_col  # Skip the target column itself
            indices = findall(row -> !ismissing(row[target_col]) && !ismissing(row[col]), eachrow(df))
            if length(indices) > 1  # Ensure enough valid rows for correlation
                temp_df = df[indices, :]
                correlations[col] = cor(temp_df[:, target_col], temp_df[:,col])
            end
        end
    end

    # Filter columns based on correlation threshold
    high_corr_cols = filter(col -> abs(correlations[col]) ≥ threshold, keys(correlations))
    high_corr_cols = [target_col; high_corr_cols...]  # Include the target column in the result

    # Return the filtered DataFrame
    return select(df, high_corr_cols)

end

threshold = 0.5
col="T_degC"

filtered_df = delete_columns_by_correlation(cleaned_numeric_data, col, threshold)

### Describe Function

println(describe(calcofi_data))