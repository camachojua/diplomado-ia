{
 "cells": [
  {
   "cell_type": "markdown",
   "id": "c67e5977-ce21-472f-9731-d0ccb9924fd3",
   "metadata": {},
   "source": [
    "# Exploratory Data Analysis (EDA)"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "76ecbffc",
   "metadata": {},
   "source": [
    "En éste notebook presentamos un Análisis Exploratorio de Datos (EDA) del dataset `Calcofi` tomado de `Kaggle`:\n",
    "https://www.kaggle.com/datasets/sohier/calcofi\n",
    "\n",
    "\n",
    "Éste Dataset representa una serie temporal que comienza en el año 1949 y llega hasta el presente, donde en más de 50.000 estaciones de muestreo se recopilaron datos oceanográficos y larvarios de peces del mundo. \"Incluye datos de abundancia de larvas de más de 250 especies de peces; datos de frecuencia de longitud de larvas y datos de abundancia de huevos de especies comerciales clave; y datos oceanográficos y de plancton. Los datos físicos, químicos y biológicos recopilados a intervalos regulares de tiempo y espacio rápidamente se volvieron valiosos para documentar los ciclos climáticos en la Corriente de California y una variedad de respuestas biológicas a ellos\".\n",
    "\n",
    "Haremos la limpieza de los datos enfocándonos en generar un Dataframe apto para hacer una Regresión Lineal sobre la variable `T_degC`"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "9ae31787-0479-4108-97c0-090c137a2c24",
   "metadata": {},
   "source": [
    "## Paquetes"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "93a1d566",
   "metadata": {},
   "source": [
    "Comenzaremos cargando los paquetes necesarios para hacer nuestra exploración.\n",
    "\n",
    "Usaremos `CSV` para cargar el dataset, convertirlo en un dataframe y para escribir nuestro dataframe resultante en un archivo de éste mismo tipo.\n",
    "\n",
    "Usaremos `DataFrames` para manipular a nuestras tablas. `Statistics` para hacer cálculos estadísticos, como conversión de dataframes a matrices, correlaciones o el uso de la función `describe()` para sacar medias, medianas y rangos.\n",
    "\n",
    "Finalmente usaremos también `Plots` para poder visualizar los mapas de calor `heatmap` para que sea más visual la correlación entre las variables a tratar."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "d603b3eb-e9f6-43c4-8371-139d60d4979a",
   "metadata": {},
   "outputs": [],
   "source": [
    "# Comenzamos importando los datos:\n",
    "using Pkg\n",
    "Pkg.add(\"CSV\")\n",
    "Pkg.add(\"DataFrames\")\n",
    "Pkg.add(\"Statistics\")\n",
    "Pkg.add(\"Plots\")"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 4,
   "id": "d9dfbf94",
   "metadata": {},
   "outputs": [],
   "source": [
    "# Usamos todos los paquetes:\n",
    "using CSV, DataFrames, Statistics, Plots"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "b3a1deb6",
   "metadata": {},
   "source": [
    "Ahora definimos las Funciones en un sólo bloque."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "17f64567-adba-4a7a-a408-9325b26877e3",
   "metadata": {},
   "outputs": [],
   "source": [
    "# ----------------------------------------------------------- dataShape -------------------------------------------------------------------------\n",
    "\n",
    "# Ésta función se encarga de obtener la forma de los datos \n",
    "\n",
    "function dataShape(df::DataFrame)                   # La función recibe un Dataframe\n",
    "    n_fil, n_col = size(df)                         # Extraemos el numero de filas y el numero de columnas\n",
    "    forma = \"El DataFrame tiene $n_fil filas (observaciones) y $n_col columnas (predictores)\"   \n",
    "    return forma                                    # La función mostrará en un mensaje las dimensiones del Dataframe\n",
    "end\n",
    "\n",
    "# ----------------------------------------------------------- dataType -------------------------------------------------------------------------\n",
    "\n",
    "# Ésta función nos proporciona el tipo de datos de cada columna del conjunto de datos\n",
    "\n",
    "# Usaremos 'eltype' para obtener el tipo de dato. Y usaremos 'eachcol' para obtener cada columna\n",
    "\n",
    "function dataType(df ::DataFrame)               # La función recibe un dataframe\n",
    "    columnas = eachcol(df)                      # Seleccionamos una por una a las columnas\n",
    "    Tipos = eltype.(columnas)                   # Extraemos el tipo de dato de cada columna (Para eso se usa el punto antes de los paréntesis)\n",
    "    return Tipos                                # Regresamos los tipos de datos que contiene el dataframe\n",
    "end\n",
    "\n",
    "# ------------------------------------------------------- count_Missing ------------------------------------------------------------------------\n",
    "\n",
    "# Ésta función cuenta el número de datos faltantes en una columna determinada.\n",
    "\n",
    "function count_Missing(df::DataFrame, col::String)   # La función recibe un dataframe y el nombre de la columna como un String\n",
    "    sum = 0                                          # Inicializamos una suma en cero\n",
    "    for i in df[!, col]                              # Accedemos los elementos de la columna del dataframe en cada iteración\n",
    "        if ismissing(i)                              # Nos fijamos en los elementos que sean 'nulos'\n",
    "            sum += 1                                 # Sumamos 1 cada vez que hallemos un elemento nulo\n",
    "        end\n",
    "    end\n",
    "    return sum                                       # Regresamos la suma que es la cuenta de los datos faltantes\n",
    "end\n",
    "\n",
    "\n",
    "# --------------------------------------------------- dataMissingPercentage --------------------------------------------------------------------\n",
    "\n",
    "# Ésta función encuentra el porcentaje faltante de cada columna.\n",
    "# Haremos que la función muestre en un DataFrame el porcentaje de datos faltantes de cada columna\n",
    "\n",
    "function dataMissingPercentage(df::DataFrame)               # La función recibe un dataframe\n",
    "    n_fil = size(df)[1]                                     # Calculamos la cantidad de filas n_fil del dataframe \"df\"\n",
    "    porcentajes = []                                        # Creamos una lista vacía, aquí se guardarán los porcentajes calculados\n",
    "    for i in names(df)                                      # Accedemos a las columnas, una a la vez en cada iteración\n",
    "        porcentaje = (count_Missing(df, i) * 100) / n_fil   # Ésto nos da el porcentaje de datos faltantes\n",
    "        push!(porcentajes, porcentaje)                      # Agregamos el porcentaje calculado a la lista de porcentajes\n",
    "    end\n",
    "\n",
    "    col1 = names(df)                          # Pondremos en el nuevo Dataframe como primer columna los nombres de las columnas del df\n",
    "    col2 = porcentajes                        # La segunda columna contendrá el porcentaje de datos faltantes\n",
    "    tabla1 = DataFrame(\"Predictores\" => col1, \"PorcDataF\" => col2)\n",
    "    return tabla1\n",
    "end\n",
    "\n",
    "\n",
    "# ------------------------------------------------------ deleteColumns ------------------------------------------------------------------------\n",
    "\n",
    "# Ésta función elimina todas las columnas que tienen un porcentaje faltante mayor que el umbral dado.\n",
    "\n",
    "function deleteColumns(DF::DataFrame, threshold)        # La función recibe al umbral y un dataframe\n",
    "    df = dataMissingPercentage(DF)                      # Usaremos los datos del dataframe generado por la función \"dataMissingPercentage\"\n",
    "    n_fil = size(df)[1]                                 # Extraemos el número de filas n_fil\n",
    "    col_eliminar = []                                   # Creamos una lista vacía donde meteremos los nombres de columnas que se deban eliminar\n",
    "    for i in 1:n_fil                                    # Vamos a iterar tantas veces como filas tiene df\n",
    "        if df[i, \"PorcDataF\"] > threshold               # Establecemos la condición de hallar los porcentajes mayores al umbral \n",
    "            push!(col_eliminar, df[i, \"Predictores\"])   # Metemos el nombre de la columna del dataframe df a eliminar a la lista \n",
    "        end\n",
    "    end\n",
    "\n",
    "    # Ahora eliminamos las columnas del DataFrame DF\n",
    "    bottleF = select(DF, Not(col_eliminar))  # Creamos un dataframe que viene de DF quitando las columnas con porcentaje mayor al umbral\n",
    "    return bottleF   # La función devuelve un Dataframe donde eliminamos a las columnas con porcentaje de datos faltantes mayor al umbral\n",
    "end\n",
    "\n",
    "\n",
    "# ----------------------------------------------------------- deleteRow -----------------------------------------------------------------------\n",
    "\n",
    "# Ésta Función elimina todos los puntos de datos nulos para una columna dada\n",
    "\n",
    "function deleteRow(df::DataFrame, col::String)      # La función recibe un DataFrame y la columna que se revisará\n",
    "    col_symbol = Symbol(col)                        # Convertimos el nombre de la columna de String a Symbol para poder usar el método .!ismissing\n",
    "    DFFil = df[.!ismissing.(df[!, col_symbol]), :]  # Seleccionamos aquellas filas que NO tengan valores faltantes\n",
    "    return DFFil                                    # Retornamos el dataframe filtrado\n",
    "end\n",
    "\n",
    "\n",
    "# -------------------------------------------------------- calculateCorrelation ---------------------------------------------------------------\n",
    "\n",
    "# Ésta función crea una matriz de correlación entre columnas.\n",
    "\n",
    "function calculateCorrelation(df::DataFrame)      # La función recibe al dataframe\n",
    "    Matriz = Matrix(df)                           # Usamos la función Matrix() para convertir a nuestro dataframe en una matriz\n",
    "    matrizCor = cor(Matriz)                       # Creamos a la matriz que muestra la correlación entre las variables con la función cor()\n",
    "    return matrizCor                              # Retornamos la matriz de correlación\n",
    "end\n",
    "\n",
    "\n",
    "# ------------------------------------------------------ displayCorrelation -------------------------------------------------------------------\n",
    "\n",
    "# Ésta función muestra la correlación mediante el mapa de calor.\n",
    "\n",
    "function displayCorrelation(df::DataFrame)                # La función recibe un Dataframe\n",
    "    columnas = names(df)                                  # Obtenemos los nombres de las columnas\n",
    "    CorMatrix = calculateCorrelation(df)                  # Generamos la matriz de Correlación con la función \"calculateCorrelation\"\n",
    "    img = heatmap(CorMatrix,                              # Usaremos el heatmap de Plots en vez de Makie, usaremos nuestra matriz de correlaciones\n",
    "    title=\"Mapa de Calor de la Matriz de Correlación\",    # Le ponemos título\n",
    "    xticks=(1:length(columnas), columnas),                # Le ponemos el nombre de la columna a cada marca del ejer X \n",
    "    yticks=(1:length(columnas), columnas),                # Le ponemos el nombre de la columna a cada marca del ejer Y\n",
    "    xrotation=50,                                         # Rotamos las etiquetas para que no salgan amontonadas\n",
    "    size=(800, 700),                                      # Ajustamos el tamaño de la imagen para una mejor visualización\n",
    "    tickfont=8,                                           # Le damos un tamaño a la letra de las etiquetas de las columnas y filas\n",
    "    c=:viridis)                                           # Usamos una paleta de colores agradable =D\n",
    "\n",
    "    for i in 1:length(columnas)                           # Nos fijamos en cada recuadro del heatmap\n",
    "        for j in 1:length(columnas)                       # Escribimos el valor de la correlación en cada cuadro a 2 dígitos\n",
    "            annotate!(i, j, text(string(round(CorMatrix[i, j], digits=2)), :white, 6))    # Cada valor a tamaño 8 y color blanco\n",
    "        end\n",
    "    end\n",
    "    return img                                            # La función regresa la imagen del heatmap\n",
    "end\n",
    "\n",
    "\n",
    "# ----------------------------------------------------- removeOutliersIQR ------------------------------------------------------------------\n",
    "\n",
    "# Ésta función elimina todos los valores atípicos de las columnas numéricas utilizando el rango intercuartil.\n",
    "\n",
    "function removeOutliersIQR(df::DataFrame)       # La función recibe un Dataframe\n",
    "    for col in names(df)                        # Iteramos sbre las columnas del DataFrame\n",
    "        if eltype(df[!, col]) <: Number         # Seleccionamos sólo columnas numéricas\n",
    "            Q1 = quantile(df[!, col], 0.25)     # Calculamos el primer cuartil \n",
    "            Q3 = quantile(df[!, col], 0.75)     # Calculamos el tercer cuartil (Q3)\n",
    "            IQR = Q3 - Q1                       # Obtenemos el Rango Intercuartílico\n",
    "            lim_inf = Q1 - 1.5 * IQR            # Límite inferior\n",
    "            lim_sup = Q3 + 1.5 * IQR            # Límite superior\n",
    "            df = filter(row -> !(row[col] < lim_inf || row[col] > lim_sup), df)  # Seleccionamos aquellos datos que están dentro de los límites\n",
    "        end\n",
    "    end\n",
    "    return df                                   # Regresamos un detaframe sin outliers\n",
    "end\n",
    "\n",
    "\n",
    "# ------------------------------------------------------ filterColumnsByCorrelation -----------------------------------------------------------\n",
    "\n",
    "# Ésta función elimina todas las columnas en función del umbral dado para una columna target y una relación.\n",
    "\n",
    "# La fución recibe al target Y, un umbral, una relación, un dataframe y un booleano \n",
    "#que determinará si usaremos el umbral con valor absoluto  (\"true\") o sin valor absoluto (\"false\")\n",
    "# La relación tendrá que ser un string: \"mayor\" o \"menor\"\n",
    "function filterColumnsByCorrelation(df::DataFrame, target::String, threshold::Float64, relation::String, absolute::Bool=true)\n",
    "    df1 = select(df, Not([target]))                                            # Creamos un DataFrame sin el target\n",
    "    columnasdf = names(df1)                                                    # Obtenemos las columnas del DataFrame\n",
    "    y = df[!, target]                                                          # Seleccionamos los valores del target\n",
    "    columnas_eliminar = []                                                     # Creamos una lista de columnas a eliminar\n",
    "\n",
    "    for i in columnasdf                                                        # Iteramos sobre cada columna\n",
    "        x = df[!, i]                                                           # Seleccionamos los valores de la columna actual\n",
    "        corxy = cor(x, y)                                                      # Calculamos la correlación entre la columna y el target\n",
    "\n",
    "        if absolute                                                            #Si nos fijamos en el valor absoluto del umbral\n",
    "            # Comparar usando valor absoluto\n",
    "            if (relation == \"mayor\" && abs(corxy) >= threshold) || (relation == \"menor\" && abs(corxy) <= threshold)\n",
    "                push!(columnas_eliminar, i)            # Agregamos la columna a la lista a eliminar dependiendo de la relación \"\"mayor o \"menor\"                    \n",
    "            end\n",
    "        else                                           # En caso de que no querramos fijarnos en el valor absoluto\n",
    "            # Comparar sin valor absoluto\n",
    "            if (relation == \"mayor\" && corxy >= threshold) || (relation == \"menor\" && corxy <= threshold)\n",
    "                push!(columnas_eliminar, i)            # Agregamos la columna a la lista a eliminar dependiendo de la relación \"\"mayor o \"menor\"\n",
    "            end\n",
    "        end\n",
    "    end\n",
    "\n",
    "    # Crear un DataFrame sin las columnas eliminadas\n",
    "    df_resultante = select(df, Not(columnas_eliminar))\n",
    "    return df_resultante\n",
    "end"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "e8fa0ad5-e990-4f0d-bb4b-668bebf3cfe8",
   "metadata": {},
   "source": [
    "## Limpieza de Datos"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "07033e8a",
   "metadata": {},
   "source": [
    "Comenzamos cargando el archivo CSV que contiene al Dataset de Calcofi llamado \"bottle.csv\" y lo guardaremos en una variable llamada `bottle`"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "885461a6-babd-426b-b01f-397aae69a2e7",
   "metadata": {},
   "outputs": [],
   "source": [
    "# Leemos el archivo y lo guardamos en un Dataframe\n",
    "bottle =  CSV.read(\"bottle.csv\", DataFrame)\n",
    "\n",
    "bottle"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "0a5510de",
   "metadata": {},
   "source": [
    "Haremos una copia del Dataframe para no alterar al original"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "23140cce-42c3-4efa-93d4-f824205180cf",
   "metadata": {},
   "outputs": [],
   "source": [
    "df = copy(bottle)  # Copiamos el dataframe para no alterar el original"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "c93cfc2c",
   "metadata": {},
   "source": [
    "Veamos las dimensiones del Dataframe"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "ecfd710c",
   "metadata": {},
   "outputs": [],
   "source": [
    "dataShape(df)"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "1c35ffce",
   "metadata": {},
   "source": [
    "Vamos a ver una tabla con el porcentaje de datos faltantes de cada variable"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "a0241573-272c-464e-9711-fa1a42ce6f57",
   "metadata": {},
   "outputs": [],
   "source": [
    "df1 = dataMissingPercentage(df)"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "6477f036",
   "metadata": {},
   "source": [
    "Se ha decidido no admitir variables que contengan más del $10\\%$ de datos faltantes, por lo cuál eliminaremos éstas variables"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "e90c50d4-69d7-471a-928b-edf3e6418f8d",
   "metadata": {},
   "outputs": [],
   "source": [
    "# Eliminamos las columnas con un porcentaje mayor al 10%\n",
    "df2 = deleteColumns(df, 10)"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "2b5948f3",
   "metadata": {},
   "source": [
    "Vamos a eliminar a TODAS las filas que contengan datos faltantes de las variables que sobreviven y así poder generar nuestras matrices de correlación, de otro modo ésto no sería del todo posible."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "4b9158c4-0c6f-4e6d-bfb6-d77cdf1bb6eb",
   "metadata": {
    "scrolled": true
   },
   "outputs": [],
   "source": [
    "# Vamos a crear una función para eliminar TODAS las filas que contengan al menos un dato faltante:\n",
    "\n",
    "# Ésta función se creó para evitar confudiones en Julia con el Scope\n",
    "function deleteFilas(df::DataFrame)\n",
    "    columnas = names(df)           # Seleccionamos Todas las columnas del DataFrame\n",
    "    df_DelRowsM = copy(df)         # Copiamos a df\n",
    "\n",
    "    for col in columnas                                # Iteramos sobre todas las columnas del dataframe df2\n",
    "        df_DelRowsM = deleteRow(df_DelRowsM, col)      # Aplicamos la fución para eliminar todas las filas con datos faltantes\n",
    "    end\n",
    "    return df_DelRowsM\n",
    "end\n",
    "\n",
    "df_DelRowsM = deleteFilas(df2)"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "afdfee6f",
   "metadata": {},
   "source": [
    "## CORRELACIONES"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "165a09b3",
   "metadata": {},
   "source": [
    "Visualicemos la correlación entre todas las variables, para ésto es necesario NO incluir a las variables que No sea numéricas."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "f329a72c",
   "metadata": {},
   "outputs": [],
   "source": [
    "# Veamos las correlaciones entre las variables numéricas\n",
    "df_numerico = select!(copy(df_DelRowsM), Not([:Sta_ID, :Depth_ID]))  # Aquí creamos un datframe que contenga puras variables categóricas\n",
    "\n",
    "displayCorrelation(df_numerico)"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "19b54eb4",
   "metadata": {},
   "source": [
    "Queremos hacer una regresión lineal para la vaiable `T_degC`, para ésto, necesitamos predictores que estén correlacionadas con nuestro target, vamos a eliminar a las variables que estén muy poco correlacionadas con nuestro target y también aquellas que estén altamente correlacionadas puesto que ésto puede generarnos un subajuste o un sobreajuste correspondientemente. Decidimos un umbral de correlación menor al valor absoluto de 0.2 y mayor al valor positivo 0.8, dado que las características negativamente correlacionadas pueden proporcionar información complementaria que es valiosa para encontrar patrones y mejorar la generalización del modelo."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "01c525bc",
   "metadata": {},
   "outputs": [],
   "source": [
    "df_umbral_menor = filterColumnsByCorrelation(df_numerico, \"T_degC\", 0.2, \"menor\")             # Eliminamos correlaciones < 0.2 (absoluto)\n",
    "df_umbral_mayor = filterColumnsByCorrelation(df_umbral_menor, \"T_degC\", 0.8, \"mayor\", false)  # Eliminamos correlaciones > 0.8 (sin absoluto)"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "7b8b9bb5",
   "metadata": {},
   "source": [
    "Veamos ahora las correlaciones entre las variables sobrevivientes"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "b3930fa7",
   "metadata": {},
   "outputs": [],
   "source": [
    "displayCorrelation(df_umbral_mayor)"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "a8c55c7f",
   "metadata": {},
   "source": [
    "Observemos lo siguiente:\n",
    "\n",
    "•   Las variables `R_Depth`, `R_DYNHT` y `R_PRES` tienen alta correlación con `Depthm`.<br>\n",
    "•   La variable `R_SALINITY` está muy correlacionada con `Salnty`<br>\n",
    "•   La variable `STheta` está muy correlacionada con `R_SIGMA`<br>\n",
    "\n",
    "Ésto puede generar redundancia en el modelo, por lo que da lo mismo quedarnos con cualquiera de las variables que están correlacionadas entre sí y eliminar las demás\n",
    "\n",
    "Así, nos quedaremos con las variables `Depthm`, `Salnty` y `STheta`, las demás las eliminaremos."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "2540a431",
   "metadata": {},
   "outputs": [],
   "source": [
    "DF = select(df_umbral_mayor, Not([:R_Depth, :R_DYNHT, :R_PRES, :R_SALINITY, :R_SIGMA]))    # Eliminamos variables redundantes\n",
    "DF"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "a7c46bbc",
   "metadata": {},
   "source": [
    "## INTEGER - ENCODING"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "d6eabd23",
   "metadata": {},
   "source": [
    "Una vez filtrado el dataframe, le volvemos a colocar las variables categóricas, pero notemos que `Depth_ID` tiene casi el mismo numero de datos diferentes que el total de filas, por tanto no sirve como una variable predictora por lo que la eliminaremos y haremos Integer-Encoding a la variable \"Sta_ID\", ya que se intentó hacer un One-Hot-Encoding pero debido a que las categorías eran demasiadas (2560) se requería más poder de cómputo y se volvió imposible generarlo.\n",
    "\n",
    "Ésto se puede corroborar haciendo:\n",
    "\n",
    "````julia\n",
    "    println(length(unique(df_DelRowsM[!, \"Sta_ID\"])))\n",
    "    println(length(unique(df_DelRowsM[!, \"Depth_ID\"])))\n",
    "````"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "cb309ce6",
   "metadata": {},
   "outputs": [],
   "source": [
    "println(dataShape(df_DelRowsM))\n",
    "println(length(unique(df_DelRowsM[!, \"Sta_ID\"])))\n",
    "println(length(unique(df_DelRowsM[!, \"Depth_ID\"])))"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "ebfd0233",
   "metadata": {},
   "source": [
    "Vamos a agregar la variable `Sta_ID` de nuevo a nuestro dataframe"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "00eb84d2",
   "metadata": {},
   "outputs": [],
   "source": [
    "# Volvemos a pegar la columna Sta_ID al dataframe DF\n",
    "columna_vieja = df_DelRowsM[:, :Sta_ID]                         #Extraemos la columna del último dataframe que manejamos con ésta variable\n",
    "DF[!, :Sta_ID] = columna_vieja                                  # La pegamos en el dataframe filtrado\n",
    "DF"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "90a2a862",
   "metadata": {},
   "source": [
    "Ahora hacemos un Integer-Encoding"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "f3ac4aac",
   "metadata": {},
   "outputs": [],
   "source": [
    "# Extraemos las categorías únicas y asignamos índices enteros\n",
    "categorias = unique(DF[!, \"Sta_ID\"])  # Extraemos las categorías\n",
    "category_to_index = Dict(categoria => idx for (idx, categoria) in enumerate(categorias))\n",
    "\n",
    "# Convertimos las categorías en índices correspondientes\n",
    "indices = [category_to_index[cat] for cat in DF[!, \"Sta_ID\"]]\n",
    "\n",
    "# Creamos un DataFrame con los índices\n",
    "integer_encoded_df = DataFrame(Sta_ID_Encoded = indices)\n",
    "\n",
    "# Renombramos la columna resultante y ajustamos el DataFrame\n",
    "# Concatenamos las columnas codificadas al DataFrame original\n",
    "df_encoded = hcat(DF, integer_encoded_df)\n",
    "\n",
    "# Eliminamos la columna categórica original\n",
    "select!(df_encoded, Not(:Sta_ID))\n",
    "\n",
    "df_encoded  # Retornamos el DataFrame final"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "ed430d0f",
   "metadata": {},
   "source": [
    "Visualicemos ahora las correlaciones"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "3beb8530-acd6-4258-87df-64205bcdc100",
   "metadata": {},
   "outputs": [],
   "source": [
    "#Vamos a ver la correlación entre las variables:\n",
    "displayCorrelation(df_encoded)"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "440c20f0",
   "metadata": {},
   "source": [
    "## OUTLIERS"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "e98ef80d",
   "metadata": {},
   "source": [
    "Recordemos que el rango intercuartil (IQR) es una medida estadística que describe la dispersión de un conjunto de datos dividiéndolo en cuartiles. \n",
    "\n",
    "Para obtenerlo, primero calculamos los cuartiles:\n",
    "\n",
    "$Q_1$: primer cuartil (25\\% de los datos). <br>\n",
    "$Q_3$: tercer cuartil (75\\% de los datos). <br>\n",
    "Y determinamos el rango IQR:\n",
    "$$\n",
    "\\text{IQR} = Q_3 - Q_1\n",
    "$$\n",
    "\n",
    "Un valor se considera atípico si se encuentra fuera del rango definido por:\n",
    "$$\n",
    "\\left[ Q_1 - 1.5 \\times \\text{IQR}, \\, Q_3 + 1.5 \\times \\text{IQR} \\right]\n",
    "$$\n",
    "\n",
    "•   Valores menores a $Q_1 - 1.5 \\times \\text{IQR}$ son atípicos por debajo.<br>\n",
    "•   Valores mayores a $Q_3 + 1.5 \\times \\text{IQR}$ son atípicos por encima."
   ]
  },
  {
   "cell_type": "markdown",
   "id": "30d8005e",
   "metadata": {},
   "source": [
    "Eliminamos valores atípicos (outliers) mediante el rango intercualntil"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "0a52cb94",
   "metadata": {},
   "outputs": [],
   "source": [
    "Bottle = removeOutliersIQR(df_encoded)\n",
    "Bottle"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "90258750",
   "metadata": {},
   "source": [
    "Ahora veremos una descripción del Dataframe resultante"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "7c8bdd1f",
   "metadata": {},
   "outputs": [],
   "source": [
    "describe(Bottle)"
   ]
  },
  {
   "cell_type": "markdown",
   "id": "e8fd9996",
   "metadata": {},
   "source": [
    "Hemos conseguido limpiar los datos de éste Dataset, ahora con ésto podemos hacer una Regresión lineal sobre la variable `T_degC`.\n",
    "\n",
    "Para ésto, finalmente guardaremos el Dataframe `Bottle` en un archivo `CSV` para poder usarlo en la regresión lineal "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "d22a0dee",
   "metadata": {},
   "outputs": [],
   "source": [
    "CSV.write(\"bottle_EDA.csv\", Bottle)"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Julia 1.11.1",
   "language": "julia",
   "name": "julia-1.11"
  },
  "language_info": {
   "file_extension": ".jl",
   "mimetype": "application/julia",
   "name": "julia",
   "version": "1.11.1"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
