# ----------------------------------------------------------- PAQUETES ------------------------------------------------------------------------

# Comenzamos añadiendo los paquetes a utilizar
using Pkg

#Pkg.add("CSV")                                    # Para leer y guardar DataFrames en archivos tipo CSV
#Pkg.add("DataFrames")                             # Para manipular los Dataframes
#Pkg.add("Statistics")                             # Para hacer uso de funciones y métodos relacionados con estadísticas
#Pkg.add("Plots")                                  # Para poder generar los mapas de calor (heatmap)

# Usamos todos los paquetes
using CSV, DataFrames, Statistics, Plots

# ----------------------------------------------------------- FUNCIONES ------------------------------------------------------------------------

# Creamos las funciones necesarias para hacer la limpieza y visualización de los datos

# ----------------------------------------------------------- dataShape -------------------------------------------------------------------------

# Ésta función se encarga de obtener la forma de los datos 

function dataShape(df::DataFrame)                   # La función recibe un Dataframe
    n_fil, n_col = size(df)                         # Extraemos el numero de filas y el numero de columnas
    forma = "El DataFrame tiene $n_fil filas (observaciones) y $n_col columnas (predictores)"   
    return forma                                    # La función mostrará en un mensaje las dimensiones del Dataframe
end

# ----------------------------------------------------------- dataType -------------------------------------------------------------------------

# Ésta función nos proporciona el tipo de datos de cada columna del conjunto de datos

# Usaremos 'eltype' para obtener el tipo de dato. Y usaremos 'eachcol' para obtener cada columna

function dataType(df ::DataFrame)               # La función recibe un dataframe
    columnas = eachcol(df)                      # Seleccionamos una por una a las columnas
    Tipos = eltype.(columnas)                   # Extraemos el tipo de dato de cada columna (Para eso se usa el punto antes de los paréntesis)
    return Tipos                                # Regresamos los tipos de datos que contiene el dataframe
end

# ------------------------------------------------------- count_Missing ------------------------------------------------------------------------

# Ésta función cuenta el número de datos faltantes en una columna determinada.

function count_Missing(df::DataFrame, col::String)   # La función recibe un dataframe y el nombre de la columna como un String
    sum = 0                                          # Inicializamos una suma en cero
    for i in df[!, col]                              # Accedemos los elementos de la columna del dataframe en cada iteración
        if ismissing(i)                              # Nos fijamos en los elementos que sean 'nulos'
            sum += 1                                 # Sumamos 1 cada vez que hallemos un elemento nulo
        end
    end
    return sum                                       # Regresamos la suma que es la cuenta de los datos faltantes
end


# --------------------------------------------------- dataMissingPercentage --------------------------------------------------------------------

# Ésta función encuentra el porcentaje faltante de cada columna.
# Haremos que la función muestre en un DataFrame el porcentaje de datos faltantes de cada columna

function dataMissingPercentage(df::DataFrame)               # La función recibe un dataframe
    n_fil = size(df)[1]                                     # Calculamos la cantidad de filas n_fil del dataframe "df"
    porcentajes = []                                        # Creamos una lista vacía, aquí se guardarán los porcentajes calculados
    for i in names(df)                                      # Accedemos a las columnas, una a la vez en cada iteración
        porcentaje = (count_Missing(df, i) * 100) / n_fil   # Ésto nos da el porcentaje de datos faltantes
        push!(porcentajes, porcentaje)                      # Agregamos el porcentaje calculado a la lista de porcentajes
    end

    col1 = names(df)                          # Pondremos en el nuevo Dataframe como primer columna los nombres de las columnas del df
    col2 = porcentajes                        # La segunda columna contendrá el porcentaje de datos faltantes
    tabla1 = DataFrame("Predictores" => col1, "PorcDataF" => col2)
    return tabla1
end


# ------------------------------------------------------ deleteColumns ------------------------------------------------------------------------

# Ésta función elimina todas las columnas que tienen un porcentaje faltante mayor que el umbral dado.

function deleteColumns(DF::DataFrame, threshold)        # La función recibe al umbral y un dataframe
    df = dataMissingPercentage(DF)                      # Usaremos los datos del dataframe generado por la función "dataMissingPercentage"
    n_fil = size(df)[1]                                 # Extraemos el número de filas n_fil
    col_eliminar = []                                   # Creamos una lista vacía donde meteremos los nombres de columnas que se deban eliminar
    for i in 1:n_fil                                    # Vamos a iterar tantas veces como filas tiene df
        if df[i, "PorcDataF"] > threshold               # Establecemos la condición de hallar los porcentajes mayores al umbral 
            push!(col_eliminar, df[i, "Predictores"])   # Metemos el nombre de la columna del dataframe df a eliminar a la lista 
        end
    end

    # Ahora eliminamos las columnas del DataFrame DF
    bottleF = select(DF, Not(col_eliminar))  # Creamos un dataframe que viene de DF quitando las columnas con porcentaje mayor al umbral
    return bottleF   # La función devuelve un Dataframe donde eliminamos a las columnas con porcentaje de datos faltantes mayor al umbral
end


# ----------------------------------------------------------- deleteRow -----------------------------------------------------------------------

# Ésta Función elimina todos los puntos de datos nulos para una columna dada

function deleteRow(df::DataFrame, col::String)      # La función recibe un DataFrame y la columna que se revisará
    col_symbol = Symbol(col)                        # Convertimos el nombre de la columna de String a Symbol para poder usar el método .!ismissing
    DFFil = df[.!ismissing.(df[!, col_symbol]), :]  # Seleccionamos aquellas filas que NO tengan valores faltantes
    return DFFil                                    # Retornamos el dataframe filtrado
end


# -------------------------------------------------------- calculateCorrelation ---------------------------------------------------------------

# Ésta función crea una matriz de correlación entre columnas.

function calculateCorrelation(df::DataFrame)      # La función recibe al dataframe
    Matriz = Matrix(df)                           # Usamos la función Matrix() para convertir a nuestro dataframe en una matriz
    matrizCor = cor(Matriz)                       # Creamos a la matriz que muestra la correlación entre las variables con la función cor()
    return matrizCor                              # Retornamos la matriz de correlación
end


# ------------------------------------------------------ displayCorrelation -------------------------------------------------------------------

# Ésta función muestra la correlación mediante el mapa de calor.

function displayCorrelation(df::DataFrame)                # La función recibe un Dataframe
    columnas = names(df)                                  # Obtenemos los nombres de las columnas
    CorMatrix = calculateCorrelation(df)                  # Generamos la matriz de Correlación con la función "calculateCorrelation"
    img = heatmap(CorMatrix,                              # Usaremos el heatmap de Plots en vez de Makie, usaremos nuestra matriz de correlaciones
    title="Mapa de Calor de la Matriz de Correlación",    # Le ponemos título
    xticks=(1:length(columnas), columnas),                # Le ponemos el nombre de la columna a cada marca del ejer X 
    yticks=(1:length(columnas), columnas),                # Le ponemos el nombre de la columna a cada marca del ejer Y
    xrotation=50,                                         # Rotamos las etiquetas para que no salgan amontonadas
    size=(800, 700),                                      # Ajustamos el tamaño de la imagen para una mejor visualización
    tickfont=8,                                           # Le damos un tamaño a la letra de las etiquetas de las columnas y filas
    c=:viridis)                                           # Usamos una paleta de colores agradable =D

    for i in 1:length(columnas)                           # Nos fijamos en cada recuadro del heatmap
        for j in 1:length(columnas)                       # Escribimos el valor de la correlación en cada cuadro a 2 dígitos
            annotate!(i, j, text(string(round(CorMatrix[i, j], digits=2)), :white, 6))    # Cada valor a tamaño 8 y color blanco
        end
    end
    return img                                            # La función regresa la imagen del heatmap
end


# ----------------------------------------------------- removeOutliersIQR ------------------------------------------------------------------

# Ésta función elimina todos los valores atípicos de las columnas numéricas utilizando el rango intercuartil.

function removeOutliersIQR(df::DataFrame)       # La función recibe un Dataframe
    for col in names(df)                        # Iteramos sbre las columnas del DataFrame
        if eltype(df[!, col]) <: Number         # Seleccionamos sólo columnas numéricas
            Q1 = quantile(df[!, col], 0.25)     # Calculamos el primer cuartil 
            Q3 = quantile(df[!, col], 0.75)     # Calculamos el tercer cuartil (Q3)
            IQR = Q3 - Q1                       # Obtenemos el Rango Intercuartílico
            lim_inf = Q1 - 1.5 * IQR            # Límite inferior
            lim_sup = Q3 + 1.5 * IQR            # Límite superior
            df = filter(row -> !(row[col] < lim_inf || row[col] > lim_sup), df)  # Seleccionamos aquellos datos que están dentro de los límites
        end
    end
    return df                                   # Regresamos un detaframe sin outliers
end


# ------------------------------------------------------ filterColumnsByCorrelation -----------------------------------------------------------

# Ésta función elimina todas las columnas en función del umbral dado para una columna target y una relación.

# La fución recibe al target Y, un umbral, una relación, un dataframe y un booleano 
#que determinará si usaremos el umbral con valor absoluto  ("true") o sin valor absoluto ("false")
# La relación tendrá que ser un string: "mayor" o "menor"
function filterColumnsByCorrelation(df::DataFrame, target::String, threshold::Float64, relation::String, absolute::Bool=true)
    df1 = select(df, Not([target]))                                            # Creamos un DataFrame sin el target
    columnasdf = names(df1)                                                    # Obtenemos las columnas del DataFrame
    y = df[!, target]                                                          # Seleccionamos los valores del target
    columnas_eliminar = []                                                     # Creamos una lista de columnas a eliminar

    for i in columnasdf                                                        # Iteramos sobre cada columna
        x = df[!, i]                                                           # Seleccionamos los valores de la columna actual
        corxy = cor(x, y)                                                      # Calculamos la correlación entre la columna y el target

        if absolute                                                            #Si nos fijamos en el valor absoluto del umbral
            # Comparar usando valor absoluto
            if (relation == "mayor" && abs(corxy) >= threshold) || (relation == "menor" && abs(corxy) <= threshold)
                push!(columnas_eliminar, i)            # Agregamos la columna a la lista a eliminar dependiendo de la relación ""mayor o "menor"                    
            end
        else                                           # En caso de que no querramos fijarnos en el valor absoluto
            # Comparar sin valor absoluto
            if (relation == "mayor" && corxy >= threshold) || (relation == "menor" && corxy <= threshold)
                push!(columnas_eliminar, i)            # Agregamos la columna a la lista a eliminar dependiendo de la relación ""mayor o "menor"
            end
        end
    end

    # Crear un DataFrame sin las columnas eliminadas
    df_resultante = select(df, Not(columnas_eliminar))
    return df_resultante
end


# ------------------------------------------- ANÁLISIS EXPLORATORIO DE DATOS (EDA) -------------------------------------------------------------

# --------------------------------------------------- Cargar el Dataset ------------------------------------------------------------------------

# Leemos el archivo y lo guardamos en un Dataframe
bottle =  CSV.read("bottle.csv", DataFrame)

df = copy(bottle)                                  # Copiamos el dataframe para no alterar el original

# -------------------------------------------------------- Ver dimensiones ---------------------------------------------------------------------

# Vemos sus dimensiones:
dataShape(df)

# ----------------------------------------------- Ver Porcentaje de Datos Faltantes ------------------------------------------------------------

# Vemos el porcentaje de datos faltantes de cada columna:
df1 = dataMissingPercentage(df)

# ------------------------------------------ Determinamos un umbral y eliminamos faltantes ------------------------------------------------------

# Eliminamos las columnas con un porcentaje mayor al 10%
df2 = deleteColumns(df, 10)

# Vamos a crear una función para eliminar TODAS las filas que contengan al menos un dato faltante:

# Ésta función se creó para evitar confudiones en Julia con el Scope
function deleteFilas(df::DataFrame)
    columnas = names(df)           # Seleccionamos Todas las columnas del DataFrame
    df_DelRowsM = copy(df)         # Copiamos a df

    for col in columnas                                # Iteramos sobre todas las columnas del dataframe df2
        df_DelRowsM = deleteRow(df_DelRowsM, col)      # Aplicamos la fución para eliminar todas las filas con datos faltantes
    end
    return df_DelRowsM
end

df_DelRowsM = deleteFilas(df2)

# ----------------------------------------- Visualizar Correlaciones y eliminar variables ------------------------------------------------------

# Vamos a ver las correlaciones entre las variables numéricas
# Se va a copiar el dataframe "df_DelRowsM" para no alterar el original ya que lo usaremos más adelante
df_numerico = select!(copy(df_DelRowsM), Not([:Sta_ID, :Depth_ID]))  # Aquí creamos un datframe que contenga puras variables categóricas

#displayCorrelation(df_numerico)                                     # Mostramos el heatmap DESCOMENTAR SI QUIERE VER EL MAPA DE CALOR

# Determinamos un umbral para el target:
df_umbral_menor = filterColumnsByCorrelation(df_numerico, "T_degC", 0.1, "menor")             # Eliminamos correlaciones < 0.1 (absoluto)
df_umbral_mayor = filterColumnsByCorrelation(df_umbral_menor, "T_degC", 0.8, "mayor", false)  # Eliminamos correlaciones > 0.8 (sin absoluto)

# Mostramos la correlación de las vatriables que sobreviven:
#displayCorrelation(df_umbral_mayor)                                  # Mostramos el heatmap DESCOMENTAR SI QUIERE VER EL MAPA DE CALOR


# Eliminamos las variables que se correlacionan entre sí para evitar multicolinealidad:
DF = select(df_umbral_mayor, Not([:R_Depth, :R_DYNHT, :R_PRES, :R_SALINITY, :R_SIGMA]))
DF
# -------------------------------------------------- INTEGER ENCODING PARA "Sta_ID" ------------------------------------------------------------

# Volvemos a pegar la columna Sta_ID al dataframe DF:
columna_vieja = df_DelRowsM[:, :Sta_ID]                         # Extraemos la columna del último dataframe que manejamos con ésta variable
DF[!, :Sta_ID] = columna_vieja                                  # La pegamos en el dataframe filtrado

# Extraemos las categorías únicas y asignamos índices enteros:
categorias = unique(DF[!, "Sta_ID"])                                                      # Extraemos las categorías

# A cada categoría se le asigna un entero y lo guardamos en un diccionario:
categoriaIndice = Dict(categoria => idx for (idx, categoria) in enumerate(categorias))  

# Convertimos las categorías en índices correspondientes
indices = [categoriaIndice[cat] for cat in DF[!, "Sta_ID"]]

# Creamos un DataFrame con los índices
encode_df_enteros = DataFrame(Sta_ID_Encoded = indices)

# Renombramos la columna resultante y ajustamos el DataFrame
# Concatenamos las columnas codificadas al DataFrame original
df_encoded = hcat(DF, encode_df_enteros)

# Eliminamos la columna categórica original
select!(df_encoded, Not(:Sta_ID))

#Vemos correlación entre las variables:
#displayCorrelation(df_encoded)                                 #DESCOMENTAR PARA VISUALIZAR EL HEATMAP


# ------------------------------------------ Creamos el Dataframe para la Regresión Lineal -----------------------------------------------------

Bottle = removeOutliersIQR(df_encoded)       # Eliminamos valores atípicos (Outliers)

describe(Bottle)                             # Vemos una descripción de las variables asociadas al target

CSV.write("bottle_EDA.csv", Bottle)          # Guardamos el Dataframe en un archivo CSV