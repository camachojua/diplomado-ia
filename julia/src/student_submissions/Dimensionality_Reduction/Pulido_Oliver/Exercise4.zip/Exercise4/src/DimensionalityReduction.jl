# -------------------------------------------------------------- PAQUETES ---------------------------------------------------------------------

#import Pkg
using Pkg

#Pkg.add("LinearAlgebra")
#Pkg.add("Images")
#Pkg.add("ImageIO")
#Pkg.add("Plots")
#Pkg.add("DataFrames")
#Pkg.update()

using LinearAlgebra
using Images
using ImageIO
using Plots
using DataFrames


# -------------------------------------------------------------- FUNCIONES ---------------------------------------------------------------------

function LoadImg(img::String)                             # La función recibe el nombre de la imagen

    imagen = load(img)                                    # Cargamos la imagen
    grises = Gray.(imagen)                                # Convertimos la imagen a escala de grises
    imagen_gris = float.(grises)                          # Extraemos los pixeles de la imagen y los escalamos a grises


    #Nos encargaremos del nombre de la imagen gris para gardarla:
    
    numeracion = img[4]                                   # Extraemos el número del nombre de la imagen
    nombre = "img" * string(numeracion) * "_Gris.jpg"     # Le damos el nombre que concuerda con la numeración de las originales

    save(nombre, imagen_gris)                             # Guardamos la imagen Gris

    return imagen_gris                                    # Devolvemos una matriz con sus pixeles grises

end



function FindSVD(M::Matrix)          # Le damos una matriz a la función
    F = svd(M)                       # Calcula la descomposición SVD de la matriz
    return F
end



function FindApproxImg(F::SVD, numeracion::String)      # La función recibe la descomposición SVD de una matriz y la numeración correspondiente a la imagen

    # Para k = 5
    k = 5
    M = F.U[:, 1:k] * Diagonal(F.S[1:k]) * F.V[:, 1:k]'
    M = abs.(M .* 0.99)

    # Nos encargamos del formato del nombre de la imagen para guardarla:
    nombre = "img" * numeracion * "RD5.jpg"             # Le damos el nombre que concuerda con la numeración de las originales

    save(nombre, M)

    # Para k = 25
    k = 25
    M = F.U[:, 1:k] * Diagonal(F.S[1:k]) * F.V[:, 1:k]'
    M = abs.(M .* 0.99)

    # Nos encargamos del formato del nombre de la imagen:
    nombre = "img" * numeracion * "RD25.jpg"             # Le damos el nombre que concuerda con la numeración de las originales

    save(nombre, M)


    # Para k = 125
    k = 125
    M = F.U[:, 1:k] * Diagonal(F.S[1:k]) * F.V[:, 1:k]'
    M = abs.(M .* 0.99)

    # Nos encargamos del formato del nombre de la imagen:
    nombre = "img" * numeracion * "RD125.jpg"            # Le damos el nombre que concuerda con la numeración de las originales

    save(nombre, M)
end



function FindNormalizedSum(v::Vector{Float32})   # La función recibe un vector 
    n = length(v)                                # Obtenemos la longitud del vector v
    svx = 0.0                                    # Inicializamos una variable svx en 0
    sv = Vector{Float32}(undef, n)               # Reservamos memoria para un vector sv de tamaño n 

    for i=1:n
        svx += v[i]                              # Aquí sumamos cada elemento de v a svx
    end

    svx = svx/n                                  # Calculamos el promedio de los valores en v
    sum = 0.0                                    # Inicializamos la suma en 0

    for i=1:n
        sv[i] = v[i] / (svx*n)                   # Aquí normalizamos cada elemento de v y se lo asignamos a sv
        sum += sv[i]                             # Sumamos cada elemento normalizado a sum
    end

    return sum, sv                      # Devolver la suma de los elementos normalizados y el vector normalizado
end



function PlotNormalizedSum(S::Vector, k::Integer)
    sum, normSum = FindNormalizedSum(S)            # Encontramos la suma normalizada y el vector normalizado
    n = length(normSum)                            # Obtenemos la longitud del vector normalizado

    if k != 0
        n = k                                      # Si k no es 0, usamos k como la longitud para graficar
    end

    y = Vector{Float32}(undef, n)                  # Reservamos memoria para un vector y de longitud n
    x = Vector{Float32}(undef, n)                  # Reservamos memoria para un vector x de longitud n

    for i=1:n
        y[i] = i                                   # Asignamos los valores 1, 2, ..., n al vector y
        x[i] = 1.0 - normSum[i]                    # Asignamos 1 - normSum[i] al vector x
    end

    p = plot(y,x)                                  # Graficamos y en función de x
    return p                                       #Devolvemos la gráfica
end

# -------------------------------------------------------------- PCA --------------------------------------------------------------------------

# ------------------------------------------------ Hacemos Reducción de Dimensiones -----------------------------------------------------------

imagen_en_gris = LoadImg("img0.jpg")                # Cargamos la imagen y extraemos su forma escalada en grises
F = FindSVD(imagen_en_gris)                         # Extraemos su descomposición SVD
FindApproxImg(F, "0")

# -------------------------------------------------------- Vemos Tamaños ----------------------------------------------------------------------

#Cargamos las imágenes

i0 = load("img0.jpg")
i0R125 = load("img0RD125.jpg")
i0R25 = load("img0RD25.jpg")
i0R5 = load("img0RD5.jpg")

imagenes = [i0, i0R125, i0R25, i0R5]
nombres = ["img0.jpg", "img0RD125.jpg", "img0RD25.jpg", "img0RD5.jpg"]
k0 =[(dimensiones[1])[2], 125, 25, 5]
dimensiones = []
Bytes = []

# Extraemos los tamaños de cada imagen
for i in imagenes
    dims = size(i)
    push!(dimensiones, dims)
end

# Extraemos sus tamaños en bytes
for i in nombres
    bytes = stat(i).size
    push!(Bytes, bytes)
end

info_im0 = DataFrame(Dict("Imagen" => nombres, "k" => k0, "Tamaño_Del_Archivo" => Bytes))
info_im0

# --------------------------------------------------------- Gráficos del Codo -----------------------------------------------------------------

nombres = ["img0RD125.jpg", "img0RD25.jpg", "img0RD5.jpg"]
k = [125, 25, 5]
p = []

for i = 1:3
    Img = load(nombres[i])
    xImg = float.(Img)
    F = FindSVD( xImg )
    sv =  convert( Vector{Float32}, F.S)
    p_i = PlotNormalizedSum(sv, k[i])
    push!(p, p_i)
end

# Crear un subplot de 1x3
plot(p[1], p[2], p[3],  layout=(1, 3), size=(900, 300))