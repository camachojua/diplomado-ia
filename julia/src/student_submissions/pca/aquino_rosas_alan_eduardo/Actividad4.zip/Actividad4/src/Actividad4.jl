### A Pluto.jl notebook ###
# v0.20.4

using Markdown
using InteractiveUtils

# ╔═╡ afe122fb-5d68-4716-beff-8d85bd8b309a
begin
	using Pkg
	Pkg.add("Images")
	Pkg.add("FileIO")
	Pkg.add("MultivariateStats")
	Pkg.add("Plots")
end

# ╔═╡ 5a4f82c4-cf30-11ef-1f76-0357416d4009
begin
using Images
using FileIO
using MultivariateStats
using Plots
end

# ╔═╡ f20f378b-072b-40cc-9c5f-0233ba65ae01
md"""# Actividad 4 PCA On Images to Reduce Size"""

# ╔═╡ 485cbe3b-4acb-4538-8653-0b523bbb497c
md"""## Alan Eduardo Aquino Rosas"""

# ╔═╡ 9cbb33fa-4b13-4a1c-8071-9915a471a1e8
md"""### Definición de función para realizar PCA

En el caso de una imagen a color, se tendrían (length x width) x 3 características por imagen, por ejemplo.

Se busca reducir esto mediante PCA. Si definimos 10 componentes, tendríamos 10 características que intentarían representar toda la varianza del total de las características.
	
"""

# ╔═╡ 2c962f8f-5b03-4814-be12-edbeff78d5cf
function apply_pca(color_matrix, num_components)
    # Centrar y calcular PCA
    pca_model = fit(PCA, color_matrix, maxoutdim=num_components)
    transformed = transform(pca_model, color_matrix)
    reconstructed = reconstruct(pca_model, transformed)
    return reconstructed
end

# ╔═╡ 8d843fc9-a4ee-4341-9311-e4e4b3ed69b0
md"""Se crea una función para descomponer una imagen en 3 matrices de colores (R, G, B) y aplicarle PCA. Se mostrará la imagen."""

# ╔═╡ 31cc90c3-09b0-4691-ab13-2018d226f264
# Procesar imágenes y mostrarlas
function process_and_show_images(image_paths, num_components)
	plots_container = []
    for img_path in image_paths
        # Cargar imagen
        img = load(img_path)
        println("Procesando imagen: ", img_path)

        # Separar en matrices de colores (R, G, B)
        img_r = channelview(img)[1, :, :]
        img_g = channelview(img)[2, :, :]
        img_b = channelview(img)[3, :, :]

        # Aplicar PCA a cada canal
        img_r_pca = apply_pca(img_r, num_components)
        img_g_pca = apply_pca(img_g, num_components)
        img_b_pca = apply_pca(img_b, num_components)

        # Reconstruir imagen
        img_reduced = colorview(RGB, img_r_pca, img_g_pca, img_b_pca)

        # Mostrar imágenes original y reducida
        println("imagen original y procesada:")
		
        or = plot(img, title="Original")
        redu = plot(img_reduced, title="RPCA Compressed")
		push!(plots_container,(or,redu))

        # Guardar la imagen resultante
        save("reduced_" * basename(img_path), img_reduced)
        println("Imagen comprimida guardada")
    end
	return plots_container
end

# ╔═╡ 5f9e5718-03af-420a-bb47-4919d61910c1
begin
	
	base_path = "../fig/dog_images/"
	
	
	rutas_relativas = [
	    "doge1.jpeg",
	    "doge2.jpeg",
	    "doge3.jpeg",
		"doge4.jpeg",
		"doge5.jpeg",
	] 
	
	for i in eachindex(rutas_relativas)
		rutas_relativas[i] = base_path * rutas_relativas[i]
	end
	
	println(rutas_relativas)
		
	
	num_components = 50 
	
	plts = process_and_show_images(rutas_relativas, num_components)
end

# ╔═╡ Cell order:
# ╠═f20f378b-072b-40cc-9c5f-0233ba65ae01
# ╠═485cbe3b-4acb-4538-8653-0b523bbb497c
# ╠═afe122fb-5d68-4716-beff-8d85bd8b309a
# ╠═5a4f82c4-cf30-11ef-1f76-0357416d4009
# ╠═9cbb33fa-4b13-4a1c-8071-9915a471a1e8
# ╠═2c962f8f-5b03-4814-be12-edbeff78d5cf
# ╠═8d843fc9-a4ee-4341-9311-e4e4b3ed69b0
# ╠═31cc90c3-09b0-4691-ab13-2018d226f264
# ╠═5f9e5718-03af-420a-bb47-4919d61910c1
