# Regresión en Julia
Este repositorio contiene un script de Julia que realiza una regresión lineal sobre el conjunto de datos procesados en el ejercicio anterior (EDA). El objetivo es predecir la temperatura del agua de mar (T_degC) a partir de diversas variables explicativas seleccionadas.

## Contenido
1. Lectura de datos limpios:
Se lee el archivo bottle_cleanedData.csv (preprocesado en el Ejercicio 1) y se almacena en un DataFrame llamado bottle_cleaned.

2. Selección de variables relevantes según diccionario de datos:
Se filtran únicamente las columnas que tengan sentido para el modelo, por ejemplo:

julia
Copiar código
bottle_cleaned = bottle_cleaned[:, [
    :T_degC, :Depthm, :Salnty, :O2ml_L, :STheta, 
    :O2Sat, :R_SVA, :R_DYNHT, :R_O2, :R_NO3, :R_NO2
]]
3. Imputación de valores faltantes (Missing):
Se imputan los valores faltantes de las columnas numéricas con la media de cada columna:

julia
Copiar código
for col in names(bottle_cleaned)
    if eltype(bottle_cleaned[!, col]) <: Union{Missing, Number}
        mean_val = mean(skipmissing(bottle_cleaned[!, col]))
        bottle_cleaned[!, col] = coalesce.(bottle_cleaned[!, col], mean_val)
    end
end
4. Métricas del modelo (función model_metrics):

MSE (Mean Squared Error)
RMSE (Root Mean Squared Error)
R-squared (R²)
Además, se genera un gráfico de dispersión comparando los valores verdaderos (y_true) y los valores predichos (y_pred).
5. División del conjunto de datos en train y test:
Utilizamos randperm y definimos un split_point para dividir el conjunto de datos (80% entrenamiento, 20% prueba).

6. Ajuste del Modelo 1 (con todas las variables):

Se construye dinámicamente una fórmula para la regresión lineal:
julia
Copiar código
explanatory_vars = names(train_data) |> x -> filter(v -> v != "T_degC", x)
explanatory_vars_symbols = Symbol.(explanatory_vars)
formula = Term(:T_degC) ~ sum(Term(v) for v in explanatory_vars_symbols)
model1 = lm(formula, train_data)
Se imprimen los resultados y se evalúan las métricas del modelo.
7. Ajuste del Modelo 2 (eliminando variables con baja significancia):

Se quitan R_O2 y O2ml_L, entre otras, y se vuelve a ajustar el modelo:
julia
Copiar código
model2 = lm(@formula(
  T_degC ~ 1 + Depthm + Salnty + STheta + O2Sat +
           R_SVA + R_DYNHT + R_NO3 + R_NO2
), train_data)
Se visualizan nuevamente los resultados y métricas del modelo.
Requisitos
Julia (versión 1.x o superior).
Paquetes de Julia necesarios (instalables con using Pkg; Pkg.add("PackageName")):
DataFrames
CSV
Statistics
Plots
GLM
StatsModels
MultivariateStats
Random