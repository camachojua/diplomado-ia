using DataFrames, CSV, Statistics, Plots, GLM, StatsModels, MultivariateStats, Random


################################################################################
#        1. Leer los datos ya limpios del EDA (bottle_cleanData.csv)
################################################################################

bottle_cleaned = CSV.read("../dat/bottle_cleanedData.csv", DataFrame, delim=',', header=true)

################################################################################
# 2. Seleccionar solo las variables que tengan sentido de acuerdo con el diccionario de datos
################################################################################

bottle_cleaned = bottle_cleaned[:, [
    :T_degC, :Depthm, :Salnty, :O2ml_L, :STheta, 
    :O2Sat, :R_SVA, :R_DYNHT, :R_O2, :R_NO3, :R_NO2
]]

################################################################################
# 3. Imputar valores faltantes con la media de cada columna
################################################################################
for col in names(bottle_cleaned)
    # Verificar si la columna es numérica y puede contener valores faltantes
    if eltype(bottle_cleaned[!, col]) <: Union{Missing, Number}
        # Calcular la media excluyendo valores faltantes
        mean_val = mean(skipmissing(bottle_cleaned[!, col]))
        # Reemplazar valores faltantes con la media
        bottle_cleaned[!, col] = coalesce.(bottle_cleaned[!, col], mean_val)
    end
end

################################################################################
# 4. Función para calcular métricas del modelo
################################################################################
function metricas_del_modelo(modelo)
    # Se asume que test_data está disponible en el ámbito global
    y_real = test_data.T_degC
    y_predicho = predict(modelo, test_data)

    # Error Cuadrático Medio (MSE)
    mse = mean((y_real .- y_predicho).^2)
    println("Error Cuadrático Medio (MSE): ", mse)

    # Raíz del Error Cuadrático Medio (RMSE)
    rmse = sqrt(mse)
    println("Raíz del Error Cuadrático Medio (RMSE): ", rmse)

    # Calcular la suma total de cuadrados (SST) y la suma de cuadrados residuales (SSE)
    sst = sum((y_real .- mean(y_real)).^2)    # Suma total de cuadrados
    sse = sum((y_real .- y_predicho).^2)      # Suma de cuadrados del residuo

    # Calcular R-cuadrado
    r2 = 1 - sse / sst
    println("R-cuadrado: ", r2)

    # Gráfica de comparación entre valores reales y predichos
    scatter(
        y_real, 
        y_predicho, 
        xlabel="Valores Reales", 
        ylabel="Valores Predichos", 
        title="Valores Predichos vs. Valores Reales"
    )
end

################################################################################
# 5. Dividir los datos en entrenamiento (train) y prueba (test)
################################################################################
# Aleatorizar los datos y dividir manualmente
Random.seed!(1234)  # Para reproducibilidad
n = size(bottle_cleaned, 1)
shuffle_indices = randperm(n)

# Definir el punto de división (80% para entrenamiento, 20% para prueba)
split_point = Int(round(0.8 * n))

# Índices de entrenamiento y prueba
train_indices = shuffle_indices[1:split_point]
test_indices = shuffle_indices[split_point+1:end]

# Crear conjuntos de entrenamiento (train_data) y prueba (test_data)
train_data = bottle_cleaned[train_indices, :]
test_data = bottle_cleaned[test_indices, :]

################################################################################
# 6. Ronda 1 - Ajustar el modelo con todas las variables
################################################################################
# Extraer los nombres de todas las variables explicativas (excluyendo la respuesta 'T_degC')
vars_explicativas = names(train_data) |> x -> filter(v -> v != "T_degC", x)

# Convertir nombres de columna a símbolos
vars_explicativas_simbolos = Symbol.(vars_explicativas)

# Construir dinámicamente la fórmula usando los símbolos
formula = Term(:T_degC) ~ sum(Term(v) for v in vars_explicativas_simbolos)

# Ajustar el modelo lineal
modelo1 = lm(formula, train_data)

# Ver los resultados del modelo
println(modelo1)

# Calcular métricas del modelo
metricas_del_modelo(modelo1)

################################################################################
# 7. Ronda 2 - Eliminar las variables menos significativas (R_O2 y O2ml_L)
################################################################################
# Ajustar el modelo lineal sin esas variables
modelo2 = lm(@formula(T_degC ~ 1 + Depthm + Salnty + STheta + O2Sat + R_SVA + R_DYNHT + R_NO3 + R_NO2), train_data)

# Ver los resultados del modelo
println(modelo2)

# Calcular métricas del modelo
metricas_del_modelo(modelo2)
