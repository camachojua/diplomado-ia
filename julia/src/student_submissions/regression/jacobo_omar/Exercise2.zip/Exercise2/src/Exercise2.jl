using DataFrames, CSV, Plots, GLM, Random, FileIO, Images, Statistics

# Leer el df generado en el ejercicio 1
df_bottle = CSV.read("/mnt/c/Users/omarm/Downloads/bottle/bottle_clean.csv", DataFrame);

first(df_bottle, 3)
# Proporcion para el conjunto de entrenamiento
train_ratio = 0.7
# Columna usada para la regresion
column_name = "R_PRES"

# Crear los conjuntos de test y train con una semilla especifica
df_shuffled = shuffle(MersenneTwister(3915), df_bottle)
n_train = floor(Int, train_ratio*size(df_bottle, 1))
n_test = floor(Int, (1-train_ratio)*size(df_bottle, 1))

println("Entrenamiento: $n_train  Testeo: $n_test")
# Dividir el dataframe
train_data = df_shuffled[1:n_train, :]
test_data = df_shuffled[n_train+1:size(df_shuffled, 1), :]
nothing

function metrics(model, test_data, column_predicted, fig_name)
    y_true = test_data[!,column_predicted]
    y_pred = predict(model, test_data)

    RMSE = sqrt(sum((y_true .- y_pred).^2) / length(y_true))
    rsq = r2(model)
    println("RMSE: ", RMSE)
    println("R^2: ", rsq)

    ## Guardar grafica
    plots = scatter(y_true, y_pred, xlabel="Valores reales", ylabel="Valores predecidos", title="Valores reales vs predecidos", color=:red, fmt = :png)
    path = pwd()
    path = path[1:length(path)-3]
    savefig(plots,"$path" * "fig/$fig_name.png")
    img = FileIO.load("$path" * "fig/$fig_name.png")
end

columns_to_fit = Symbol.([name for name in names(train_data) if name != column_name])
fm1 = Term(Symbol(column_name)) ~ sum(Term(v) for v in columns_to_fit)

println(fm1)
# Ajustar el modelo
model1 = lm(fm1, train_data)
println(model1)
metrics(model1, test_data, Symbol(column_name), "figura1")

fm2 = @formula(R_PRES ~ R_Depth)
println(fm2)
# Ajustar el modelo
model2 = lm(fm2, train_data)
println(model2)
metrics(model2, test_data, Symbol(column_name), "figura2")

fm3 = @formula(R_PRES ~ T_degC + O2ml_L + STheta + R_TEMP + R_POTEMP + R_SIGMA + R_SVA + R_DYNHT + R_O2)
model3 = lm(fm3, train_data)
println(fm3)
# Ajustar el modelo
println(model3)
metrics(model3, test_data, Symbol(column_name), "figura3")