# Regression Analysis Report: Temperature Prediction in Ocean Data

## Overview
This report presents the findings of a regression analysis performed on oceanographic data to understand the factors influencing water temperature (T_degC). The analysis included correlation assessment, individual predictor evaluation, and multiple regression modeling.

## Key Findings

### 1. Correlation Analysis
Five significant predictors were identified with strong correlations to temperature:

- R_TEMP: Perfect positive correlation (1.0)
- DIC1: Strong negative correlation (-0.936)
- R_PRES: Strong negative correlation (-0.788)
- BtlNum: Strong positive correlation (0.748)
- TA1: Strong negative correlation (-0.737)

### 2. Individual Predictor Performance

#### R_TEMP (Temperature)
- Strongest individual predictor
- Perfect predictive power (R² = 1.0)

#### DIC1 (Dissolved Inorganic Carbon)
- Second strongest predictor
- Very high predictive power (R² = 0.877)
- For each unit increase in DIC1, temperature decreases by 0.03°C

#### R_PRES (Pressure)
- Moderate to strong predictive power (R² = 0.621)
- Temperature decreases by 0.021°C for each unit increase in pressure

#### BtlNum (Bottle Number)
- Moderate predictive power (R² = 0.56)
- Each unit increase corresponds to 0.434°C increase in temperature

#### TA1 (Total Alkalinity)
- Moderate predictive power (R² = 0.543)
- Temperature decreases by 0.087°C for each unit increase in TA1

## Conclusions

1. **Primary Predictor**: R_TEMP is the dominant predictor of water temperature, providing perfect prediction capability on its own.

2. **Redundancy**: While other variables show strong individual correlations, they don't add meaningful predictive power if combined with R_TEMP.

3. **Model Selection**: For practical applications, using R_TEMP alone as a predictor is sufficient and more efficient than a combined model.

4. **Physical Relationships**: The analysis revealed expected physical relationships:
   - Positive correlation with bottle number
   - Negative correlation with pressure (depth)
   - Negative correlation with dissolved inorganic carbon
   - Negative correlation with total alkalinity

## Recommendations

1. Use R_TEMP as the primary predictor for temperature estimations
2. Consider DIC1 as a backup predictor when R_TEMP measurements are unavailable
