# Install dependencies
using Pkg
Pkg.add("DataFrames")
Pkg.add("CSV")
Pkg.add("Statistics")
Pkg.add("StatsBase")
Pkg.add("GLM")
Pkg.add("StatsModels")

# Initialize script
using DataFrames
using CSV
using Statistics
using StatsBase
using GLM
using StatsModels

# Read the data
df = CSV.read("dat/bottle.csv", DataFrame)

# Function to remove outliers using IQR method
function removeOutliersIQR(df::DataFrame)
    df_clean = copy(df)
    numeric_cols = names(df)[eltype.(eachcol(df)) .<: Union{Missing, Number}]
    
    for col in numeric_cols
        # Skip if column has missing values
        if any(ismissing.(df_clean[!, col]))
            continue
        end
        
        q1 = quantile(df_clean[!, col], 0.25)
        q3 = quantile(df_clean[!, col], 0.75)
        iqr = q3 - q1
        lower_bound = q1 - 1.5 * iqr
        upper_bound = q3 + 1.5 * iqr
        
        df_clean = df_clean[.!((df_clean[!, col] .< lower_bound) .| (df_clean[!, col] .> upper_bound)), :]
    end
    
    return df_clean
end

# Function to calculate correlation matrix
function calculateCorrelation(df::DataFrame)
    # Select only numeric columns and convert to Float64
    numeric_cols = names(df)[eltype.(eachcol(df)) .<: Union{Missing, Number}]
    numeric_df = DataFrame()
    
    for col in numeric_cols
        # Skip non-numeric or all-missing columns
        if all(x -> ismissing(x) || !isnumeric(x), df[!, col])
            continue
        end
        # Convert to Float64 and handle missing values
        numeric_df[!, col] = convert.(Float64, coalesce.(df[!, col], 0.0))
    end
    
    # Get final numeric columns
    final_cols = names(numeric_df)
    
    if isempty(final_cols)
        error("No numeric columns found after processing")
    end
    
    # Calculate correlation matrix
    cor_matrix = cor(Matrix(numeric_df))
    return cor_matrix, final_cols
end

# Helper function to check if a value is numeric
isnumeric(x) = typeof(x) <: Number

# Function to filter columns based on correlation with target
function filterColumnsByCorrelation(df::DataFrame, target::String, threshold::Float64, relation::String)
    cor_matrix, col_names = calculateCorrelation(df)
    target_idx = findfirst(==(target), col_names)
    
    if target_idx === nothing
        error("Target column not found in numeric columns")
    end
    
    correlations = cor_matrix[target_idx, :]
    
    if relation == "greater"
        cols_to_keep = col_names[abs.(correlations) .>= threshold]
    elseif relation == "less"
        cols_to_keep = col_names[abs.(correlations) .<= threshold]
    else
        error("Invalid relation. Use 'greater' or 'less'")
    end
    
    return df[!, cols_to_keep]
end

# Function to perform linear regression and get R²
function perform_regression(df::DataFrame, target::String, predictors::Vector{String})
    if isempty(predictors)
        error("No predictors provided")
    end
    
    # Get complete cases for all variables involved
    cols_to_check = vcat(target, predictors)
    complete_cases = completecases(df[:, cols_to_check])
    
    if !any(complete_cases)
        error("No complete cases available for regression")
    end
    
    # Create a new dataframe with only complete cases
    regression_df = df[complete_cases, cols_to_check]
    
    # Create formula by combining terms with +
    if length(predictors) == 1
        formula = Term(Symbol(target)) ~ Term(Symbol(predictors[1]))
    else
        rhs = foldl((x,y) -> x + y, Term.(Symbol.(predictors)))
        formula = Term(Symbol(target)) ~ rhs
    end
    
    model = lm(formula, regression_df)
    r2 = r²(model)
    adj_r2 = adjr²(model)
    return model, r2, adj_r2
end

# Print initial data info
println("Initial columns: ", names(df))

# Clean the data
clean_df = removeOutliersIQR(df)
println("\nColumns after cleaning: ", names(clean_df))

# Get numeric columns for correlation analysis
numeric_cols = names(clean_df)[eltype.(eachcol(clean_df)) .<: Union{Missing, Number}]
numeric_cols = setdiff(numeric_cols, ["T_degC"])  # Exclude target variable

# Calculate correlations and store them
println("\nCorrelations with T_degC:")
println("======================")
correlations = Dict{String, Tuple{Float64, Int}}()
for col in numeric_cols
    if !all(ismissing, clean_df[!, col])  # Skip columns with all missing values
        # Get complete cases for both columns
        valid_rows = .!ismissing.(clean_df[!, "T_degC"]) .& .!ismissing.(clean_df[!, col])
        n_complete = sum(valid_rows)
        if n_complete > 30  # Only use predictors with sufficient complete cases
            x = clean_df[valid_rows, "T_degC"]
            y = clean_df[valid_rows, col]
            correlation = cor(x, y)
            println("$col: $(round(correlation, digits=3)) (n=$n_complete)")
            if !isnan(correlation) && abs(correlation) >= 0.3  # Keep predictors with correlation >= 0.3
                correlations[col] = (abs(correlation), n_complete)
            end
        end
    end
end

# Sort predictors by correlation strength and number of complete cases
sorted_predictors = sort(collect(correlations), by=x->(-x[2][1], -x[2][2]))

# Function to check if a predictor is redundant with existing ones
function is_redundant(col::String, selected::Vector{String}, df::DataFrame, threshold::Float64=0.95)
    if isempty(selected)
        return false
    end
    
    for existing in selected
        valid_rows = .!ismissing.(df[!, col]) .& .!ismissing.(df[!, existing])
        if sum(valid_rows) > 30
            correlation = abs(cor(df[valid_rows, col], df[valid_rows, existing]))
            if correlation > threshold
                return true
            end
        end
    end
    return false
end

# Select top non-redundant predictors
println("\nSelecting top non-redundant predictors...")
predictor_cols = String[]
test_cols = ["T_degC"]
max_predictors = 5  # Limit the number of predictors to avoid overfitting

for (col, _) in sorted_predictors
    if length(predictor_cols) >= max_predictors
        break
    end
    
    if !is_redundant(col, predictor_cols, clean_df)
        push!(test_cols, col)
        complete_cases = completecases(clean_df[:, test_cols])
        if sum(complete_cases) > 30
            push!(predictor_cols, col)
            println("Added $col ($(sum(complete_cases)) complete cases)")
        else
            pop!(test_cols)
        end
    else
        println("Skipped $col (redundant with existing predictors)")
    end
end

if isempty(predictor_cols)
    error("No suitable predictors found")
end

println("\nFinal predictors: ", predictor_cols)
# Get the best model (using all predictors since they're already filtered by correlation)
best_model, best_r2, best_adj_r2 = perform_regression(clean_df, "T_degC", collect(predictor_cols))

# Write regression results to file
open("report/regression_results.txt", "w") do file
    write(file, "REGRESSION ANALYSIS RESULTS\n")
    write(file, "========================\n\n")
    
    # Write correlations
    write(file, "Correlations with T_degC:\n")
    write(file, "======================\n")
    for col in predictor_cols
        valid_rows = .!ismissing.(clean_df[!, "T_degC"]) .& .!ismissing.(clean_df[!, col])
        x = clean_df[valid_rows, "T_degC"]
        y = clean_df[valid_rows, col]
        correlation = cor(x, y)
        write(file, "$col: $(round(correlation, digits=3))\n")
    end
    write(file, "\n")
    
    # Write single predictor models
    write(file, "Single Predictor Models:\n")
    write(file, "-----------------------\n")
    for predictor in predictor_cols
        model, r2, adj_r2 = perform_regression(clean_df, "T_degC", [predictor])
        write(file, "Predictor: $predictor\n")
        write(file, "R²: $(round(r2, digits=3))\n")
        write(file, "Adjusted R²: $(round(adj_r2, digits=3))\n")
        write(file, "Model: $model\n\n")
    end
    
    # Write best model results
    write(file, "Best Model Summary:\n")
    write(file, "=================\n")
    write(file, "Predictors: $(join(predictor_cols, ", "))\n")
    write(file, "R²: $(round(best_r2, digits=3))\n")
    write(file, "Adjusted R²: $(round(best_adj_r2, digits=3))\n")
    write(file, "Model:\n$best_model\n")
end
