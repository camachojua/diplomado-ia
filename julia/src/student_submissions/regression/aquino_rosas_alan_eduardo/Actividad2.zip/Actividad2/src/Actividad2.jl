### A Pluto.jl notebook ###
# v0.20.4

using Markdown
using InteractiveUtils

# ╔═╡ f4f3006c-4807-4c4f-925e-513f5d303ee0
begin
	using Pkg
	
	Pkg.add("MLJLinearModels")
	Pkg.add("Combinatorics")
	Pkg.add("MLJ")
	Pkg.add("MLJBase")
	Pkg.add("StatsBase")
	
end

# ╔═╡ d3327ee8-d346-42d4-84a2-914c243a14c1
begin
	using DataFrames
	using Random
	using Statistics
	using Combinatorics
	using CSV
	using MLJ, MLJLinearModels, MLJBase, StatsBase
	
end

# ╔═╡ 06dfff22-cd75-11ef-13be-a76c4898b005
md"""# Regression con CalCofi Dataset Procesado

## Alan Eduardo Aquino Rosas 
"""

# ╔═╡ 5fea8b81-4a82-4366-90f7-4ea536ec0957
md"""Ya procesado el dataset en la Actividad 1, durante esta actividad se utilizará el dataset para entrenar diferentes modelos estadísticos/ML de regresión lineal.

Recordando los objetivos de una regresión lineal, al momento de entrenar el modelo se intenta obtener inferencia sobre las variables independientes en relación con la dependiente (cuáles características aportan a la predicción de T_degC), así como predecir nuevos valores de T_degC.

Debido a que en la actividad anterior se determinó que existen correlaciones entre las variables independientes, se utilizarán regresiones como Lasso (L1 norm), Ridge (L2 norm) y Elastic-Net (L1 & L2 norm). Por adelantado, se considera que, debido a las correlaciones existentes (multicolinealidad), el modelo que funcionará mejor será Ridge Regression.
"""

# ╔═╡ 8548a028-60a5-4b07-a87c-c0271c71bad2
md"""### Importación de Paquetes
Se importarán los paquetes necesarios.
"""

# ╔═╡ 0b237a93-e82d-4335-aa6b-a574ed7022f7
md"""### Entrenamiento de Modelos de Regresión Lineal"""

# ╔═╡ 736223a8-2f3c-4e6e-9a26-1193c6a3c01d
md"""Para el modelado de los datos se utilizarán 3 modelos de regresión lineal:

1.	Linear Regression: Se utiliza este modelo base que no tiene ningún tipo de regularización. La regularización sirve para penalizar variables que pueden llevar al overfitting de un modelo, penalizando los coeficientes o pesos altos del modelo mediante una escala, conocida como la variable lambda.

2.	Lasso Regression: Este es un modelo semejante a Linear Regression, con la única diferencia de que se añade un término de regularización (L1 regularization). En términos de álgebra lineal, la regularización L1 consiste en computar la Manhattan Distance.

3.	Ridge Regression: Al igual que Lasso Regression, es un modelo similar a Linear Regression, pero con un término de regularización de tipo L2, computado mediante la Euclidean Distance.

4.	Elastic Net Regression: Esta regresión lineal combina las regularizaciones L1 y L2 para tener un modelo más flexible.

Es importante tener en cuenta que la diferencia práctica entre las regularizaciones L1 y L2 radica en su efecto sobre los coeficientes:
	
La regularización L1 se enfoca en minimizar la magnitud de los coeficientes y es capaz de eliminar características por completo, ajustando sus coeficientes a 0.

En cambio, la regularización L2 se centra más en reducir los coeficientes que pueden causar overfitting, pero retiene las características, ya que nunca ajusta los coeficientes de las características a 0.


"""

# ╔═╡ 7ad7fd43-a32f-449c-9a44-41affd299296
import MLJLinearModels: fit, predict, LassoRegressor, RidgeRegressor

# ╔═╡ ca711542-fb87-441f-9401-e854cbb03373
md"""Para probar los diferentes modelos con distintos subconjuntos de características, se desarrolló la función train_models_with_cv..

La función recibe 4 parámetros:

1. dataframe: El dataframe con el cual se entrenarán los modelos.

2. target: El nombre de la variable dependiente en formato String. A partir de este, se separa el dataset.

3. num_models: La función fue diseñada con el propósito de generar subconjuntos del dataset con diferentes características. Permite trabajar en un modo donde defines el número de modelos a generar y entrena  n  modelos de regresión lineal, Ridge, Lasso y Elastic Net probando diferentes combinaciones de variables independientes. num_models define la cantidad de combinaciones de variables seleccionadas de manera aleatoria que se van a probar. Este método funciona de esta manera y toma en consideración este parámetro al ejecutarse con el valor "RANDOM_SUBSETS" en el parámetro combination_variables_mode.

4. combination_variables_mode: Para probar diferentes combinaciones de variables independientes, la función puede ejecutarse en 3 modos distintos.
	1. ALL_VARS_SUBSETS: Se generarán todos los subconjuntos de las variables independientes para probar las diferentes combinaciones y determinar cuál es la mejor. Se generan  2^{\# \text{características}}  subconjuntos.

	2. ALL_VARS: Únicamente se entrenan los modelos con un subconjunto que está conformado por todas las variables independientes.

	3. RAMDON_SUBSETS: Se generan num_models combinaciones de variables independientes para entrenar los modelos con diferentes combinaciones generadas de manera aleatoria.

5. train_ratio: La función implementada usa cross-validation para identificar qué tan bien generaliza el modelo para datos nuevos. train_ratio representa el porcentaje, en formato decimal, de datos que se utilizarán en la etapa de entrenamiento.
'"""

# ╔═╡ 49ad0c36-db51-4a3a-8fb7-13f73b0862ac
begin
	function train_models_with_cv(dataframe, target, num_models::Int; combination_varaibles_mode::String="ALL_VARS", train_ratio::Float64=0.8)
	    # Extract column names except the target, using set diff
	    predictors = setdiff(names(dataframe), [target])
		println("predictors", predictors)
	    # Datastucture to store results
		results = DataFrame(
	        ModelType = String[],
	        PredictorCombination = String[],
	        TrainR2 = Float64[],
	        TrainRMSE = Float64[],
	        ValidationR2 = Float64[],
	        ValidationRMSE = Float64[]
	    )
	    
	    # If using all variables, set combinations to include all predictors
		if combination_varaibles_mode == "ALL_VARS"
			#Only train and test with all the variables in the model, not subsets generated apart from the one including all vars
			combinations = [predictors]
		elseif combination_varaibles_mode == "ALL_VARS_SUBSETS"
			#Generate and test with all the combinations of independent variables
			combinations = [comb for r in 1:length(predictors) for comb in combinations(predictors, r)]
		else
			#Only a some ramdon subsets of the independent variables to consider for the model
			combinations = [StatsBase.sample(predictors, rand(1:length(predictors)), replace=false) for _ in 1:num_models]
		end
			
	
	    # Loop through combinations of predictors, aka the combinations of the column names generated
	    Random.seed!(123)  # Set seed for same ramdom values
	    for selected_predictors in combinations
	
	        # Prepare data for MLJLinearModels
	        X = Matrix(DataFrames.select(dataframe, selected_predictors))
	        y = dataframe[!, target]
	
	        # Split into training and validation sets
	        n = nrow(dataframe)
	        indices = shuffle(1:n)
	        train_size = Int(floor(train_ratio * n))
	        train_indices = indices[1:train_size]
	        val_indices = indices[train_size+1:end]
	
	        X_train, y_train = X[train_indices, :], y[train_indices]
	        X_val, y_val = X[val_indices, :], y[val_indices]
	        train_df = dataframe[train_indices, :]
	        val_df = dataframe[val_indices, :]
			X_train_table = MLJBase.table(X_train)
			X_val_table   = MLJBase.table(X_val)
	
	        # Perform Linear Regression with lasso lib, just setting lamda to 0
	        lm = LassoRegressor(lambda=0)
			linear_model = machine(lm,X_train_table, y_train)
			fit!(linear_model)
	        train_preds_linear = MLJ.predict(linear_model, X_train_table)
	        val_preds_linear = MLJ.predict(linear_model, X_val_table)
			#println("DEBUGGGG")
			#println(train_preds_linear)
			#print("NOW Y")
			#println(y_train)
			#println("FINISHHH DEBUGGGG")
	        train_r2_linear = 1 - sum((train_preds_linear - y_train).^2) / sum((y_train .- mean(y_train)).^2)
	        train_rmse_linear = sqrt(mean((train_preds_linear - y_train).^2))
	        val_r2_linear = 1 - sum((val_preds_linear - y_val).^2) / sum((y_val .- mean(y_val)).^2)
	        val_rmse_linear = sqrt(mean((val_preds_linear - y_val).^2))
	        push!(results, ("Linear", join(selected_predictors, ", "), train_r2_linear, train_rmse_linear, val_r2_linear, val_rmse_linear))
	
	        # Perform Lasso Regression, no need for formula because of package def
	        lsm = LassoRegressor(lambda=0.1) 
			lasso_model = machine(lsm,X_train_table, y_train)
			fit!(lasso_model)
	        train_preds_lasso = MLJ.predict(lasso_model, X_train_table)
	        val_preds_lasso = MLJ.predict(lasso_model, X_val_table)
	        train_r2_lasso = 1 - sum((train_preds_lasso - y_train).^2) / sum((y_train .- mean(y_train)).^2)
	        train_rmse_lasso = sqrt(mean((train_preds_lasso - y_train).^2))
	        val_r2_lasso = 1 - sum((val_preds_lasso - y_val).^2) / sum((y_val .- mean(y_val)).^2)
	        val_rmse_lasso = sqrt(mean((val_preds_lasso - y_val).^2))
	        push!(results, ("Lasso", join(selected_predictors, ", "), train_r2_lasso, train_rmse_lasso, val_r2_lasso, val_rmse_lasso))
	
	        # Perform Ridge Regression,  no need for formula because of package def
	        rdgem = RidgeRegressor(lambda=0.1) 
			
	        ridge_model = machine(rdgem, X_train_table, y_train)
			fit!(ridge_model)
			train_preds_ridge = MLJ.predict(ridge_model, X_train_table)
	        val_preds_ridge = MLJ.predict(ridge_model, X_val_table)
	        train_r2_ridge = 1 - sum((train_preds_ridge - y_train).^2) / sum((y_train .- mean(y_train)).^2)
	        train_rmse_ridge = sqrt(mean((train_preds_ridge - y_train).^2))
	        val_r2_ridge = 1 - sum((val_preds_ridge - y_val).^2) / sum((y_val .- mean(y_val)).^2)
	        val_rmse_ridge = sqrt(mean((val_preds_ridge - y_val).^2))
	        push!(results, ("Ridge", join(selected_predictors, ", "), train_r2_ridge, train_rmse_ridge, val_r2_ridge, val_rmse_ridge))
	
	        # Perform Elastic-Net Regression,  no need for formula because of package def
	        enetm = ElasticNetRegressor(lambda=0.1, gamma=0.5)
			enet_model = machine(enetm, X_train_table, y_train)
			fit!(enet_model)
	        train_preds_enet = MLJ.predict(enet_model, X_train_table)
	        val_preds_enet = MLJ.predict(enet_model, X_val_table)
	        train_r2_enet = 1 - sum((train_preds_enet - y_train).^2) / sum((y_train .- mean(y_train)).^2)
	        train_rmse_enet = sqrt(mean((train_preds_enet - y_train).^2))
	        val_r2_enet = 1 - sum((val_preds_enet - y_val).^2) / sum((y_val .- mean(y_val)).^2)
	        val_rmse_enet = sqrt(mean((val_preds_enet - y_val).^2))
	        push!(results, ("Elastic-Net", join(selected_predictors, ", "), train_r2_enet, train_rmse_enet, val_r2_enet, val_rmse_enet))
	    end
	    return results
	end
	   
end

# ╔═╡ 2e5510bf-57d6-4cc9-92dd-fb5879790614
md"""Ya con nuestra función, que nos permitirá entrenar diferentes subconjuntos de datos con distintos modelos, podemos empezar nuestro modelado."""

# ╔═╡ e09bcf4b-c78e-4a05-b5f3-ced27b47dbc8
md"""
Primero, se leerá nuestro dataset ya preprocesado en la Actividad 1 y se llamará a la función generada.

A continuación, se muestra un dataframe con las diferentes combinaciones de variables y los modelos utilizados, junto con su respectivo error y  R^2  en los conjuntos de entrenamiento y validación."""

# ╔═╡ d2884674-6c46-46a5-a6af-7559b51181d3
begin
	# Load data
	df = CSV.read("../dat/processed-bottle.csv", DataFrame)
		
	# Train models
	results_all = train_models_with_cv(df, "T_degC", 20; combination_varaibles_mode="ALL_VARS", train_ratio=0.8)
	results_random = train_models_with_cv(df, "T_degC", 20; combination_varaibles_mode="SAMPLE_COMBINATION", train_ratio=0.8)
	
	# Display results
	println("Results using all variables:")
	df1 = sort(results_all, :ValidationR2, rev=true)
	
	println("Results using random combinations:")
	df2 = sort(results_random, :ValidationR2, rev=true)
end

# ╔═╡ 2aabd924-b4c5-472f-9112-9a4222398a2f
md"""### Resultados de Experimento"""

# ╔═╡ 92d96e5a-27b4-47d7-bf4a-6fba1cd089c5
md""" Dataframe de resultados de la función en modo ALL_VARS, ordenados por el mejor puntaje de  R^2  en validación, de manera descendente."""

# ╔═╡ e7412110-6b7d-4e98-932b-86765b73caf9
df1

# ╔═╡ 4a749059-fdab-42c3-a42b-9f846310a016
md"""Dataframe de resultados de la función en modo SAMPLE_COMBINATION, ordenados por el mejor puntaje de  R^2  en validación, de manera descendente."""

# ╔═╡ c080671d-56cf-4906-a7fe-3623a428a6cb
df2

# ╔═╡ 93abf828-5421-46b1-b6ac-aa4346dab8ab
md"""### Resultados Interpetacion"""

# ╔═╡ 17030eb6-bd08-43b7-b94a-97cb5a9f243c
md"""El modelo que tuvo mejor desempeño fue Ridge Regression, con la combinación de variables independientes: 'R_TEMP, NO3q, Oxy_µmol/Kg, O2ml_L, DarkAq, NH3q'.

Obtuvo un RMSE en el conjunto de entrenamiento de 0.0375977 y en el conjunto de validación de 0.037561.

Asimismo, logró un R² en el conjunto de entrenamiento de 0.999904 y en el conjunto de validación de 0.999904.
"""

# ╔═╡ d3d82978-0959-4c68-84e8-68126e66f5a6
md"""### Conclusiones"""

# ╔═╡ 2db7cb7d-b569-4ff3-bf9c-29f598ca4fe7
md"""Al concluir las actividades 1 y 2, hay varios aspectos que me gustaría destacar. Estos se expresarán en forma de puntos:

1.	Importancia del EDA: Se puede observar cómo el EDA realizado en la Actividad 1 nos proporcionó una idea clara de las mejores opciones para entrenar y modelar nuestros datos. Se limpiaron los datos para eliminar todo el ruido que podría impedir que nuestro modelo generalice bien. Además, identificamos que existía una alta colinealidad entre las variables independientes, lo que nos indicó que un modelo que empleara algún tipo de regularización sería una mejor opción para nuestro dataset, ayudando a evitar el overfitting.


2.	Importancia de la Regularización en los modelos de ML: Pudimos notar que el modelo con mejor desempeño en nuestro conjunto de validación fue la regresión Ridge. Esto se debe a que, en casos de multicolinealidad, la regularización ayuda a distribuir la varianza que puede estar expresada en múltiples variables, en lugar de concentrarla en una sola, evitando el overfitting.


"""

# ╔═╡ Cell order:
# ╠═06dfff22-cd75-11ef-13be-a76c4898b005
# ╠═5fea8b81-4a82-4366-90f7-4ea536ec0957
# ╠═8548a028-60a5-4b07-a87c-c0271c71bad2
# ╠═f4f3006c-4807-4c4f-925e-513f5d303ee0
# ╠═d3327ee8-d346-42d4-84a2-914c243a14c1
# ╠═0b237a93-e82d-4335-aa6b-a574ed7022f7
# ╠═736223a8-2f3c-4e6e-9a26-1193c6a3c01d
# ╠═7ad7fd43-a32f-449c-9a44-41affd299296
# ╠═ca711542-fb87-441f-9401-e854cbb03373
# ╠═49ad0c36-db51-4a3a-8fb7-13f73b0862ac
# ╠═2e5510bf-57d6-4cc9-92dd-fb5879790614
# ╠═e09bcf4b-c78e-4a05-b5f3-ced27b47dbc8
# ╠═d2884674-6c46-46a5-a6af-7559b51181d3
# ╠═2aabd924-b4c5-472f-9112-9a4222398a2f
# ╠═92d96e5a-27b4-47d7-bf4a-6fba1cd089c5
# ╠═e7412110-6b7d-4e98-932b-86765b73caf9
# ╠═4a749059-fdab-42c3-a42b-9f846310a016
# ╠═c080671d-56cf-4906-a7fe-3623a428a6cb
# ╠═93abf828-5421-46b1-b6ac-aa4346dab8ab
# ╠═17030eb6-bd08-43b7-b94a-97cb5a9f243c
# ╠═d3d82978-0959-4c68-84e8-68126e66f5a6
# ╠═2db7cb7d-b569-4ff3-bf9c-29f598ca4fe7
