using DataFrames
using CSV
using Statistics
using StatsBase
using Plots
using StatsPlots

function printDictPretty(d::Dict)
    for (key, value) in d
        println("""    "$key" => $value,""")
    end
end

function printCorrelationMatrixPretty(cols::Vector{String}, corr_matrix::Matrix{Float64})
    println("Correlation Matrix:")
    header = "       " * join(cols, "  ")
    println(header)
    for (i, row) in enumerate(eachrow(corr_matrix))
        row_str = join([string(round(x, digits=3)) for x in row], "  ")
        println(rpad(cols[i], 8, ' ') * row_str)
    end
end

function printNewSection()
    println()
    println("-------------------------------------------------------------------")    
    println()
end

count_missing(col::AbstractVector) = count(ismissing, col)

function dataMissingPercentage(df::DataFrame)
    total_rows = nrow(df)
    percs = Dict()
    for c in names(df)
        miss = count_missing(df[!, c])
        percs[c] = (miss / total_rows) * 100
    end
    return percs
end

function deleteColumns!(df::DataFrame, threshold::Float64)
    percs = dataMissingPercentage(df)
    cols_to_keep = [c for c in names(df) if percs[c] ≤ threshold]
    return df[:, cols_to_keep]
end

function calculateCorrelation(df::DataFrame)
    numeric_cols = [c for c in names(df) if eltype(df[!, c]) <: Number]
    numeric_df = df[:, numeric_cols]
    dropped_df = dropmissing(numeric_df)
    mat = Matrix(dropped_df)
    corr_matrix = cor(mat, dims=1) # Pearson correlation by default
    return numeric_cols, corr_matrix
end

function displayCorrelation(cols::Vector{String}, corr_matrix::Matrix{Float64})
    heatmap(
        cols, cols, corr_matrix,
        title="Correlation Heatmap",
        color=:bluesreds,   # Gradient colors
        c=:RdBu,            # Color palette
        clim=(-1, 1)        # Value range limits
    )

    savefig("fig/heatmap.png")
end

function removeOutliersIQR!(df::DataFrame)
    numeric_cols = [c for c in names(df) if eltype(df[!, c]) <: Number]
    for c in numeric_cols
        col_data = skipmissing(df[!, c])
        q1 = quantile(col_data, 0.25)
        q3 = quantile(col_data, 0.75)
        iqr = q3 - q1
        lower_bound = q1 - 1.5*iqr
        upper_bound = q3 + 1.5*iqr
        df = df[(df[!, c] .≥ lower_bound) .& (df[!, c] .≤ upper_bound) .| (ismissing.(df[!, c])), :]
    end
    return df
end

function deleteRow!(df::DataFrame, colname::Symbol)
    return df[.!ismissing.(df[!, colname]), :]
end

function filterColumnsByCorrelation!(df::DataFrame, target::String, threshold::Float64, relation::String)
    if !(target in names(df))
        error("Target column $target not found in DataFrame.")
    end

    numeric_cols = [c for c in names(df) if eltype(df[!, c]) <: Number && c != target]
    complete_rows = .!ismissing.(df[!, target])
    for c in numeric_cols
        complete_rows .&= .!ismissing.(df[!, c])
    end
    
    filtered_df = df[complete_rows, [target; numeric_cols]]
    mat = Matrix(filtered_df)
    target_data = mat[:, 1]
    
    corr_values = Dict()
    for (i, c) in enumerate(numeric_cols)
        col_data = mat[:, i + 1]
        corr_val = cor(target_data, col_data)
        corr_values[c] = corr_val
    end

    if relation == "greater"
        cols_to_keep = [c for c in names(df) if c == target || !(c in numeric_cols) || abs(corr_values[c]) < threshold]
    elseif relation == "less"
        cols_to_keep = [c for c in names(df) if c == target || !(c in numeric_cols) || abs(corr_values[c]) > threshold]
    else
        error("Relation must be 'greater' or 'less'.")
    end

    return df[:, cols_to_keep]
end

# Load data
df = CSV.read("dat/bottle.csv", DataFrame)

# Preprocessing specifically for T_degC
println("Dataset dimensions: ", size(df))
printNewSection()

# Filter based on missing data threshold
thresh_missingPct = 30.0
prev_shape = size(df)[2]
df = deleteColumns!(df, thresh_missingPct)
current_shape = size(df)[2]
println("Columns before missing percentage threshold: ", prev_shape)
println("Columns after missing percentage threshold: ", current_shape)
println("Columns dropped: ", prev_shape - current_shape)
printNewSection()

# Drop rows with missing values in T_degC
prev_shape = size(df)[1]
df = deleteRow!(df, :T_degC)
current_shape = size(df)[1]
println("Rows before dropping missing T_degC: ", prev_shape)
println("Rows after dropping missing T_degC: ", current_shape)
printNewSection()

# Remove outliers
prev_shape = size(df)[1]
df = removeOutliersIQR!(df)
current_shape = size(df)[1]
println("Data with outliers: ", prev_shape)
println("Data without outliers: ", current_shape)
println("Data dropped: ", prev_shape - current_shape)
printNewSection()

# Block to remove columns one by one and handle null values
println("Iteratively removing columns and handling null values:")
cols_to_remove = names(df)
println("Original Dataframe shape: ", size(df))
for col in cols_to_remove
    # Remove the column
    temp_df = select(df, Not(col))
    
    # Remove rows with null values
    temp_df = dropmissing(temp_df)
    
    # Print the shape of the resulting DataFrame
    println("Removed column: ", col)
    println("Final DataFrame shape: ", size(temp_df))
    printNewSection()
end

# Remove a column "P_qual" that produce a lot of missing values
df = select(df, Not("P_qual"))
println("Column 'P_qual' removed.")
# Drop all missing values
prev_shape = size(df)
df = dropmissing(df)
current_shape = size(df)
println("Rows before removing null values: ", prev_shape[1])
println("Rows after removing null values: ", current_shape[1])
println("Rows dropped: ", prev_shape[1] - current_shape[1])
println("Current DataFrame shape: ", current_shape)

# Function that deletes string columns
function deleteStringColumns!(df::DataFrame)
    # Filtrar columnas que no son subtipos de AbstractString
    cols_to_keep = [c for c in names(df) if !(eltype(df[!, c]) <: AbstractString)]
    # Retornar el DataFrame solo con columnas válidas
    return df[:, cols_to_keep]
end
# Preprocess to delete most string columns
prev_shape = size(df)[2]
df = deleteStringColumns!(df)
current_shape = size(df)[2]
println("Data with string columns: ", prev_shape)
println("Data without string columns: ", current_shape)
println("Columns dropped: ", prev_shape - current_shape)
printNewSection()

# Show column types
println("Column types after cleaning:")
eltypes = Dict(col => eltype(df[!, col]) for col in names(df))
for (col, dtype) in eltypes
    println("Column: $col, Type: $dtype")
end

# Correlation matrix
cols, corr_matrix = calculateCorrelation(df)
displayCorrelation(cols, corr_matrix)

# Correlation filtering for T_degC
prev_shape = size(df)[2]
df = filterColumnsByCorrelation!(df, "Depthm", 0.9, "greater")
df = filterColumnsByCorrelation!(df, "Depthm", -0.9, "less")
current_shape = size(df)[2]
println("Columns in the DataFrame: ", prev_shape)
println("Columns that meet the correlation condition: ", current_shape)
println("Columns dropped: ", prev_shape - current_shape)
printNewSection()

using Statistics
using LinearAlgebra

# Define the target column and independent variables
target = :T_degC
target_name = "T_degC"
independent_vars = [col for col in names(df) if col != target_name]

# Function to calculate R^2 for a linear regression model
function calculate_r2(y_true, y_pred)
    ss_total = sum((y_true .- mean(y_true)).^2)
    ss_residual = sum((y_true .- y_pred).^2)
    return 1 - (ss_residual / ss_total)
end

# Function to check if a matrix is singular
function is_singular(X::Matrix{Float64})
    return rank(X' * X) < size(X, 2)
end

# Function to perform linear regression
function linear_regression(X::Matrix{Float64}, y::Vector{Float64})
    beta = (X' * X) \ (X' * y)  # Calculate coefficients
    y_pred = X * beta           # Predicted values
    return beta, y_pred
end

# Function to generate combinations of variables of a specific size
function generate_combinations(vars::Vector{String}, size::Int)
    function comb_recursive(current::Vector{String}, remaining::Vector{String}, k::Int)
        if length(current) == k
            return [current]
        elseif isempty(remaining)
            return []
        else
            include_current = comb_recursive(push!(copy(current), remaining[1]), remaining[2:end], k)
            exclude_current = comb_recursive(copy(current), remaining[2:end], k)
            return vcat(include_current, exclude_current)
        end
    end
    return comb_recursive(String[], vars, size)
end

# Dependent variable
y = df[!, target] |> collect  # Dependent variable as a vector

# Iterate through sizes from 7 to 17
for comb_size in 8:17
    println("Evaluating combinations of size $comb_size...")
    combinations = generate_combinations(independent_vars, comb_size)

    best_r2 = -Inf
    best_combination = []
    best_model = nothing

    # Evaluate each combination
    for combination in combinations
        X = hcat(ones(size(df, 1)), [df[!, col] |> collect for col in combination]...)
        
        # Skip singular matrices
        if is_singular(X)
            continue
        end

        beta, y_pred = linear_regression(X, y)
        r2 = calculate_r2(y, y_pred)
        
        if r2 > best_r2
            best_r2 = r2
            best_combination = combination
            best_model = beta
        end
    end

    # Output the best combination and R^2 for this size
    println("Best combination for size $comb_size: ", best_combination)
    println("Best R^2 value for size $comb_size: ", best_r2)
    println("Best model coefficients for size $comb_size: ", best_model)
    println("----------------------------------------------------")
end
