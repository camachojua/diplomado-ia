# Regression Analysis Report

## **Overview**

This report outlines the approach and methodology employed to identify the most significant factors influencing the temperature (`T_degC`) in the `bottle.csv` dataset from the CalCOFI dataset. Utilizing Julia for data preprocessing, exploratory data analysis (EDA), and linear regression modeling, the objective was to determine the optimal combination of independent variables that yield the most accurate predictions of `T_degC`.

## **Data Preprocessing**

### 1. **Data Loading**
The `bottle.csv` dataset was imported using Julia's `CSV` and `DataFrames` packages. An initial examination of the dataset's dimensions provided a foundational understanding of its structure and size.

### 2. **Handling Missing Data**
- **Missing Percentage Calculation:** A custom function computed the percentage of missing values for each column. Columns exceeding a 30% missing data threshold were deemed unreliable and subsequently removed to enhance data quality.
  
- **Dropping Incomplete Rows:** Specifically, rows with missing values in the target column `T_degC` were excluded to maintain the integrity of the regression analysis.

### 3. **Outlier Removal**
To ensure robust model performance, outliers in numerical columns were identified and eliminated using the Interquartile Range (IQR) method. Values falling outside the range `[Q1 - 1.5 * IQR, Q3 + 1.5 * IQR]` were considered outliers and removed.

### 4. **Column Filtering Based on Correlation**
- **Correlation Analysis:** A Pearson correlation matrix was computed for all numerical columns. This matrix served as a basis for identifying multicollinearity among variables.
  
- **Threshold-Based Filtering:** Columns exhibiting an absolute correlation greater than 0.9 with the target variable `T_degC` were removed. This step aimed to eliminate highly collinear predictors, thereby simplifying the model and preventing overfitting.

### 5. **String Columns Removal**
Non-numeric (string) columns were excluded from the analysis to ensure compatibility with the linear regression models.

### 6. **Final Data Cleaning**
After the above steps, the dataset underwent a final cleansing to remove any remaining rows with null values, resulting in a refined dataset ready for regression analysis.

## **Exploratory Data Analysis (EDA)**

### 1. **Correlation Matrix Visualization**
A heatmap representing the Pearson correlation coefficients between numerical variables was generated. This visualization facilitated the identification of relationships and potential predictors for `T_degC`.

### 2. **Descriptive Statistics**
Key statistical measures such as mean, standard deviation, and range were computed for each numerical column, providing insights into the data distribution and variability.

## **Regression Analysis**

### 1. **Modeling Approach**
The analysis involved performing multiple linear regression models by systematically combining different sets of independent variables. The goal was to identify the combination that maximizes the coefficient of determination ($R^2$), indicating the proportion of variance in `T_degC` explained by the predictors.

### 2. **Variable Combination Strategy**
- **Combination Sizes:** Independent variables were combined in groups ranging from 8 to 17 to explore various model complexities.
  
- **Iterative Evaluation:** For each combination size, all possible subsets of variables were evaluated. The combinations were assessed based on their $R^2$ values, and the best-performing set for each size was recorded.

### 3. **Handling Multicollinearity**
Before fitting each model, checks were performed to ensure that the predictor matrix was non-singular, thereby avoiding issues related to multicollinearity that could distort the regression coefficients.

### 4. **Performance Metric**
The primary metric for model evaluation was the $R^2$ value. Higher $R^2$ values indicate better model fit, with values closer to 1 representing a strong explanatory power of the predictors.

## **Key Findings**

1. **Data Quality Improvement:**
   - Removal of columns with excessive missing data and outliers significantly enhanced the dataset's quality, leading to more reliable regression models.
   
2. **Impact of Multicollinearity:**
   - By filtering out highly correlated variables, the analysis mitigated the risks of multicollinearity, ensuring that each predictor contributed uniquely to the model.

3. **Optimal Variable Combinations:**
   - Through exhaustive evaluation, specific combinations of independent variables were identified that provided the highest $R^2$ values, indicating superior predictive performance for `T_degC`.
   
4. **Predictive Insights:**
   - The final models highlighted key factors that are most influential in determining water temperature, offering valuable insights for further ecological or environmental studies.

## **Conclusion**

The regression analysis successfully identified the most important factors influencing `T_degC` in the `bottle.csv` dataset. Through meticulous data preprocessing, including handling missing values and outliers, and strategic variable selection based on correlation analysis, the study achieved robust and accurate predictive models. The systematic combination and evaluation of independent variables using linear regression in Julia culminated in the identification of optimal predictors, laying the groundwork for future predictive modeling and decision-making processes within the CalCOFI framework.
