"""
# Exercise 2: Regression
"""

using DataFrames, CSV
using Statistics
using Plots
using GLM
using StatsModels#MultivariateStats
using Random

#Read the data already cleaned on the EDA 
bottle_cleaned = CSV.read("/Users/marbazua/Documents/Diplomado/Mar_Bazua/regression/bazua_mar/dat/bottle_cleanData.csv", DataFrame, delim=',', header=true)


#we want to include in the model only variables that make sense according to the data dictionary
bottle_cleaned=bottle_cleaned[:, [:T_degC, :Depthm, :Salnty, :O2ml_L, :STheta, :O2Sat, :R_SVA, :R_DYNHT, :R_O2, :R_NO3, :R_NO2]]

#Impute missing values with the mean of it's column
# Loop through each column and impute missing values with the mean
for col in names(bottle_cleaned)
    if eltype(bottle_cleaned[!, col]) <: Union{Missing, Number}  # Check if the column is numeric with missing values
        mean_val = mean(skipmissing(bottle_cleaned[!, col]))  # Compute mean excluding missing values
        bottle_cleaned[!, col] = coalesce.(bottle_cleaned[!, col], mean_val)  # Replace missing with the mean
    end
end

#println("\nAfter Mean Imputation:")
#println(bottle_cleaned)

### Model metrics
function model_metrics(model)
    y_true = test_data.T_degC
    y_pred = predict(model, test_data)

    mse = mean((y_true .- y_pred).^2)
    println("Mean Squared Error (MSE): ", mse)

    rmse = sqrt(mse)
    println("Root Mean Squared Error (RMSE): ", rmse)

    # Compute the total sum of squares (SST) and residual sum of squares (SSE)
    sst = sum((y_true .- mean(y_true)).^2)    # Total sum of squares
    sse = sum((y_true .- y_pred).^2)          # Residual sum of squares

    # Compute R²
    r2 = 1 - sse / sst

    println("R-squared: ", r2)

    ## Plot
    scatter(y_true, y_pred, xlabel="True Values", ylabel="Predicted Values", title="Predicted vs True Values")
end

## Split the data into test and train
# Shuffle data and split manually
Random.seed!(1234)  # For reproducibility
n = size(bottle_cleaned, 1)
shuffle_indices = randperm(n)

# Define split point
split_point = Int(round(0.8 * n))

# Training and testing indices
train_indices = shuffle_indices[1:split_point]
test_indices = shuffle_indices[split_point+1:end]

# Create training and testing datasets
train_data = bottle_cleaned[train_indices, :]
test_data = bottle_cleaned[test_indices, :]

## Round 1 - All the variables
# Extract the names of all explanatory variables (excluding the response variable 'T_degC')
explanatory_vars = names(train_data) |> x -> filter(v -> v != "T_degC", x)

# Convert column names to symbols
explanatory_vars_symbols = Symbol.(explanatory_vars)

# Dynamically construct the formula using symbols
formula = Term(:T_degC) ~ sum(Term(v) for v in explanatory_vars_symbols)

# Fit the linear model
model1 = lm(formula, train_data)

# View the results
println(model1)

model_metrics(model1)

# Remove the least significant variables (R_O2 and O2ml_L )
# Fit the linear model
model2 = lm(@formula(T_degC ~  1 + Depthm + Salnty  + STheta + O2Sat + R_SVA + R_DYNHT + R_NO3 + R_NO2), train_data)

# View the results
println(model2)
model_metrics(model2)
 