# CalCOFI bottle.csv: Análisis de Regresión Lineal y Limpieza de Datos
Este informe detalla el proceso de análisis realizado sobre el conjunto de datos **bottle.csv** del proyecto CalCOFI (California Cooperative Oceanic Fisheries Investigations) relacionados con las condiciones oceanográficas. El análisis se enfoca en la limpieza de datos, la exploración de variables y la creación de modelos de regresión lineal para predecir la temperatura (**"T_degC"**) en función de diversas variables.

## 1. Carga y Preparación de los Datos

Se utiliza el archivo de datos `bottle_cleaned.csv` después de realizar la limpieza y análisis exploratorio del dataset `bottle.csv`. Es cargado en un `DataFrame` de Julia utilizando el paquete `CSV` y se verifica su existencia antes de cargarlo. 



```julia
using GLM, DataFrames, CSV, StatsBase, Plots
	
# Cargar los datos
data = CSV.read("bottle_cleaned.csv", DataFrame)

describe(select(data, Not(:Depth_ID)))
```




<div><div style = "float: left;"><span>6×7 DataFrame</span></div><div style = "clear: both;"></div></div><div class = "data-frame" style = "overflow-x: scroll;"><table class = "data-frame" style = "margin-bottom: 6px;"><thead><tr class = "header"><th class = "rowNumber" style = "font-weight: bold; text-align: right;">Row</th><th style = "text-align: left;">variable</th><th style = "text-align: left;">mean</th><th style = "text-align: left;">min</th><th style = "text-align: left;">median</th><th style = "text-align: left;">max</th><th style = "text-align: left;">nmissing</th><th style = "text-align: left;">eltype</th></tr><tr class = "subheader headerLastRow"><th class = "rowNumber" style = "font-weight: bold; text-align: right;"></th><th title = "Symbol" style = "text-align: left;">Symbol</th><th title = "Union{Nothing, Float64}" style = "text-align: left;">Union…</th><th title = "Any" style = "text-align: left;">Any</th><th title = "Union{Nothing, Float64}" style = "text-align: left;">Union…</th><th title = "Any" style = "text-align: left;">Any</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Type" style = "text-align: left;">Type</th></tr></thead><tbody><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1</td><td style = "text-align: left;">Sta_ID</td><td style = "font-style: italic; text-align: left;"></td><td style = "text-align: left;">001.0 168.0</td><td style = "font-style: italic; text-align: left;"></td><td style = "text-align: left;">176.7 030.0</td><td style = "text-align: right;">0</td><td style = "text-align: left;">String15</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">2</td><td style = "text-align: left;">Depthm</td><td style = "text-align: left;">168.405</td><td style = "text-align: left;">0</td><td style = "text-align: left;">119.0</td><td style = "text-align: left;">676</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Int64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">3</td><td style = "text-align: left;">T_degC</td><td style = "text-align: left;">11.2116</td><td style = "text-align: left;">2.88</td><td style = "text-align: left;">10.41</td><td style = "text-align: left;">23.25</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Float64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">4</td><td style = "text-align: left;">Salnty</td><td style = "text-align: left;">33.7899</td><td style = "text-align: left;">32.446</td><td style = "text-align: left;">33.795</td><td style = "text-align: left;">35.15</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Float64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">5</td><td style = "text-align: left;">O2ml_L</td><td style = "text-align: left;">3.55094</td><td style = "text-align: left;">-0.01</td><td style = "text-align: left;">3.7</td><td style = "text-align: left;">11.13</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Float64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">6</td><td style = "text-align: left;">STheta</td><td style = "text-align: left;">25.727</td><td style = "text-align: left;">22.709</td><td style = "text-align: left;">25.886</td><td style = "text-align: left;">27.42</td><td style = "text-align: right;">215</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr></tbody></table></div>



### Exploración Inicial

Se realiza una exploración inicial del conjunto de datos:
- **Forma del conjunto de datos**: El número de filas y columnas se imprime para asegurar que se ha cargado correctamente.
- **Tipos de datos**: Se obtienen los tipos de datos de cada columna del `DataFrame` para comprender la estructura del dataset.



```julia
# Función para obtener la forma del dataset (número de filas y columnas)
function dataShape(data)
    rows, cols = size(data)
	println("No. of rows: $rows \nNo. of Columns: $cols \n")
end
	
# Mostrar la forma del dataset (número de filas y columnas)
dataShape(data)
```

    No. of rows: 621955 
    No. of Columns: 7 
    



```julia
# Función para obtener los tipos de datos de cada columna en un DataFrame
function dataType(df::DataFrame)
    results = DataFrame(column_name = names(df), data_type = eltype.(eachcol(df)))
    return results    
end
```




    dataType (generic function with 1 method)



## 2. Manejo de Valores Faltantes

El análisis incluye un enfoque para manejar los valores faltantes en los datos. Se implementan las siguientes funciones:

- **Cálculo de valores faltantes**: Se calcula el número y el porcentaje de valores faltantes por columna, ayudando a identificar posibles problemas en los datos.
- **Eliminación de filas**: Se desarrolló una función para eliminar filas que contienen valores faltantes en una columna específica (en este caso, en la columna `STheta`).



```julia
# Función para obtener los tipos de datos de cada columna en un DataFrame
function dataType(df::DataFrame)
    results = DataFrame(column_name = names(df), data_type = eltype.(eachcol(df)))
    return results    
end

# Función para contar el número de valores faltantes en una columna específica
function count_missing(df::DataFrame, col::String)
    if col in names(df)
        count = 0
        for value in df[!, col]
            if ismissing(value)
                count += 1
            end
        end
        return (col, count)
    else
        println("Column: '$col' does not exist in the DataFrame.")
        return nothing
    end
end

# Función para calcular el porcentaje de valores faltantes por columna
function dataMissingPercentage(df::DataFrame)
    # Recupera los tipos de datos
    data_types = dataType(df)

    # Agrega una columna para los porcentajes de valores faltantes
    data_types[!, :missing_percent] .= 0.0

    # Calcula los porcentajes de valores faltantes por columna
    for col in names(df)
        _, missing_count = count_missing(df, col)
        missing_percentage = (missing_count * 100) / nrow(df) #Calcula el porcentaje
        row_idx = findfirst(==(col), data_types[!, :column_name]) # Encuentra el índice
        data_types[row_idx, :missing_percent] = missing_percentage
    end
	
    return data_types
end
```




    dataMissingPercentage (generic function with 1 method)




```julia
dataMissingPercentage(data)
```




<div><div style = "float: left;"><span>7×3 DataFrame</span></div><div style = "clear: both;"></div></div><div class = "data-frame" style = "overflow-x: scroll;"><table class = "data-frame" style = "margin-bottom: 6px;"><thead><tr class = "header"><th class = "rowNumber" style = "font-weight: bold; text-align: right;">Row</th><th style = "text-align: left;">column_name</th><th style = "text-align: left;">data_type</th><th style = "text-align: left;">missing_percent</th></tr><tr class = "subheader headerLastRow"><th class = "rowNumber" style = "font-weight: bold; text-align: right;"></th><th title = "String" style = "text-align: left;">String</th><th title = "Type" style = "text-align: left;">Type</th><th title = "Float64" style = "text-align: left;">Float64</th></tr></thead><tbody><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1</td><td style = "text-align: left;">Sta_ID</td><td style = "text-align: left;">String15</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">2</td><td style = "text-align: left;">Depth_ID</td><td style = "text-align: left;">String</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">3</td><td style = "text-align: left;">Depthm</td><td style = "text-align: left;">Int64</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">4</td><td style = "text-align: left;">T_degC</td><td style = "text-align: left;">Float64</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">5</td><td style = "text-align: left;">Salnty</td><td style = "text-align: left;">Float64</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">6</td><td style = "text-align: left;">O2ml_L</td><td style = "text-align: left;">Float64</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">7</td><td style = "text-align: left;">STheta</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">0.0345684</td></tr></tbody></table></div>




```julia
# Función para eliminar filas con valores faltantes en una columna específica
function deleteRow(df::DataFrame, column::Symbol)
    # Verificar si la columna existe en el DataFrame
    if hasproperty(df, column)
       # Identificar los indices de las filas con valores missing
        missing_indices = findall(ismissing, df[:, column])

        # Eliminar las filas con valores missing
        delete!(df, missing_indices)

        println("Rows with missing values in column '$column' have been deleted")
    else
        println("Column '$column' does not exist in the DataFrame")
    end

    println("Updated DataFrame:")
    println(dataShape(df))
    println(dataType(df))

    return df
end
```




    deleteRow (generic function with 1 method)




```julia
clean_data = deleteRow(data, :STheta)
dataMissingPercentage(clean_data)
```

    Rows with missing values in column 'STheta' have been deleted
    Updated DataFrame:
    No. of rows: 621740 
    No. of Columns: 7 
    
    nothing
    [1m7×2 DataFrame[0m
    [1m Row [0m│[1m column_name [0m[1m data_type               [0m
         │[90m String      [0m[90m Type                    [0m
    ─────┼──────────────────────────────────────
       1 │ Sta_ID       String15
       2 │ Depth_ID     String
       3 │ Depthm       Int64
       4 │ T_degC       Float64
       5 │ Salnty       Float64
       6 │ O2ml_L       Float64
       7 │ STheta       Union{Missing, Float64}





<div><div style = "float: left;"><span>7×3 DataFrame</span></div><div style = "clear: both;"></div></div><div class = "data-frame" style = "overflow-x: scroll;"><table class = "data-frame" style = "margin-bottom: 6px;"><thead><tr class = "header"><th class = "rowNumber" style = "font-weight: bold; text-align: right;">Row</th><th style = "text-align: left;">column_name</th><th style = "text-align: left;">data_type</th><th style = "text-align: left;">missing_percent</th></tr><tr class = "subheader headerLastRow"><th class = "rowNumber" style = "font-weight: bold; text-align: right;"></th><th title = "String" style = "text-align: left;">String</th><th title = "Type" style = "text-align: left;">Type</th><th title = "Float64" style = "text-align: left;">Float64</th></tr></thead><tbody><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1</td><td style = "text-align: left;">Sta_ID</td><td style = "text-align: left;">String15</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">2</td><td style = "text-align: left;">Depth_ID</td><td style = "text-align: left;">String</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">3</td><td style = "text-align: left;">Depthm</td><td style = "text-align: left;">Int64</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">4</td><td style = "text-align: left;">T_degC</td><td style = "text-align: left;">Float64</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">5</td><td style = "text-align: left;">Salnty</td><td style = "text-align: left;">Float64</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">6</td><td style = "text-align: left;">O2ml_L</td><td style = "text-align: left;">Float64</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">7</td><td style = "text-align: left;">STheta</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">0.0</td></tr></tbody></table></div>



## 3. Modelado de Regresión Lineal

Una vez que los datos fueron limpiados, se ajustaron múltiples modelos de regresión lineal con diferentes combinaciones de variables independientes para predecir la temperatura (`T_degC`). Se probaron las siguientes fórmulas:

### Combinaciones de Variables

Se definieron varias combinaciones de variables independientes, que incluyen:

- Una sola variable: `Salnty`, `Depthm`, `O2ml_L`, `STheta`.
- Combinaciones de dos variables: `Salnty + Depthm`, `Salnty + O2ml_L`, etc.
- Combinaciones de tres y cuatro variables: `Salnty + Depthm + O2ml_L`, etc.


```julia
# Definir combinaciones de variables independientes para probar
formulas = [
	@formula(T_degC ~ Salnty),
	@formula(T_degC ~ Depthm),
	@formula(T_degC ~ O2ml_L),
	@formula(T_degC ~ STheta),
	@formula(T_degC ~ Salnty + Depthm),
	@formula(T_degC ~ Salnty + O2ml_L),
	@formula(T_degC ~ Depthm + O2ml_L),
	@formula(T_degC ~ STheta + Salnty),
	@formula(T_degC ~ STheta + Depthm),
	@formula(T_degC ~ STheta + O2ml_L),
	@formula(T_degC ~ Salnty + Depthm + O2ml_L),
	@formula(T_degC ~ Salnty + Depthm + STheta),
	@formula(T_degC ~ Salnty + O2ml_L + STheta),
	@formula(T_degC ~ Depthm + O2ml_L + STheta),
	@formula(T_degC ~ Salnty + Depthm + O2ml_L + STheta),
]
```




    15-element Vector{FormulaTerm{Term}}:
     T_degC ~ Salnty
     T_degC ~ Depthm
     T_degC ~ O2ml_L
     T_degC ~ STheta
     T_degC ~ Salnty + Depthm
     T_degC ~ Salnty + O2ml_L
     T_degC ~ Depthm + O2ml_L
     T_degC ~ STheta + Salnty
     T_degC ~ STheta + Depthm
     T_degC ~ STheta + O2ml_L
     T_degC ~ Salnty + Depthm + O2ml_L
     T_degC ~ Salnty + Depthm + STheta
     T_degC ~ Salnty + O2ml_L + STheta
     T_degC ~ Depthm + O2ml_L + STheta
     T_degC ~ Salnty + Depthm + O2ml_L + STheta



### Evaluación de Modelos

Los modelos fueron evaluados utilizando dos métricas clave:
- **R² (Coeficiente de Determinación)**: Mide el porcentaje de la variabilidad de la variable dependiente (`T_degC`) que es explicada por el modelo.
- **AIC (Criterio de Información de Akaike)**: Evalúa la calidad del modelo penalizando la complejidad del modelo (más variables).



```julia
# Crear una tabla para almacenar los resultados
results = DataFrame(
	Formula = String[],
	R2 = Float64[],
	AIC = Float64[]
)
```




<div><div style = "float: left;"><span>0×3 DataFrame</span></div><div style = "clear: both;"></div></div><div class = "data-frame" style = "overflow-x: scroll;"><table class = "data-frame" style = "margin-bottom: 6px;"><thead><tr class = "header"><th class = "rowNumber" style = "font-weight: bold; text-align: right;">Row</th><th style = "text-align: left;">Formula</th><th style = "text-align: left;">R2</th><th style = "text-align: left;">AIC</th></tr><tr class = "subheader headerLastRow"><th class = "rowNumber" style = "font-weight: bold; text-align: right;"></th><th title = "String" style = "text-align: left;">String</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th></tr></thead><tbody></tbody></table></div>




```julia
# Ajustar modelos y guardar métricas
for formula in formulas
	model = lm(formula, clean_data)
	push!(results, (string(formula), r2(model), aic(model)))
end
```

A continuación, se presentan los resultados de los modelos ajustados:


```julia
# Mostrar los resultados
println("Resultados de los modelos:")
results
```

    Resultados de los modelos:





<div><div style = "float: left;"><span>15×3 DataFrame</span></div><div style = "clear: both;"></div></div><div class = "data-frame" style = "overflow-x: scroll;"><table class = "data-frame" style = "margin-bottom: 6px;"><thead><tr class = "header"><th class = "rowNumber" style = "font-weight: bold; text-align: right;">Row</th><th style = "text-align: left;">Formula</th><th style = "text-align: left;">R2</th><th style = "text-align: left;">AIC</th></tr><tr class = "subheader headerLastRow"><th class = "rowNumber" style = "font-weight: bold; text-align: right;"></th><th title = "String" style = "text-align: left;">String</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th></tr></thead><tbody><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1</td><td style = "text-align: left;">T_degC ~ Salnty</td><td style = "text-align: right;">0.278154</td><td style = "text-align: right;">3.23901e6</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">2</td><td style = "text-align: left;">T_degC ~ Depthm</td><td style = "text-align: right;">0.64892</td><td style = "text-align: right;">2.79086e6</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">3</td><td style = "text-align: left;">T_degC ~ O2ml_L</td><td style = "text-align: right;">0.641014</td><td style = "text-align: right;">2.80471e6</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">4</td><td style = "text-align: left;">T_degC ~ STheta</td><td style = "text-align: right;">0.925292</td><td style = "text-align: right;">1.82877e6</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">5</td><td style = "text-align: left;">T_degC ~ Salnty + Depthm</td><td style = "text-align: right;">0.652045</td><td style = "text-align: right;">2.7853e6</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">6</td><td style = "text-align: left;">T_degC ~ Salnty + O2ml_L</td><td style = "text-align: right;">0.728459</td><td style = "text-align: right;">2.63114e6</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">7</td><td style = "text-align: left;">T_degC ~ Depthm + O2ml_L</td><td style = "text-align: right;">0.690753</td><td style = "text-align: right;">2.71198e6</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">8</td><td style = "text-align: left;">T_degC ~ STheta + Salnty</td><td style = "text-align: right;">0.991792</td><td style = "text-align: right;">4.55642e5</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9</td><td style = "text-align: left;">T_degC ~ STheta + Depthm</td><td style = "text-align: right;">0.925293</td><td style = "text-align: right;">1.82875e6</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">10</td><td style = "text-align: left;">T_degC ~ STheta + O2ml_L</td><td style = "text-align: right;">0.945592</td><td style = "text-align: right;">1.63163e6</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">11</td><td style = "text-align: left;">T_degC ~ Salnty + Depthm + O2ml_L</td><td style = "text-align: right;">0.762537</td><td style = "text-align: right;">2.54776e6</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">12</td><td style = "text-align: left;">T_degC ~ Salnty + Depthm + STheta</td><td style = "text-align: right;">0.99585</td><td style = "text-align: right;">31639.2</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">13</td><td style = "text-align: left;">T_degC ~ Salnty + O2ml_L + STheta</td><td style = "text-align: right;">0.992912</td><td style = "text-align: right;">3.64461e5</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">14</td><td style = "text-align: left;">T_degC ~ Depthm + O2ml_L + STheta</td><td style = "text-align: right;">0.951409</td><td style = "text-align: right;">1.56133e6</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">15</td><td style = "text-align: left;">T_degC ~ Salnty + Depthm + O2ml_L + STheta</td><td style = "text-align: right;">0.995891</td><td style = "text-align: right;">25486.3</td></tr></tbody></table></div>




```julia
# Seleccionar el mejor modelo según R^2 o AIC
best_model_r2 = results[results.R2 .== maximum(results.R2), :]
best_model_aic = results[results.AIC .== minimum(results.AIC), :]
```




<div><div style = "float: left;"><span>1×3 DataFrame</span></div><div style = "clear: both;"></div></div><div class = "data-frame" style = "overflow-x: scroll;"><table class = "data-frame" style = "margin-bottom: 6px;"><thead><tr class = "header"><th class = "rowNumber" style = "font-weight: bold; text-align: right;">Row</th><th style = "text-align: left;">Formula</th><th style = "text-align: left;">R2</th><th style = "text-align: left;">AIC</th></tr><tr class = "subheader headerLastRow"><th class = "rowNumber" style = "font-weight: bold; text-align: right;"></th><th title = "String" style = "text-align: left;">String</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th></tr></thead><tbody><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1</td><td style = "text-align: left;">T_degC ~ Salnty + Depthm + O2ml_L + STheta</td><td style = "text-align: right;">0.995891</td><td style = "text-align: right;">25486.3</td></tr></tbody></table></div>



### Resultados Destacados

- El **Modelo 15** (`T_degC ~ Salnty + Depthm + O2ml_L + STheta`) tiene el **mejor R²** (0.995891) y el **mejor AIC** (25486.3), lo que indica un excelente ajuste con el menor costo en términos de complejidad.
- El **Modelo 12** (`T_degC ~ Salnty + Depthm + STheta`) también tiene un alto R² (0.99585) pero un AIC más alto (31639.2), lo que sugiere que el Modelo 15 es preferible debido a su menor complejidad.



```julia
println("Mejor modelo por R^2:")
println(best_model_r2)
println("Mejor modelo por AIC:")
println(best_model_aic)
```

    Mejor modelo por R^2:
    [1m1×3 DataFrame[0m
    [1m Row [0m│[1m Formula                           [0m[1m R2       [0m[1m AIC     [0m
         │[90m String                            [0m[90m Float64  [0m[90m Float64 [0m
    ─────┼──────────────────────────────────────────────────────
       1 │ T_degC ~ Salnty + Depthm + O2ml_…  0.995891  25486.3
    Mejor modelo por AIC:
    [1m1×3 DataFrame[0m
    [1m Row [0m│[1m Formula                           [0m[1m R2       [0m[1m AIC     [0m
         │[90m String                            [0m[90m Float64  [0m[90m Float64 [0m
    ─────┼──────────────────────────────────────────────────────
       1 │ T_degC ~ Salnty + Depthm + O2ml_…  0.995891  25486.3


## 4. Predicción y Visualización

El **Modelo 15** fue elegido como el mejor modelo, y se utilizó para realizar predicciones de la temperatura (`T_degC`). A continuación, se muestra la comparación gráfica entre los valores reales de temperatura y las predicciones del modelo:



```julia
# Ajustar y mostrar detalles del mejor modelo
best_formula = @formula(T_degC ~ Salnty + Depthm + O2ml_L + STheta)
best_model = lm(best_formula, clean_data)
```




    StatsModels.TableRegressionModel{LinearModel{GLM.LmResp{Vector{Float64}}, GLM.DensePredChol{Float64, LinearAlgebra.CholeskyPivoted{Float64, Matrix{Float64}, Vector{Int64}}}}, Matrix{Float64}}
    
    T_degC ~ 1 + Salnty + Depthm + O2ml_L + STheta
    
    Coefficients:
    ──────────────────────────────────────────────────────────────────────────────────
                       Coef.   Std. Error         t  Pr(>|t|)    Lower 95%   Upper 95%
    ──────────────────────────────────────────────────────────────────────────────────
    (Intercept)   7.80105     0.055366       140.90    <1e-99   7.69253      7.90956
    Salnty        3.66671     0.00141337    2594.30    <1e-99   3.66394      3.66948
    Depthm       -0.00278774  4.15232e-6    -671.37    <1e-99  -0.00279588  -0.0027796
    O2ml_L        0.0403466   0.000513003     78.65    <1e-99   0.0393411    0.0413521
    STheta       -4.67068     0.000786039  -5942.05    <1e-99  -4.67222     -4.66914
    ──────────────────────────────────────────────────────────────────────────────────




```julia
println("\nDetalles del mejor modelo ajustado:")
println("Coeficientes: ", coef(best_model))
println("Errores estándar: ", stderror(best_model))
println("R²: ", r2(best_model))
println("AIC: ", aic(best_model))
```

    
    Detalles del mejor modelo ajustado:
    [7.801048282164321, 3.6667055505874604, -0.0027877382140480264, 0.04034659272579911, -4.670683039249659]
    Errores estándar: [0.05536604154247739, 0.0014133674455134465, 4.15231723726391e-6, 0.0005130032047812894, 0.0007860388715614741]
    R²: 0.9958908898492872
    AIC: 25486.252708672033



```julia
# Predicciones
clean_data[:, :Prediction] = predict(best_model)
```




    621740-element Vector{Float64}:
     10.683172907621994
     18.656497197392582
     10.65151529232169
     10.636593875362152
     10.65816610353923
     10.673297087457513
     10.678497533429251
     10.594974911208183
     10.578078513482751
     10.45323686632213
     10.247011994420049
      9.736980796887934
      9.69890883595994
      ⋮
      7.844714436998942
      7.577721778371526
      6.98220299349164
      6.771090501171216
      6.4068218506166374
      6.033179124794685
      5.867493950653511
     19.041886276067686
     19.035516783522908
     18.96546351564338
     18.335528765220403
     17.60529103186066




```julia
# Graficar datos reales vs predicciones
scatter(
	clean_data.T_degC, clean_data.Prediction,
	xlabel = "T_degC Real",
	ylabel = "T_degC Predicho",
	title = "Modelo: T_degC Predicho vs Real",
	legend = false,
	label = "",
	color = :blue,
	markerstrokecolor = :black
)

# Linea de referencia (predicción perfecta)
plot!(0:0.1:maximum(clean_data.T_degC), 0:0.1: maximum(clean_data.T_degC),
	label = "Perfecto",
	color = :red,
	linestyle = :dash
)

savefig("best_regression.png")
```

![Gráfico de Predicciones](../fig/best_regression.png)

### Análisis Gráfico

El gráfico muestra la relación entre los valores reales de temperatura (`T_degC`) y las predicciones del modelo. La línea roja discontinua indica una predicción perfecta, lo que permite observar cuán bien el modelo se ajusta a los datos reales.


## 5. Conclusión

El análisis de regresión lineal revela que el **Modelo 15** (`T_degC ~ Salnty + Depthm + O2ml_L + STheta`) es el mejor modelo en términos de ajuste (R²) y simplicidad (AIC). Este modelo proporciona una excelente aproximación para predecir la temperatura en función de las variables seleccionadas.

Se recomienda realizar una validación cruzada para confirmar la robustez del modelo en datos no vistos y considerar la posible colinealidad entre las variables al realizar ajustes adicionales.

---

**Código Fuente**: El código utilizado para este análisis está disponible en el archivo `regression.jl`.

