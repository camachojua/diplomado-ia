using GLM, DataFrames, CSV, StatsBase, Plots

# Función para obtener la forma del dataset (número de filas y columnas)
function dataShape(data)
    rows, cols = size(data)
	println("No. of rows: $rows \nNo. of Columns: $cols \n")
end

# Función para obtener los tipos de datos de cada columna en un DataFrame
function dataType(df::DataFrame)
    results = DataFrame(column_name = names(df), data_type = eltype.(eachcol(df)))
    return results    
end

# Función para contar el número de valores faltantes en una columna específica
function count_missing(df::DataFrame, col::String)
    if col in names(df)
        count = 0
        for value in df[!, col]
            if ismissing(value)
                count += 1
            end
        end
        return (col, count)
    else
        println("Column: '$col' does not exist in the DataFrame.")
        return nothing
    end
end

# Función para calcular el porcentaje de valores faltantes por columna
function dataMissingPercentage(df::DataFrame)
    # Recupera los tipos de datos
    data_types = dataType(df)

    # Agrega una columna para los porcentajes de valores faltantes
    data_types[!, :missing_percent] .= 0.0

    # Calcula los porcentajes de valores faltantes por columna
    for col in names(df)
        _, missing_count = count_missing(df, col)
        missing_percentage = (missing_count * 100) / nrow(df) #Calcula el porcentaje
        row_idx = findfirst(==(col), data_types[!, :column_name]) # Encuentra el índice
        data_types[row_idx, :missing_percent] = missing_percentage
    end
	
    return data_types
end

# Función para eliminar filas con valores faltantes en una columna específica
function deleteRow(df::DataFrame, column::Symbol)
    # Verificar si la columna existe en el DataFrame
    if hasproperty(df, column)
       # Identificar los indices de las filas con valores missing
        missing_indices = findall(ismissing, df[:, column])

        # Eliminar las filas con valores missing
        delete!(df, missing_indices)

        println("Rows with missing values in column '$column' have been deleted")
    else
        println("Column '$column' does not exist in the DataFrame")
    end

    println("Updated DataFrame:")
    println(dataShape(df))
    println(dataType(df))

    return df
end

# Construye la ruta del archivo
dataset_path = joinpath(@__DIR__, "../dat/bottle_cleaned.csv")

# Verifica si el archivo existe
if !isfile(dataset_path)
    error("El archivo no existe en la ruta: $dataset_path")
end

# Carga el archivo
data = CSV.read(dataset_path, DataFrame)
println("Archivo cargado exitosamente.")

println(dataMissingPercentage(data))
println(describe(data))

clean_data = deleteRow(data, :STheta)
println(dataMissingPercentage(clean_data))

# Definir combinaciones de variables independientes para probar
formulas = [
	@formula(T_degC ~ Salnty),
	@formula(T_degC ~ Depthm),
	@formula(T_degC ~ O2ml_L),
	@formula(T_degC ~ STheta),
	@formula(T_degC ~ Salnty + Depthm),
	@formula(T_degC ~ Salnty + O2ml_L),
	@formula(T_degC ~ Depthm + O2ml_L),
	@formula(T_degC ~ STheta + Salnty),
	@formula(T_degC ~ STheta + Depthm),
	@formula(T_degC ~ STheta + O2ml_L),
	@formula(T_degC ~ Salnty + Depthm + O2ml_L),
	@formula(T_degC ~ Salnty + Depthm + STheta),
	@formula(T_degC ~ Salnty + O2ml_L + STheta),
	@formula(T_degC ~ Depthm + O2ml_L + STheta),
	@formula(T_degC ~ Salnty + Depthm + O2ml_L + STheta),
]

# Crear una tabla para almacenar los resultados
results = DataFrame(
	Formula = String[],
	R2 = Float64[],
	AIC = Float64[]
)

# Ajustar modelos y guardar métricas
for formula in formulas
	model = lm(formula, clean_data)
	push!(results, (string(formula), r2(model), aic(model)))
end

# Mostrar los resultados
println("Resultados de los modelos:")
println(results)

# Seleccionar el mejor modelo según R^2 o AIC
best_model_r2 = results[results.R2 .== maximum(results.R2), :]
best_model_aic = results[results.AIC .== minimum(results.AIC), :]

println("Mejor modelo por R^2:")
println(best_model_r2)
println("Mejor modelo por AIC:")
println(best_model_aic)

# Ajustar y mostrar detalles del mejor modelo
best_formula = @formula(T_degC ~ Salnty + Depthm + O2ml_L + STheta)
best_model = lm(best_formula, clean_data)

println("\nDetalles del mejor modelo ajustado:")
println("Coeficientes: ", coef(best_model))
println("Errores estándar: ", stderror(best_model))
println("R²: ", r2(best_model))
println("AIC: ", aic(best_model))

# Predicciones
clean_data[:, :Prediction] = predict(best_model)

# Graficar datos reales vs predicciones
scatter(
	clean_data.T_degC, clean_data.Prediction,
	xlabel = "T_degC Real",
	ylabel = "T_degC Predicho",
	title = "Modelo: T_degC Predicho vs Real",
	legend = false,
	label = "",
	color = :blue,
	markerstrokecolor = :black
)

# Linea de referencia (predicción perfecta)
plot!(0:0.1:maximum(clean_data.T_degC), 0:0.1: maximum(clean_data.T_degC),
	label = "Perfecto",
	color = :red,
	linestyle = :dash
)

# Guardar el gráfico en un archivo
ruta_archivo = joinpath("fig", "best_regression.png")
savefig(ruta_archivo)
