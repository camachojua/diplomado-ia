# Regresión Lineal para Predecir `T_degC`.

## Objetivo

Determinar los factores más importantes que afectan la variable `T_degC` en el `bottle.csv` del dataset `CalCofi`, utilizando regresiones lineales con diferentes combinaciones de variables independientes.

---
Se realizó un análisis exploratorio de datos (EDA) que incluyó:

* Eliminación de columnas con valores missing superiores al 50%.
<br>

* Cálculo de correlaciones para seleccionar variables relacionadas con `T_degC`.
<br>

* Eliminación de filas con valores atípicos (`removeOutliersIQR`) y valores missing en columnas clave.
<br>

* Filtro de columnas por correlación `filterColumnsByCorrelation`
    1. **Correlación ≥ $0.99$**:
        - Columnas casi idénticas a la columna objetivo no aportan información adicional y pueden causar que el modelo se ajuste demasiado a los datos de entrenamiento.

    2. **Correlación ≤ $0.7$**:
        -  Permite mantener columnas que aún tienen una correlación moderada con la columna objetivo, aportando información útil. Esto ayuda a evitar eliminar columnas que podrían ser relevantes.
    <br>
    
    En resumen, estos valores mejoran la eficiencia y precisión del modelo al eliminar redundancia y ruido en los datos.

    Después de limpiar el conjunto de datos obtenemos un dataframe llamado `variables`.
<br>

* Revisión de la calidad del modelo.
Las columnas duplicadas se eliminan solo si tienen exactamente los mismos datos (incluso considerando valores null o missing). 

    ```julia
    begin
        # Identificar columnas con los mismos datos
        duplicates = []
        for i in 1:size(variables, 2)
            for j in (i+1):size(variables, 2)
                if all(variables[:, i] == variables[:, j])
                    push!(duplicates, (names(variables)[j]))
                end
            end
        end
        
        # Convertir el vector de duplicados a una cadena de texto 
        duplicates_str = join(duplicates, ", ") 
            println("Columnas duplicadas: ", duplicates_str)
    end
    ```
    Eliminar las variables redundantes puede mejorar el ajuste del modelo y reducir problemas en la interpretación de los coeficientes.

Como resultado, se generó el DataFrame `regression_data`, que contiene las variables relevantes para el modelo.

```julia
regression_data = select!(variables, Not(Symbol.(duplicates)))
``` 

El DataFrame tiene **222,428 filas** y **7 columnas**.


Se mostrarán las **primeras 13** y las **últimas 13** filas debido a la gran cantidad de filas.

| **O2ml\_L**<br>`Float64` | **O2Sat**<br>`Float64` | **Oxy\_µmol/Kg**<br>`Float64` | **R\_SVA**<br>`Float64` | **R\_O2**<br>`Float64` | **R\_O2Sat**<br>`Float64` | **T\_degC**<br>`Float64` |
|-------------------------:|-----------------------:|------------------------------:|------------------------:|-----------------------:|--------------------------:|-------------------------:|
| 6.04                     | 95.0                   | 263.089                       | 266.1                   | 6.04                   | 95.0                      | 10.29                    |
| 6.06                     | 95.3                   | 263.952                       | 263.3                   | 6.06                   | 95.3                      | 10.29                    |
| 6.04                     | 95.1                   | 263.08                        | 262.9                   | 6.04                   | 95.1                      | 10.33                    |
| 6.01                     | 94.8                   | 261.766                       | 260.4                   | 6.01                   | 94.8                      | 10.39                    |
| 6.01                     | 94.8                   | 261.765                       | 260.2                   | 6.01                   | 94.8                      | 10.4                     |
| 5.78                     | 91.1                   | 251.729                       | 253.2                   | 5.78                   | 91.1                      | 10.36                    |
| 5.76                     | 90.8                   | 250.854                       | 251.8                   | 5.76                   | 90.8                      | 10.35                    |
| 5.6                      | 88.1                   | 243.864                       | 243.6                   | 5.6                    | 88.1                      | 10.25                    |
| 5.07                     | 79.5                   | 220.757                       | 231.6                   | 5.07                   | 79.5                      | 10.05                    |
| 3.82                     | 59.3                   | 166.283                       | 204.7                   | 3.82                   | 59.3                      | 9.54                     |
| 3.76                     | 58.3                   | 163.668                       | 202.9                   | 3.76                   | 58.3                      | 9.5                      |
| 3.2                      | 49.2                   | 139.266                       | 185.0                   | 3.2                    | 49.2                      | 9.05                     |
| 3.1                      | 47.5                   | 134.908                       | 181.1                   | 3.1                    | 47.5                      | 8.93                     |          |
|  ⁝ | ⁝| ⁝|  ⁝ |  ⁝ | ⁝ |  ⁝|
| 1.12                     | 16.7                   | 48.7191                       | 139.9                   | 1.12                   | 16.7                      | 7.58                     |
| 0.72                     | 10.6                   | 31.3161                       | 130.8                   | 0.72                   | 10.6                      | 6.95                     |
| 0.4                      | 5.7                    | 17.3949                       | 115.1                   | 0.4                    | 5.7                       | 6.03                     |
| 1.47                     | 22.0                   | 63.948                        | 145.3                   | 1.47                   | 22.0                      | 7.75                     |
| 1.01                     | 15.0                   | 43.9334                       | 138.0                   | 1.01                   | 15.0                      | 7.44                     |
| 0.59                     | 8.6                    | 25.6604                       | 125.2                   | 0.59                   | 8.6                       | 6.65                     |
| 0.4                      | 5.7                    | 17.3947                       | 113.4                   | 0.4                    | 5.7                       | 5.93                     |
| 1.75                     | 26.5                   | 76.1388                       | 157.9                   | 1.75                   | 26.5                      | 8.38                     |
| 1.51                     | 22.6                   | 65.6901                       | 148.5                   | 1.51                   | 22.6                      | 7.83                     |
| 1.18                     | 17.4                   | 51.3277                       | 136.9                   | 1.18                   | 17.4                      | 7.09                     |
| 0.62                     | 9.0                    | 26.965                        | 124.3                   | 0.62                   | 9.0                       | 6.5                      |
| 0.4                      | 5.7                    | 17.3946                       | 112.9                   | 0.4                    | 5.7                       | 5.84                     |
| 6.4                      | 118.4                  | 279.077                       | 373.1                   | 6.4                    | 118.4 | 18.05|  


Mostramos mapa de calor de las correlaciones de `regression_data`.

![heatmap_Regression_1](../fig/heatmap_Regression_1.png)

---
## Carga de Librerías

- `CSV`: Lectura y escritura de archivos CSV.
- `DataFrames`: Manipulación de tablas de datos.
- `Plots`: Generación de gráficos.
- `Statistics`: Para realizar cálculos estadísticos.
- `GLM`: Modelos de regresión lineal y logística.
- `Combinatorics`: Generación de combinaciones y permutaciones.
- `PrettyTables`: Visualización tabular más estética.

``` julia
using CSV, GLM, Statistics, DataFrames, Combinatorics, Plots, PrettyTables
```

---
## Función para Evaluar Modelos (`evaluate_model`)

``` julia
function evaluate_model(formula::FormulaTerm, train_data::DataFrame, test_data::DataFrame)
    # Ajustar el modelo usando GLM
    model = lm(formula, train_data)

    # Predicciones en el conjunto de prueba
    y_pred = predict(model, test_data)
    y_ = test_data[:, :T_degC]  # Usamos el símbolo para acceder a la columna
    
    # Calcular métricas
    r2 = 1 - sum((y_ .- y_pred).^2) / sum((y_ .- mean(y_)).^2)
    ecm = mean((y_ .- y_pred).^2)
    
    return model, r2, ecm, y_, y_pred
end
```
Evalúa un modelo de regresión lineal, ajustándolo a los datos de entrenamiento y calculando el coeficiente de determinación \(R^2\), el error cuadrático medio (ECM), y las predicciones en los datos de prueba.


## Función para Evaluar Combinaciones de Variables

``` julia
function evaluate_combinations(target::Symbol, features::Vector{Symbol}, train_data::DataFrame, test_data::DataFrame)
    best_r2 = -Inf  # Mejor R^2 inicial
    best_model = nothing
    best_formula = nothing
    best_ecm = Inf  # Mejor ECM inicial
    best_y = nothing
    best_y_pred = nothing

    # Probar todas las combinaciones de variables independientes (1 a todas las features)
    for k in 1:length(features)
        for combo in combinations(features, k)
            # Crear la fórmula dinámica correctamente
            terms = Term.(combo)  # Generar términos
            formula = Term(target) ~ reduce(+, terms)  # Combinar términos con '+'

            # Evaluar el modelo
            model, r2, ecm, y_, y_pred = evaluate_model(formula, train_data, test_data)
            
            # Actualizar si es el mejor modelo hasta ahora
            if r2 > best_r2 || (r2 == best_r2 && ecm < best_ecm)
                best_r2 = r2
                best_model = model
                best_formula = formula
                best_ecm = ecm
                best_y = y_
                best_y_pred = y_pred
            end
        end
    end
    return best_model, best_formula, best_r2, best_ecm, best_y, best_y_pred
end
```

Prueba todas las combinaciones posibles de las variables independientes y selecciona la que produce el mejor modelo basado en 
\(R^2\) y el ECM.

##### Fórmulas
(Solo para mostrar las combinaciones que hace `evaluate_combinations` )
``` julia
# Almacenar las fórmulas generadas en una lista
begin
formulas = []

for k in 1:length(features_symbols)
    for combo in combinations(features_symbols, k)
        terms = Term.(combo)
        formula = Term(target_symbol) ~ reduce(+, terms)
        push!(formulas, formula)  # Agregar cada fórmula a la lista
    end
end

println(formulas)  # Verifica las fórmulas generadas
end
```

Genera todas las combinaciones de variables independientes y almacena las fórmulas en una lista para su evaluación.


> Any[T_degC ~ O2ml_L, T_degC ~ O2Sat, T_degC ~ Oxy_µmol/Kg, T_degC ~ R_SVA, T_degC ~ R_O2, T_degC ~ R_O2Sat, T_degC ~ O2ml_L + O2Sat, T_degC ~ O2ml_L + Oxy_µmol/Kg, T_degC ~ O2ml_L + R_SVA, T_degC ~ O2ml_L + R_O2, T_degC ~ O2ml_L + R_O2Sat, T_degC ~ O2Sat + Oxy_µmol/Kg, T_degC ~ O2Sat + R_SVA, T_degC ~ O2Sat + R_O2, T_degC ~ O2Sat + R_O2Sat, T_degC ~ Oxy_µmol/Kg + R_SVA, T_degC ~ Oxy_µmol/Kg + R_O2, T_degC ~ Oxy_µmol/Kg + R_O2Sat, T_degC ~ R_SVA + R_O2, T_degC ~ R_SVA + R_O2Sat, T_degC ~ R_O2 + R_O2Sat, T_degC ~ O2ml_L + O2Sat + Oxy_µmol/Kg, T_degC ~ O2ml_L + O2Sat + R_SVA, T_degC ~ O2ml_L + O2Sat + R_O2, T_degC ~ O2ml_L + O2Sat + R_O2Sat, T_degC ~ O2ml_L + Oxy_µmol/Kg + R_SVA, T_degC ~ O2ml_L + Oxy_µmol/Kg + R_O2, T_degC ~ O2ml_L + Oxy_µmol/Kg + R_O2Sat, T_degC ~ O2ml_L + R_SVA + R_O2, T_degC ~ O2ml_L + R_SVA + R_O2Sat, T_degC ~ O2ml_L + R_O2 + R_O2Sat, T_degC ~ O2Sat + Oxy_µmol/Kg + R_SVA, T_degC ~ O2Sat + Oxy_µmol/Kg + R_O2, T_degC ~ O2Sat + Oxy_µmol/Kg + R_O2Sat, T_degC ~ O2Sat + R_SVA + R_O2, T_degC ~ O2Sat + R_SVA + R_O2Sat, T_degC ~ O2Sat + R_O2 + R_O2Sat, T_degC ~ Oxy_µmol/Kg + R_SVA + R_O2, T_degC ~ Oxy_µmol/Kg + R_SVA + R_O2Sat, T_degC ~ Oxy_µmol/Kg + R_O2 + R_O2Sat, T_degC ~ R_SVA + R_O2 + R_O2Sat, T_degC ~ O2ml_L + O2Sat + Oxy_µmol/Kg + R_SVA, T_degC ~ O2ml_L + O2Sat + Oxy_µmol/Kg + R_O2, T_degC ~ O2ml_L + O2Sat + Oxy_µmol/Kg + R_O2Sat, T_degC ~ O2ml_L + O2Sat + R_SVA + R_O2, T_degC ~ O2ml_L + O2Sat + R_SVA + R_O2Sat, T_degC ~ O2ml_L + O2Sat + R_O2 + R_O2Sat, T_degC ~ O2ml_L + Oxy_µmol/Kg + R_SVA + R_O2, T_degC ~ O2ml_L + Oxy_µmol/Kg + R_SVA + R_O2Sat, T_degC ~ O2ml_L + Oxy_µmol/Kg + R_O2 + R_O2Sat, T_degC ~ O2ml_L + R_SVA + R_O2 + R_O2Sat, T_degC ~ O2Sat + Oxy_µmol/Kg + R_SVA + R_O2, T_degC ~ O2Sat + Oxy_µmol/Kg + R_SVA + R_O2Sat, T_degC ~ O2Sat + Oxy_µmol/Kg + R_O2 + R_O2Sat, T_degC ~ O2Sat + R_SVA + R_O2 + R_O2Sat, T_degC ~ Oxy_µmol/Kg + R_SVA + R_O2 + R_O2Sat, T_degC ~ O2ml_L + O2Sat + Oxy_µmol/Kg + R_SVA + R_O2, T_degC ~ O2ml_L + O2Sat + Oxy_µmol/Kg + R_SVA + R_O2Sat, T_degC ~ O2ml_L + O2Sat + Oxy_µmol/Kg + R_O2 + R_O2Sat, T_degC ~ O2ml_L + O2Sat + R_SVA + R_O2 + R_O2Sat, T_degC ~ O2ml_L + Oxy_µmol/Kg + R_SVA + R_O2 + R_O2Sat, T_degC ~ O2Sat + Oxy_µmol/Kg + R_SVA + R_O2 + R_O2Sat, T_degC ~ O2ml_L + O2Sat + Oxy_µmol/Kg + R_SVA + R_O2 + R_O2Sat]
</small>

## Gráficas de Resultados

### a. Actual vs Predicted
```julia
function plot_actual_vs_predicted(y_, y_pred)
    scatter(y_, y_pred, 
        label="Predictions", 
        color=:blue, 
        xlabel="Actual", 
        ylabel="Predicted", 
        title="Actual vs Predicted in degree")

    # Línea de predicción perfecta
    plot!([minimum(y_), maximum(y_)], 
          [minimum(y_), maximum(y_)], 
          color=:red, 
          lw=2, 
          label="Perfect Prediction")
end
```

### b. Residuales con Tolerancia
```julia
function plot_residuals_with_tolerance(y_, y_pred, tolerance=0.1)

	residuals = y_ .- y_pred

    scatter(y_pred, residuals, 
        label="Residuos", 
        color=:green, 
        xlabel="Predicted", 
        ylabel="Residuals", 
        title="Predicted vs Residuals with Tolerance")

    # Línea de tolerancia superior e inferior
    upper_tolerance = tolerance .* abs.(y_)
    lower_tolerance = -tolerance .* abs.(y_)

    plot!([minimum(y_pred), maximum(y_pred)], [0, 0], 
          color=:red, 
          lw=2, 
          label="Zero Residual")

    plot!([minimum(y_pred), maximum(y_pred)], 
          [mean(upper_tolerance), mean(upper_tolerance)], 
          color=:blue, 
          lw=2, 
          linestyle=:dash, 
          label="Upper Tolerance")

    plot!([minimum(y_pred), maximum(y_pred)], 
          [mean(lower_tolerance), mean(lower_tolerance)], 
          color=:orange, 
          lw=2, 
          linestyle=:dash, 
          label="Lower Tolerance")
end
```

---

## Aplicación del Modelo
### a. Dividir Datos en Entrenamiento y Prueba

```julia
Random.seed!(25)

ids = collect(1:nrow(regression_data))

# Baraja los ids de forma aleatoria.
ran_ids = shuffle!(ids)

# Calcula el id para el 80%.
div_ids = Int(floor(0.8 * length(ran_ids)))

# Toma los primeros 80%.
train_ids = ran_ids[1:div_ids]

# Toma el resto (20%).
test_ids = ran_ids[div_ids+1:end]

# Filas para entrenamiento.
train_regression = regression_data[train_ids, :]

# Filas para prueba.
test_regression = regression_data[test_ids, :]
```

`ids`: Crea ids para todas las filas del conjunto de datos ( *regression_data* ) que se usara para dividir los datos en entrenamiento y prueba.

`div_ids`: Calcula el id para el 80% de *regression_data*.

`train_ids`: Es el subconjunto de ids de entrenamiento seleccionados usando `ran_ids`.

`test_ids`: Es el subconjunto de ids que no pertenece a `train_ids`. Este conjunto se usa para evaluar el rendimiento del modelo ajustado.

`train_regression`: Este es el subconjunto de los datos de *regression_data* que se utiliza para ajustar (entrenar) el modelo. Es decir, el modelo aprende los patrones a partir de estos datos.

`test_regression`: Este subconjunto se utiliza para evaluar el rendimiento del modelo después de que se ha entrenado. Los datos de prueba son completamente separados del entrenamiento para garantizar que la evaluación sea objetiva.

El modelo nunca "ve" estos datos durante el entrenamiento. Sirven para medir qué tan bien generaliza el modelo en datos nuevos, no observados previamente.




### b. Evaluar Combinaciones
```julia
# Definir la columna objetivo
target = "T_degC"

# Seleccionar las columnas independientes
features = filter(col -> col != target, names(regression_data))

# Convertimos target y features a Symbol.
target_symbol = Symbol(target)
features_symbols = Symbol.(features)

best_model, best_formula, best_r2, best_ecm, best_y, best_y_pred = evaluate_combinations(
    target_symbol, features_symbols, train_regression, test_regression)
```

`target`: Es la variable que contiene el nombre de la columna objetivo.

`features`: Es un vector que contiene los nombres de las variables independientes (predictoras) que se van a utilizar para ajustar el modelo.


---

## Resultados
```julia
println("Mejor Fórmula: ", best_formula)  

println("Mejor R^2: ", best_r2)     

# Error Cuádratico Medio
println("Mejor ECM: ", best_ecm)          
println("Coeficientes del Modelo:\n", coeftable(best_model))  
```

**Mejor Fórmula:** `T_degC ~ O2Sat + Oxy_µmol/Kg + R_SVA + R_O2 + R_O2Sat`
**Mejor R^2:** 0.9773341131956339
**Mejor ECM:** 0.3371077082900926

**Coeficientes del Mejor Modelo:** 



| **Name**     | **Coef.** | **Std. Error** | **t**   | **Pr (\(>\mid t \mid\))** |<span style="white-space: nowrap;"> **Lower 95%** </span>   |<span style="white-space: nowrap;"> **Upper 95%** </span>  |
|-------------:|----------:|---------------:|--------:|---------------:|--------------:|--------------:|
| (Intercept)  | 0.289767  | 0.0114081      | 25.4001  |<span style="white-space: nowrap;">  4.51474e-142  </span>  | 0.267407      | 0.312127      |
| O2Sat        | -2.29263  | 1.69651        | -1.35138 | 0.176576       | -5.61776      | 1.0325        |
| Oxy\_µmol/Kg | -17.9136  | 0.0394324      | -454.286 | 0.0            | -17.9909      | -17.8363      |
| R\_SVA       | 0.0570573 | 7.83759e-5     | 727.995  | 0.0            | 0.0569037     | 0.0572109     |
| R\_O2        | 772.276   | 1.70759        | 452.262  | 0.0            | 768.929       | 775.623       |
| R\_O2Sat     | 2.73911   | 1.69651        | 1.61455  | 0.106409       | -0.586016     | 6.06424       |


`best_y` y `best_y_pred` son vectores que representan los valores reales (`best_y`) y las predicciones (`best_y_pred`) del mejor modelo respectivamente.
Ambos vectores tienen 44,486 elementos, por lo que solo se mostrarán los primeros y últimos 10 elementos de cada vector.


|**best_y**<br>`Vector{Float64}`|**best_y_pred**<br>`Vector{Union{Missing, Float64}}` | 
|-------------------------:|-----------------------:|
17.92 | 17.9765
21.38 | 22.4689
8.9 | 8.71222
10.36 | 10.6275
9.68 |9.98295
7.49|  7.39335
15.88| 16.077
18.26| 18.3895
10.4|10.1728
15.71| 15.5189
|  ⁝ | ⁝| 
7.27 | 7.52901
7.45| 7.52934
5.28 |6.56936
7.8 |7.17614
15.97 |16.1113
22.52 |24.3988
5.84 |6.50886
9.15 | 9.01862
6.84 |6.64965
5.58  |  6.66251


```julia
# Crear las gráficas
begin
	Grafica1 = plot_actual_vs_predicted(best_y, best_y_pred)
	# Guardamos la gráfica generada
    Grafica1_path = joinpath("..", "fig", "Grafica1.png")
	savefig(Grafica1,Grafica1_path)
    

	Grafica2 = plot_residuals_with_tolerance(best_y, best_y_pred)
	Grafica2_path = joinpath("..", "fig", "Grafica2.png")
	savefig(Grafica2,Grafica2_path)
end
```
`Grafica1`: Actual vs Predicted.

![Grafica1](../fig/Grafica1.png)

`Grafica2`: Residuales con Tolerancia.

![Grafica2](../fig/Grafica2.png)





---

## Conclusiones
#### **Resultados numéricos del modelo:**

1. **Mejor Fórmula:**
   - `T_degC ~ O2Sat + Oxy_µmol/Kg + R_SVA + R_O2 + R_O2Sat`
   - Es un modelo que combina varias variables independientes con alta significancia para predecir la temperatura en grados Celsius (`T_degC`). 

2. **Mejor \(R^2\):** 
   - **0.9773**: Indica que el modelo explica aproximadamente el **97.73% de la variabilidad** en los datos de `T_degC`.

3. **Mejor ECM:** 
   - **0.3371**: Un Error Cuadrático Medio bajo sugiere que las predicciones del modelo están cerca de los valores reales.

4. **Coeficientes del modelo:**
   - **Oxy_µmol/Kg:** Este coeficiente tiene una magnitud muy alta y negativa, lo que podría significar un fuerte impacto de esta variable en la predicción.
   - **R_SVA y R_O2:** Ambos tienen coeficientes positivos altos y significativos, sugiriendo que incrementos en estas variables están altamente correlacionados con el aumento de `T_degC`.
   - **O2Sat y R_O2Sat:** Aunque están incluidos en el modelo, la significancia estadística (valores \(p\)) indica que su efecto puede no ser tan relevante como las demás variables.

#### **Gráfica 1: Actual vs. Predicted**

1. **Interpretación:**
   - La línea roja representa la "predicción perfecta", y los puntos azules son las predicciones reales del modelo.
   - La mayoría de los puntos están alineados con la línea roja, lo que indica que el modelo tiene un buen desempeño al predecir los valores de `T_degC`.

2. **Análisis:**
Algunos puntos se desvían ligeramente de la línea, lo cual es normal y esperado en modelos de regresión. Sin embargo, parece haber cierta variación más alta en los valores extremos, lo cual podría ser un área para investigar más.

#### **Gráfica 2: Predicted vs. Residuals**

1. **Interpretación:**
   - Los residuales son las diferencias entre los valores reales y las predicciones del modelo.
   - Las líneas de tolerancia superior e inferior muestran límites donde los residuales deberían caer si el modelo tiene un buen desempeño.

2. **Análisis:**
   - La mayoría de los puntos están dentro de las líneas de tolerancia, indicando un buen ajuste del modelo.
   - Hay una tendencia en los residuales para valores extremos (tanto predicciones bajas como altas), lo que podría sugerir que el modelo no está capturando completamente ciertas relaciones no lineales.

#### **Conclusiones generales:**
- El \(R^2\) y el ECM reflejan que el modelo es altamente preciso.
- La gráfica de Actual vs Predicted muestra un ajuste sólido en general.


