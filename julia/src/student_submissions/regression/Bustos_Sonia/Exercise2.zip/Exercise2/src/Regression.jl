using Pkg
# Pkg.add("CSV"); Pkg.add("GLM"); Pkg.add("Statistics")
# Pkg.add("DataFrames"); Pkg.add("Random"); Pkg.add("Combinatorics")
# Pkg.add("Plots")

using CSV, GLM, Statistics, DataFrames, Random, Combinatorics, Plots

function deleteColumns(threshold::Float64)
    # Número de filas
    n_rows = nrow(bottle_df)

    # Sacamos el porcentaje de missing por columna, y si es menor igual que el threshold matenemos la columna.
    keep_cols = map(col -> round((count(ismissing, col) / n_rows * 100),digits = 0) <= threshold, eachcol(bottle_df))
    
    # Llamamos a las columnas del DataFrame que cumplieron con el criterio.
    return bottle_df[:, keep_cols]
end


function calculateCorrelation(df::DataFrame)
    # Filtrar columnas de tipo numérico o Union{Missing, Number}
    numeric_columns = filter( 
        col -> eltype(df[!, col]) <: Union{Missing, Number},
        names(df)
        )

    # Seleccionar solo las columnas numéricas
    numeric_data = select(df, numeric_columns)

    # Eliminar filas con valores faltantes para evitar problemas al calcular correlaciones
    clean_numeric_data = dropmissing(numeric_data)


    # Calcular la matriz de correlación
    correlation_matrix = cor(Matrix(clean_numeric_data))


    # Calcular la desviación estándar de cada columna
    desviaciones_estandar = map(col -> std(skipmissing(clean_numeric_data[!, col])), names(clean_numeric_data))
    

    return correlation_matrix, desviaciones_estandar
end


# Gráficamos la matriz de correlación en un mapa de calor 
function displayCorrelation(df::DataFrame, correlation_matrix::Matrix)

    # Nombre se las columnas númericas.
    numeric_columns = filter( 
        col -> eltype(df[!, col]) <: Union{Missing, Number},
        names(df)
        )

    # Crear el heatmap con etiquetas.
    corr_heatmap =heatmap(correlation_matrix, color=cgrad([:green, :yellow, :red]), 
            title="Correlation Heatmap",
            xticks=(1:length(numeric_columns), numeric_columns), yticks=(1:length(numeric_columns), numeric_columns))
            
    return corr_heatmap
end

function removeOutliersIQR(df::DataFrame)
    # Iterar sobre cada columna
    for col in names(df)
        # Verificar si la columna es numérica o Union{Missing, Number}
        if eltype(df[!, col]) <: Union{Missing, Number}

            # Calcular los cuantiles ignorando valores missing
            col_values = skipmissing(df[!, col])
            Q1 = quantile(col_values, 0.25)
            Q3 = quantile(col_values, 0.75)
            IQR = Q3 - Q1

            # Límites superior e inferior
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR

            # Filtrar filas manteniendo solo los valores dentro de los límites
            df = filter(row -> 
                ismissing(row[col]) || 
                (row[col] >= lower_bound && row[col] <= upper_bound), df)
        end
    end
    return df
end

function deleteRow(column)
    # Dataframe con columnas sin missing
    no_missing = dropmissing(cleaned_data_RO, column)
    return no_missing
end

function filterColumnsByCorrelation(df::DataFrame, target::String, threshold::Float64, relation::Bool)
    # Verificar que la columna objetivo exista
    if !(target in names(df))
        throw(ArgumentError("La columna '$target' no existe en el DataFrame."))
    end

    # Seleccionar solo columnas numéricas o Union{Missing, Number}
    numeric_columns = filter(
        col -> eltype(df[!, col]) <: Union{Missing, Number},
        names(df)
    )

    # Verificar que la columna objetivo sea numérica
    if !(target in numeric_columns)
        throw(ArgumentError("La columna objetivo '$target' no es numérica."))
    end

    # Calcular la matriz de correlación
    corr_matrix, _ = calculateCorrelation(df)

    # Obtener el índice de la columna objetivo
    target_idx = findfirst(Symbol.(numeric_columns) .== Symbol(target))

    # Obtener la correlación con la columna objetivo
    target_corr = corr_matrix[:, target_idx]

    # Filtrar las columnas según la relación
    if relation
        keep_columns = numeric_columns[target_corr .>= threshold]
    else
        keep_columns = numeric_columns[target_corr .<= threshold]
    end

    # Agregar la columna objetivo a las columnas seleccionadas (si no está incluida ya)
    if !(target in keep_columns)
        push!(keep_columns, target)
    end

    # Seleccionar las columnas filtradas del DataFrame original
    return select(df, keep_columns)
end

function File(file_path::String)
    bottle_source = file_path
    bottle_df = CSV.read(bottle_source,DataFrame)

    return bottle_df
end


# Función para evaluar modelos
function evaluate_model(formula::FormulaTerm, train_data::DataFrame, test_data::DataFrame)
    # Ajustar el modelo usando GLM
    model = lm(formula, train_data)
    
    # Predicciones en el conjunto de prueba
    y_pred = predict(model, test_data)
    y_ = test_data[:, :T_degC]  # Usamos el símbolo para acceder a la columna
    
    # Calcular métricas
    r2 = 1 - sum((y_ .- y_pred).^2) / sum((y_ .- mean(y_)).^2)
    ecm = mean((y_ .- y_pred).^2)
    
    return model, r2, ecm, y_, y_pred
end


# Función para evaluar combinaciones de features
function evaluate_combinations(target::Symbol, features::Vector{Symbol}, train_data::DataFrame, test_data::DataFrame)
    best_r2 = -Inf  # Mejor R^2 inicial
    best_model = nothing
    best_formula = nothing
    best_ecm = Inf  # Mejor ECM inicial
    best_y = nothing
    best_y_pred = nothing

    # Probar todas las combinaciones de variables independientes (1 a todas las features)
    for k in 1:length(features)
        for combo in combinations(features, k)
            # Crear la fórmula dinámica correctamente
            terms = Term.(combo)  # Generar términos
            formula = Term(target) ~ reduce(+, terms)  # Combinar términos con '+'

            # Evaluar el modelo
            model, r2, ecm, y_, y_pred = evaluate_model(formula, train_data, test_data)
            
            # Actualizar si es el mejor modelo hasta ahora
            if r2 > best_r2 || (r2 == best_r2 && ecm < best_ecm)
                best_r2 = r2
                best_model = model
                best_formula = formula
                best_ecm = ecm
                best_y = y_
                best_y_pred = y_pred
            end
        end
    end
    return best_model, best_formula, best_r2, best_ecm, best_y, best_y_pred
end

## Gráficas
### Función para graficar "Actual vs Predicted" (`plot_actual_vs_predicted`)
function plot_actual_vs_predicted(y_, y_pred)
    scatter(y_, y_pred, 
        label="Predictions", 
        color=:blue, 
        xlabel="Actual", 
        ylabel="Predicted", 
        title="Actual vs Predicted in degree")

    # Línea de predicción perfecta
    plot!([minimum(y_), maximum(y_)], 
          [minimum(y_), maximum(y_)], 
          color=:red, 
          lw=2, 
          label="Perfect Prediction")
end

### Función para graficar residuos con tolerancia (`plot_residuals_with_tolerance`)
function plot_residuals_with_tolerance(y_, y_pred, tolerance=0.1)

	residuals = y_ .- y_pred

    scatter(y_pred, residuals, 
        label="Residuos", 
        color=:green, 
        xlabel="Predicted", 
        ylabel="Residuals", 
        title="Predicted vs Residuals with Tolerance")

    # Línea de tolerancia superior e inferior
    upper_tolerance = tolerance .* abs.(y_)
    lower_tolerance = -tolerance .* abs.(y_)

    plot!([minimum(y_pred), maximum(y_pred)], [0, 0], 
          color=:red, 
          lw=2, 
          label="Zero Residual")

    plot!([minimum(y_pred), maximum(y_pred)], 
          [mean(upper_tolerance), mean(upper_tolerance)], 
          color=:blue, 
          lw=2, 
          linestyle=:dash, 
          label="Upper Tolerance")

    plot!([minimum(y_pred), maximum(y_pred)], 
          [mean(lower_tolerance), mean(lower_tolerance)], 
          color=:orange, 
          lw=2, 
          linestyle=:dash, 
          label="Lower Tolerance")
end


# Generando DataFrame `regression_data`

bottle_path = joinpath("..", "dat", "bottle.csv")

bottle_df = File(bottle_path)

cleaned_data = deleteColumns(50.0)  # Umbral del 50%

cleaned_data_RO = removeOutliersIQR(cleaned_data)

col_name = names(cleaned_data_RO)

Without_missing_rows = deleteRow(col_name)

### Quitamos columnas redundantes
target_ = "T_degC"
threshold1 = 0.99
realtion1 = false

no_redundant_columns = filterColumnsByCorrelation(Without_missing_rows, target_, threshold1, realtion1)

### Seleccionamos solo las variables más influyentes.
threshold2 = 0.7
realtion2 = true

variables = filterColumnsByCorrelation(no_redundant_columns, target_, threshold2, realtion2)

begin
	# Identificar columnas con los mismos datos
	duplicates = []
	for i in 1:size(variables, 2)
	    for j in (i+1):size(variables, 2)
	        if all(variables[:, i] == variables[:, j])
	            push!(duplicates, (names(variables)[j]))
	        end
	    end
	end
	
	# Convertir el vector de duplicados a una cadena de texto 
	duplicates_str = join(duplicates, ", ") 
		println("Columnas duplicadas: ", duplicates_str)
end



regression_data = select!(variables, Not(Symbol.(duplicates)))



# Calcular la matriz de correlación
corr_matrix_regression, _ = calculateCorrelation(regression_data)

begin
	heatmap_Regression_1 = displayCorrelation(regression_data, corr_matrix_regression)
		
	# Guardamos la gráfica generada
    heatmap_Regression_1_path = joinpath("..", "fig", "heatmap_Regression_1.png")
	savefig(heatmap_Regression_1,heatmap_Regression_1_path)

end

# Mostramos mapa de calor
heatmap_Regression_1

# ---------------- REGRESIÓN -------------------

## Dividir los datos en entrenamiento y prueba
Random.seed!(42)

# Crea ids para todas las filas del conjunto de datos ( `regression_data` ) que se usara para dividir los datos en entrenamiento y prueba
# Vector con números de 1 a la cantidad de filas de regression_data.
ids = collect(1:nrow(regression_data))  


# Baraja los índices de forma aleatoria
ran_ids = shuffle!(ids) 


# Calcula el id para el 80% de filter_data
div_ids = Int(floor(0.8 * length(ran_ids)))  

train_ids = ran_ids[1:div_ids]  # Toma los primeros 80%

test_ids = ran_ids[div_ids+1:end]  # Toma el resto (20%)

train_regression = regression_data[train_ids, :]

test_regression = regression_data[test_ids, :]  # Filas para prueba


## Definir la columna objetivo y las independientes

# Columna objetivo
target = "T_degC"

features = filter(col -> col != target, names(regression_data))


# Convertimos target y features a Symbol. 
target_symbol = Symbol(target)

features_symbols = Symbol.(features)


# Fórmulas (Para mostrar resultados)
# Almacenar las fórmulas generadas en una lista
begin
formulas = []

for k in 1:length(features_symbols)
    for combo in combinations(features_symbols, k)
        terms = Term.(combo)
        formula = Term(target_symbol) ~ reduce(+, terms)
        push!(formulas, formula)  # Agregar cada fórmula a la lista
    end
end

println(formulas)  # Verifica las fórmulas generadas
end


## Evaluar todas las combinaciones
best_model, best_formula, best_r2, best_ecm, best_y, best_y_pred = evaluate_combinations(
    target_symbol, features_symbols, train_regression, test_regression
)


## Imprimir los resultados
println("Mejor Fórmula: ", best_formula)

println("Mejor R^2: ", best_r2)

println("Mejor Error Cuádratico Medio (ECM): ", best_ecm)

println("Coeficientes del Mejor Modelo:\n", coeftable(best_model))

best_y

best_y_pred


# Crear las gráficas
begin
	Grafica1 = plot_actual_vs_predicted(best_y, best_y_pred)

	# Guardamos la gráfica generada
    Grafica1_path = joinpath("..", "fig", "Grafica1.png")
	savefig(Grafica1,Grafica1_path)
end

# Mostramos Grafica1
Grafica1


begin
	Grafica2 = plot_residuals_with_tolerance(best_y, best_y_pred)

	# Guardamos la gráfica generada
    Grafica2_path = joinpath("..", "fig", "Grafica2.png")
	savefig(Grafica2,Grafica2_path)
end

# Mostramos Grafica2
Grafica2