module Exercise1

using DataFrames, CSV, Statistics, PlutoUI, StatsBase, CairoMakie, AlgebraOfGraphics

"""
    removeColumnsOverMissingThreshold(df; threshold=0.2)

Return a new DataFrame without the columns that have more missing values
than the allowed threshold: `threshold * size(df, 1)`
"""
function removeColumnsOverMissingThreshold(df::DataFrame;
    threshold::Float64=0.2)
    totalMissingAllowed = threshold * size(df, 1)
    isOverThreshold(col) = count(ismissing, col) > totalMissingAllowed
    colsToRemove = [isOverThreshold(col) for col in eachcol(df)]
    df[!, Not(colsToRemove)]
end

"""
    removeColumnsByName(df, colNames)

Return a new DataFrame without the columns given in the `colNames`
vector.
"""
removeColumnsByName(df::DataFrame, colNames::Vector{String}) = df[!, Not(colNames)]

"""
    drawHeatmap(df)

Return a Makie heatmap from the input DataFrame. All missing values are
dropped before plotting.
"""
function drawHeatmap(df::DataFrame)
    matcorr = cor(Matrix(dropmissing(df)))

    fig, ax, hm = heatmap(matcorr; colormap=:balance)

    Colorbar(fig[:, end+1], hm; ticks=-1.0:0.2:1)

    ax.xticks = (1:size(matcorr, 1), names(df))
    ax.xticklabelrotation = π / 2
    ax.yticks = (1:size(matcorr, 1), names(df))
    ax.width = 340
    ax.height = 340
    ax.title = "Correlation Matrix"

    fig
end

function drawBoxplotGrid(df::DataFrame)
    totalPlots = length(names(df))
    plotsPerRow = Int64(ceil(sqrt(totalPlots)))

    fig = Figure()

    for row = 1:plotsPerRow, col = 1:plotsPerRow
        linearIndex = (row - 1) * plotsPerRow + col
        if linearIndex > totalPlots
            break
        end

        colname = names(df)[linearIndex]

        ax = Axis(fig[row, col])
        ax.yticklabelsize = 8.0
        ax.xticksvisible = false
        ax.title = colname
        ax.titlesize = 9.0

        y = collect(skipmissing(df[!, colname]))
        x = ones(length(y))
        boxplot!(ax, x, y, markersize=5)
        hidexdecorations!(ax, ticks=false)
    end

    fig
end

function markIqrOutliersAsMissing(df::DataFrame)
    dfout = []
    for colname in names(df)
        col = df[!, colname]

        itr = skipmissing(col)
        q1 = quantile(itr, 0.25)
        q3 = quantile(itr, 0.75)
        whiskerLength = 1.5 * (q3 - q1)
        lowerBound = q1 - whiskerLength
        upperBound = q3 + whiskerLength

        isOutlier = ismissing.(col) .| (col .< lowerBound) .| (col .> upperBound)
        push!(dfout, ifelse.(isOutlier, missing, col))
    end
    DataFrame(dfout, names(df))
end

function removeColumnsByCorrelation(df::DataFrame, colnameTarget::String;
    α::Float64=0.1, β::Float64=0.9)
    isNumeric(colname) = eltype(df[!, colname]) <: Union{Missing,Number}
    if !isNumeric(colnameTarget)
        return Nothing
    end

    colsToRemove = String[]
    for colnameTest in names(df)
        areColumnsEqual = cmp(colnameTest, colnameTarget) == 0
        if !isNumeric(colnameTest) || areColumnsEqual
            continue
        end

        dfpair = dropmissing(df[!, [colnameTarget, colnameTest]])
        x1 = dfpair[!, colnameTest]
        x2 = dfpair[!, colnameTarget]

        corr = cor(x1, x2)
        if abs(corr) < α || corr > β || isnan(corr)
            push!(colsToRemove, colnameTest)
        end
    end
    df[!, Not(colsToRemove)]
end

end
