#=
1. Get the Churn_Modelling.csv data that was used to demonstrate the GLM package. 
The data is available at  https://github.com/selva86/datasets/tree/master
The data was manually downloaded from github and move to this directory Exercise5 > dat

2. Follow the steps described in the Flux Demos and in the GLM demos shown during the sessions
3. Evaluate the accuracy of the model’s prediction, using a confusion matrix and a ROC curve.
4. Submit your project following the submission guidelines

The code below is based on the tutorial https://fluxml.ai/Flux.jl/stable/tutorials/logistic_regression/ on which 
Iris data is used 

=#


using Flux
#Flux.Data.MNIST
using Flux: onehotbatch, argmax, crossentropy, throttle
using Base.Iterators: repeated
using CSV
using DataFrames
using MLBase
using OneHotArrays
using Random
using EvalMetrics
using PlotlyJS

## 1. Get the data 
# Data manually downloaded from https://github.com/selva86/datasets/blob/master/Churn_Modelling.csv
## and stored on the Exercise5 > dat directory

## EDA to the dataset for useful insights of the data 

cd("/Users/carolinabernal/Documents/DiplomadoExercises") # Use the correct directory 

Churn_file = "Exercise5/dat/Churn_Modelling.csv"
Churn_df = CSV.File(Churn_file) |> DataFrame
size(Churn_df)

Churn_info = describe(Churn_df)
first(Churn_df,10)


# Filter Categorical ie String type columns 
# <: AbstractString: to verify if elType() of the col is a  subclass of AbstractString ie String and text type in Julia

str_cols = names(Churn_df)[map(col -> eltype(Churn_df[!, col]) <: AbstractString, names(Churn_df))]

println("String type columns: ", str_cols)
geo_unique = unique(Churn_df.Geography)
@show geo_unique# 3-element Vector{String7}:"France" , "Spain" , "Germany"


gender_unique = unique(Churn_df.Gender)
@show gender_unique # 2-element Vector{String7}: "Female"  , "Male"



## One hot encoding to convert the Categorical variables to binary data to represent the category
# We can use what we previously learn on exercise 3 with Smarket data as follows:
#=
### Replace the elements of type string that contain "Up" or "Down" in 
### column Direction with a number [0,1] to compute LogReg on the data.
Smarket_df = copy(Smarket_r_df)
replace!(Smarket_df.Direction, "Up" => "1")
replace!(Smarket_df.Direction, "Down" => "0")
Smarket_df
describe(Smarket_df)
Smarket_df[!, :Direction] = parse.(Int64,Smarket_df[!, :Direction]) # to convert string value to Integer
describe(Smarket_df)
=# 

ChurnModel_df = copy(Churn_df) #Create a copy to have the backup of the original 
replace!(ChurnModel_df.Gender, "Male" => "0")
replace!(ChurnModel_df.Gender, "Female" => "1")
ChurnModel_df[!, :Gender] = parse.(Int64,ChurnModel_df[!, :Gender])

## Another option shown in Ex 3 is labelmap()
# Smarket_dct_map = labelmap(Smarket_r_dct) were Smarket_r_dct was the column for Direction Up and Down
# labelencode(Smarket_dct_map, Smarket_r_dct)
churnGender = Churn_df.Gender
churnGeo = Churn_df.Geography    
churnGender_map =  labelmap(churnGender) # LabelMap (with 2 labels): [1] Female ;[2] Male
churnGeo_map =  labelmap(churnGeo)   #LabelMap (with 3 labels):[1] France , [2] Spain , [3] Germany


churnGendermod = labelencode(churnGender_map, churnGender)
churnGeomod = labelencode(churnGeo_map, churnGeo)
describe(Churn_df)
Churn_df


## Delete the columns that will not be useful to the model ie RowNumber, CustomerId and Surname
dfChurnModel = copy(Churn_df)
dfChurnModel = select(dfChurnModel, Not([:RowNumber,:CustomerId,:Surname]))
describe(dfChurnModel)


# Using the same idea of only using numeric colums (like in ex 1 and 3) we are going to filter non String columns
str_cols = names(dfChurnModel)[map(col -> eltype(dfChurnModel[!, col]) <: AbstractString, names(dfChurnModel))]
println("Remaining String type columns: ", str_cols)
dfChurnModel[!, "Gender"] .=  churnGendermod
dfChurnModel[!, "Geography"] .=  churnGeomod
str_cols = names(dfChurnModel)[map(col -> eltype(dfChurnModel[!, col]) <: AbstractString, names(dfChurnModel))]
println("Remaining String type columns: ", str_cols)

## Now from the numeric dataframe we're going to select all columns except for Exited since we're going to predict those values
dfChurnNumeric = select(dfChurnModel,Not([:Exited]))
dfChurnNumeric
dfChurnModel

Churn_df

#"CreditScore", "Age", "Tenure", "Balance", "NumOfProducts",
#"HasCrCard", "IsActiveMember", "EstimatedSalary
# Gender and Geography

## Here we're going yo define the parameters X and y to train a classifier that outputs
## the Exited value based on numeric columns of the data 
#=
Our next step would be to convert this data into a form that can be fed to a machine learning model. 
The x values are arranged in a matrix and should ideally be converted to Float32 type
labels y have to be hot enconded 
=#
dfChurnNumeric
x = Matrix(dfChurnNumeric)'  .|> Float32
xnames = names(dfChurnNumeric)
x
churnExited = dfChurnModel.Exited

y = Vector(churnExited) .|> Float32
custom_y_onehot = unique(y) .== permutedims(y)

x = (x .- mean(x, dims=2)) ./ std(x, dims=2) ## WARNING! It's really important to normalize to avoid errors

#=
Building a model

A logistic regression model is defined mathematically as -

model(x)=σ(Wx+b)

where W is the weight matrix, b is the bias vector, and σ is any activation function. 
For our case, let's use the softmax activation function as we will be performing a multiclass classification task.
=#

###### Building a model - Logistic Regression
# where W is the weight matrix, b is the bias vector, and σ is any activation function.
# For our case, let's use the softmax activation function as we will be performing a multiclass classification task.

m(W, b, x) = W*x .+ b

# Set the values, we have 2 different classes  for Exited and 10 features on the model
# This model lacks an activation function . We're going to initialize the parameters for the model
# We have 10 inputs (X names/cols) features in every data point and 2 outputs (2 different 0 and 1 in Exited), 
# therefore the initialization should be :
W = rand(Float32, 2, 10)
b = [0.0f0, 0.0f0]


# Now our model can take in the complete dataset and predict the class of each x in one go.
# But, we need to ensure that our model outputs the probabilities of an input belonging to the respective 
# classes. As our model has 2 outputs, each would denote the probability of the input belonging to a particular class.

# We will use an activation function to map our outputs to a probability value. We'll use softmax 
# The function scales down the outputs to probability values such that the sum of all the final outputs equals 1



custom_softmax(x) = exp.(x) ./ sum(exp.(x), dims=1)
x
custom_softmax(x)


# we specify dims=1 in the sum function to calculate the sum of probabilities in each column.
# The 2×10000 BitMatrix (Exited) predicted ys as the output of the model

# Let's combine this softmax function with our model to construct the complete custom_model.

custom_model(W, b, x) = m(W, b, x) |> custom_softmax

custom_model(W, b, x) |> size # Check if the model works, if it does, the output shoul be (2,10000)

#Let's check if the softmax function is working.
custom_model(W, b, x)
all(0 .<= custom_model(W, b, x) .<= 1)
sum(custom_model(W, b, x), dims=1)

## To validate that everything is correct every output value should be between 0 and 1 and every colunm should add 1 

#=
Let's convert our custom_model to a Flux model. Flux provides the users with a very elegant API that almost feels like writing your code!

Note, all the flux_* variables in this tutorial would be general, that is, they can be used as it is with some other 
similar-looking dataset, but the custom_* variables will remain specific to this tutorial.
=#

flux_model = Chain(Dense(10 => 2), softmax)

#=
A Dense(10 => 2) layer denotes a layer with 10 inputs (four features in every data point) and 2 outputs (2 classes or labels).
This layer is the same as the mathematical model defined by us above. Under the hood, Flux too calculates the output using the same expression,
but we don't have to initialize the parameters ourselves this time, instead Flux does it for us.
=#

#=
The softmax function provided by NNLib.jl is re-exported by Flux, which has been used here.
Lastly, Flux provides users with a Chain struct which makes stacking layers seamless.

A model's weights and biases can be accessed as follows -
=#

flux_model[1].weight, flux_model[1].bias


###### ---- Loss and accuracy ------ ######


#=
Our next step should be to define some quantitative values for our model, which we will maximize or minimize
during the complete training procedure. These values will be the loss function and the accuracy metric.

Let's start by defining a loss function, a logitcrossentropy function.
=#

custom_logitcrossentropy(ŷ, y) = mean(.-sum(y .* logsoftmax(ŷ; dims = 1); dims = 1));

# Now we can wrap the custom_logitcrossentropy inside a function that takes in the model parameters, xs, and ys, and returns the loss value.

function custom_loss(weights, biases, features, labels_onehot)
    ŷ = custom_model(weights, biases, features)
    custom_logitcrossentropy(ŷ, labels_onehot)
end

custom_loss(W, b, x, custom_y_onehot) #Test if the function works

#=
Flux provides us with many minimal yet elegant loss functions. In fact, the custom_logitcrossentropy defined above has been taken directly from Flux. 
The functions present in Flux includes sanity checks, ensures efficient performance, and behaves well with the overall FluxML ecosystem.
=#


unique(y)

const classes = [1.0, 0.0];
flux_y_onehot = onehotbatch(y, classes)

function flux_loss(flux_model, features, labels_onehot)
    ŷ = flux_model(features)
    Flux.logitcrossentropy(ŷ, labels_onehot)
end

flux_loss(flux_model, x, flux_y_onehot)

#=
Next, let's define an accuracy function, which we will try to maximize during our training procedure. Before jumping to accuracy, 
let's define a onecold function. The onecold function would convert our output, which remember, are probability values, to the actual class names.

We can divide this task into two parts -

1. Identify the index of the maximum element of each column in the output matrix
2. Convert this index to a class name
The maximum index should be calculated along the columns (remember, each column is the output of a single x data point). We can use Julia's argmax function to achieve this.

=#

argmax(custom_y_onehot, dims=1)  # calculate the cartesian index of max element column-wise
max_idx = [x[1] for x in argmax(custom_y_onehot; dims=1)]


#function that calculates the indices of the maximum element in each column, and maps them to a class name.
function custom_onecold(labels_onehot)
    max_idx = [x[1] for x in argmax(labels_onehot; dims=1)]
    return vec(classes[max_idx])
end

#Flux provides users with the onecold function so that we don't have to write it on our own. 
#Let's see how our custom_onecold function compares to Flux.onecold.

custom_onecold(custom_y_onehot)

istrue = Flux.onecold(flux_y_onehot, classes) .== custom_onecold(custom_y_onehot);

all(istrue)

# Both the functions act identically!

custom_accuracy(W, b, x, y) = mean(custom_onecold(custom_model(W, b, x)) .== y);
custom_accuracy(W, b, x, y)

# Flux's built-in functionality to define this accuracy function.
flux_accuracy(x, y) = mean(Flux.onecold(flux_model(x), classes) .== y);
flux_accuracy(x, y)


#=
Training the model

Let's train our model using the classic Gradient Descent algorithm.
According to the gradient descent algorithm, the weights and biases 
should be iteratively updated using the following mathematical equations

Our first step would be to obtain the gradient of the loss function with respect to the weights and the biases. 

    Flux re-exports Zygote's gradient function; hence, we don't need to import Zygote explicitly to use the functionality. 
    gradient takes in a function and its arguments, and returns a tuple containing ∂f/∂x for each argument x. 
    Let's pass in custom_loss and the arguments required by custom_loss to gradient. 
    We will require the derivatives of the loss function (custom_loss) with respect to the weights (∂f/∂w) and the bias (∂f/∂b)
    to carry out gradient descent, but we can ignore the partial derivatives of the loss function (custom_loss) with respect to x (∂f/∂x)
    and one hot encoded y (∂f/∂y).

=#


dLdW, dLdb, _, _ = gradient(custom_loss, W, b, x, custom_y_onehot);
W .= W .- 0.1 .* dLdW;
b .= b .- 0.1 .* dLdb;
#Parameters updated, check the value of cusrom loss func
custom_loss(W, b, x, custom_y_onehot)

#Let's plug the training logic inside a function.

function train_custom_model!(f_loss, weights, biases, features, labels_onehot)
    dLdW, dLdb, _, _ = gradient(f_loss, weights, biases, features, labels_onehot)
    weights .= weights .- 0.1 .* dLdW
    biases .= biases .- 0.1 .* dLdb
end

#=
We can plug the training function inside a loop and train the model for more epochs. 
The loop can be tailored to suit the user's needs, and the conditions can be specified in plain Julia.
Here we will train the model for a maximum of 500 epochs, but to ensure that the model does not overfit, 
we will break as soon as our accuracy value crosses or becomes equal to 0.98.
=#
for i = 1:500
    train_custom_model!(custom_loss, W, b, x, custom_y_onehot);
    custom_accuracy(W, b, x, y) >= 0.98 && break
end

@show custom_accuracy(W, b, x, y);
# Check the loss
custom_loss(W, b, x, custom_y_onehot)


# Now, let's repeat the same steps with our flux_model.Write a similar-looking training loop for our flux_model and train it similarly.

flux_loss(flux_model, x, flux_y_onehot)

function train_flux_model!(f_loss, model, features, labels_onehot)
    dLdm, _, _ = gradient(f_loss, model, features, labels_onehot)
    @. model[1].weight = model[1].weight - 0.1 * dLdm[:layers][1][:weight]
    @. model[1].bias = model[1].bias - 0.1 * dLdm[:layers][1][:bias]
end;

for i = 1:500
    train_flux_model!(flux_loss, flux_model, x, flux_y_onehot);
    flux_accuracy(x, y) >= 0.98 && break
end

#Looking at the accuracy and loss value
@show flux_accuracy(x, y);
@show custom_accuracy(W, b, x, y);

flux_loss(flux_model, x, flux_y_onehot)

#calculating the ROC curve:
function dfROC(y_observable, y_calc)

    #sorting probabilities and indexes
    sorted_indices = sortperm(vec(y_calc), rev=true)
    y_obs_sort= vec(y_observable[sorted_indices])
    n_pos = sum(y_observable)
    n_neg = length(y_observable) - n_pos
    
    #calculating ROC curve
    tp, fp = 0, 0
    tpr = Float64[]
    fpr = Float64[]
    
    y_l = length(y_obs_sort)
    
    for i in 1:y_l
        if y_obs_sort[i] == 1
            tp += 1
        else
            fp += 1
        end
        push!(tpr, tp/n_pos)
        push!(fpr, fp/n_neg)
    end
    
    #defining the DF

    df = DataFrame(FPR = fpr, TPR = tpr)
    df.FPR = Float64.(df.FPR)
    df.TPR = Float64.(df.TPR)
    
    return df
end



######## ----------#####
#### GLM Model ###
### GLM #### 

using GLM, GLMNet, GLMakie
using MLJBase
#uploading the df again:
cd("/Users/carolinabernal/Documents/DiplomadoExercises")
churn = CSV.read("Exercise5/dat/Churn_Modelling.csv", DataFrame, delim=',', header=true)

#2. Following the steps shown during the session:

# Cleaning data
# Just as we did in flux
churn = select(churn, Not([:RowNumber,:CustomerId,:Surname]))
describe(churn)

function stringCols(DataFrame)
    counter = 1
    catNames = String[]
    dDataFrame = describe(DataFrame)

    for k in dDataFrame.eltype

        if match(r"String", string(k)) != nothing
            push!(catNames, string(dDataFrame.variable[counter]))
        end
        counter += 1
    end

    return catNames

end


#label encoding categorical columns
function labelEncoder(DataFrame)

    for i in stringCols(DataFrame)
        vec = DataFrame[!, Symbol(i)]
        en_vec = labelencode(labelmap(vec), vec)
        DataFrame[!, Symbol(i)] = en_vec
    end
    
end

labelEncoder(churn)
describe(churn)



#selecting non-target variables:
function termnsSymbol(DataFrame, target::Symbol)
    
    selected_columns = names(DataFrame)
    selected_columns = filter(x -> x != string(target), selected_columns)
    
    return sum(Term.(Symbol.(selected_columns)))

end

#setting a random index:
DFs = size(churn)[1]
index_train = Random.shuffle(1:DFs)[1:floor(Int, 0.75*DFs)]
index_test = setdiff(1:DFs, index_train)

#setting the training and test data:
churn_test = churn[index_test, :]
churn_train = churn[index_train, :]

#let's choose a p value of 0.05!
LRmod = glm(Term(:Exited) ~ termnsSymbol(churn_train, :Exited), churn_train, Binomial(), ProbitLink())

#=
 P value, the columns: 

:Tenure
:NumOfProducts
:HasCrCard
:EstimatedSalary

non-significant
=#

#let's evaluate the model and then see how it performs without those columns:
y_prob = GLM.predict(LRmod, churn_test)
y_pred = (y_prob .>= 0.5) .|> Bool

y_true = churn_test.Exited

#Printing the confusion matrix for the data:
println("The confusion matrix of the model looks like this: ")
display(EvalMetrics.ConfusionMatrix(Int64.(y_true), y_pred);)
acc_GLM = accuracy(EvalMetrics.ConfusionMatrix(Int64.(y_true), y_pred))
println("The accuracy of the model is: $(acc_GLM)")

#the DF for the ROC curve is like follows:
ROCdf = dfROC(Int64.(y_true), y_pred)


#Plotting ROC curve
#this value is going to be needed to plot a line in plotlyJL
t = 0:0.01:1 
fpr = ROCdf.FPR
tpr = ROCdf.TPR
# Calculating the AUC value:
auC = 0.0
for i in 1:length(fpr)-1
    auC += (fpr[i+1] - fpr[i]) * (tpr[i+1] + tpr[i]) / 2
end

p = PlotlyJS.plot([
    PlotlyJS.scatter(x = ROCdf.FPR , y = ROCdf.TPR, name = "ROC curve"),
    PlotlyJS.scatter(x = t, y = t, name = "reference curve")
    ], 
    Layout(
        autosize=false,
        width=700,
        height=500,
        title = "ROC Curve, AUC:$(round(auC, digits = 3))",
        xlabel = "TPR",
        ylabel = "FPR"
    )
)

savefig(p, "Exercise5/fig/ROC_churn_GLM.png")
display(p)

######################################### pt2 evaluating the model without non-significant parameters:


churn = CSV.read("Exercise5/dat/Churn_Modelling.csv", DataFrame, delim=',', header=true)

#2. Following the steps shown during the session:

# Cleaning data
churn = select(churn, Not([:RowNumber,:CustomerId,:Surname]))
churn = select(churn, Not([:Tenure,:NumOfProducts,:HasCrCard,:EstimatedSalary]))
describe(churn)

#label encoding categorical columns
labelEncoder(churn)
describe(churn)

#setting a random index:
DFs = size(churn)[1]
index_train = Random.shuffle(1:DFs)[1:floor(Int, 0.75*DFs)]
index_test = setdiff(1:DFs, index_train)

#setting the training and test data:
churn_test = churn[index_test, :]
churn_train = churn[index_train, :]

#let's choose a p value of 0.05!

LRmod = glm(Term(:Exited) ~ termnsSymbol(churn_train, :Exited), churn_train, Binomial(), ProbitLink())

#let's evaluate the model and then see how it performs without those columns:
y_prob = GLM.predict(LRmod, churn_test)
y_pred = (y_prob .>= 0.5) .|> Bool

y_true = churn_test.Exited

#Printing the confusion matrix for the data:
println("The confusion matrix of the model looks like this: ")
display(EvalMetrics.ConfusionMatrix(Int64.(y_true), y_pred);)
pred_enhaced = accuracy(EvalMetrics.ConfusionMatrix(Int64.(y_true), y_pred))
println("The accuracy of the model is: $(pred_enhaced)")

#the DF for the ROC curve is like follows:
ROCdf = dfROC(Int64.(y_true), y_pred)



#Plotting ROC curve
#this value is going to be needed to plot a line in plotlyJL
t = 0:0.01:1 
fpr = ROCdf.FPR
tpr = ROCdf.TPR
# Calculating the AUC value:
auC = 0.0
for i in 1:length(fpr)-1
    auC += (fpr[i+1] - fpr[i]) * (tpr[i+1] + tpr[i]) / 2
end

p = plot([
    PlotlyJS.scatter(x = ROCdf.FPR , y = ROCdf.TPR, name = "ROC curve"),
    PlotlyJS.scatter(x = t, y = t, name = "reference curve")
    ], 
    Layout(
        autosize=false,
        width=700,
        height=500,
        title = "ROC Curve, AUC:$(round(auC, digits = 3))",
        xlabel = "TPR",
        ylabel = "FPR"
    )
)

PlotlyJS.savefig(p, "Exercise5/fig/ROCchurnGLMImproved.png")
display(p)

