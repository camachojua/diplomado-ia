#Use the Stock Market data from Chap 4 of the ISL Book to do classification, using the following algorithms:

### changing the directory
cd("/Users/zoe/drv3/hm3/code/julia/hmw_diplo")

using Pkg
Pkg.add("DataFrames")
Pkg.add("PlotlyJS")
Pkg.add("NamedArrays")
Pkg.add("GLM")
Pkg.add("Random")
Pkg.add("StatsBase")
Pkg.add("Plots")
Pkg.add("GLMNet")
Pkg.add(["LIBSVM", "Distances", "DataStructures", "DecisionTree", "MLBase", "NearestNeighbors", "EvalMetrics", "ROCAnalysis"])

using CSV
using DataFrames
using Statistics
using Printf
using PlotlyJS
using NamedArrays
using Random
using GLM
using StatsBase

using GLMNet
using LinearAlgebra
using LIBSVM
using Distances
using DataStructures
using DecisionTree
using MLBase
using NearestNeighbors
using EvalMetrics
using ROCAnalysis



#1. getting the data (I downloaded it from Python + Colab)

smarket = CSV.read("Exercise3/dat/smarket.csv", DataFrame)

##filtering out first column, it was the index...
smarket = select(smarket, Not(:Column1))

#2. cleanning the data:

describe(smarket)

##notes:
    #data don't have any missing value
    #data don't have mixed values also

#including my tools to clean data:
include("/Users/zoe/drv3/hm3/code/julia/hmw_diplo/Exercise1/src/ExerciseN1.jl")

##making a copy of the df
csmarket = copy(smarket)
first(csmarket, 10)

## I want to remove year from csmarket to avoid linkg year to the calculations, 
## and :Today because it's directly linked to Direction
csmarket = select(csmarket, Not([:Year, :Today]))

y = csmarket.Direction
y_en = labelencode(labelmap(y), y) ##labelencode(map, vector)

csmarket.Direction = y_en
describe(csmarket) #now the Y variable is a numeric variable, let's see if we can find some dependencies with the cor function
first(csmarket, 20)

p = displayCorrelation(csmarket)
savefig(p, "Exercise3/fig/cor_smarket.png")
    #note: there's not a great column here, for most of them the cor is less than 10%

##Cleaning IQR range from the DS:
oriSize=size(csmarket)[1]
cleSize = size(removeOutliersIQR(csmarket))[1]

cleSize/oriSize ##if outer IQR range is excluded we're keeping ~80% of data

iqrmarket = removeOutliersIQR(csmarket)
describe(iqrmarket)

function classSplit(v::Vector, train_ratio::Float64 = 0.8, seed::Int = 1234)
    Random.seed!(seed)
    uids = unique(v)
    keepids = []

    for ui in uids
        #finding ui coincidences:
        curids = findall(v.==ui)
        #shuffling curuids:
        scuids = shuffle(curids)
        #keeping the train_ratio:
        l = Int(round(length(scuids)*train_ratio))
        randUids = scuids[1:l] 
        #adding ids to keepids list:
        push!(keepids, randUids...)
    end

    train = keepids
    test = setdiff(1:length(v), keepids) #notice that v is a vector with 1 and 2, then I have to compare w somethin that has "index"

    return train, test

end


## transforming data to have it in the formar the logs required it:

Y = csmarket.Direction
X = Matrix(csmarket[:, 1:6])

index_train, index_test = classSplit(Y, 0.8)

#3. Use Go or Julia to write/use the classification algos. 

    #Finally, now we have prep the data we can start with the fun part!
    # making a function to assign a value to a model output:
    assign_class(predictedvalue) = argmin(abs.(predictedvalue .- [1,2]))
    #making a function to measure a simple accuracy
    findaccuracy(predictedvals,groundtruthvals) = sum(predictedvals.==groundtruthvals)/length(groundtruthvals)

    #3.1 LASSO! :D
    # calculating the best λ:
    #training 
    path = glmnet(X[index_train,:], Y[index_train])
    cv = glmnetcv(X[index_train,:], Y[index_train])
    mylambda = path.lambda[argmin(cv.meanloss)] #this is the best lambda
    path = glmnet(X[index_train,:], Y[index_train],lambda=[mylambda]);
    #testing
    q = X[index_test,:];
    predictions_lasso = GLMNet.predict(path,q);
    predictions_lasso = assign_class.(predictions_lasso);
    acc_lasso = findaccuracy(predictions_lasso,Y[index_test])
    println("Model Lasso accuracy :  ",acc_lasso ) 

    #3.2 Ridge
    #training 
    path = glmnet(X[index_train,:], Y[index_train],alpha=0);
    cv = glmnetcv(X[index_train,:], Y[index_train],alpha=0)
    mylambda = path.lambda[argmin(cv.meanloss)]
    path = glmnet(X[index_train,:], Y[index_train],alpha=0,lambda=[mylambda]);
    #testing
    q = X[index_test,:];
    predictions_ridge = GLMNet.predict(path,q)
    predictions_ridge = assign_class.(predictions_ridge)
    acc_ridge = findaccuracy(predictions_ridge,Y[index_test])
    println("Model Ridge accuracy :  ",acc_ridge )

    #3.3 Elastic Net
    path = glmnet(X[index_train,:], Y[index_train],alpha=0.5);
    cv = glmnetcv(X[index_train,:], Y[index_train],alpha=0.5)
    mylambda = path.lambda[argmin(cv.meanloss)]
    path = glmnet(X[index_train,:], Y[index_train],alpha=0.5,lambda=[mylambda]);
    q = X[index_test,:];
    predictions_EN = GLMNet.predict(path,q)
    predictions_EN = assign_class.(predictions_EN)
    acc_eln = findaccuracy(predictions_EN,Y[index_test])
    println("Model Elastic Net accuracy :  ",acc_eln )


    #3.4 DecisionTree

    model = DecisionTreeClassifier(max_depth=3)
    DecisionTree.fit!(model, X[index_train,:], Y[index_train])


    q = X[index_test,:];
    predictions_DT = DecisionTree.predict(model, q)
    acc_dt = findaccuracy(predictions_DT,Y[index_test])
    println("Model Decision Tree accuracy :  ",acc_dt )
    
    #3.5 RandomForest
    model = RandomForestClassifier(n_trees=20)
    DecisionTree.fit!(model, X[index_train,:], Y[index_train])


    q = X[index_test,:];
    predictions_RF = DecisionTree.predict(model, q)
    acc_rmf = findaccuracy(predictions_RF,Y[index_test])
    println("Model Random Forests accuracy :  ",acc_rmf )


    #3.6 NearestNeighbors
    Xtrain = X[index_train,:]
    ytrain = Y[index_train]
    kdtree = KDTree(Xtrain')

    queries = X[index_test,:]
    idxs, dists = knn(kdtree, queries', 5, true)


    c = ytrain[hcat(idxs...)]
    possible_labels = map(i->counter(c[:,i]),1:size(c,2))
    predictions_NN = map(i->parse(Int,string(string(argmax(possible_labels[i])))),1:size(c,2))
    acc_nn = findaccuracy(predictions_NN,Y[index_test])
    println("Model Nearest Neighbor accuracy :  ",acc_nn )


    #3.7 SVM
    Xtrain = X[index_train,:]
    ytrain = Y[index_train]

    model = svmtrain(Xtrain', ytrain)


    predictions_SVM, decision_values = svmpredict(model, X[index_test,:]')
    acc_svm = findaccuracy(predictions_SVM,Y[index_test])
    println("Model Support Vector Machines accuracy :  ",acc_svm )

# Summary:

overall_accuracies = zeros(7)
methods = ["lasso","ridge","EN", "DT", "RF","kNN", "SVM"]
overall_accuracies[1] = acc_lasso 
overall_accuracies[2] = acc_ridge
overall_accuracies[3] = acc_eln
overall_accuracies[4] = acc_dt
overall_accuracies[5] = acc_rmf
overall_accuracies[6] = acc_nn
overall_accuracies[7] = acc_svm

@show hcat(methods, overall_accuracies)
median(overall_accuracies)

#=
We can see that the best performance is for
Decision Trees in this case, but in general 
the performance of the models isn't the best
the median for all the models is ~50%,
which is not better than fliping a coin...
=#

#4.1 Evaluate the accuracy of each prediction, using a confusion matrix and a ROC curve.

## making a prettier confusion_matrix
function confMatrixModel(y_observable, y_calc)
    
    predicts_model = y_calc[:,1]

    #re-mapping in case is needed, this is super particular for this use case:
    predicts_model[predicts_model .== 2] .= 0
    y_observable[y_observable .== 2] .= 0 

    cm_model = ConfusionMatrix(y_observable, predicts_model)

    n_cm_model = NamedArray(getproperty.(Ref(cm_model), [:tn :fn ; :fp :tp]), 
               (["f", "t"], ["f", "t"]), 
               ("pred", "true"))

    return n_cm_model
    
end

#making a function to facilitate the process of calculating the ROC curve:
function dfROC(y_observable, y_calc)

    #re-mapping in case is needed, this is super particular for this use case:
    y_observable[y_observable .== 2] .= 0 
    y_calc[y_calc .== 2] .= 0

    #sorting probabilities and indexes
    sorted_indices = sortperm(vec(y_calc), rev=true)
    y_obs_sort= vec(y_observable[sorted_indices])
    n_pos = sum(y_observable)
    n_neg = length(y_observable) - n_pos
    
    #calculating ROC curve
    tp, fp = 0, 0
    tpr = Float64[]
    fpr = Float64[]
    
    y_l = length(y_obs_sort)
    
    for i in 1:y_l
        if y_obs_sort[i] == 1
            tp += 1
        else
            fp += 1
        end
        push!(tpr, tp/n_pos)
        push!(fpr, fp/n_neg)
    end
    
    #defining the DF

    df = DataFrame(FPR = fpr, TPR = tpr)
    df.FPR = Float64.(df.FPR)
    df.TPR = Float64.(df.TPR)
    
    return df
end

## these are the Confusion matrix

println("These are the results for the model: lasso")
display(confMatrixModel(obsVal, predictions_lasso))
println("\n")

println("These are the results for the model: ridge")
display(confMatrixModel(obsVal, predictions_ridge))
println("\n")

println("These are the results for the model: EN")
display(confMatrixModel(obsVal, predictions_EN))
println("\n")

println("These are the results for the model: DT")
display(confMatrixModel(obsVal, predictions_DT))
println("\n")

println("These are the results for the model: RF")
display(confMatrixModel(obsVal, predictions_RF))
println("\n")

println("These are the results for the model: kNN")
display(confMatrixModel(obsVal, predictions_NN))
println("\n")

println("These are the results for the model: SVM")
display(confMatrixModel(obsVal, predictions_SVM))
println("\n")

#4.2 Plotting the roc curve:
rocDF = dfROC(targets, predictions_lasso)
p = plot(rocDF, x = :FPR, y= :TPR, mode="markers", Layout(title="ROC curve: predictions_lasso"))
savefig(p, "Exercise3/fig/ROC_predictions_lasso.png")

rocDF = dfROC(targets, predictions_ridge)
p = plot(rocDF, x = :FPR, y= :TPR, mode="markers", Layout(title="ROC curve: predictions_ridge"))
savefig(p, "Exercise3/fig/ROC_predictions_ridge.png")

rocDF = dfROC(targets, predictions_EN)
p = plot(rocDF, x = :FPR, y= :TPR, mode="markers", Layout(title="ROC curve: predictions_EN"))
savefig(p, "Exercise3/fig/ROC_predictions_EN.png")

rocDF = dfROC(targets, predictions_DT)
p = plot(rocDF, x = :FPR, y= :TPR, mode="markers", Layout(title="ROC curve: predictions_DT"))
savefig(p, "Exercise3/fig/ROC_predictions_DT.png")

rocDF = dfROC(targets, predictions_RF)
p = plot(rocDF, x = :FPR, y= :TPR, mode="markers", Layout(title="ROC curve: predictions_RF"))
savefig(p, "Exercise3/fig/ROC_predictions_RF.png")

rocDF = dfROC(targets, predictions_NN)
p = plot(rocDF, x = :FPR, y= :TPR, mode="markers", Layout(title="ROC curve: predictions_NN"))
savefig(p, "Exercise3/fig/ROC_predictions_NN.png")

rocDF = dfROC(targets, predictions_SVM)
p = plot(rocDF, x = :FPR, y= :TPR, mode="markers", Layout(title="ROC curve: predictions_SVM"))
savefig(p, "Exercise3/fig/ROC_predictions_SVM.png")

#=Conclusion: as said before, the predictions suited with each model
are not much better than flipping a coin, then trying to use a 
trained model to predict if the market is going to be up isn't a great idea
... at least with this data.
=#