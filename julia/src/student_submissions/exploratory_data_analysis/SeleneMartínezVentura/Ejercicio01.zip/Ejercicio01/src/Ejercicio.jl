using Markdown
using InteractiveUtils


	import Pkg;
	#Pkg.add(["CSV", "DataFrames"])
	#Pkg.add("Plots")
	#Pkg.add("Statistics")
	#Pkg.add(["GLMakie", "CairoMakie"])
	Pkg.offline(true)
	#Pkg.add("StatsBase")
	using CSV
	using DataFrames
	using Statistics
	using Printf: @sprintf
	using Plots
	using StatsBase
	#using GLMakie

	# Directories
	println(isfile("../dat/bottle.csv"))
	dir = "../dat/"
	filename = "bottle.csv"

	dr = dir*filename
	# Carga del archivo CSV
	df = df = CSV.read(dr, DataFrame);

	# Get the data list shape
	println("Data Shape: ", size(df))
	
	# Get data field types
	#=data_types = eltype.(eachcol(df))
	println("Data Types: ", data_types)
	# Describir el conjunto de datos
	names(df)=#
	
	data_types = eltype.(eachcol(df))
	for data_type  in data_types
	println("Data Types: ", data_type)
	end
	# Describir el conjunto de datos
	names(df)

	# Cleaninig
	# Counting missing columns
	function count_missing(column)#::Vector)
	    return sum(ismissing, column)
	    end
	
	for column in names(df)
	        println("Missing in column $column: ", count_missing(df[!, column]))
	end

	# Missing columns percent 
	    # Percent calculus of every missing sum divided by number of rows from data set.
	function missingPercent(df::DataFrame)
	        mpercent = Dict(column => sum(ismissing, df[!, column]) / nrow(df) * 100 for column in names(df) )
	    sorted_percent = sort(collect(mpercent), by = x -> x[2], rev = true)
	end
	percentList =  missingPercent(df)
	println("Porcentaje de valores faltantes por columna, en orden descendente")
	for (column, percent) in percentList
	    println("$column: $percent%")
	end

			# Threshold 50%
			# Delete data function
			function deleteColumns(df::DataFrame, threshold::Int64)
			    cols_to_drop = [col for col in names(df) if sum(ismissing, df[!, col]) / nrow(df) * 100 > threshold]
			    return select(df, Not(cols_to_drop))
			end
				df_percentfiltered = deleteColumns(df, 30)

# Obtener los nombres de las columnas y sus tipos de datos
column_names = names(df_percentfiltered)
data_types = eltype.(eachcol(df_percentfiltered))

	# Obtener los tipos de las columnas correspondientes
    for (i, (col, t)) in enumerate(zip(column_names, data_types))
		 println(@sprintf("%-2d.%-12s type: %-30s", i, col, t))
    end

	# Correlation Matrix 
	function numericalData(df::DataFrame)
	cols_numerical = [col for col in names(df) if 
	                                !occursin("String", string(eltype(df[!, col])))]
	# Crear un nuevo DataFrame con solo las columnas numéricas
	    return df[:, cols_numerical]
	end
	df_numerical = numericalData(df_percentfiltered)

	#function corMatrix(df::DataFrame)
	
		#Convert rhe DataFrame  to a Matrix
		matrix_cor = Matrix(df_numerical)
		correlation_matrix = cor(matrix_cor, dims=1)
		#return 
		#println(correlation_matrix)
		#end

			heatmap(   correlation_matrix,
		    xlabel = "Variables",
		    ylabel = "Variables",
		    xticks = (1.0:length(column_names), column_names),
		    yticks = (1.0:length(column_names), column_names),
		    color=:Spectral,
		    title = "Matriz de Correlación",
				xrotation = 90,
		    size=(1000, 1000))

# removeOutliersIQR() : using interquartile range delete all the outliers from the numerical columns.
#Q1: Percentil 25 (el valor que separa el 25% de los datos más bajos).
#Q3: Percentil 75 (el valor que separa el 25% de los datos más altos).
function removeOutliersIQR(df)
    for col in names(df)
        if eltype(df[!, col]) <: Real
            q1, q3 = quantile(df[!, col], 0.25), quantile(df[!, col], 0.75)
            iqr = q3 - q1
            lower_bound = q1 - 1.5 * iqr
            upper_bound = q3 + 1.5 * iqr
            df = df[df[!, col] .>= lower_bound .&& df[!, col] .<= upper_bound, :]
        end
    end
    return df
 
df_outliersRemoved = removeOutliersIQR(df_numerical)

	#deleteRow(column): for a given column delete all the null data points.
	function deleteRow(df, column)
	    return df[.!ismissing.(df[!, column]), :]
	end
	
	df_no_missing = deleteRow(df_outliersRemoved, "T_degC")

describe(df_no_missing)

#=
	function deleteRow(df::DataFrame)
	    return dropmissing(df)
	end
	
	# Uso de la función
	df_no_missing_II = deleteRow(df_outliersRemoved)
end=#

function filterColumnsByCorrelation(df::DataFrame, target_col::Symbol, threshold::Float64, relation::String)
    
    # Validar que el target_col exista en el DataFrame
    if !(target_col in propertynames(df))  # Usamos propertynames que devuelve Symbols
        throw(ArgumentError("La columna objetivo no está en el DataFrame"))
    end

    # Calcular las correlaciones de todas las columnas con la columna objetivo
    correlations = Dict{Symbol, Float64}()
    for col in propertynames(df)
        if col != target_col
            # Usamos skipmissing() para manejar valores faltantes
            valid_data_target, valid_data_col = [], []
			            for (t, c) in zip(df[!, target_col], df[!, col])
                if !ismissing(t) && !ismissing(c)
                    push!(valid_data_target, t)
                    push!(valid_data_col, c)
                end
            end

            # Verificar que ambos vectores tengan suficientes datos para calcular la correlación
 if length(valid_data_target) > 1 && length(valid_data_col) > 1
                correlations[col] = cor(valid_data_col, valid_data_target)
            end
        end
    end

    # Filtrar columnas según la relación y el umbral
    if relation == "greater"
        selected_columns = [name for (name, corr) in correlations if abs(corr) > threshold]
    elseif relation == "less"
        selected_columns = [name for (name, corr) in correlations if abs(corr) < threshold]
    else
        throw(ArgumentError("La relación debe ser 'greater' o 'less'"))
    end

    # Crear un DataFrame con las columnas seleccionadas y la columna objetivo
    return select(df, [target_col; selected_columns]...)
end


		df_correlated = filterColumnsByCorrelation(df_no_missing, :T_degC, 0.7, "greater")

#describe() : it is used to describe data by giving following for each column/
# Describir datos numéricos: media, mediana, etc.
function describeII(df::DataFrame)
    stats = Dict(col => Dict(
        "mean" => mean(skipmissing(df[!, col])),
        "median" => median(skipmissing(df[!, col])),
        "std" => std(skipmissing(df[!, col])),
        "min" => minimum(skipmissing(df[!, col])),
        "max" => maximum(skipmissing(df[!, col]))
    ) for col in names(df))
    return stats
end

describe(df_correlated)

	# Llamar a la función describeII con tu DataFrame
	stats = describeII(df_correlated)
	
	# Imprimir las estadísticas descriptivas
	# println(stats)
	# Imprimir las estadísticas de forma más legible
	for (i, (col, values)) in enumerate(stats)
	    println("Column $i:  $col")
	    println("  Mean   : $(round(values["mean"], digits=2))")
	    println("  Median : $(round(values["median"], digits=2))")
	    println("  Std    : $(round(values["std"], digits=2))")
	    println("  Min    : $(round(values["min"], digits=2))")
	    println("  Max    : $(round(values["max"], digits=2))")
	    println("*-"^15)
	end
	
	first(df_correlated, 200)
	describe(df_correlated)

GC.gc()

	matrix_cor2 = Matrix(df_correlated)
			correlation_matrix2 = cor(matrix_cor2, dims=1)



			heatmap(   correlation_matrix2,
		    xlabel = "Variables",
		    ylabel = "Variables",
		    xticks = (0.2:length(column_names), column_names),
		    yticks = (0.2:length(column_names), column_names),
		    color=:cool,
		    title = "Matriz de Correlación",
				xrotation = 90,
		    size=(1000, 1000))