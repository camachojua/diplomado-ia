import Pkg

####################################
#Paquetes usados en el proyecto:
paquetes = ["CSV", "DataFrames", "Statistics", "Random","GLM","CairoMakie"]
#"CairoMakie", "GLM",

#Instalar y usar los paquetes
for pkg in paquetes
    # Instalación de paquetes.
    if haskey(Pkg.installed(), pkg)
        println("El paquete \"$pkg\" ya está instalado.")
    else
        println("El paquete \"$pkg\" NO está instalado.")
        Pkg.add(pkg)
    end
    #Usar el paquete en el proyecto.
    try
        @eval using $(Symbol(pkg))
        println("El paquete \"$pkg\" se ha cargado exitosamente.")
    catch e
        println("Error al cargar el paquete \"$pkg\": $e")
    end
end
####################################

function leer_csv_como_dataframe(ruta::String)
    # Obtener la ruta al archivo CSV a partir de la ubicación de archivo.jl
    # Obtener la ruta al directorio actual
    directorio_actual = @__DIR__
    # Construir la ruta al directorio superior (un nivel arriba)
    ruta_superior = joinpath(directorio_actual, "..")
    # Convertir la ruta superior a una ruta absoluta (resuelve los "..")
    ruta_absoluto_superior = realpath(ruta_superior)
    # Superior
    ruta_csv = joinpath(ruta_absoluto_superior, ruta)
    # Leer el archivo CSV y convertirlo en un DataFrame
    df = CSV.read(ruta_csv, DataFrame)
    println("El archivo \"$ruta\" se ha cargado exitosamente.")
    # Retornar el DataFrame
    return df
end

####################################
#función que devuelve en un vector de dos elementos: el número de filas y número de columnas de un DataFrame.
function dataShape(df)
    forma = size(df)
    println("Número de filas: ", forma[1])  # Primer valor de la tupla: número de filas
    println("Número de columnas: ", forma[2])  # Segundo valor de la tupla: número de columnas
   return forma
end

####################################
#función que devuelve 3 elementos: 1.- Un diccionario con el nombre de las columnas del DataFrame como llave y el tipo de dato del DataFrame como valor.
# 2.-Un vector ordenado con el nombre de cada columna del dataframe
# 3.-Un vector ordenado con el tipo de cada columna del dataframe
function dataType(df,print=false)
    # Crear un diccionario para almacenar los tipos de datos de cada columna
    dic_tipos_columnas = Dict()
    # Iterar sobre las columnas y almacenar su tipo
    for columna in names(df)
        dic_tipos_columnas[columna] = eltype(df[!, columna])
    end
    # Mostrar el diccionario con los tipos de datos
    println("Se creó el diccionario con el nombre de columna como llave y tipo de dato como valor del dataframe")

    # Obtener las llaves como un vector
    nombres_columnas = collect(keys(dic_tipos_columnas))
    # Mostrar el resultado
    println("Se creó el vector con el nombre de columnas del dataframe")

    # Obtener las llaves como un vector
    datatype_columnas = collect(values(dic_tipos_columnas))
    # Mostrar el resultado
    println("Se creó el vector con el tipo de dato de cada columna del dataframe")

    # Mostrar el resultado
    if print==true
        for (llave, valor) in zip(nombres_columnas, datatype_columnas)
            valor_dir = dic_tipos_columnas[llave]
            println("El campo |$llave| tiene el tipo de dato |$valor")
        end
    else
        nothing
    end

    return dic_tipos_columnas, nombres_columnas, datatype_columnas
end

####################################
# Función para contar valores faltantes (missing) en una columna
function count_missing(col)
    return sum(ismissing.(col))
end

####################################
#Cuenta valores nulos y no nulos 
function contar_valores_missing_and_not(col)
    num_missing = count_missing(col)      # Contar valores faltantes (missing)
    num_no_missing = length(col) - num_missing  # Calcular no faltantes
    return num_missing, num_no_missing
end
####################################
#Saca el porcentaje como decimal de los valores nulos o no nulos.
function dataMissingPercentage(col)
    num_missing, num_no_missing = contar_valores_missing_and_not(col)
    colMissingPercentage=num_missing/(num_missing+num_no_missing)
    #println("Los casos son:", num_missing+num_no_missing)
    #println("numero de campos vacios:",num_missing)
    return colMissingPercentage
end
####################################
#Falta el data columns
function deleteColumns(df,threshold)
    columnsToEliminate=[]
    nThresholdToEliminate=0
    dic_tipos_columnas, nombres_columnas, datatype_columnas=dataType(df)
    n=0
    for llaves in nombres_columnas
        n+=1
        #println(n, ".-Columna: ", llaves)
        cuenta_vacios_de_columna=round(dataMissingPercentage(df[:, llaves])*10000)/100
       #println("% de vacios: ", cuenta_vacios_de_columna,"y es >=", threshold,":",cuenta_vacios_de_columna  >= threshold )
        if cuenta_vacios_de_columna >= threshold
            #println("Cumple el threshold de >=,", threshold, "y se elimina")
            #println("El porcentaje de no vacíos de la columna: ",llaves," es ",cuenta_vacios_de_columna, "% y supera el threshold de: ",threshold,"%, por lo que se elimina")
            push!(columnsToEliminate, llaves)
            nThresholdToEliminate+=1
        else
            #println("El porcentaje de no vacíos de la columna: ",llaves," es: ",cuenta_vacios_de_columna, "% y no supera el threshold de: ",threshold,"%, por lo que se mantiene")
        end
    end
    println("El número de columnas a eliminar es: ",nThresholdToEliminate)
    return select(df, Not(columnsToEliminate))
end

####################################
#Matriz de correlación de un df
function eliminarStringsDf(df)
    # Identificar columnas que NO tienen `String` o tipos relacionados
    non_string_columns = filter(col_name -> !(eltype(df[!, col_name]) <: Union{String, Union{Missing, String}, AbstractString}), names(df))
    println("El número de columnas conservadas que no son String son: ",length(non_string_columns))
    # Filtrar el DataFrame, seleccionando solo las columnas no String
    filtered_df = select(df, non_string_columns)
    return filtered_df
end


####################################
#Matriz de correlación de un df
function calculateCorrelation(df)
    df2=dropmissing(df)
    return cor(Matrix(df))
end

####################################
# Reemplazar `missing` con 0 solo en columnas que permitan `missing`
function missingToZeroDf(df)
    for col_name in names(df)
        if eltype(df[!, col_name]) <: Union{Missing, Number}
            df[!, col_name] = coalesce.(df[!, col_name], 0)
        end
    end
    return df
end

####################################
#Crear heatmap
function displayCorrelation(matrizCorrelacion, ruta::String)
    println("entrar a crear mapa")
    directorio_actual = @__DIR__
    # Construir la ruta al directorio superior (un nivel arriba)
    ruta_superior = joinpath(directorio_actual, "..")
    # Convertir la ruta superior a una ruta absoluta (resuelve los "..")
    ruta_absoluto_superior = realpath(ruta_superior)
    # Superior
    ruta_fig = joinpath(ruta_absoluto_superior, ruta)
    # Leer el archivo CSV y convertirlo en un DataFrame

    println(ruta_fig)

    # Plot the heatmap
    println("Inicio heatmap")
    
    fig, ax, hm = heatmap(
        matrizCorrelacion;
        colormap = :coolwarm,  # Diverging color scheme
        colorrange = (-1, 1),  # Match correlation range
        axis = (title = "Correlation Heatmap", xlabel = "Variables", ylabel = "Variables")
    )

    # Guardar la figura en el disco (formato PNG, PDF, SVG, etc.)
    save(ruta_fig, fig)  # Cambia la extensión según necesites
    println("Se guardo el heatmap")

end

########
 # función para filtrar los puntos que son extremos usando el rango intercuantil
 function removeOutliersIQR(df::DataFrame)
   # Indentificar columnas numericas
    df2=df
    columns_to_remove=[]
    #println("Longitud del df para remover outliers:")
    #dataShape(df2)
    numeric_cols = filter(col_name -> eltype(df2[!, col_name]) <: Union{Number,Missing}, names(df2))
    println("Columnas numericas son: ",length(numeric_cols))
    n=0
   for col in numeric_cols
        n+=1
        if col in names(df2)
            # Calcula cuantiles: Q1, Q3, y su rango IQR
                Q1 = quantile(filter(!ismissing, df[!, col]), 0.25)
                Q3 = quantile(filter(!ismissing, df[!, col]), 0.75)
                #println(n,".-El Q1 de la columna: ", col, "es: ", Q1)
                #println(n,".-El promedio es:", mean(filter(!ismissing, df[!, col])))
                #println(n,".-El Q3 de la columna: ", col, "es: ", Q3)
                #println(n,".-El número de columnas vacías es: ", length(filter(ismissing, df[!, col])))
                IQR = Q3 - Q1
                if IQR ==0
                    push!(columns_to_remove, col)
                    #println(n,".-Columna no representativa y a eliminar: ",col)
                else
                    #println(n,".-El valor de IQR del col: ",col, "es: ", IQR)
                    # Limites según outliers por intercuantiles: 
                    limite_inferior = Q1 - 1.5 * IQR
                    limite_superior = Q3 + 1.5 * IQR
                        #println(lower_bound,"|",upper_bound,"|",col)
                    # filtro del df por rango
                    df2 = filter(row -> !ismissing(row[col]) && row[col] >= limite_inferior && row[col] <= limite_superior, df2)
                    #println("Filtro por IQR del renglon: ", col)
                    #println(dataShape(df2))
                end
            
            
        else
            #println("El valor: ",col," fue removido del dataframe")
        end
   end
   return select(df2, Not(columns_to_remove))
end

##########
function deleteRow(df::DataFrame)
    # remueve filas solo si todos los valores son nulos, aplica para df o columnas de df
    clean_df = df[.![all(ismissing, row) for row in eachrow(df)], :]
    return clean_df
end

function filterColumnsByCorrelation(df::DataFrame, target::String, threshold::Float64, relation::Function)
    # Manejo de errores inesperados
    try
        # Valida si el tarjet existe:
        if !(target in names(df))
            throw(ArgumentError("La columna $target no existe en el DataFrame"))
        end
        
         # Valida si el valor es numerico o nulo:
        if !(eltype(df[!,target]) <: Union{Number,Missing})
            throw(ArgumentError("La columna $target debe contener valores numericos"))
        end
        
        # Genera el vector para saber que columnas remover:
        columns_to_remove = []
        
        for col in names(df)
            #println("Columna evaluada: ",col)
            # Skipea target
            if col == target
                #println("Salto por la columna target")
                continue
            end
            
            # Valida si la columna es de tipo Number o Missing si es distinta a target
            if eltype(df[!,col]) <: Union{Number,Missing}
                # Nos quedamos con las columnas que sean de tipo numerico
                nonmissing_rows = .!(ismissing.(df[!,target]) .| ismissing.(df[!,col]))
                target_values = df[!,target][nonmissing_rows]
                column_values = df[!,col][nonmissing_rows]
                #println("nonmissing_rows: ",nonmissing_rows)
                #println("Valores de column: ",column_values)
                # Calcula correlación si hay más de dos valores:
                if length(target_values) > 1
                    correlation = cor(target_values, column_values)
                    #println("Correlación de la columna ",target,"con la columna",cor,"es: ",correlation)
                    # Aplica la correlación
                    if relation(threshold,correlation)
                        push!(columns_to_remove, col)
                    end
                else
                    #hace push si no hay valores que comparar
                    push!(columns_to_remove, col)
                end
            end
        end
        #println("Columnas a remover: ",length(columns_to_remove))
        return select(df, Not(columns_to_remove))
    catch
        throw(ArgumentError("Error de procesamiento"))
    end
     # Regresa el DataFrame sin las columnas que no pasan el threshold o que no tienen data suficiente:
end

function filtrar_nombres(df::DataFrame, columna_a_eliminar::String)
    # Obtener los nombres de las columnas
    nombres_columnas = names(df)
    # Filtrar los nombres que no coincidan con el valor dado
    nombres_filtrados = filter(nombre -> nombre != columna_a_eliminar, nombres_columnas)
    return nombres_filtrados
end

function dfCorrelaciónYDiccionario(df::DataFrame, threshold::Float64, relation::Function)
    df2=df
    resultado = Dict()
    #Se evalua cada uno de las columnas
    for col in names(df2)
        if col in names(df2)
            resultado[col]= filtrar_nombres(filterColumnsByCorrelation(df2, col, threshold, relation),col)      
            if length(resultado[col]) != 0
                #println("true:",length(resultado[col]),",",resultado[col]) 
                select!(df2, Not(resultado[col]))
                #println(df2)
            else
                continue
            end
        else
            continue
        end
    end
    return resultado, df2
end

# Función para aplicar describe a cada columna
function describe_columns(df::DataFrame)
    for col in names(df)
        println("Descripción de la columna: $col")
        println(describe(df[:, col]))
        println("-"^40)
    end
end

# Función para entrenar un modelo de regresión lineal multivariable
function train_multivariable_linear_model(df::DataFrame, target::AbstractString)
    # Filtrar las columnas que no sean la variable objetivo
    independent_vars = setdiff(names(df), [target])
    
    # Construir la fórmula dinámicamente
    formula = Term(Symbol(target)) ~ sum(Term.(Symbol.(independent_vars)))
    
    # Entrenar el modelo
    model = lm(formula, df)
    
    return model
end

function manejoDirectorio(ruta_fit)
    directorio_actual = @__DIR__
    # Construir la ruta al directorio superior (un nivel arriba)
    ruta_superior = joinpath(directorio_actual, "..")
    # Convertir la ruta superior a una ruta absoluta (resuelve los "..")
    ruta_absoluto_superior = realpath(ruta_superior)
    ruta_fit2 = joinpath(ruta_absoluto_superior, ruta_fit)
    return ruta_fit2
end

########
function run(normal=true)

        if normal==true
            #Código:

            #ruta de información
            ruta="dat/bottle.csv"
            ruta_fig_sin_quitar_correlaciones="fig/Correlation_heatmap.png"
            ruta_fig_baja_correlacion="fig/Low_Correlation_heatmap.png"
            #leer csv
            df=leer_csv_como_dataframe(ruta)
            println("DataFrame original")
            dataShape(df)
            #dic_tipos_columnas, nombres_columnas, datatype_columnas=dataType(df)
            #println(nombres_columnas)
            #----Eiminar renglones vacíos
            #df1=deleteRow(df)
            #println("DataFrame sin renglones vacíos")
            #dataShape(df1)
            #----Definir threshold
            threshold=10
            #----Eliminar columnas según el threshold de datos missing
            df2=deleteColumns(df,threshold)
            println("DataFrame con columnas que tengan un porcentaje de vacíos mayor a: ",threshold,"%")
            dataShape(df2)
            dic_tipos_columnas2, nombres_columnas2, datatype_columnas2=dataType(df2)
            println(nombres_columnas2)
            #----Construir df sin strings
            df3=eliminarStringsDf(df2)
            println("DataFrame Sin Strings")
            dataShape(df3)
            #----Cambiar missing a cero
            #df4=missingToZeroDf(df3)
            #println("Data Frame donde missing se vuelve cero")
            #dataShape(df4)
            #----Quitar outliyers siguiendo el rango intercuantil sobre valores numericos
            #df5=removeOutliersIQR(df4)
            df5=removeOutliersIQR(df3)
            println("Data Frame donde se eliminan renglones fuera del rango intercuantil")
            dataShape(df5)
            #----Calculo de matriz de correlación
            matrizCorrelacion=calculateCorrelation(df5)
            #----crear mapa de color
            #displayCorrelation(matrizCorrelacion,ruta_fig_sin_quitar_correlaciones)
            #----A partir de un threshold determinar columnas con alta correlación:
            threshold2=0.90
            relation= >=
            variablesCorrelacionadas, df6=dfCorrelaciónYDiccionario(df5, threshold2, relation)
            println(variablesCorrelacionadas)
            dataShape(df6) 
            #----Calculo de matriz de correlación
            matrizCorrelacion=calculateCorrelation(df6)
            #----crear mapa de color
            #displayCorrelation(matrizCorrelacion,ruta_fig_baja_correlacion)
            #println(matrizCorrelacion)
            #----Describir columnas:
            #describe_columns(df6)
            #Regresión lineal
            dic_tipos_columnas, nombres_columnas, datatype_columnas=dataType(df6)
           

            # Entrenar el modelo para predecir T_degC
            model = train_multivariable_linear_model(df6, "T_degC")

            # Mostrar resultados del modelo
            println("Resumen del modelo:")
            println(model)

            # Coeficientes del modelo
            println("Coeficientes del modelo:")
            println(coef(model))

            # R² del modelo
            println("R² (R-squared): ", r2(model))

            # Obtener las predicciones del modelo
            df6.T_degC_pred = predict(model, df6)
            dataShape(df6)
            println(names(df6))

            # Gráfica de la data real (scatter) y la línea de predicción
            #Plots.scatter(df6[!,"T_degC"], df6[!,"Cst_Cnt"], label="Datos reales", xlabel="Cst_Cnt", ylabel="T_degC", color=:blue,markersize=1)

            directorio_actual = @__DIR__
            # Construir la ruta al directorio superior (un nivel arriba)
            ruta_superior = joinpath(directorio_actual, "..")
            # Convertir la ruta superior a una ruta absoluta (resuelve los "..")
            ruta_absoluto_superior = realpath(ruta_superior)
            # Superior
            #ruta_fit = joinpath(ruta_absoluto_superior, "fig/linear_fit.png")
            # Guardar el gráfico en el mismo directorio con el nombre "grafico.png"
            #Plots.savefig(ruta_fit)  # Guardar como PNG



            #Plots.scatter(df6[!,"T_degC_pred"], df6[!,"Cst_Cnt"], label="Datos estimados", xlabel="Cst_Cnt", ylabel="T_degC_pred", color=:yellow, markersize=1)
            # Superior
            #ruta_fit2 = joinpath(ruta_absoluto_superior, "fig/linear_fit2.png")

            # Guardar el gráfico en el mismo directorio con el nombre "grafico.png"
            #Plots.savefig(ruta_fit2)  # Guardar como PNG


            Plots.scatter(df6[!,"T_degC_pred"], df6[!,"T_degC"], label="Comparación de datos", xlabel="T_degC", ylabel="T_degC_pred", color=:green, markersize=1)
            # Superior
            ruta_fit3 = joinpath(ruta_absoluto_superior, "fig/linear_fit3.png")

            # Guardar el gráfico en el mismo directorio con el nombre "grafico.png"
            Plots.savefig(ruta_fit3)  # Guardar como PNG

        else

            # Ejemplo DataFrame
            println("start")
            df = DataFrame(a = rand(10), b = rand(10), c = rand(10), d = [missing,missing,3,4,5,6,7,8,9,0], e=[2,2,2,4,5,6,7,8,9,missing])
            println("Original DataFrame:")
            println(df)

            df[!,:a] .= 0.5df[!,:b]  # Add correlation between `a` and `b`

            println("DataFrame correlation:")
            println(df)
            threshold=0.90
            relation= >=
            # Apply function to filter columns with correlation > 0.8 with the target column :a
            #filtered_df = filterColumnsByCorrelation(df, "e", 0.9, >=)
            #println(filtered_df)
            #println(filtrar_nombres(filtered_df,"e"))

            matrizCorrelación, df6=dfCorrelaciónYDiccionario(df, threshold, relation)
            dataShape(df6)
            println(matrizCorrelación)
        end
end

#run()


