using CSV, DataFrames, Statistics, Plots, Measures

# Función para obtener la forma del dataset (número de filas y columnas)
function dataShape(data)
    rows, cols = size(data)
    println("No. of rows: $rows \nNo. of Columns: $cols \n")
    return nothing
end

# Función para obtener los tipos de datos de cada columna en un DataFrame
function dataType(df::DataFrame)
    results = DataFrame(column_name = names(df), data_type = eltype.(eachcol(df)))
    return results    
end

# Función para contar el número de valores faltantes en una columna específica
function count_missing(df::DataFrame, col::String)
    if col in names(df)
        count = 0
        for value in df[!, col]
            if ismissing(value)
                count += 1
            end
        end
        return (col, count)
    else
        println("Column: '$col' does not exist in the DataFrame.")
        return nothing
    end
end

# Función para calcular el porcentaje de valores faltantes por columna
function dataMissingPercentage(df::DataFrame)
    # Recupera los tipos de datos
    data_types = dataType(df)

    # Agrega una columna para los porcentajes de valores faltantes
    data_types[!, :missing_percent] .= 0.0

    # Calcula los porcentajes de valores faltantes por columna
    for col in names(df)
        _, missing_count = count_missing(df, col)
        missing_percentage = (missing_count * 100) / nrow(df) #Calcula el porcentaje
        row_idx = findfirst(==(col), data_types[!, :column_name]) # Encuentra el índice
        data_types[row_idx, :missing_percent] = missing_percentage
    end

    return data_types
end

# Función para eliminar columnas con un porcentaje de valores faltantes mayor al umbral especificado
function deleteColumns(df::DataFrame, results::DataFrame, threshold::Float64)
    # Iterar sobre cada columna
    for row in eachrow(results)
        col_name = row[:column_name]
        missingPercentage = row[:missing_percent]

        # Verificar si el porcentaje de valores faltantes supera el umbral
        if missingPercentage > threshold
            select!(df, Not(col_name)) #Eliminar la columna del DataFrame
        end
    end

    # Mostrar la nueva forma y los tipos de datos después de la eliminación
    println("Updated DataFrame:")
    println(dataShape(df))
    println(dataType(df))

    return df
end

# Función para eliminar filas con valores faltantes en una columna específica
function deleteRow(df::DataFrame, column::Symbol)
    # Verificar si la columna existe en el DataFrame
    if hasproperty(df, column)
        # Identificar los indices de las filas con valores missing
        missing_indices = findall(ismissing, df[:, column])

        # Eliminar las filas con valores missing
        delete!(df, missing_indices)

        println("Rows with missing values in column '$column' have been deleted")
    else
        println("Column '$column' does not exist in the DataFrame")
    end

    println("Updated DataFrame:")
    println(dataShape(df))
    println(dataType(df))

    return df
end

# Función para calcular la matriz de correlación entre columnas numéricas
function calculateCorrelation(df::DataFrame)
    numeric_cols = get_numeric_columns(df)
    corr_mat = Dict{String, Dict{String, Float64}}()

    for col1 in numeric_cols
        corr_mat[col1] = Dict{String, Float64}()
        for col2 in numeric_cols
            if col1 == col2
                corr_mat[col1][col2] = 1.0
            else
                # Eliminar filas con valores faltantes en ambas columnas
                filtered_df = dropmissing(df, [col1, col2])
                if nrow(filtered_df) > 1
                    corr_mat[col1][col2] = cor(filtered_df[!, col1], filtered_df[!, col2])
                else
                    corr_mat[col1][col2] = NaN  # No hay suficientes datos para calcular
                end
            end
        end
    end

    
    return corr_mat
end

# Función para mostrar el heatmap de correlación
function displayCorrelation(df::DataFrame, outFile::String)
    corr_mat = calculateCorrelation(df)
    numeric_cols = get_numeric_columns(df)
    
    corr_matrix = [corr_mat[col1][col2] for col1 in numeric_cols, col2 in numeric_cols]

    rounded_corr_matrix = round.(corr_matrix; digits=2)

    # Crear el heatmap
    plot = heatmap(
    numeric_cols,
    numeric_cols,
    rounded_corr_matrix,
    color=:coolwarm,
    clims=(-1, 1),
    size=(1800, 1800),
    title="Correlation Heatmap\n\n",
    xlabel="Columns",
    ylabel="Columns",
    xticks=(1:length(numeric_cols), numeric_cols),
    yticks=(1:length(numeric_cols), numeric_cols),
    xrotation=45,
    left_margin=10mm,   # Aquí usamos mm del paquete Measures
    right_margin=10mm,
    top_margin=20mm,
    bottom_margin=20mm
    )

    # Agregar anotaciones para cada valor en la matriz
    for i in 1:size(rounded_corr_matrix, 1)
        for j in 1:size(rounded_corr_matrix, 2)
            annotate!(
                j-0.5,
                i-0.5,  # Nota: intercambiamos i y j para alinearlas correctamente
                text(string(rounded_corr_matrix[i, j]), 10, :black, :center)
            )
        end
    end    

    fig_path = joinpath(@__DIR__, "../fig/$outFile")
    savefig(plot, fig_path)

    println("Figura $outFile generado y guardado en /fig\n")

    return plot 
end

# Función para obtener las columnas numéricas del DataFrame
function get_numeric_columns(df::DataFrame)
    return [name for name in names(df) if eltype(df[!, name]) <: Union{Missing, Int64,Float64}]
end

# Función para filtrar columnas según la correlación con una columna objetivo
function filterColumnsByCorrelation(df::DataFrame, target::AbstractString, threshold::Float64, relation::Bool)
    corr_mat = calculateCorrelation(df)
    numeric_cols = get_numeric_columns(df)

    if !(target in numeric_cols)
        error("La columna objetivo no existe en el DataFrame")
    end

    # Iterar sobre las columnas y aplicar la eliminación
    cols_to_delete = []
    for key in keys(corr_mat[target])
        if key == target
            continue
        end

        val = corr_mat[target][key]

        # Relación falsa
        if !relation && abs(val) <= abs(threshold)
            push!(cols_to_delete, key)
        end

        # Relación verdadera
        if relation && val >= threshold

            push!(cols_to_delete, key)
        end
    end

    #Eliminar las columnas seleccionadas
    select!(df, Not(cols_to_delete))
    return df
end

# Función para eliminar valores atípicos en columnas numéricas utilizando el rango intercuartil (IQR)
function removeOutliersIQR(df::DataFrame)
    numeric_cols = get_numeric_columns(df)

    for col in numeric_cols
        # Calcular los cuartiles e IQR
        Q1 = quantile(skipmissing(df[!, col]), 0.25)
        Q3 = quantile(skipmissing(df[!, col]), 0.75)
        IQR = Q3 - Q1

        # Calcular los límites inferior y superior
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR

        # Filtrar filas dentro de los límites
        df = filter(row -> row[col] === missing || (row[col] >= lower_bound && row[col] <= upper_bound), df)
    end

    println(dataShape(df))
    return df
end

# Construye la ruta del archivo
dataset_path = joinpath(@__DIR__, "../dat/bottle.csv")

# Verifica si el archivo existe
if !isfile(dataset_path)
    error("El archivo no existe en la ruta: $dataset_path")
end

# Carga el archivo
data = CSV.read(dataset_path, DataFrame)
println("Archivo cargado exitosamente.")

println(first(data, 5))

println("Forma del dataset:")

# Mostrar la forma del dataset (número de filas y columnas)
println(dataShape(data))

println("Tipos de datos de cada columna:")

# Mostrar los tipos de datos de cada columna
result = dataType(data)
println(result)

println("Descripción de los datos:")
println(describe(data))

# Mostrar porcentaje de datos faltantes
missing_percentages_df = dataMissingPercentage(data)
println(missing_percentages_df)

println("Eliminación de columnas")
data_cleaned = deleteColumns(data, missing_percentages_df, 25.0)
println(dataMissingPercentage(data_cleaned))

println("Eliminación de filas")

data_no_null= deleteRow(data_cleaned, :T_degC)
data_no_null= deleteRow(data_no_null, :Salnty)
data_no_null= deleteRow(data_no_null, :O2ml_L)
	
println(dataMissingPercentage(data_no_null))

println(describe(data_no_null))

displayCorrelation(data_no_null, "Correlation_heatmap.png")

# Filtrar columnas por correlación
df_filtered = filterColumnsByCorrelation(data_no_null, "T_degC", 0.1, false)
df_filtered = filterColumnsByCorrelation(df_filtered, "T_degC", 0.9, true)

println("Datos filtrados por correlación:\n ")

println(dataShape(df_filtered))
println(dataMissingPercentage(df_filtered))

displayCorrelation(df_filtered, "Correlation_heatmap_filtered.png")

# Eliminar columnas redundantes
cols_to_delete_symbols = Symbol.(collect(["R_Depth", "R_SALINITY","R_O2","R_O2Sat","R_SIGMA", "R_PRES", "R_DYNHT","Oxy_µmol/Kg", "O2Sat"]))
		
df_no_redundant= select(df_filtered, Not(cols_to_delete_symbols))

println(dataShape(df_no_redundant))
println(dataMissingPercentage(df_no_redundant))

displayCorrelation(df_no_redundant, "Correlation_no_redundant.png")

# Eliminar outliers
outliersRemoved = removeOutliersIQR(df_no_redundant)
	
println("Outliers removidos")

println(dataMissingPercentage(outliersRemoved))
println(describe(outliersRemoved))

displayCorrelation(outliersRemoved, "Correlation_outliers_removed.png")

# Guardar datset limpio en el directorio /out

out_path = joinpath(@__DIR__, "../out/bottle_cleaned.csv")

CSV.write(out_path, outliersRemoved)

println("Dataset limpiado y guardado en /out")



