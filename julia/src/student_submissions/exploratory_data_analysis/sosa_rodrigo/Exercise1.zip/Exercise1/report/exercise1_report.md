# CalCOFI bottle.csv: Análisis Exploratorio y Preparación de Datos

## Introducción

El presente reporte documenta el proceso de análisis, limpieza y visualización de datos realizado sobre el conjunto de datos oceanográficos **`bottle.csv`**, el cual proviene del proyecto CalCOFI (California Cooperative Oceanic Fisheries Investigations).

El objetivo principal del análisis exploratorio es preparar los datos para su uso posterior mediante un proceso de limpieza y exploración. Esto incluye:

- **Inspección inicial**: Evaluar la estructura del conjunto de datos, identificando tipos de datos y valores faltantes.
- **Limpieza de datos**: Eliminar datos redundantes, manejar valores atípicos y reducir el ruido en los datos.
- **Exploración de relaciones**: Evaluar las correlaciones entre variables numéricas y generar visualizaciones como mapas de calor para identificar patrones relevantes.
- **Creación de un conjunto de datos listo para análisis**: Producir un DataFrame limpio, representativo y adecuado para aplicaciones posteriores como modelos predictivos y análisis estadístico avanzado.

El resultado final de este reporte es proporcionar un conjunto de datos limpio y listo para su análisis. Además, se incluye el código utilizado en el proceso, de manera que sea reproducible y modificable según sea necesario.

### Sobre el Dataset

El conjunto de datos **`bottle.csv`** pertenece al proyecto CalCOFI (California Cooperative Oceanic Fisheries Investigations), que representa una de las series temporales más largas y completas de datos oceanográficos y biológicos en el mundo. Desde su inicio en 1949, CalCOFI ha recolectado información de más de 50,000 estaciones de muestreo. Algunas de las principales variables incluidas son:

- **Físicas**: Temperatura del agua (°C), salinidad (g/kg).
- **Químicas**: Oxígeno disuelto (ml/L), fosfatos, nitratos y silicatos (μM).
- **Biológicas**: Clorofila y biomasa de zooplancton.

La investigación de CalCOFI ha sido fundamental para documentar ciclos climáticos en la Corriente de California y su impacto en ecosistemas marinos, destacando fenómenos como el evento de calentamiento del Pacífico en 1957-58 que introdujo el término “El Niño” en la literatura científica.

Actualmente, CalCOFI realiza estudios trimestrales frente a la costa de California, recolectando datos físicos, químicos y biológicos a profundidades de hasta 500 metros.

El análisis de estos datos tiene el potencial de ofrecer valiosa información sobre el medio marino, su respuesta a cambios climáticos y la gestión sostenible de sus recursos vivos.

## Preparación del Dataset

En esta sección se describen las etapas realizadas para limpiar y procesar los datos del archivo **`bottle.csv`**, enfocándonos en manejar valores faltantes y preparar el dataset para su análisis exploratorio.

### 1. Carga del dataset

El primer paso fué cargar el conjunto de datos **`bottle.csv`** en un entorno de análisis de datos. En este caso, se utilizó Julia con las bibliotecas CSV y DataFrames para manejar los datos de manera eficiente.


```julia
using CSV, DataFrames, Statistics, Plots, Measures

# Carga el archivo
data = CSV.read("bottle.csv", DataFrame)
first(data, 5)
```




<div><div style = "float: left;"><span>5×74 DataFrame</span></div><div style = "clear: both;"></div></div><div class = "data-frame" style = "overflow-x: scroll;"><table class = "data-frame" style = "margin-bottom: 6px;"><thead><tr class = "header"><th class = "rowNumber" style = "font-weight: bold; text-align: right;">Row</th><th style = "text-align: left;">Cst_Cnt</th><th style = "text-align: left;">Btl_Cnt</th><th style = "text-align: left;">Sta_ID</th><th style = "text-align: left;">Depth_ID</th><th style = "text-align: left;">Depthm</th><th style = "text-align: left;">T_degC</th><th style = "text-align: left;">Salnty</th><th style = "text-align: left;">O2ml_L</th><th style = "text-align: left;">STheta</th><th style = "text-align: left;">O2Sat</th><th style = "text-align: left;">Oxy_µmol/Kg</th><th style = "text-align: left;">BtlNum</th><th style = "text-align: left;">RecInd</th><th style = "text-align: left;">T_prec</th><th style = "text-align: left;">T_qual</th><th style = "text-align: left;">S_prec</th><th style = "text-align: left;">S_qual</th><th style = "text-align: left;">P_qual</th><th style = "text-align: left;">O_qual</th><th style = "text-align: left;">SThtaq</th><th style = "text-align: left;">O2Satq</th><th style = "text-align: left;">ChlorA</th><th style = "text-align: left;">Chlqua</th><th style = "text-align: left;">Phaeop</th><th style = "text-align: left;">Phaqua</th><th style = "text-align: left;">PO4uM</th><th style = "text-align: left;">PO4q</th><th style = "text-align: left;">SiO3uM</th><th style = "text-align: left;">SiO3qu</th><th style = "text-align: left;">NO2uM</th><th style = "text-align: left;">NO2q</th><th style = "text-align: left;">NO3uM</th><th style = "text-align: left;">NO3q</th><th style = "text-align: left;">NH3uM</th><th style = "text-align: left;">NH3q</th><th style = "text-align: left;">C14As1</th><th style = "text-align: left;">C14A1p</th><th style = "text-align: left;">C14A1q</th><th style = "text-align: left;">C14As2</th><th style = "text-align: left;">C14A2p</th><th style = "text-align: left;">C14A2q</th><th style = "text-align: left;">DarkAs</th><th style = "text-align: left;">DarkAp</th><th style = "text-align: left;">DarkAq</th><th style = "text-align: left;">MeanAs</th><th style = "text-align: left;">MeanAp</th><th style = "text-align: left;">MeanAq</th><th style = "text-align: left;">IncTim</th><th style = "text-align: left;">LightP</th><th style = "text-align: left;">R_Depth</th><th style = "text-align: left;">R_TEMP</th><th style = "text-align: left;">R_POTEMP</th><th style = "text-align: left;">R_SALINITY</th><th style = "text-align: left;">R_SIGMA</th><th style = "text-align: left;">R_SVA</th><th style = "text-align: left;">R_DYNHT</th><th style = "text-align: left;">R_O2</th><th style = "text-align: left;">R_O2Sat</th><th style = "text-align: left;">R_SIO3</th><th style = "text-align: left;">R_PO4</th><th style = "text-align: left;">R_NO3</th><th style = "text-align: left;">R_NO2</th><th style = "text-align: left;">R_NH4</th><th style = "text-align: left;">R_CHLA</th><th style = "text-align: left;">R_PHAEO</th><th style = "text-align: left;">R_PRES</th><th style = "text-align: left;">R_SAMP</th><th style = "text-align: left;">DIC1</th><th style = "text-align: left;">DIC2</th><th style = "text-align: left;">TA1</th><th style = "text-align: left;">TA2</th><th style = "text-align: left;">pH2</th><th style = "text-align: left;">pH1</th><th style = "text-align: left;">DIC Quality Comment</th></tr><tr class = "subheader headerLastRow"><th class = "rowNumber" style = "font-weight: bold; text-align: right;"></th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "String15" style = "text-align: left;">String15</th><th title = "String" style = "text-align: left;">String</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Int64}" style = "text-align: left;">Int64?</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Union{Missing, Int64}" style = "text-align: left;">Int64?</th><th title = "Union{Missing, Int64}" style = "text-align: left;">Int64?</th><th title = "Union{Missing, Int64}" style = "text-align: left;">Int64?</th><th title = "Union{Missing, Int64}" style = "text-align: left;">Int64?</th><th title = "Union{Missing, Int64}" style = "text-align: left;">Int64?</th><th title = "Union{Missing, Int64}" style = "text-align: left;">Int64?</th><th title = "Union{Missing, Int64}" style = "text-align: left;">Int64?</th><th title = "Union{Missing, Int64}" style = "text-align: left;">Int64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Int64}" style = "text-align: left;">Int64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Int64}" style = "text-align: left;">Int64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Int64}" style = "text-align: left;">Int64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Int64}" style = "text-align: left;">Int64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Int64}" style = "text-align: left;">Int64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Int64}" style = "text-align: left;">Int64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Int64}" style = "text-align: left;">Int64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Int64}" style = "text-align: left;">Int64?</th><th title = "Union{Missing, Int64}" style = "text-align: left;">Int64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Int64}" style = "text-align: left;">Int64?</th><th title = "Union{Missing, Int64}" style = "text-align: left;">Int64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Int64}" style = "text-align: left;">Int64?</th><th title = "Union{Missing, Int64}" style = "text-align: left;">Int64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Int64}" style = "text-align: left;">Int64?</th><th title = "Union{Missing, Int64}" style = "text-align: left;">Int64?</th><th title = "Union{Missing, String31}" style = "text-align: left;">String31?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Union{Missing, Int64}" style = "text-align: left;">Int64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, String}" style = "text-align: left;">String?</th></tr></thead><tbody><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: left;">054.0 056.0</td><td style = "text-align: left;">19-4903CR-HY-060-0930-05400560-0000A-3</td><td style = "text-align: right;">0</td><td style = "text-align: right;">10.5</td><td style = "text-align: right;">33.44</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">25.649</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">3</td><td style = "text-align: right;">1</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">2</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: left;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">10.5</td><td style = "text-align: right;">10.5</td><td style = "text-align: right;">33.44</td><td style = "text-align: right;">25.64</td><td style = "text-align: right;">233.0</td><td style = "text-align: right;">0.0</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">0</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: left;">missing</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">2</td><td style = "text-align: right;">1</td><td style = "text-align: right;">2</td><td style = "text-align: left;">054.0 056.0</td><td style = "text-align: left;">19-4903CR-HY-060-0930-05400560-0008A-3</td><td style = "text-align: right;">8</td><td style = "text-align: right;">10.46</td><td style = "text-align: right;">33.44</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">25.656</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">3</td><td style = "text-align: right;">2</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">2</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: left;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">8.0</td><td style = "text-align: right;">10.46</td><td style = "text-align: right;">10.46</td><td style = "text-align: right;">33.44</td><td style = "text-align: right;">25.65</td><td style = "text-align: right;">232.5</td><td style = "text-align: right;">0.01</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">8</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: left;">missing</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">3</td><td style = "text-align: right;">1</td><td style = "text-align: right;">3</td><td style = "text-align: left;">054.0 056.0</td><td style = "text-align: left;">19-4903CR-HY-060-0930-05400560-0010A-7</td><td style = "text-align: right;">10</td><td style = "text-align: right;">10.46</td><td style = "text-align: right;">33.437</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">25.654</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">7</td><td style = "text-align: right;">2</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">3</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: left;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">10.0</td><td style = "text-align: right;">10.46</td><td style = "text-align: right;">10.46</td><td style = "text-align: right;">33.437</td><td style = "text-align: right;">25.65</td><td style = "text-align: right;">232.8</td><td style = "text-align: right;">0.02</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">10</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: left;">missing</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">4</td><td style = "text-align: right;">1</td><td style = "text-align: right;">4</td><td style = "text-align: left;">054.0 056.0</td><td style = "text-align: left;">19-4903CR-HY-060-0930-05400560-0019A-3</td><td style = "text-align: right;">19</td><td style = "text-align: right;">10.45</td><td style = "text-align: right;">33.42</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">25.643</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">3</td><td style = "text-align: right;">2</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">2</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: left;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">19.0</td><td style = "text-align: right;">10.45</td><td style = "text-align: right;">10.45</td><td style = "text-align: right;">33.42</td><td style = "text-align: right;">25.64</td><td style = "text-align: right;">234.1</td><td style = "text-align: right;">0.04</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">19</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: left;">missing</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">5</td><td style = "text-align: right;">1</td><td style = "text-align: right;">5</td><td style = "text-align: left;">054.0 056.0</td><td style = "text-align: left;">19-4903CR-HY-060-0930-05400560-0020A-7</td><td style = "text-align: right;">20</td><td style = "text-align: right;">10.45</td><td style = "text-align: right;">33.421</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">25.643</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">7</td><td style = "text-align: right;">2</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">3</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">9</td><td style = "font-style: italic; text-align: left;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">20.0</td><td style = "text-align: right;">10.45</td><td style = "text-align: right;">10.45</td><td style = "text-align: right;">33.421</td><td style = "text-align: right;">25.64</td><td style = "text-align: right;">234.0</td><td style = "text-align: right;">0.04</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "text-align: right;">20</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: right;">missing</td><td style = "font-style: italic; text-align: left;">missing</td></tr></tbody></table></div>



### 2. Inspección Inicial

La inspección inicial del dataset permitió determinar su estructura y características principales. Esto incluyó:

- El número total de filas y columnas.
- Los nombres y tipos de datos de cada columna.
- Identificación de columnas con valores faltantes y su tipo de dato.


```julia
# Función para obtener la forma del dataset (número de filas y columnas)
function dataShape(data)
    rows, cols = size(data)
	println("No. of rows: $rows \nNo. of Columns: $cols \n")
end
	
# Mostrar la forma del dataset (número de filas y columnas)
dataShape(data)
```

    No. of rows: 864863 
    No. of Columns: 74 
    



```julia
# Función para obtener los tipos de datos de cada columna en un DataFrame
function dataType(df::DataFrame)
    results = DataFrame(column_name = names(df), data_type = eltype.(eachcol(df)))
    return results    
end
	
# Mostrar los tipos de datos de cada columna
dataType(data)
```




<div><div style = "float: left;"><span>74×2 DataFrame</span></div><div style = "float: right;"><span style = "font-style: italic;">49 rows omitted</span></div><div style = "clear: both;"></div></div><div class = "data-frame" style = "overflow-x: scroll;"><table class = "data-frame" style = "margin-bottom: 6px;"><thead><tr class = "header"><th class = "rowNumber" style = "font-weight: bold; text-align: right;">Row</th><th style = "text-align: left;">column_name</th><th style = "text-align: left;">data_type</th></tr><tr class = "subheader headerLastRow"><th class = "rowNumber" style = "font-weight: bold; text-align: right;"></th><th title = "String" style = "text-align: left;">String</th><th title = "Type" style = "text-align: left;">Type</th></tr></thead><tbody><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1</td><td style = "text-align: left;">Cst_Cnt</td><td style = "text-align: left;">Int64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">2</td><td style = "text-align: left;">Btl_Cnt</td><td style = "text-align: left;">Int64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">3</td><td style = "text-align: left;">Sta_ID</td><td style = "text-align: left;">String15</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">4</td><td style = "text-align: left;">Depth_ID</td><td style = "text-align: left;">String</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">5</td><td style = "text-align: left;">Depthm</td><td style = "text-align: left;">Int64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">6</td><td style = "text-align: left;">T_degC</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">7</td><td style = "text-align: left;">Salnty</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">8</td><td style = "text-align: left;">O2ml_L</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9</td><td style = "text-align: left;">STheta</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">10</td><td style = "text-align: left;">O2Sat</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">11</td><td style = "text-align: left;">Oxy_µmol/Kg</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">12</td><td style = "text-align: left;">BtlNum</td><td style = "text-align: left;">Union{Missing, Int64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">13</td><td style = "text-align: left;">RecInd</td><td style = "text-align: left;">Int64</td></tr><tr><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">63</td><td style = "text-align: left;">R_NH4</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">64</td><td style = "text-align: left;">R_CHLA</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">65</td><td style = "text-align: left;">R_PHAEO</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">66</td><td style = "text-align: left;">R_PRES</td><td style = "text-align: left;">Int64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">67</td><td style = "text-align: left;">R_SAMP</td><td style = "text-align: left;">Union{Missing, Int64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">68</td><td style = "text-align: left;">DIC1</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">69</td><td style = "text-align: left;">DIC2</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">70</td><td style = "text-align: left;">TA1</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">71</td><td style = "text-align: left;">TA2</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">72</td><td style = "text-align: left;">pH2</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">73</td><td style = "text-align: left;">pH1</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">74</td><td style = "text-align: left;">DIC Quality Comment</td><td style = "text-align: left;">Union{Missing, String}</td></tr></tbody></table></div>




```julia
# Resumen estadístico de las columnas numéricas
describe(select(data, Not(:Depth_ID)))
```




<div><div style = "float: left;"><span>15×7 DataFrame</span></div><div style = "clear: both;"></div></div><div class = "data-frame" style = "overflow-x: scroll;"><table class = "data-frame" style = "margin-bottom: 6px;"><thead><tr class = "header"><th class = "rowNumber" style = "font-weight: bold; text-align: right;">Row</th><th style = "text-align: left;">variable</th><th style = "text-align: left;">mean</th><th style = "text-align: left;">min</th><th style = "text-align: left;">median</th><th style = "text-align: left;">max</th><th style = "text-align: left;">nmissing</th><th style = "text-align: left;">eltype</th></tr><tr class = "subheader headerLastRow"><th class = "rowNumber" style = "font-weight: bold; text-align: right;"></th><th title = "Symbol" style = "text-align: left;">Symbol</th><th title = "Union{Nothing, Float64}" style = "text-align: left;">Union…</th><th title = "Any" style = "text-align: left;">Any</th><th title = "Union{Nothing, Float64}" style = "text-align: left;">Union…</th><th title = "Any" style = "text-align: left;">Any</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Type" style = "text-align: left;">Type</th></tr></thead><tbody><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1</td><td style = "text-align: left;">Sta_ID</td><td style = "font-style: italic; text-align: left;"></td><td style = "text-align: left;">001.0 168.0</td><td style = "font-style: italic; text-align: left;"></td><td style = "text-align: left;">176.7 030.0</td><td style = "text-align: right;">0</td><td style = "text-align: left;">String15</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">2</td><td style = "text-align: left;">Depthm</td><td style = "text-align: left;">219.686</td><td style = "text-align: left;">0</td><td style = "text-align: left;">125.0</td><td style = "text-align: left;">5351</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Int64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">3</td><td style = "text-align: left;">T_degC</td><td style = "text-align: left;">10.9188</td><td style = "text-align: left;">1.44</td><td style = "text-align: left;">10.16</td><td style = "text-align: left;">31.14</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">4</td><td style = "text-align: left;">Salnty</td><td style = "text-align: left;">33.8327</td><td style = "text-align: left;">29.402</td><td style = "text-align: left;">33.853</td><td style = "text-align: left;">37.034</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">5</td><td style = "text-align: left;">O2ml_L</td><td style = "text-align: left;">3.4167</td><td style = "text-align: left;">-0.01</td><td style = "text-align: left;">3.47</td><td style = "text-align: left;">11.13</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">6</td><td style = "text-align: left;">STheta</td><td style = "text-align: left;">25.7979</td><td style = "text-align: left;">20.996</td><td style = "text-align: left;">25.972</td><td style = "text-align: left;">28.083</td><td style = "text-align: right;">221</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">7</td><td style = "text-align: left;">O2Sat</td><td style = "text-align: left;">57.1036</td><td style = "text-align: left;">-0.1</td><td style = "text-align: left;">54.4</td><td style = "text-align: left;">214.1</td><td style = "text-align: right;">217</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">8</td><td style = "text-align: left;">Oxy_µmol/Kg</td><td style = "text-align: left;">148.809</td><td style = "text-align: left;">-0.4349</td><td style = "text-align: left;">151.064</td><td style = "text-align: left;">485.702</td><td style = "text-align: right;">221</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9</td><td style = "text-align: left;">R_Depth</td><td style = "text-align: left;">219.686</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">125.0</td><td style = "text-align: left;">5351.0</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Float64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">10</td><td style = "text-align: left;">R_SALINITY</td><td style = "text-align: left;">33.8326</td><td style = "text-align: left;">4.57</td><td style = "text-align: left;">33.853</td><td style = "text-align: left;">37.034</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">11</td><td style = "text-align: left;">R_SIGMA</td><td style = "text-align: left;">25.7928</td><td style = "text-align: left;">20.99</td><td style = "text-align: left;">25.97</td><td style = "text-align: left;">27.95</td><td style = "text-align: right;">1706</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">12</td><td style = "text-align: left;">R_DYNHT</td><td style = "text-align: left;">0.434145</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.35</td><td style = "text-align: left;">3.88</td><td style = "text-align: right;">4052</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">13</td><td style = "text-align: left;">R_O2</td><td style = "text-align: left;">3.41674</td><td style = "text-align: left;">-0.01</td><td style = "text-align: left;">3.47</td><td style = "text-align: left;">11.13</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">14</td><td style = "text-align: left;">R_O2Sat</td><td style = "text-align: left;">57.1314</td><td style = "text-align: left;">-0.1</td><td style = "text-align: left;">54.4</td><td style = "text-align: left;">214.1</td><td style = "text-align: right;">1635</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">15</td><td style = "text-align: left;">R_PRES</td><td style = "text-align: left;">221.164</td><td style = "text-align: left;">0</td><td style = "text-align: left;">126.0</td><td style = "text-align: left;">5458</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Int64</td></tr></tbody></table></div>



El conjunto de datos constó de 864,863 filas y 74 columnas, donde cada fila corresponde a una observación de las condiciones oceanográficas tomadas en distintas estaciones de muestreo, y cada columna representa un parámetro específico de medición. Entre los parámetros más relevantes se incluyen:

- **Cst_Cnt** y **Btl_Cnt** (Conteo de botellas)
- **Sta_ID** 
- **T_degC** (Temperatura en grados Celsius), **Salnty** (Salinidad), **O2ml_L** (Oxígeno disuelto en mililitros por litro).
- **ChlorA** (Clorofila A), **PO4uM** (Fósforo en micromolar), **NO2uM** (Nitrito en micromolar), entre otros.

Al revisar el tipo de datos, se detectó que la mayoría de las columnas contienen valores de tipo numérico (enteros o flotantes) y algunas contienen datos de texto (por ejemplo, identificadores). La inspección de los valores faltantes reveló lo siguiente:

- **Cst_Cnt** y **Btl_Cnt** no tienen valores faltantes, lo que indica que estos campos están completos y bien registrados.
- Se observó que algunas columnas, como **T_degC** (Temperatura), **O2ml_L** (Oxígeno disuelto), y **ChlorA** (Clorofila A), contienen valores faltantes, específicamente 10,963 valores faltantes para la temperatura, 168,662 para oxígeno disuelto y 639,591 para Chlorofila A. Estas ausencias podrían ser debidas a mediciones que no fueron realizadas en ciertos puntos o condiciones de muestreo.
- **Salnty** (Salinidad) presenta un número significativo de valores faltantes (47,354), lo que podría indicar que en ciertas profundidades o estaciones no se realizaron mediciones de salinidad.

Durante la inspección inicial también se identificaron algunos valores anómalos o fuera del rango esperado en algunas variables:

- **O2ml_L** (Oxígeno disuelto): En algunos registros, el oxígeno disuelto tiene valores negativos (por ejemplo, -0.01 ml/L), lo que puede ser indicativo de errores en la medición o en el procesamiento de los datos.
- **ChlorA** (Clorofila A): Se encontraron valores negativos, como -0.001, lo cual es anómalo, ya que se espera que los valores de clorofila sean siempre positivos. Esto podría ser un indicio de un error de instrumentación o de un fallo en el proceso de calibración.

### 3. Manejo de Valores Faltantes

Durante la inspección inicial del conjunto de datos, se identificaron varias columnas con valores faltantes. Para identificar estas columnas, se utilizó la función **`count_missing(col)`** que cuenta el número de valores nulos en cada columna y posteriormente se usa la función **`dataMissingPercentage()`** para calcular el porcentaje de valores faltantes respecto al total de registros. Esto permitió obtener un panorama general de la cantidad de datos perdidos por columna.


```julia
# Función para contar el número de valores faltantes en una columna específica
function count_missing(df::DataFrame, col::String)
    if col in names(df)
        count = 0
        for value in df[!, col]
            if ismissing(value)
                count += 1
            end
        end
        return (col, count)
    else
        println("Column: '$col' does not exist in the DataFrame.")
        return nothing
    end
end

# Función para calcular el porcentaje de valores faltantes por columna
function dataMissingPercentage(df::DataFrame)
    # Recupera los tipos de datos
    data_types = dataType(df)

    # Agrega una columna para los porcentajes de valores faltantes
    data_types[!, :missing_percent] .= 0.0

    # Calcula los porcentajes de valores faltantes por columna
    for col in names(df)
        _, missing_count = count_missing(df, col)
        missing_percentage = (missing_count * 100) / nrow(df) #Calcula el porcentaje
        row_idx = findfirst(==(col), data_types[!, :column_name]) # Encuentra el índice
        data_types[row_idx, :missing_percent] = missing_percentage
    end
	
    return data_types
end
```




    dataMissingPercentage (generic function with 1 method)




```julia
missing_percentages_df = dataMissingPercentage(data)
```




<div><div style = "float: left;"><span>74×3 DataFrame</span></div><div style = "float: right;"><span style = "font-style: italic;">49 rows omitted</span></div><div style = "clear: both;"></div></div><div class = "data-frame" style = "overflow-x: scroll;"><table class = "data-frame" style = "margin-bottom: 6px;"><thead><tr class = "header"><th class = "rowNumber" style = "font-weight: bold; text-align: right;">Row</th><th style = "text-align: left;">column_name</th><th style = "text-align: left;">data_type</th><th style = "text-align: left;">missing_percent</th></tr><tr class = "subheader headerLastRow"><th class = "rowNumber" style = "font-weight: bold; text-align: right;"></th><th title = "String" style = "text-align: left;">String</th><th title = "Type" style = "text-align: left;">Type</th><th title = "Float64" style = "text-align: left;">Float64</th></tr></thead><tbody><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1</td><td style = "text-align: left;">Cst_Cnt</td><td style = "text-align: left;">Int64</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">2</td><td style = "text-align: left;">Btl_Cnt</td><td style = "text-align: left;">Int64</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">3</td><td style = "text-align: left;">Sta_ID</td><td style = "text-align: left;">String15</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">4</td><td style = "text-align: left;">Depth_ID</td><td style = "text-align: left;">String</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">5</td><td style = "text-align: left;">Depthm</td><td style = "text-align: left;">Int64</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">6</td><td style = "text-align: left;">T_degC</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">1.2676</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">7</td><td style = "text-align: left;">Salnty</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">5.47532</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">8</td><td style = "text-align: left;">O2ml_L</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">19.5016</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9</td><td style = "text-align: left;">STheta</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">6.09218</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">10</td><td style = "text-align: left;">O2Sat</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">23.54</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">11</td><td style = "text-align: left;">Oxy_µmol/Kg</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">23.5407</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">12</td><td style = "text-align: left;">BtlNum</td><td style = "text-align: left;">Union{Missing, Int64}</td><td style = "text-align: right;">86.2791</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">13</td><td style = "text-align: left;">RecInd</td><td style = "text-align: left;">Int64</td><td style = "text-align: right;">0.0</td></tr><tr><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">63</td><td style = "text-align: left;">R_NH4</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">92.4864</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">64</td><td style = "text-align: left;">R_CHLA</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">73.9524</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">65</td><td style = "text-align: left;">R_PHAEO</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">73.9525</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">66</td><td style = "text-align: left;">R_PRES</td><td style = "text-align: left;">Int64</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">67</td><td style = "text-align: left;">R_SAMP</td><td style = "text-align: left;">Union{Missing, Int64}</td><td style = "text-align: right;">85.893</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">68</td><td style = "text-align: left;">DIC1</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">99.7689</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">69</td><td style = "text-align: left;">DIC2</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">99.9741</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">70</td><td style = "text-align: left;">TA1</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">99.759</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">71</td><td style = "text-align: left;">TA2</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">99.9729</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">72</td><td style = "text-align: left;">pH2</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">99.9988</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">73</td><td style = "text-align: left;">pH1</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">99.9903</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">74</td><td style = "text-align: left;">DIC Quality Comment</td><td style = "text-align: left;">Union{Missing, String}</td><td style = "text-align: right;">99.9936</td></tr></tbody></table></div>



El análisis reveló que un número significativo de columnas tenía un alto porcentaje de valores faltantes. Las columnas con mayores porcentajes de datos faltantes fueron las siguientes:

- **DIC1**: 99.77% de valores faltantes
- **DIC2**: 99.97% de valores faltantes
- **TA1**: 99.76% de valores faltantes
- **TA2**: 99.97% de valores faltantes
- **pH2**: 99.99% de valores faltantes
- **pH1**: 99.99% de valores faltantes
- **DIC Quality Comment**: 99.99% de valores faltantes

Por otro lado, algunas columnas, como **Cst_Cnt**, **Btl_Cnt**, y **Sta_ID**, no presentan valores faltantes, lo que indica que los datos en estas columnas son completos y no requieren tratamiento en términos de valores nulos.

En base al análisis realizado, se aplicaron dos estrategias para manejar los valores faltantes:

#### **1. Eliminación de Columnas con Valores Faltantes Significativos**:

Se estableció un umbral del 25% para eliminar columnas con una cantidad excesiva de valores faltantes. Las columnas con más del 25% de valores faltantes fueron descartadas usando la función **`deleteColumns(threshold)`** para evitar que afectaran el análisis posterior.


```julia
# Función para eliminar columnas con un porcentaje de valores faltantes mayor al umbral especificado
function deleteColumns(df::DataFrame, results::DataFrame, threshold::Float64)
    # Iterar sobre cada columna
    for row in eachrow(results)
        col_name = row[:column_name]
        missingPercentage = row[:missing_percent]

        # Verificar si el porcentaje de valores faltantes supera el umbral
        if missingPercentage > threshold
            select!(df, Not(col_name)) #Eliminar la columna del DataFrame
        end
    end

    # Mostrar la nueva forma y los tipos de datos después de la eliminación
    println("Updated DataFrame:")
    println(dataShape(df))
    println(dataType(df))

    return df
end
```




    deleteColumns (generic function with 1 method)




```julia
data_cleaned = deleteColumns(data, missing_percentages_df, 25.0)
dataMissingPercentage(data_cleaned)
```

    Updated DataFrame:
    No. of rows: 864863 
    No. of Columns: 30 
    
    nothing
    [1m30×2 DataFrame[0m
    [1m Row [0m│[1m column_name [0m[1m data_type               [0m
         │[90m String      [0m[90m Type                    [0m
    ─────┼──────────────────────────────────────
       1 │ Cst_Cnt      Int64
       2 │ Btl_Cnt      Int64
       3 │ Sta_ID       String15
       4 │ Depth_ID     String
       5 │ Depthm       Int64
       6 │ T_degC       Union{Missing, Float64}
       7 │ Salnty       Union{Missing, Float64}
       8 │ O2ml_L       Union{Missing, Float64}
       9 │ STheta       Union{Missing, Float64}
      10 │ O2Sat        Union{Missing, Float64}
      11 │ Oxy_µmol/Kg  Union{Missing, Float64}
      12 │ RecInd       Int64
      13 │ T_prec       Union{Missing, Int64}
      14 │ S_prec       Union{Missing, Int64}
      15 │ P_qual       Union{Missing, Int64}
      16 │ NH3q         Union{Missing, Int64}
      17 │ C14A1q       Union{Missing, Int64}
      18 │ C14A2q       Union{Missing, Int64}
      19 │ DarkAq       Union{Missing, Int64}
      20 │ MeanAq       Union{Missing, Int64}
      21 │ R_Depth      Float64
      22 │ R_TEMP       Union{Missing, Float64}
      23 │ R_POTEMP     Union{Missing, Float64}
      24 │ R_SALINITY   Union{Missing, Float64}
      25 │ R_SIGMA      Union{Missing, Float64}
      26 │ R_SVA        Union{Missing, Float64}
      27 │ R_DYNHT      Union{Missing, Float64}
      28 │ R_O2         Union{Missing, Float64}
      29 │ R_O2Sat      Union{Missing, Float64}
      30 │ R_PRES       Int64





<div><div style = "float: left;"><span>30×3 DataFrame</span></div><div style = "float: right;"><span style = "font-style: italic;">5 rows omitted</span></div><div style = "clear: both;"></div></div><div class = "data-frame" style = "overflow-x: scroll;"><table class = "data-frame" style = "margin-bottom: 6px;"><thead><tr class = "header"><th class = "rowNumber" style = "font-weight: bold; text-align: right;">Row</th><th style = "text-align: left;">column_name</th><th style = "text-align: left;">data_type</th><th style = "text-align: left;">missing_percent</th></tr><tr class = "subheader headerLastRow"><th class = "rowNumber" style = "font-weight: bold; text-align: right;"></th><th title = "String" style = "text-align: left;">String</th><th title = "Type" style = "text-align: left;">Type</th><th title = "Float64" style = "text-align: left;">Float64</th></tr></thead><tbody><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1</td><td style = "text-align: left;">Cst_Cnt</td><td style = "text-align: left;">Int64</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">2</td><td style = "text-align: left;">Btl_Cnt</td><td style = "text-align: left;">Int64</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">3</td><td style = "text-align: left;">Sta_ID</td><td style = "text-align: left;">String15</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">4</td><td style = "text-align: left;">Depth_ID</td><td style = "text-align: left;">String</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">5</td><td style = "text-align: left;">Depthm</td><td style = "text-align: left;">Int64</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">6</td><td style = "text-align: left;">T_degC</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">1.2676</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">7</td><td style = "text-align: left;">Salnty</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">5.47532</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">8</td><td style = "text-align: left;">O2ml_L</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">19.5016</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9</td><td style = "text-align: left;">STheta</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">6.09218</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">10</td><td style = "text-align: left;">O2Sat</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">23.54</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">11</td><td style = "text-align: left;">Oxy_µmol/Kg</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">23.5407</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">12</td><td style = "text-align: left;">RecInd</td><td style = "text-align: left;">Int64</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">13</td><td style = "text-align: left;">T_prec</td><td style = "text-align: left;">Union{Missing, Int64}</td><td style = "text-align: right;">1.2676</td></tr><tr><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">19</td><td style = "text-align: left;">DarkAq</td><td style = "text-align: left;">Union{Missing, Int64}</td><td style = "text-align: right;">2.82392</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">20</td><td style = "text-align: left;">MeanAq</td><td style = "text-align: left;">Union{Missing, Int64}</td><td style = "text-align: right;">2.82403</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">21</td><td style = "text-align: left;">R_Depth</td><td style = "text-align: left;">Float64</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">22</td><td style = "text-align: left;">R_TEMP</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">1.2676</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">23</td><td style = "text-align: left;">R_POTEMP</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">5.3242</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">24</td><td style = "text-align: left;">R_SALINITY</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">5.47532</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">25</td><td style = "text-align: left;">R_SIGMA</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">6.11149</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">26</td><td style = "text-align: left;">R_SVA</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">6.10166</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">27</td><td style = "text-align: left;">R_DYNHT</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">5.39473</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">28</td><td style = "text-align: left;">R_O2</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">19.5016</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">29</td><td style = "text-align: left;">R_O2Sat</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">22.9418</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">30</td><td style = "text-align: left;">R_PRES</td><td style = "text-align: left;">Int64</td><td style = "text-align: right;">0.0</td></tr></tbody></table></div>



Se eliminaron 44 columnas debido a la alta proporción de valores faltantes, entre estas están las antes mencionadas, **DIC1**, **DIC2**, **TA1**, **TA2**, **pH2**, **pH1** y **DIC Quality Comment**. Después de la eliminación de columnas con un porcentaje mayor a 25% de datos faltantes, el dataframe permaneció con 30 columnas entre las que destacan:

- **Cst_Cnt**
- **Btl_Cnt**
- **Depthm**
- **T_degC**
- **Salnty**
- **O2ml_L**
- **STheta**

#### **2. Eliminación de Filas con Valores Faltantes en Columnas Clave**:

En el caso de algunas columnas con valores faltantes en una proporción moderada, se optó por eliminar las filas que contenían valores nulos. Esto se hizo para no perder información valiosa de las otras columnas que sí contenían datos completos. Las columnas con una proporción moderada de valores faltantes, como **T_degC**, **Salnty**, y **O2ml_L**, fueron tratadas mediante la función **`deleteRow(col)`** eliminando las filas con valores nulos en estas columnas específicas.

Estas columnas fueron seleccionadas debido a su importancia en el análisis, y su eliminación permitió mantener la calidad del conjunto de datos sin perder demasiada información de otras columnas.


```julia
# Función para eliminar filas con valores faltantes en una columna específica
function deleteRow(df::DataFrame, column::Symbol)
    # Verificar si la columna existe en el DataFrame
    if hasproperty(df, column)
       # Identificar los indices de las filas con valores missing
        missing_indices = findall(ismissing, df[:, column])

        # Eliminar las filas con valores missing
        delete!(df, missing_indices)

        println("Rows with missing values in column '$column' have been deleted")
    else
        println("Column '$column' does not exist in the DataFrame")
    end

    println("Updated DataFrame:")
    println(dataShape(df))
    println(dataType(df))

    return df
end
```




    deleteRow (generic function with 1 method)




```julia
data_no_null= deleteRow(data_cleaned, :T_degC)
data_no_null= deleteRow(data_no_null, :Salnty)
data_no_null= deleteRow(data_no_null, :O2ml_L)
	
dataMissingPercentage(data_no_null)
```

    Rows with missing values in column 'T_degC' have been deleted
    Updated DataFrame:
    No. of rows: 853900 
    No. of Columns: 30 
    
    nothing
    [1m30×2 DataFrame[0m
    [1m Row [0m│[1m column_name [0m[1m data_type               [0m
         │[90m String      [0m[90m Type                    [0m
    ─────┼──────────────────────────────────────
       1 │ Cst_Cnt      Int64
       2 │ Btl_Cnt      Int64
       3 │ Sta_ID       String15
       4 │ Depth_ID     String
       5 │ Depthm       Int64
       6 │ T_degC       Union{Missing, Float64}
       7 │ Salnty       Union{Missing, Float64}
       8 │ O2ml_L       Union{Missing, Float64}
       9 │ STheta       Union{Missing, Float64}
      10 │ O2Sat        Union{Missing, Float64}
      11 │ Oxy_µmol/Kg  Union{Missing, Float64}
      12 │ RecInd       Int64
      13 │ T_prec       Union{Missing, Int64}
      14 │ S_prec       Union{Missing, Int64}
      15 │ P_qual       Union{Missing, Int64}
      16 │ NH3q         Union{Missing, Int64}
      17 │ C14A1q       Union{Missing, Int64}
      18 │ C14A2q       Union{Missing, Int64}
      19 │ DarkAq       Union{Missing, Int64}
      20 │ MeanAq       Union{Missing, Int64}
      21 │ R_Depth      Float64
      22 │ R_TEMP       Union{Missing, Float64}
      23 │ R_POTEMP     Union{Missing, Float64}
      24 │ R_SALINITY   Union{Missing, Float64}
      25 │ R_SIGMA      Union{Missing, Float64}
      26 │ R_SVA        Union{Missing, Float64}
      27 │ R_DYNHT      Union{Missing, Float64}
      28 │ R_O2         Union{Missing, Float64}
      29 │ R_O2Sat      Union{Missing, Float64}
      30 │ R_PRES       Int64
    Rows with missing values in column 'Salnty' have been deleted
    Updated DataFrame:
    No. of rows: 814247 
    No. of Columns: 30 
    
    nothing
    [1m30×2 DataFrame[0m
    [1m Row [0m│[1m column_name [0m[1m data_type               [0m
         │[90m String      [0m[90m Type                    [0m
    ─────┼──────────────────────────────────────
       1 │ Cst_Cnt      Int64
       2 │ Btl_Cnt      Int64
       3 │ Sta_ID       String15
       4 │ Depth_ID     String
       5 │ Depthm       Int64
       6 │ T_degC       Union{Missing, Float64}
       7 │ Salnty       Union{Missing, Float64}
       8 │ O2ml_L       Union{Missing, Float64}
       9 │ STheta       Union{Missing, Float64}
      10 │ O2Sat        Union{Missing, Float64}
      11 │ Oxy_µmol/Kg  Union{Missing, Float64}
      12 │ RecInd       Int64
      13 │ T_prec       Union{Missing, Int64}
      14 │ S_prec       Union{Missing, Int64}
      15 │ P_qual       Union{Missing, Int64}
      16 │ NH3q         Union{Missing, Int64}
      17 │ C14A1q       Union{Missing, Int64}
      18 │ C14A2q       Union{Missing, Int64}
      19 │ DarkAq       Union{Missing, Int64}
      20 │ MeanAq       Union{Missing, Int64}
      21 │ R_Depth      Float64
      22 │ R_TEMP       Union{Missing, Float64}
      23 │ R_POTEMP     Union{Missing, Float64}
      24 │ R_SALINITY   Union{Missing, Float64}
      25 │ R_SIGMA      Union{Missing, Float64}
      26 │ R_SVA        Union{Missing, Float64}
      27 │ R_DYNHT      Union{Missing, Float64}
      28 │ R_O2         Union{Missing, Float64}
      29 │ R_O2Sat      Union{Missing, Float64}
      30 │ R_PRES       Int64
    Rows with missing values in column 'O2ml_L' have been deleted
    Updated DataFrame:
    No. of rows: 661489 
    No. of Columns: 30 
    
    nothing
    [1m30×2 DataFrame[0m
    [1m Row [0m│[1m column_name [0m[1m data_type               [0m
         │[90m String      [0m[90m Type                    [0m
    ─────┼──────────────────────────────────────
       1 │ Cst_Cnt      Int64
       2 │ Btl_Cnt      Int64
       3 │ Sta_ID       String15
       4 │ Depth_ID     String
       5 │ Depthm       Int64
       6 │ T_degC       Union{Missing, Float64}
       7 │ Salnty       Union{Missing, Float64}
       8 │ O2ml_L       Union{Missing, Float64}
       9 │ STheta       Union{Missing, Float64}
      10 │ O2Sat        Union{Missing, Float64}
      11 │ Oxy_µmol/Kg  Union{Missing, Float64}
      12 │ RecInd       Int64
      13 │ T_prec       Union{Missing, Int64}
      14 │ S_prec       Union{Missing, Int64}
      15 │ P_qual       Union{Missing, Int64}
      16 │ NH3q         Union{Missing, Int64}
      17 │ C14A1q       Union{Missing, Int64}
      18 │ C14A2q       Union{Missing, Int64}
      19 │ DarkAq       Union{Missing, Int64}
      20 │ MeanAq       Union{Missing, Int64}
      21 │ R_Depth      Float64
      22 │ R_TEMP       Union{Missing, Float64}
      23 │ R_POTEMP     Union{Missing, Float64}
      24 │ R_SALINITY   Union{Missing, Float64}
      25 │ R_SIGMA      Union{Missing, Float64}
      26 │ R_SVA        Union{Missing, Float64}
      27 │ R_DYNHT      Union{Missing, Float64}
      28 │ R_O2         Union{Missing, Float64}
      29 │ R_O2Sat      Union{Missing, Float64}
      30 │ R_PRES       Int64





<div><div style = "float: left;"><span>30×3 DataFrame</span></div><div style = "float: right;"><span style = "font-style: italic;">5 rows omitted</span></div><div style = "clear: both;"></div></div><div class = "data-frame" style = "overflow-x: scroll;"><table class = "data-frame" style = "margin-bottom: 6px;"><thead><tr class = "header"><th class = "rowNumber" style = "font-weight: bold; text-align: right;">Row</th><th style = "text-align: left;">column_name</th><th style = "text-align: left;">data_type</th><th style = "text-align: left;">missing_percent</th></tr><tr class = "subheader headerLastRow"><th class = "rowNumber" style = "font-weight: bold; text-align: right;"></th><th title = "String" style = "text-align: left;">String</th><th title = "Type" style = "text-align: left;">Type</th><th title = "Float64" style = "text-align: left;">Float64</th></tr></thead><tbody><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1</td><td style = "text-align: left;">Cst_Cnt</td><td style = "text-align: left;">Int64</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">2</td><td style = "text-align: left;">Btl_Cnt</td><td style = "text-align: left;">Int64</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">3</td><td style = "text-align: left;">Sta_ID</td><td style = "text-align: left;">String15</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">4</td><td style = "text-align: left;">Depth_ID</td><td style = "text-align: left;">String</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">5</td><td style = "text-align: left;">Depthm</td><td style = "text-align: left;">Int64</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">6</td><td style = "text-align: left;">T_degC</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">7</td><td style = "text-align: left;">Salnty</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">8</td><td style = "text-align: left;">O2ml_L</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9</td><td style = "text-align: left;">STheta</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">0.0334095</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">10</td><td style = "text-align: left;">O2Sat</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">0.0328048</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">11</td><td style = "text-align: left;">Oxy_µmol/Kg</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">0.0334095</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">12</td><td style = "text-align: left;">RecInd</td><td style = "text-align: left;">Int64</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">13</td><td style = "text-align: left;">T_prec</td><td style = "text-align: left;">Union{Missing, Int64}</td><td style = "text-align: right;">0.0</td></tr><tr><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">19</td><td style = "text-align: left;">DarkAq</td><td style = "text-align: left;">Union{Missing, Int64}</td><td style = "text-align: right;">3.27473</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">20</td><td style = "text-align: left;">MeanAq</td><td style = "text-align: left;">Union{Missing, Int64}</td><td style = "text-align: right;">3.27488</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">21</td><td style = "text-align: left;">R_Depth</td><td style = "text-align: left;">Float64</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">22</td><td style = "text-align: left;">R_TEMP</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">23</td><td style = "text-align: left;">R_POTEMP</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">0.111113</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">24</td><td style = "text-align: left;">R_SALINITY</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">25</td><td style = "text-align: left;">R_SIGMA</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">0.257903</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">26</td><td style = "text-align: left;">R_SVA</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">0.254426</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">27</td><td style = "text-align: left;">R_DYNHT</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">0.612557</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">28</td><td style = "text-align: left;">R_O2</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">29</td><td style = "text-align: left;">R_O2Sat</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">0.24717</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">30</td><td style = "text-align: left;">R_PRES</td><td style = "text-align: left;">Int64</td><td style = "text-align: right;">0.0</td></tr></tbody></table></div>



Una vez eliminadas las filas con valores nulos en las columnas **T_degC**, **Salnty** y **O2ml_L**, el dataframe la estructura del conjunto de datos quedó de la siguiente manera:

- No. de filas: 661489 
- No. de columnas: 30 

Con una considerable reducción de datos faltantes en cada columna, destacando únicamente la columna **P_qual** que permaneció con un porcentaje de 28% de datos faltantes

## Análisis Exploratorio

A continuación se procedió a realizar el análisis exploratorio de datos (EDA, por sus siglas en inglés) para comprender la estructura del conjunto de datos, identificar patrones y relaciones entre variables, y guiar el diseño de análisis posteriores. A continuación, se detallan los aspectos clave del análisis realizado.

### 1. Estadísticas descriptivas generales

Se calcularon las estadísticas descriptivas de las variables numéricas del conjunto de datos con la función **`describe()`**. Estas incluyen medidas de tendencia central (media, mediana), dispersión (desviación estándar, rango intercuartílico), y límites mínimos y máximos.

El análisis de las variables principales arrojó los siguientes resultados descriptivos:

- **Cst_Cnt**: promedio de 18,381.0, mínimo de 71, mediana de 19167.0, y máximo de 34,404.
- **Btl_Cnt**: promedio de 462,809.0, con un mínimo de 2,163 y un máximo de 864,863.
- **Depthm (profundidad en metros)**: promedio de 219.69, con un rango de 0 a 5,351 metros.
- **T_degC (temperatura en °C)**: promedio de 10.92, con un mínimo de 1.44 y un máximo de 31.14.
- **Salnty (salinidad en PSU)**: promedio de 33.83, con un mínimo de 29.4 y un máximo de 37.03.
- **O2ml_L (oxígeno disuelto en ml/L)**: promedio de 3.42, con un mínimo de -0.01 y un máximo de 11.13.
- **STheta (densidad potencial)**: promedio de 25.80, con valores entre 20.996 y 28.083.
- Las variables relacionadas con oxígeno disuelto, como **O2Sat** y **Oxy_µmol/Kg**, presentan valores negativos o atípicos, lo que podría ser indicativo de condiciones extremas o errores en los datos.


```julia
describe(select(data_no_null, Not(:Depth_ID)))
```




<div><div style = "float: left;"><span>15×7 DataFrame</span></div><div style = "clear: both;"></div></div><div class = "data-frame" style = "overflow-x: scroll;"><table class = "data-frame" style = "margin-bottom: 6px;"><thead><tr class = "header"><th class = "rowNumber" style = "font-weight: bold; text-align: right;">Row</th><th style = "text-align: left;">variable</th><th style = "text-align: left;">mean</th><th style = "text-align: left;">min</th><th style = "text-align: left;">median</th><th style = "text-align: left;">max</th><th style = "text-align: left;">nmissing</th><th style = "text-align: left;">eltype</th></tr><tr class = "subheader headerLastRow"><th class = "rowNumber" style = "font-weight: bold; text-align: right;"></th><th title = "Symbol" style = "text-align: left;">Symbol</th><th title = "Union{Nothing, Float64}" style = "text-align: left;">Union…</th><th title = "Any" style = "text-align: left;">Any</th><th title = "Union{Nothing, Float64}" style = "text-align: left;">Union…</th><th title = "Any" style = "text-align: left;">Any</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Type" style = "text-align: left;">Type</th></tr></thead><tbody><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1</td><td style = "text-align: left;">Sta_ID</td><td style = "font-style: italic; text-align: left;"></td><td style = "text-align: left;">001.0 168.0</td><td style = "font-style: italic; text-align: left;"></td><td style = "text-align: left;">176.7 030.0</td><td style = "text-align: right;">0</td><td style = "text-align: left;">String15</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">2</td><td style = "text-align: left;">Depthm</td><td style = "text-align: left;">219.686</td><td style = "text-align: left;">0</td><td style = "text-align: left;">125.0</td><td style = "text-align: left;">5351</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Int64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">3</td><td style = "text-align: left;">T_degC</td><td style = "text-align: left;">10.9188</td><td style = "text-align: left;">1.44</td><td style = "text-align: left;">10.16</td><td style = "text-align: left;">31.14</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">4</td><td style = "text-align: left;">Salnty</td><td style = "text-align: left;">33.8327</td><td style = "text-align: left;">29.402</td><td style = "text-align: left;">33.853</td><td style = "text-align: left;">37.034</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">5</td><td style = "text-align: left;">O2ml_L</td><td style = "text-align: left;">3.4167</td><td style = "text-align: left;">-0.01</td><td style = "text-align: left;">3.47</td><td style = "text-align: left;">11.13</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">6</td><td style = "text-align: left;">STheta</td><td style = "text-align: left;">25.7979</td><td style = "text-align: left;">20.996</td><td style = "text-align: left;">25.972</td><td style = "text-align: left;">28.083</td><td style = "text-align: right;">221</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">7</td><td style = "text-align: left;">O2Sat</td><td style = "text-align: left;">57.1036</td><td style = "text-align: left;">-0.1</td><td style = "text-align: left;">54.4</td><td style = "text-align: left;">214.1</td><td style = "text-align: right;">217</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">8</td><td style = "text-align: left;">Oxy_µmol/Kg</td><td style = "text-align: left;">148.809</td><td style = "text-align: left;">-0.4349</td><td style = "text-align: left;">151.064</td><td style = "text-align: left;">485.702</td><td style = "text-align: right;">221</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9</td><td style = "text-align: left;">R_Depth</td><td style = "text-align: left;">219.686</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">125.0</td><td style = "text-align: left;">5351.0</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Float64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">10</td><td style = "text-align: left;">R_SALINITY</td><td style = "text-align: left;">33.8326</td><td style = "text-align: left;">4.57</td><td style = "text-align: left;">33.853</td><td style = "text-align: left;">37.034</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">11</td><td style = "text-align: left;">R_SIGMA</td><td style = "text-align: left;">25.7928</td><td style = "text-align: left;">20.99</td><td style = "text-align: left;">25.97</td><td style = "text-align: left;">27.95</td><td style = "text-align: right;">1706</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">12</td><td style = "text-align: left;">R_DYNHT</td><td style = "text-align: left;">0.434145</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.35</td><td style = "text-align: left;">3.88</td><td style = "text-align: right;">4052</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">13</td><td style = "text-align: left;">R_O2</td><td style = "text-align: left;">3.41674</td><td style = "text-align: left;">-0.01</td><td style = "text-align: left;">3.47</td><td style = "text-align: left;">11.13</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">14</td><td style = "text-align: left;">R_O2Sat</td><td style = "text-align: left;">57.1314</td><td style = "text-align: left;">-0.1</td><td style = "text-align: left;">54.4</td><td style = "text-align: left;">214.1</td><td style = "text-align: right;">1635</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">15</td><td style = "text-align: left;">R_PRES</td><td style = "text-align: left;">221.164</td><td style = "text-align: left;">0</td><td style = "text-align: left;">126.0</td><td style = "text-align: left;">5458</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Int64</td></tr></tbody></table></div>



### 2. Correlaciones y análisis de columnas relevantes
A continuación se generó una matriz de correlación para identificar relaciones significativas entre las variables con la función **`calculateCorrelation()`** para posteriormente presentarlo en un heatmap con la función **`displayCorrelation()`**. Para realizar los calculos se consideraron únicamente columnas numéricas, las cuales se identifican con la función **`get_numeric_columns()`**


```julia
# Función para calcular la matriz de correlación entre columnas numéricas
function calculateCorrelation(df::DataFrame)
	    numeric_cols = get_numeric_columns(df)
	    corr_mat = Dict{String, Dict{String, Float64}}()
	
	    for col1 in numeric_cols
	        corr_mat[col1] = Dict{String, Float64}()
	        for col2 in numeric_cols
	            if col1 == col2
	                corr_mat[col1][col2] = 1.0
	            else
	                # Eliminar filas con valores faltantes en ambas columnas
	                filtered_df = dropmissing(df, [col1, col2])
	                if nrow(filtered_df) > 1
	                    corr_mat[col1][col2] = cor(filtered_df[!, col1], filtered_df[!, col2])
	                else
	                    corr_mat[col1][col2] = NaN  # No hay suficientes datos para calcular
	                end
	            end
	        end
	    end	
	    return corr_mat
	end
```




    calculateCorrelation (generic function with 1 method)




```julia
# Función para mostrar el heatmap de correlación
function displayCorrelation(df::DataFrame, outFile::String)
    corr_mat = calculateCorrelation(df)
    numeric_cols = get_numeric_columns(df)
    
    corr_matrix = [corr_mat[col1][col2] for col1 in numeric_cols, col2 in numeric_cols]

    rounded_corr_matrix = round.(corr_matrix; digits=2)

    # Crear el heatmap
    plot = heatmap(
    numeric_cols,
    numeric_cols,
    rounded_corr_matrix,
    color=:coolwarm,
    clims=(-1, 1),
    size=(1800, 1800),
    title="Correlation Heatmap\n\n",
    xlabel="Columns",
    ylabel="Columns",
    xticks=(1:length(numeric_cols), numeric_cols),
    yticks=(1:length(numeric_cols), numeric_cols),
    xrotation=45,
    left_margin=10mm,   # Aquí usamos mm del paquete Measures
    right_margin=10mm,
    top_margin=20mm,
    bottom_margin=20mm
    )

    # Agregar anotaciones para cada valor en la matriz
    for i in 1:size(rounded_corr_matrix, 1)
        for j in 1:size(rounded_corr_matrix, 2)
            annotate!(
	            j-0.5,
	            i-0.5,  # Nota: intercambiamos i y j para alinearlas correctamente
	            text(string(rounded_corr_matrix[i, j]), 10, :black, :center)
	        )
	    end
	end    
	savefig(plot, outFile)
	
	 return plot 
end
```




    displayCorrelation (generic function with 1 method)




```julia
# Función para obtener las columnas numéricas del DataFrame
function get_numeric_columns(df::DataFrame)
    return [name for name in names(df) if eltype(df[!, name]) <: Union{Missing, Int64,Float64}]
end
```




    get_numeric_columns (generic function with 1 method)




```julia
displayCorrelation(data_no_null, "Correlation_heatmap.png")
```




    
![svg](output_29_0.svg)
    



Se evaluaron las correlaciones entre las principales variables relacionadas con la temperatura del agua (**T_degC**) y otros factores oceanográficos

Para evitar tratar con columnas que no sean factores importantes para nuestra variable objetivo (**T_degC**), se filtraron las columnas que mostraron una correlación baja (< 0.1) con esta variable, ésto usando la función **`filterColumnsByCorrelation(target)`**. 

Similarmente se filtraron aquellas columnas de características altamente correlacionadas positivamente con **T_degC** para reducir la redundancia y así evitar el sobreajuste y la multicolinealidad. Ejemplo de ello son las columnas **R_POTEMP** y **R_TEMP** pues muestran una fuerte correlación positiva.


```julia
# Función para filtrar columnas según la correlación con una columna objetivo
function filterColumnsByCorrelation(df::DataFrame, target::AbstractString, threshold::Float64, relation::Bool)
    corr_mat = calculateCorrelation(df)
    numeric_cols = get_numeric_columns(df)

    if !(target in numeric_cols)
        error("La columna objetivo no existe en el DataFrame")
    end

    # Iterar sobre las columnas y aplicar la eliminación
    cols_to_delete = []
    for key in keys(corr_mat[target])
        if key == target
            continue
        end

        val = corr_mat[target][key]

        # Relación falsa
        if !relation && abs(val) <= abs(threshold)
            push!(cols_to_delete, key)
        end

        # Relación verdadera
        if relation && val >= threshold

            push!(cols_to_delete, key)
        end
    end

    #Eliminar las columnas seleccionadas
    select!(df, Not(cols_to_delete))
    return df
end
```




    filterColumnsByCorrelation (generic function with 1 method)




```julia
df_filtered = filterColumnsByCorrelation(data_no_null, "T_degC", 0.1, false)
df_filtered = filterColumnsByCorrelation(df_filtered, "T_degC", 0.9, true)

println(dataShape(df_filtered))
println(dataMissingPercentage(df_filtered))
```

    No. of rows: 661489 
    No. of Columns: 16 
    
    nothing
    [1m16×3 DataFrame[0m
    [1m Row [0m│[1m column_name [0m[1m data_type               [0m[1m missing_percent [0m
         │[90m String      [0m[90m Type                    [0m[90m Float64         [0m
    ─────┼───────────────────────────────────────────────────────
       1 │ Sta_ID       String15                       0.0
       2 │ Depth_ID     String                         0.0
       3 │ Depthm       Int64                          0.0
       4 │ T_degC       Union{Missing, Float64}        0.0
       5 │ Salnty       Union{Missing, Float64}        0.0
       6 │ O2ml_L       Union{Missing, Float64}        0.0
       7 │ STheta       Union{Missing, Float64}        0.0334095
       8 │ O2Sat        Union{Missing, Float64}        0.0328048
       9 │ Oxy_µmol/Kg  Union{Missing, Float64}        0.0334095
      10 │ R_Depth      Float64                        0.0
      11 │ R_SALINITY   Union{Missing, Float64}        0.0
      12 │ R_SIGMA      Union{Missing, Float64}        0.257903
      13 │ R_DYNHT      Union{Missing, Float64}        0.612557
      14 │ R_O2         Union{Missing, Float64}        0.0
      15 │ R_O2Sat      Union{Missing, Float64}        0.24717
      16 │ R_PRES       Int64                          0.0


Con esto el número de variables a tratar se redujo a 16 columnas y el porcentaje de datos faltantes se redujo significativamente.


```julia
displayCorrelation(df_filtered, "Correlation_heatmap_filtered.png")
```




    
![svg](output_34_0.svg)
    



A partir de la matriz de correlación, se identificaron las siguientes relaciones significativas entre variables:

- **R_SALINITY** y **Salnty**: Ambas están altamente correlacionadas (~1.0).

- **R_O2**, **O2ml_L** y **Oxy_µmol/Kg** : Correlación ~1.0.

- **R_O2Sat** y **O2Sat**: Correlación ~1.0.

- **R_Depth**, **Depthm**, **R_PRES** y **R_DYNHT**: Correlación ~1.0. R_DYNHT (correlación alta con el resto, aunque ligeramente menor, ~0.92)

- **R_SIGMA** y **STheta**: Correlación ~0.99.

Esto puede significar que dependen en gran medida entre sí, por lo que son redundantes y pueden provocar un sobreajuste, por lo que sería mejor eliminarlas.


```julia
cols_to_delete_symbols = Symbol.(collect(["R_Depth", "R_SALINITY","R_O2","R_O2Sat","R_SIGMA", "R_PRES", "R_DYNHT","Oxy_µmol/Kg", "O2Sat"]))
		
df_no_redundant= select(df_filtered, Not(cols_to_delete_symbols))

println(dataShape(df_no_redundant))
println(dataMissingPercentage(df_no_redundant))

first(df_no_redundant, 5)
```

    No. of rows: 661489 
    No. of Columns: 7 
    
    nothing
    [1m7×3 DataFrame[0m
    [1m Row [0m│[1m column_name [0m[1m data_type               [0m[1m missing_percent [0m
         │[90m String      [0m[90m Type                    [0m[90m Float64         [0m
    ─────┼───────────────────────────────────────────────────────
       1 │ Sta_ID       String15                       0.0
       2 │ Depth_ID     String                         0.0
       3 │ Depthm       Int64                          0.0
       4 │ T_degC       Union{Missing, Float64}        0.0
       5 │ Salnty       Union{Missing, Float64}        0.0
       6 │ O2ml_L       Union{Missing, Float64}        0.0
       7 │ STheta       Union{Missing, Float64}        0.0334095





<div><div style = "float: left;"><span>5×7 DataFrame</span></div><div style = "clear: both;"></div></div><div class = "data-frame" style = "overflow-x: scroll;"><table class = "data-frame" style = "margin-bottom: 6px;"><thead><tr class = "header"><th class = "rowNumber" style = "font-weight: bold; text-align: right;">Row</th><th style = "text-align: left;">Sta_ID</th><th style = "text-align: left;">Depth_ID</th><th style = "text-align: left;">Depthm</th><th style = "text-align: left;">T_degC</th><th style = "text-align: left;">Salnty</th><th style = "text-align: left;">O2ml_L</th><th style = "text-align: left;">STheta</th></tr><tr class = "subheader headerLastRow"><th class = "rowNumber" style = "font-weight: bold; text-align: right;"></th><th title = "String15" style = "text-align: left;">String15</th><th title = "String" style = "text-align: left;">String</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th><th title = "Union{Missing, Float64}" style = "text-align: left;">Float64?</th></tr></thead><tbody><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1</td><td style = "text-align: left;">044.0 048.5</td><td style = "text-align: left;">19-4904CR-HY-087-0606-04400485-0000B-3</td><td style = "text-align: right;">0</td><td style = "text-align: right;">10.3</td><td style = "text-align: right;">33.03</td><td style = "text-align: right;">5.9</td><td style = "text-align: right;">25.364</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">2</td><td style = "text-align: left;">044.0 048.5</td><td style = "text-align: left;">19-4904CR-HY-087-0606-04400485-0006A-3</td><td style = "text-align: right;">6</td><td style = "text-align: right;">18.46</td><td style = "text-align: right;">32.92</td><td style = "text-align: right;">6.02</td><td style = "text-align: right;">23.568</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">3</td><td style = "text-align: left;">044.0 048.5</td><td style = "text-align: left;">19-4904CR-HY-087-0606-04400485-0010A-7</td><td style = "text-align: right;">10</td><td style = "text-align: right;">10.29</td><td style = "text-align: right;">32.951</td><td style = "text-align: right;">6.04</td><td style = "text-align: right;">25.304</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">4</td><td style = "text-align: left;">044.0 048.5</td><td style = "text-align: left;">19-4904CR-HY-087-0606-04400485-0015A-3</td><td style = "text-align: right;">15</td><td style = "text-align: right;">10.29</td><td style = "text-align: right;">32.99</td><td style = "text-align: right;">6.06</td><td style = "text-align: right;">25.335</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">5</td><td style = "text-align: left;">044.0 048.5</td><td style = "text-align: left;">19-4904CR-HY-087-0606-04400485-0020A-7</td><td style = "text-align: right;">20</td><td style = "text-align: right;">10.33</td><td style = "text-align: right;">33.005</td><td style = "text-align: right;">6.04</td><td style = "text-align: right;">25.339</td></tr></tbody></table></div>




```julia
describe(select(df_no_redundant, Not(:Depth_ID)))
```




<div><div style = "float: left;"><span>6×7 DataFrame</span></div><div style = "clear: both;"></div></div><div class = "data-frame" style = "overflow-x: scroll;"><table class = "data-frame" style = "margin-bottom: 6px;"><thead><tr class = "header"><th class = "rowNumber" style = "font-weight: bold; text-align: right;">Row</th><th style = "text-align: left;">variable</th><th style = "text-align: left;">mean</th><th style = "text-align: left;">min</th><th style = "text-align: left;">median</th><th style = "text-align: left;">max</th><th style = "text-align: left;">nmissing</th><th style = "text-align: left;">eltype</th></tr><tr class = "subheader headerLastRow"><th class = "rowNumber" style = "font-weight: bold; text-align: right;"></th><th title = "Symbol" style = "text-align: left;">Symbol</th><th title = "Union{Nothing, Float64}" style = "text-align: left;">Union…</th><th title = "Any" style = "text-align: left;">Any</th><th title = "Union{Nothing, Float64}" style = "text-align: left;">Union…</th><th title = "Any" style = "text-align: left;">Any</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Type" style = "text-align: left;">Type</th></tr></thead><tbody><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1</td><td style = "text-align: left;">Sta_ID</td><td style = "font-style: italic; text-align: left;"></td><td style = "text-align: left;">001.0 168.0</td><td style = "font-style: italic; text-align: left;"></td><td style = "text-align: left;">176.7 030.0</td><td style = "text-align: right;">0</td><td style = "text-align: left;">String15</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">2</td><td style = "text-align: left;">Depthm</td><td style = "text-align: left;">219.686</td><td style = "text-align: left;">0</td><td style = "text-align: left;">125.0</td><td style = "text-align: left;">5351</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Int64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">3</td><td style = "text-align: left;">T_degC</td><td style = "text-align: left;">10.9188</td><td style = "text-align: left;">1.44</td><td style = "text-align: left;">10.16</td><td style = "text-align: left;">31.14</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">4</td><td style = "text-align: left;">Salnty</td><td style = "text-align: left;">33.8327</td><td style = "text-align: left;">29.402</td><td style = "text-align: left;">33.853</td><td style = "text-align: left;">37.034</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">5</td><td style = "text-align: left;">O2ml_L</td><td style = "text-align: left;">3.4167</td><td style = "text-align: left;">-0.01</td><td style = "text-align: left;">3.47</td><td style = "text-align: left;">11.13</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">6</td><td style = "text-align: left;">STheta</td><td style = "text-align: left;">25.7979</td><td style = "text-align: left;">20.996</td><td style = "text-align: left;">25.972</td><td style = "text-align: left;">28.083</td><td style = "text-align: right;">221</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr></tbody></table></div>




```julia
displayCorrelation(df_no_redundant, "Correlation_no_redundant.png")
```




    
![svg](output_38_0.svg)
    



## Detección y tratamiento de outliers: Uso del rango intercuartílico (IQR)
Finalmente se decidió eliminar los outliers de los datos restantes.

Los valores atípicos, o outliers, son datos que se alejan significativamente del resto de las observaciones y pueden distorsionar tanto el análisis exploratorio como los modelos predictivos. En este proyecto, se utilizó el rango intercuartílico (IQR, por sus siglas en inglés) como método principal para identificar y tratar valores extremos.

### Cálculo del IQR
El rango intercuartílico se calcula como la diferencia entre el tercer cuartil (Q_3) y el primer cuartil (Q_1):
$$
IQR = Q_3 - Q_1
$$

Donde:
Q1: Valor que delimita el 25% inferior de los datos.
Q3: Valor que delimita el 75% superior de los datos.
Cualquier valor que se encuentre fuera del rango definido por los límites inferior y superior se considera un outlier:

$$
Limite_{inf} = Q_1 - 1.5 * IQR
$$
$$
Limite_{sup} = Q_3 + 1.5 * IQR
$$

Para ello la función removeOutliersIQR() implementó la siguiente metodología para procesar todas las variables numéricas del DataFrame:

1. **Detección**: Se identificaron valores extremos en las columnas seleccionadas mediante los límites calculados con el IQR.
2. **Capping**: Los valores que excedían los límites superior e inferior se ajustaron al límite correspondiente.
3. **Preservación**: Las filas con valores faltantes o valores no atípicos se mantuvieron intactas.



```julia
# Función para eliminar valores atípicos en columnas numéricas utilizando el rango intercuartil (IQR)
function removeOutliersIQR(df::DataFrame)
    numeric_cols = get_numeric_columns(df)

    for col in numeric_cols
        # Calcular los cuartiles e IQR
        Q1 = quantile(skipmissing(df[!, col]), 0.25)
        Q3 = quantile(skipmissing(df[!, col]), 0.75)
        IQR = Q3 - Q1

        # Calcular los límites inferior y superior
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR

        # Filtrar filas dentro de los límites
        df = filter(row -> row[col] === missing || (row[col] >= lower_bound && row[col] <= upper_bound), df)
    end

    println(dataShape(df))
    return df
end
```




    removeOutliersIQR (generic function with 1 method)




```julia
outliersRemoved = removeOutliersIQR(df_no_redundant)
	
dataMissingPercentage(outliersRemoved)
```

    No. of rows: 621955 
    No. of Columns: 7 
    
    nothing





<div><div style = "float: left;"><span>7×3 DataFrame</span></div><div style = "clear: both;"></div></div><div class = "data-frame" style = "overflow-x: scroll;"><table class = "data-frame" style = "margin-bottom: 6px;"><thead><tr class = "header"><th class = "rowNumber" style = "font-weight: bold; text-align: right;">Row</th><th style = "text-align: left;">column_name</th><th style = "text-align: left;">data_type</th><th style = "text-align: left;">missing_percent</th></tr><tr class = "subheader headerLastRow"><th class = "rowNumber" style = "font-weight: bold; text-align: right;"></th><th title = "String" style = "text-align: left;">String</th><th title = "Type" style = "text-align: left;">Type</th><th title = "Float64" style = "text-align: left;">Float64</th></tr></thead><tbody><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1</td><td style = "text-align: left;">Sta_ID</td><td style = "text-align: left;">String15</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">2</td><td style = "text-align: left;">Depth_ID</td><td style = "text-align: left;">String</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">3</td><td style = "text-align: left;">Depthm</td><td style = "text-align: left;">Int64</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">4</td><td style = "text-align: left;">T_degC</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">5</td><td style = "text-align: left;">Salnty</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">6</td><td style = "text-align: left;">O2ml_L</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">0.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">7</td><td style = "text-align: left;">STheta</td><td style = "text-align: left;">Union{Missing, Float64}</td><td style = "text-align: right;">0.0345684</td></tr></tbody></table></div>




```julia
describe(select(outliersRemoved, Not(:Depth_ID)))
```




<div><div style = "float: left;"><span>6×7 DataFrame</span></div><div style = "clear: both;"></div></div><div class = "data-frame" style = "overflow-x: scroll;"><table class = "data-frame" style = "margin-bottom: 6px;"><thead><tr class = "header"><th class = "rowNumber" style = "font-weight: bold; text-align: right;">Row</th><th style = "text-align: left;">variable</th><th style = "text-align: left;">mean</th><th style = "text-align: left;">min</th><th style = "text-align: left;">median</th><th style = "text-align: left;">max</th><th style = "text-align: left;">nmissing</th><th style = "text-align: left;">eltype</th></tr><tr class = "subheader headerLastRow"><th class = "rowNumber" style = "font-weight: bold; text-align: right;"></th><th title = "Symbol" style = "text-align: left;">Symbol</th><th title = "Union{Nothing, Float64}" style = "text-align: left;">Union…</th><th title = "Any" style = "text-align: left;">Any</th><th title = "Union{Nothing, Float64}" style = "text-align: left;">Union…</th><th title = "Any" style = "text-align: left;">Any</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Type" style = "text-align: left;">Type</th></tr></thead><tbody><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1</td><td style = "text-align: left;">Sta_ID</td><td style = "font-style: italic; text-align: left;"></td><td style = "text-align: left;">001.0 168.0</td><td style = "font-style: italic; text-align: left;"></td><td style = "text-align: left;">176.7 030.0</td><td style = "text-align: right;">0</td><td style = "text-align: left;">String15</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">2</td><td style = "text-align: left;">Depthm</td><td style = "text-align: left;">168.405</td><td style = "text-align: left;">0</td><td style = "text-align: left;">119.0</td><td style = "text-align: left;">676</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Int64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">3</td><td style = "text-align: left;">T_degC</td><td style = "text-align: left;">11.2116</td><td style = "text-align: left;">2.88</td><td style = "text-align: left;">10.41</td><td style = "text-align: left;">23.25</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">4</td><td style = "text-align: left;">Salnty</td><td style = "text-align: left;">33.7899</td><td style = "text-align: left;">32.446</td><td style = "text-align: left;">33.795</td><td style = "text-align: left;">35.15</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">5</td><td style = "text-align: left;">O2ml_L</td><td style = "text-align: left;">3.55094</td><td style = "text-align: left;">-0.01</td><td style = "text-align: left;">3.7</td><td style = "text-align: left;">11.13</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">6</td><td style = "text-align: left;">STheta</td><td style = "text-align: left;">25.727</td><td style = "text-align: left;">22.709</td><td style = "text-align: left;">25.886</td><td style = "text-align: left;">27.42</td><td style = "text-align: right;">215</td><td style = "text-align: left;">Union{Missing, Float64}</td></tr></tbody></table></div>




```julia
displayCorrelation(outliersRemoved, "Correlation_outliers_removed.png")
```




    
![svg](output_44_0.svg)
    



### Resultados obtenidos
A partir de la matriz de correlación, se identificaron las siguientes relaciones significativas 

**1. Correlaciones altas y significativas**
- O2ml_L y STheta presentan una correlación alta y negativa (-0.9), lo que indica que estas variables están fuertemente relacionadas.
- T_degC y STheta tienen una correlación fuerte y negativa (-0.96), lo cual es consistente con la física oceánica: las variaciones en temperatura suelen estar inversamente relacionadas con la densidad potencial.

**2. Correlaciones moderadas**
- Depthm y Salinity tienen una correlación positiva moderada (0.7). Esto puede reflejar patrones regionales o locales en los datos, ya que la salinidad y la profundidad pueden estar relacionadas dependiendo de las masas de agua específicas.

- Depthm y otras variables como T_degC y O2ml_L presentan correlaciones negativas (-0.81 y -0.87, respectivamente). Esto es esperado, ya que, a mayores profundidades, la temperatura tiende a disminuir y el oxígeno puede reducirse debido a limitaciones en el intercambio superficial.

**3. Correlaciones débiles**
- Algunas variables, como Salinity con T_degC (-0.53), presentan relaciones algo más débiles en comparación con las otras. Esto podría implicar que estas variables están influidas por otros factores independientes.

### Relación con la Variable Objetivo (T_degC)

**1. Relación con STheta (Densidad Potencial)**
- **Correlación**: -0.96 (muy fuerte y negativa).
- **Interpretación**: Esto es consistente con principios físicos oceánicos, donde a mayor temperatura, la densidad potencial del agua disminuye, ya que el agua se expande al calentarse. Esta relación es esperada en la mayoría de los entornos marinos.
- **Implicación**: T_degC y STheta contienen información complementaria, pero también podrían considerarse redundantes en algunos casos, dependiendo del contexto del análisis.

**2. Relación con Salinity (Salinidad)**
- **Correlación**: -0.53 (moderada y negativa).
- **Interpretación**: A medida que aumenta la temperatura, la salinidad tiende a disminuir de manera moderada. Esto podría deberse a procesos como la mezcla vertical, el deshielo (en regiones polares), o la influencia de aguas dulces (ríos, lluvia). Sin embargo, esta relación no es fuerte, lo que indica que hay otros factores que afectan significativamente la salinidad en los datos.
- **Implicación**: T_degC y Salnty no son variables redundantes; es decir, ambas tienen valor analítico independiente. La correlación negativa moderada sugiere que, aunque relacionadas, estas variables reflejan procesos oceánicos distintos.

**3. Relación con O2ml_L (Oxígeno Disuelto)**
- **Correlación**: 0.8 (fuerte y positiva).
- **Interpretación**: A mayor temperatura, generalmente hay más oxígeno disuelto en aguas superficiales debido a la mayor actividad biológica (como fotosíntesis). Sin embargo, a profundidades mayores, esta relación puede invertirse debido al agotamiento de oxígeno por respiración biológica y menor mezcla superficial.
- **Implicación**: Aunque existe una relación fuerte, es probable que T_degC y O2ml_L reflejen procesos diferentes y sean variables importantes en análisis complementarios.

**4. Relación con Depthm (Profundidad)**
- **Correlación**: -0.81 (fuerte y negativa).
- **Interpretación**: A medida que aumenta la profundidad, la temperatura disminuye debido a la falta de radiación solar y a las características de las masas de agua profundas, como la termoclina.
- **Implicación**: La relación entre Depthm y T_degC refleja un gradiente térmico natural. Dependiendo del análisis, esta relación puede ser clave para modelar condiciones oceánicas.

## Impacto de las modificaciones:
- **Reducción del tamaño**: Se redujo aproximadamente un 27% del total original de filas, lo cual puede ser significativo dependiendo de los análisis planeados. Sin embargo, el volumen de datos restantes es suficiente para realizar análisis robustos.
- **Simplificación**: El dataset ahora contiene menos redundancias, lo que simplifica los análisis posteriores y evita sobreajustes en modelos estadísticos o de machine learning.
- **Precisión**: La eliminación de outliers asegura que las relaciones entre las variables no están sesgadas por valores atípicos.
- **Integridad de los datos**: Este enfoque ayuda a mejorar la calidad del conjunto de datos al eliminar valores potencialmente sesgados o erróneos.

El resultado final es un DataFrame más limpio y robusto para el análisis posterior.



```julia
CSV.write("bottle_cleaned.csv", outliersRemoved)
```




    "bottle_cleaned.csv"


