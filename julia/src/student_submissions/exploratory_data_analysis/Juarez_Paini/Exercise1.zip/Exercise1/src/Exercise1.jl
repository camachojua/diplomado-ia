using CSV, DataFrames, GLM, Statistics, StatsModels, Plots
file_path = "bottle.csv"
df = CSV.read(file_path, DataFrame);
function dataType(df::DataFrame)
    clean_df = dropmissing(df, names(df))
    for i = 1:ncol(df)
        column_name = names(df)[i]
        column_type = eltype(clean_df[:, column_name])
        println("Data Type column $column_name: $column_type")
    end
end

dataType(df)
function count_missing(df::DataFrame, column_name)
    missing_count = count(ismissing, df[:, column_name])
    println("En la columna $column_name hay $missing_count datos faltantes")
end

count_missing(df,"T_degC")
count_missing(df,"R_CHLA")

function dataMissingPercentage(df::DataFrame)
    for i = 1:ncol(df)
        column_name = names(df)[i]
        missing_count = count(ismissing, df[:, column_name])
        missing_percentage = (missing_count / nrow(df)) * 100
        println("En la columna $column_name falta el ($missing_percentage%) de los datos")
    end
end

dataMissingPercentage(df)

function deleteColumns(df, completeness_threshold)
    clean_df = dropmissing(df, names(df))
    num_rows = nrow(df)
    valid_columns = String[]
    for col_name in names(df)
        col = df[:, col_name]
        if count(ismissing, col) / num_rows <= (1 - completeness_threshold)
            push!(valid_columns, string(col_name))  # Asegurar que son nombres en formato String
        end
    end
    df_subset = select(df, intersect(names(df), valid_columns))
    return df_subset
end

deleteColumns(df, 1.0)

function filter_columns(df, completeness_threshold)
    clean_df = dropmissing(df, names(df))
    num_rows = nrow(df)
    valid_columns = String[]
    for col_name in names(df)
        col = df[:, col_name]
        col_type = clean_df[:, col_name]
        if eltype(col_type) <: Number && count(ismissing, col) / num_rows <= (1 - completeness_threshold)
            push!(valid_columns, string(col_name))  # Asegurar que son nombres en formato String
        end
    end
    return valid_columns
end

function clean_dataframe(df::DataFrame, valid_columns::Vector{String})
    # Seleccionar solo las columnas válidas
    df_subset = select(df, intersect(names(df), valid_columns))
    return df_subset
end


function calculate_correlation(df::DataFrame)
    # Eliminar filas con valores faltantes
    clean_df = dropmissing(df)
    
    # Seleccionar columnas numéricas
    numeric_cols = names(clean_df)[eltype.(eachcol(clean_df)) .<: Number]
    
    # Inicializar matriz de correlaciones
    corr_mat = Dict{String, Dict{String, Float64}}()
    for col1 in numeric_cols
        corr_mat[string(col1)] = Dict(string(col2) => 0.0 for col2 in numeric_cols)
    end
    
    # Calcular las correlaciones
    for i in 1:length(numeric_cols)
        for j in i:length(numeric_cols)
            col1 = numeric_cols[i]
            col2 = numeric_cols[j]
            
            # Seleccionar filas sin valores faltantes para ambas columnas
            valid_rows = .!(ismissing.(df[!, col1]) .| ismissing.(df[!, col2]))
            
            # Si no hay datos suficientes, omitir
            if sum(valid_rows) <= 1
                correlation = NaN
            else
                m1 = mean(df[valid_rows, col1])
                m2 = mean(df[valid_rows, col2])
                cov = mean((df[valid_rows, col1] .- m1) .* (df[valid_rows, col2] .- m2))
                std1 = std(df[valid_rows, col1])
                std2 = std(df[valid_rows, col2])
                correlation = cov / (std1 * std2)
            end
            
            # Actualizar la matriz
            corr_mat[string(col1)][string(col2)] = correlation
            corr_mat[string(col2)][string(col1)] = correlation
        end
    end
    
    return corr_mat
end
    
valid_cols = filter_columns(df, 0.93)
df_subset = clean_dataframe(df,valid_cols);
corr_mat = calculate_correlation(df_subset)


function display_correlation(corr_mat::Dict)
    # Extraer nombres de filas y columnas
    rows = collect(keys(corr_mat))
    cols = collect(keys(first(values(corr_mat))))
    
    # Crear la matriz de correlaciones
    matrix = [corr_mat[row][col] for row in rows, col in cols]
    
    # Crear el heatmap
    fig = heatmap(
        cols,       # Las columnas (variables)
        rows,       # Las filas (también variables)
        matrix,     # Los valores de correlación
        color=:viridis,
        title="Heatmap de Correlación",
        xlabel="Variables",
        ylabel="Variables",
        size=(800, 600),
        colorbar=true  # Activar la barra de colores
    )
    
    # Guardar la imagen del heatmap
    savefig("Correlation_Matrix.png")
    return fig
end

display_correlation(corr_mat)


function removeOutliersIQR(clean_df::DataFrame)
    for col in names(clean_df)
        if eltype(clean_df[!, col]) <: Number
            Q1 = quantile(skipmissing(clean_df[!, col]), 0.25)
            Q3 = quantile(skipmissing(clean_df[!, col]), 0.75)
            IQR = Q3 - Q1
            
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR
            
            # Filtrar filas dentro del rango
            clean_df = filter(row -> row[col] ≥ lower_bound && row[col] ≤ upper_bound, clean_df)
        end
    end
    return clean_df
end

removeOutliersIQR(df_subset)


function deleteRow(df::DataFrame, column_name)
    # Filtrar las filas donde los valores de la columna no sean nulos
    clean_df = filter(row -> !ismissing(row[column_name]), df)
    return clean_df
end

deleteRow(df_subset, "T_degC")


function filter_columns_by_correlation(df::DataFrame, corr_mat::Dict, target::Symbol, threshold::Float64, relation::Bool)
    target_corr = corr_mat[string(target)]
    
    for key in keys(target_corr)
        if key == string(target)
            continue
        end
        
        val = target_corr[key]
        if (!relation && abs(val) ≤ abs(threshold)) || (relation && val ≥ threshold)
            select!(df, Not(Symbol(key)))  # Eliminar columna
        end
    end
    
    return df
end

df1 = filter_columns_by_correlation(df_subset, corr_mat, :T_degC, 0.1, false)

describe(df)