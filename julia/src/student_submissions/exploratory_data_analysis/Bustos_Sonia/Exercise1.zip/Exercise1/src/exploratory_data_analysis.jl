using Pkg
# Pkg.add("CSV") ; Pkg.add("Tables")
# Pkg.add("DataFrames") ; Pkg.add("JSON")
# Pkg.add("Statistics") ; Pkg.add("Plots")
# Pkg.add("PrettyTables") ; Pkg.add("GLM")
using CSV, Tables, DataFrames, JSON, Statistics, Plots, GLM, PrettyTables

# Función que devuelve un vector con el número de columnas y filas.
function dataShape(df::DataFrame)
    return size(df)
end

function dataType(df ::DataFrame)
    # Asociamos a data el DataFrame con los datos que necesitamos
    data = describe(df)
    
    # Seleccionamos de data el nombre y el tipo de dato de las columnas
    type_col = select(data, :variable, :eltype)
    
    return  type_col
end

function count_missing(col)

    # Se recibe  una columnas y se cuenta los missing que tiene 
    missing_counts = map(columna -> count(ismissing, columna), col)
    
    # Se crea un Dataframe con el nombre de cada columna y su respectiva cantidad de missing
    MissingCounts_df = DataFrame(; Column = names(bottle_df), MissingCounts = missing_counts)
    
    return MissingCounts_df

end

function dataMissingPercentage()
    n_rows = first(dataShape(bottle_df))
    CM_df = count_missing(eachcol(bottle_df))

    Column_Percentage = [] 
    
    # Obtener el porcentaje de missings
    for i in CM_df.MissingCounts 
        percent = (i * 100) / n_rows 

        # Ponemos formato el el porcentaje obtenido
        format = string(Int(round(percent, digits=0)),"%")
        
        # Agregamos porcentaje al vector
        push!(Column_Percentage, format) 
    end 
  
    # Hacemos un DataFrame con el nombre de las columnas y el porcentaje de missings
    Percentage_df = DataFrame(; Column = names(bottle_df), MissingPercentage = Column_Percentage)
    return Percentage_df
end


function deleteColumns(threshold::Float64)
    # Número de filas
    n_rows = nrow(bottle_df)

    # Sacamos el porcentaje de missing por columna, y si es menor igual que el threshold matenemos la columna.
    # Para mantener consistencia se redondea el porcentaje como en dataMissingPercentage().
    keep_cols = map(col -> round((count(ismissing, col) / n_rows * 100),digits = 0) <= threshold, eachcol(bottle_df))
    
    # Llamamos a las columnas del DataFrame que cumplieron con el criterio.
    return bottle_df[:, keep_cols]
end


function calculateCorrelation(df::DataFrame)
    # Filtrar columnas de tipo numérico o Union{Missing, Number}
    numeric_columns = filter( 
        col -> eltype(df[!, col]) <: Union{Missing, Number},
        names(df)
        )

    # Seleccionar solo las columnas numéricas
    numeric_data = select(df, numeric_columns)

    # Eliminar filas con valores faltantes para evitar problemas al calcular correlaciones
    clean_numeric_data = dropmissing(numeric_data)


    # Calcular la matriz de correlación
    correlation_matrix = cor(Matrix(clean_numeric_data))


    # Calcular la desviación estándar de cada columna
    desviaciones_estandar = map(col -> std(skipmissing(clean_numeric_data[!, col])), names(clean_numeric_data))
    

    return correlation_matrix, desviaciones_estandar
end

# Gráficamos la matriz de correlación en un mapa de calor 
function displayCorrelation(df::DataFrame, correlation_matrix::Matrix)

    # Nombre se las columnas númericas.
    numeric_columns = filter( 
        col -> eltype(df[!, col]) <: Union{Missing, Number},
        names(df)
        )

    # Crear el heatmap con etiquetas.
    corr_heatmap =heatmap(correlation_matrix, color=cgrad([:green, :yellow, :red]), 
            title="Correlation Heatmap",
            xticks=(1:length(numeric_columns), numeric_columns), yticks=(1:length(numeric_columns), numeric_columns))
            
    return corr_heatmap
end

function removeOutliersIQR(df::DataFrame)
    # Iterar sobre cada columna
    for col in names(df)
        # Verificar si la columna es numérica o Union{Missing, Number}
        if eltype(df[!, col]) <: Union{Missing, Number}

            # Calcular los cuantiles ignorando valores missing
            col_values = skipmissing(df[!, col])
            Q1 = quantile(col_values, 0.25)
            Q3 = quantile(col_values, 0.75)
            IQR = Q3 - Q1

            # Límites superior e inferior
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR

            # Filtrar filas manteniendo solo los valores dentro de los límites
            df = filter(row -> 
                ismissing(row[col]) || 
                (row[col] >= lower_bound && row[col] <= upper_bound), df)
        end
    end
    return df
end

function deleteRow(column)
    # Dataframe con columnas sin missing
    no_missing = dropmissing(cleaned_data_RO, column)
    return no_missing
end

function filterColumnsByCorrelation(df::DataFrame, target::String, threshold::Float64, relation::Bool)
    # Verificar que la columna objetivo exista
    if !(target in names(df))
        throw(ArgumentError("La columna '$target' no existe en el DataFrame."))
    end

    # Seleccionar solo columnas numéricas o Union{Missing, Number}
    numeric_columns = filter(
        col -> eltype(df[!, col]) <: Union{Missing, Number},
        names(df)
    )

    # Verificar que la columna objetivo sea numérica
    if !(target in numeric_columns)
        throw(ArgumentError("La columna objetivo '$target' no es numérica."))
    end

    # Calcular la matriz de correlación
    corr_matrix, _ = calculateCorrelation(df)

    # Obtener el índice de la columna objetivo
    target_idx = findfirst(Symbol.(numeric_columns) .== Symbol(target))

    # Obtener la correlación con la columna objetivo
    target_corr = corr_matrix[:, target_idx]

    # Filtrar las columnas según la relación
    if relation
        keep_columns = numeric_columns[target_corr .>= threshold]
    else
        keep_columns = numeric_columns[target_corr .<= threshold]
    end

    # Agregar la columna objetivo a las columnas seleccionadas (si no está incluida ya)
    if !(target in keep_columns)
        push!(keep_columns, target)
    end

    # Seleccionar las columnas filtradas del DataFrame original
    return select(df, keep_columns)
end


function File(file_path::String)
    bottle_source = file_path
    bottle_df = CSV.read(bottle_source,DataFrame)

    return bottle_df
end


# Results
# Ruta al archivo CSV 
bottle_path = joinpath("..", "dat", "bottle.csv")
bottle_df = File(bottle_path)
rows1, columns1 = dataShape(bottle_df)
println("SHAPE OF THE DATA: \n",
        "Número de columnas: ",columns1, "\n",
        "Número de filas: ",rows1, "\n\n",
        
        
        "DATA TYPE: \n", dataType(bottle_df), "\n")

println("MISSING COUNTS: \n", count_missing(eachcol(bottle_df)))

println("MISSING PERCENTAGE: \n", dataMissingPercentage())

Missing_values = innerjoin(count_missing(eachcol(bottle_df)), dataMissingPercentage(), on=:Column)

cleaned_data = deleteColumns(50.0)  # Umbral del 50%
rows2, columns2 = dataShape(cleaned_data)
println("\nDELETE COLUMNS: \n", 
        "Número de columnas: ",columns2, "\n",
        "Número de filas: ",rows2, "\n\n",

        "CORRELATION MATRIX:", 
        )

correlation_matrix, desv_estan = calculateCorrelation(cleaned_data)
correlation_matrix

println("Desviación Estandar: ",desv_estan)
println("DISPLAY CORRELATION:")

heatmap_EDA_1 = displayCorrelation(cleaned_data, correlation_matrix)

# Guardamos la gráfica generada
heatmap_EDA_1_path = joinpath("..", "fig", "heatmap_EDA_1.png")
savefig(heatmap_EDA_1,heatmap_EDA_1_path)


cleaned_data_RO = removeOutliersIQR(cleaned_data)

rows3, columns3 = dataShape(cleaned_data_RO)

println("REMOVE OUTLIERS IQR:\n", 
        "Número de columnas: ",columns3, "\n",
        "Número de filas: ",rows3,"\n"
        )
        
col_name = names(cleaned_data_RO)

Without_missing_rows = deleteRow(col_name)

rows4, columns4 = dataShape(Without_missing_rows)

println("WITHOUT MISSING ROWS:\n",
        "Número de columnas: ",columns4, "\n",
        "Número de filas: ",rows4,"\n",
        )

println("FILTER COLUMNS BY CORRELATION:")

target = "T_degC"
threshold = 0.5
realtion = true

filtered_data = filterColumnsByCorrelation(Without_missing_rows, target, threshold, realtion)

rows5, columns5 = dataShape(filtered_data)

println("Número de columnas: ",columns5, "\n",
        "Número de filas: ",rows5
        )


println("\nDESCRIBE:")
describe(filtered_data)


corr_matrix_2, desv_estan = calculateCorrelation(filtered_data)
heatmap_EDA_2 = displayCorrelation(filtered_data, corr_matrix_2)

# Guardamos la gráfica generada
heatmap_EDA_2_path = joinpath("..", "fig", "heatmap_EDA_2.png")
savefig(heatmap_EDA_2,heatmap_EDA_2_path)