# Reporte de Análisis Exploratorio de Datos (EDA): `bottle.csv`

## Introducción
Este reporte describe el análisis de datos llevado a cabo sobre el conjunto de datos `bottle.csv`. Incluye información sobre la estructura de los datos, tipos de columnas, valores faltantes, y la eliminación de columnas y filas en función de ciertos criterios. Además, se aborda el cálculo y la visualización de la correlación entre columnas, así como la identificación y eliminación de valores atípicos (outliers).

---
### Librerias Utilizadas
Los librerias utilizadas en este análisis son:
- `CSV`: Lectura y escritura de archivos CSV..
- `DataFrames`: Manipulación de tablas de datos.
- `Plots`: Generación de gráficos.
- `Statistics`: Para realizar cálculos estadísticos.
- `PrettyTables`: Para formatear tablas en Markdown.

``` julia
using CSV, Tables, DataFrames, Statistics, Plots, GLM, PrettyTables
```

---
## Exploración Inicial
### Forma de los Datos (`dataShape`)
``` julia
# Función que devuelve un vector con el número de columnas y filas.
function dataShape(df::DataFrame)
    return size(df)
end
```

El DataFrame tiene **864,863 filas** y **74 columnas**.


### Tipos de Datos (`dataType`)
Se analizaron los tipos de datos en las columnas del `DataFrame`. 

```julia

function dataType(df ::DataFrame)
    # Asociamos a data el DataFrame con los datos que necesitamos
    data = describe(df)
    
    # Seleccionamos de data el nombre y el tipo de dato de las columnas
    type_col = select(data, :variable, :eltype)

    return  type_col
end
```
El resultado es el siguiente:

| **variable**<br>`Symbol` | **eltype**<br>`Type`     |
|-------------------------:|-------------------------:|
| Cst\_Cnt                 | Int64                    |
| Btl\_Cnt                 | Int64                    |
| Sta\_ID                  | String15                 |
| Depth\_ID                | String                   |
| Depthm                   | Int64                    |
| T\_degC                  | Union{Missing, Float64}  |
| Salnty                   | Union{Missing, Float64}  |
| O2ml\_L                  | Union{Missing, Float64}  |
| STheta                   | Union{Missing, Float64}  |
| O2Sat                    | Union{Missing, Float64}  |
| Oxy\_µmol/Kg             | Union{Missing, Float64}  |
| BtlNum                   | Union{Missing, Int64}    |
| RecInd                   | Int64                    |
| T\_prec                  | Union{Missing, Int64}    |
| T\_qual                  | Union{Missing, Int64}    |
| S\_prec                  | Union{Missing, Int64}    |
| S\_qual                  | Union{Missing, Int64}    |
| P\_qual                  | Union{Missing, Int64}    |
| O\_qual                  | Union{Missing, Int64}    |
| SThtaq                   | Union{Missing, Int64}    |
| O2Satq                   | Union{Missing, Int64}    |
| ChlorA                   | Union{Missing, Float64}  |
| Chlqua                   | Union{Missing, Int64}    |
| Phaeop                   | Union{Missing, Float64}  |
| Phaqua                   | Union{Missing, Int64}    |
| PO4uM                    | Union{Missing, Float64}  |
| PO4q                     | Union{Missing, Int64}    |
| SiO3uM                   | Union{Missing, Float64}  |
| SiO3qu                   | Union{Missing, Int64}    |
| NO2uM                    | Union{Missing, Float64}  |
| NO2q                     | Union{Missing, Int64}    |
| NO3uM                    | Union{Missing, Float64}  |
| NO3q                     | Union{Missing, Int64}    |
| NH3uM                    | Union{Missing, Float64}  |
| NH3q                     | Union{Missing, Int64}    |
| C14As1                   | Union{Missing, Float64}  |
| C14A1p                   | Union{Missing, Int64}    |
| C14A1q                   | Union{Missing, Int64}    |
| C14As2                   | Union{Missing, Float64}  |
| C14A2p                   | Union{Missing, Int64}    |
| C14A2q                   | Union{Missing, Int64}    |
| DarkAs                   | Union{Missing, Float64}  |
| DarkAp                   | Union{Missing, Int64}    |
| DarkAq                   | Union{Missing, Int64}    |
| MeanAs                   | Union{Missing, Float64}  |
| MeanAp                   | Union{Missing, Int64}    |
| MeanAq                   | Union{Missing, Int64}    |
| IncTim                   | Union{Missing, String31} |
| LightP                   | Union{Missing, Float64}  |
| R\_Depth                 | Float64                  |
| R\_TEMP                  | Union{Missing, Float64}  |
| R\_POTEMP                | Union{Missing, Float64}  |
| R\_SALINITY              | Union{Missing, Float64}  |
| R\_SIGMA                 | Union{Missing, Float64}  |
| R\_SVA                   | Union{Missing, Float64}  |
| R\_DYNHT                 | Union{Missing, Float64}  |
| R\_O2                    | Union{Missing, Float64}  |
| R\_O2Sat                 | Union{Missing, Float64}  |
| R\_SIO3                  | Union{Missing, Float64}  |
| R\_PO4                   | Union{Missing, Float64}  |
| R\_NO3                   | Union{Missing, Float64}  |
| R\_NO2                   | Union{Missing, Float64}  |
| R\_NH4                   | Union{Missing, Float64}  |
| R\_CHLA                  | Union{Missing, Float64}  |
| R\_PHAEO                 | Union{Missing, Float64}  |
| R\_PRES                  | Int64                    |
| R\_SAMP                  | Union{Missing, Int64}    |
| DIC1                     | Union{Missing, Float64}  |
| DIC2                     | Union{Missing, Float64}  |
| TA1                      | Union{Missing, Float64}  |
| TA2                      | Union{Missing, Float64}  |
| pH2                      | Union{Missing, Float64}  |
| pH1                      | Union{Missing, Float64}  |
| DIC Quality Comment      | Union{Missing, String}   |


### Valores Missing
#### Cantidad de Valores Missing (`count_missing`):

```julia
function count_missing(col)

    # Se recibe  una columnas y se cuenta los missing que tiene 
    missing_counts = map(columna -> count(ismissing, columna), col)
    
    # Se crea un Dataframe con el nombre de cada columna y su respectiva cantidad de missing
    MissingCounts_df = DataFrame(; Column = names(bottle_df), MissingCounts = missing_counts)
    
    return MissingCounts_df

end
```
Se identificaron valores faltantes en las columnas del `Dataframe`:

| **Column**<br>`String` | **MissingCounts**<br>`Int64` |
|-----------------------:|-----------------------------:|
| Cst\_Cnt               | 0                            |
| Btl\_Cnt               | 0                            |
| Sta\_ID                | 0                            |
| Depth\_ID              | 0                            |
| Depthm                 | 0                            |
| T\_degC                | 10963                        |
| Salnty                 | 47354                        |
| O2ml\_L                | 168662                       |
| STheta                 | 52689                        |
| O2Sat                  | 203589                       |
| Oxy\_µmol/Kg           | 203595                       |
| BtlNum                 | 746196                       |
| RecInd                 | 0                            |
| T\_prec                | 10963                        |
| T\_qual                | 841736                       |
| S\_prec                | 47354                        |
| S\_qual                | 789949                       |
| P\_qual                | 191108                       |
| O\_qual                | 680187                       |
| SThtaq                 | 799040                       |
| O2Satq                 | 647066                       |
| ChlorA                 | 639591                       |
| Chlqua                 | 225697                       |
| Phaeop                 | 639592                       |
| Phaqua                 | 225693                       |
| PO4uM                  | 451546                       |
| PO4q                   | 413077                       |
| SiO3uM                 | 510772                       |
| SiO3qu                 | 353997                       |
| NO2uM                  | 527287                       |
| NO2q                   | 335389                       |
| NO3uM                  | 527460                       |
| NO3q                   | 334930                       |
| NH3uM                  | 799901                       |
| NH3q                   | 56564                        |
| C14As1                 | 850431                       |
| C14A1p                 | 852103                       |
| C14A1q                 | 16258                        |
| C14As2                 | 850449                       |
| C14A2p                 | 852121                       |
| C14A2q                 | 16240                        |
| DarkAs                 | 842214                       |
| DarkAp                 | 844406                       |
| DarkAq                 | 24423                        |
| MeanAs                 | 842213                       |
| MeanAp                 | 844406                       |
| MeanAq                 | 24424                        |
| IncTim                 | 850426                       |
| LightP                 | 846212                       |
| R\_Depth               | 0                            |
| R\_TEMP                | 10963                        |
| R\_POTEMP              | 46047                        |
| R\_SALINITY            | 47354                        |
| R\_SIGMA               | 52856                        |
| R\_SVA                 | 52771                        |
| R\_DYNHT               | 46657                        |
| R\_O2                  | 168662                       |
| R\_O2Sat               | 198415                       |
| R\_SIO3                | 510764                       |
| R\_PO4                 | 451538                       |
| R\_NO3                 | 527452                       |
| R\_NO2                 | 527279                       |
| R\_NH4                 | 799881                       |
| R\_CHLA                | 639587                       |
| R\_PHAEO               | 639588                       |
| R\_PRES                | 0                            |
| R\_SAMP                | 742857                       |
| DIC1                   | 862864                       |
| DIC2                   | 864639                       |
| TA1                    | 862779                       |
| TA2                    | 864629                       |
| pH2                    | 864853                       |
| pH1                    | 864779                       |
| DIC Quality Comment    | 864808                       |


#### Porcentaje de Valores Missing (`dataMissingPercentage`):
```julia
function dataMissingPercentage()
    n_rows = first(dataShape(bottle_df))
    CM_df = count_missing(eachcol(bottle_df))

    Column_Percentage = [] 
    
    # Obtener el porcentaje de missings
    for i in CM_df.MissingCounts 
        percent = (i * 100) / n_rows 

        # Ponemos formato en el porcentaje obtenido
        format = string(Int(round(percent, digits=0)),"%")
        
        # Agregamos porcentaje al vector
        push!(Column_Percentage, format) 
    end 
  
    # Hacemos un DataFrame con el nombre de las columnas y el porcentaje de missings
    Percentage_df = DataFrame(; Column = names(bottle_df), MissingPercentage = Column_Percentage)
    return Percentage_df
end
```
El porcentaje de valores faltantes para cada columna es:

| **Column**<br>`String` | **MissingPercentage**<br>`Any` |
|-----------------------:|-------------------------------:|
| Cst\_Cnt               | 0%                             |
| Btl\_Cnt               | 0%                             |
| Sta\_ID                | 0%                             |
| Depth\_ID              | 0%                             |
| Depthm                 | 0%                             |
| T\_degC                | 1%                             |
| Salnty                 | 5%                             |
| O2ml\_L                | 20%                            |
| STheta                 | 6%                             |
| O2Sat                  | 24%                            |
| Oxy\_µmol/Kg           | 24%                            |
| BtlNum                 | 86%                            |
| RecInd                 | 0%                             |
| T\_prec                | 1%                             |
| T\_qual                | 97%                            |
| S\_prec                | 5%                             |
| S\_qual                | 91%                            |
| P\_qual                | 22%                            |
| O\_qual                | 79%                            |
| SThtaq                 | 92%                            |
| O2Satq                 | 75%                            |
| ChlorA                 | 74%                            |
| Chlqua                 | 26%                            |
| Phaeop                 | 74%                            |
| Phaqua                 | 26%                            |
| PO4uM                  | 52%                            |
| PO4q                   | 48%                            |
| SiO3uM                 | 59%                            |
| SiO3qu                 | 41%                            |
| NO2uM                  | 61%                            |
| NO2q                   | 39%                            |
| NO3uM                  | 61%                            |
| NO3q                   | 39%                            |
| NH3uM                  | 92%                            |
| NH3q                   | 7%                             |
| C14As1                 | 98%                            |
| C14A1p                 | 99%                            |
| C14A1q                 | 2%                             |
| C14As2                 | 98%                            |
| C14A2p                 | 99%                            |
| C14A2q                 | 2%                             |
| DarkAs                 | 97%                            |
| DarkAp                 | 98%                            |
| DarkAq                 | 3%                             |
| MeanAs                 | 97%                            |
| MeanAp                 | 98%                            |
| MeanAq                 | 3%                             |
| IncTim                 | 98%                            |
| LightP                 | 98%                            |
| R\_Depth               | 0%                             |
| R\_TEMP                | 1%                             |
| R\_POTEMP              | 5%                             |
| R\_SALINITY            | 5%                             |
| R\_SIGMA               | 6%                             |
| R\_SVA                 | 6%                             |
| R\_DYNHT               | 5%                             |
| R\_O2                  | 20%                            |
| R\_O2Sat               | 23%                            |
| R\_SIO3                | 59%                            |
| R\_PO4                 | 52%                            |
| R\_NO3                 | 61%                            |
| R\_NO2                 | 61%                            |
| R\_NH4                 | 92%                            |
| R\_CHLA                | 74%                            |
| R\_PHAEO               | 74%                            |
| R\_PRES                | 0%                             |
| R\_SAMP                | 86%                            |
| DIC1                   | 100%                           |
| DIC2                   | 100%                           |
| TA1                    | 100%                           |
| TA2                    | 100%                           |
| pH2                    | 100%                           |
| pH1                    | 100%                           |
| DIC Quality Comment    | 100%                           |
---

## Limpieza de Datos
### Eliminación de Columnas (`deleteColumns`)
Se eliminaron las columnas con más del 50% de valores faltantes. 
En muchos análisis exploratorios, el 50% se considera un punto de referencia común. Las columnas con más del 50% de datos faltantes son menos confiables para cualquier modelo o interpretación.

```julia
function deleteColumns(threshold::Float64)
    # Número de filas
    n_rows = nrow(bottle_df)

    # Sacamos el porcentaje de missing por columna, y si es menor igual que el threshold matenemos la columna.
    # Para mantener consistencia se redondea el porcentaje como en dataMissingPercentage().
    keep_cols = map(col -> round((count(ismissing, col) / n_rows * 100),digits = 0) <= threshold, eachcol(bottle_df))
    
    # Llamamos a las columnas del DataFrame que cumplieron con el criterio.
    return bottle_df[:, keep_cols]
end
```

- **Número de columnas restantes**: 36
- **Número de filas restantes**: 864,863

### Eliminación de Valores Atípicos (`removeOutliersIQR`)
Utilizando el rango intercuartílico (IQR), se eliminaron valores atípicos en las columnas numéricas. Después de este proceso:

```julia
function removeOutliersIQR(df::DataFrame)
    # Iterar sobre cada columna
    for col in names(df)
        # Verificar si la columna es numérica o Union{Missing, Number}
        if eltype(df[!, col]) <: Union{Missing, Number}

            # Calcular los cuantiles ignorando valores missing
            col_values = skipmissing(df[!, col])
            Q1 = quantile(col_values, 0.25)
            Q3 = quantile(col_values, 0.75)
            IQR = Q3 - Q1

            # Límites superior e inferior
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR

            # Filtrar filas manteniendo solo los valores dentro de los límites
            df = filter(row -> 
                ismissing(row[col]) || 
                (row[col] >= lower_bound && row[col] <= upper_bound), df)
        end
    end
    return df
end
```

- **Número de columnas restantes**: 36
- **Número de filas restantes**: 754,830

### Eliminación de Filas con Datos Missing (`deleteRow`)
Se eliminaron todas las filas que contenían datos faltantes en alguna columna. Utilizando la siguiente funcion:

```julia
function deleteRow(column)
    # Dataframe con columnas sin missing
    no_missing = dropmissing(cleaned_data_RO, column)

    return no_missing
end
```

- **Número de columnas restantes**: 36
- **Número de filas restantes**: 222,428

---

## Correlación entre Columnas
### Cálculo de Correlación (`calculateCorrelation`)

```julia
function calculateCorrelation(df::DataFrame)
    # Filtrar columnas de tipo numérico o Union{Missing, Number}
    numeric_columns = filter( 
        col -> eltype(df[!, col]) <: Union{Missing, Number},
        names(df)
        )

    # Seleccionar solo las columnas numéricas
    numeric_data = select(df, numeric_columns)

    # Eliminar filas con valores faltantes para evitar problemas al calcular correlaciones
    clean_numeric_data = dropmissing(numeric_data)


    # Calcular la matriz de correlación
    correlation_matrix = cor(Matrix(clean_numeric_data))


    # Calcular la desviación estándar de cada columna
    desviaciones_estandar = map(col -> std(skipmissing(clean_numeric_data[!, col])), names(clean_numeric_data))
    

    return correlation_matrix, desviaciones_estandar
end
```

Se calculó la matriz de correlación para las columnas numéricas, lo que resulto en una matriz 34\(\times\)34.

| **Col. 1**  | **Col. 2**  | **Col. 3**   | **Col. 4**   | **Col. 5** | **Col. 6**  | **Col. 7**  | **Col. 8**  | **Col. 9**  | **Col. 10** | **Col. 11** | **Col. 12** | **Col. 13**  | **Col. 14** | **Col. 15** | **Col. 16**  | **Col. 17**  | **Col. 18**  | **Col. 19**  | **Col. 20** | **Col. 21** | **Col. 22** | **Col. 23** | **Col. 24** | **Col. 25**  | **Col. 26**  | **Col. 27**  | **Col. 28** | **Col. 29** | **Col. 30** | **Col. 31**  | **Col. 32** | **Col. 33** | **Col. 34**  |
|------------:|------------:|-------------:|-------------:|-----------:|------------:|------------:|------------:|------------:|------------:|------------:|------------:|-------------:|------------:|------------:|-------------:|-------------:|-------------:|-------------:|------------:|------------:|------------:|------------:|------------:|-------------:|-------------:|-------------:|------------:|------------:|------------:|-------------:|------------:|------------:|-------------:|
| 1.0         | 0.998624    | -0.0254087   | 0.0579617    | 0.075628   | 0.00657505  | -0.0151526  | 0.0117098   | 0.00654296  | -0.0253404  | -0.057184   | 0.27811     | -0.00995485  | NaN         | NaN         | -0.0154086   | -0.0148404   | -0.0154086   | -0.0154086   | NaN         | NaN         | NaN         | NaN         | NaN         | -0.0254087   | 0.0579617    | 0.0577764    | 0.075628    | -0.0151351  | 0.0153484   | -0.0227598   | 0.00657505  | 0.0117098   | -0.0252874   |
| 0.998624    | 1.0         | -0.023928    | 0.0560461    | 0.0743083  | 0.00648779  | -0.013788   | 0.0112564   | 0.00645206  | -0.0285418  | -0.0552827  | 0.286104    | -0.00959656  | NaN         | NaN         | -0.0143002   | -0.013773    | -0.0143002   | -0.0143002   | NaN         | NaN         | NaN         | NaN         | NaN         | -0.023928    | 0.0560461    | 0.0558593    | 0.0743083   | -0.0137711  | 0.0139646   | -0.0215132   | 0.00648779  | 0.0112564   | -0.0238004   |
| -0.0254087  | -0.023928   | 1.0          | -0.662724    | 0.511542   | -0.552908   | 0.663928    | -0.56427    | -0.55303    | 0.0723017   | -0.0134677  | 0.111031    | 0.00125107   | NaN         | NaN         | -0.00147573  | -0.000257039 | -0.00147573  | -0.00147573  | NaN         | NaN         | NaN         | NaN         | NaN         | 1.0          | -0.662724    | -0.66584     | 0.511542    | 0.663927    | -0.655599   | 0.928852     | -0.552908   | -0.56427    | 0.999995     |
| 0.0579617   | 0.0560461   | -0.662724    | 1.0          | -0.360671  | 0.746766    | -0.956935   | 0.810607    | 0.747339    | -0.073676   | 0.00550605  | -0.131457   | -0.000926795 | NaN         | NaN         | -0.000248697 | -0.00102978  | -0.000248697 | -0.000248697 | NaN         | NaN         | NaN         | NaN         | NaN         | -0.662724    | 1.0          | 0.999991     | -0.360671   | -0.956932   | 0.957817    | -0.783734    | 0.746766    | 0.810607    | -0.661431    |
| 0.075628    | 0.0743083   | 0.511542     | -0.360671    | 1.0        | -0.780447   | 0.595623    | -0.731925   | -0.780268   | 0.0426342   | -0.0379171  | 0.0610719   | 0.00394229   | NaN         | NaN         | -0.0136253   | -0.0134113   | -0.0136253   | -0.0136253   | NaN         | NaN         | NaN         | NaN         | NaN         | 0.511542     | -0.360671    | -0.362531    | 1.0         | 0.595621    | -0.58938    | 0.610495     | -0.780447   | -0.731925   | 0.510465     |
| 0.00657505  | 0.00648779  | -0.552908    | 0.746766     | -0.780447  | 1.0         | -0.869592   | 0.992489    | 0.999999    | -0.0638113  | 0.0292745   | -0.0891828  | -0.00272243  | NaN         | NaN         | 0.00586596   | 0.00532853   | 0.00586596   | 0.00586596   | NaN         | NaN         | NaN         | NaN         | NaN         | -0.552908    | 0.746766     | 0.747371     | -0.780447   | -0.869592   | 0.866149    | -0.73663     | 1.0         | 0.992489    | -0.551171    |
| -0.0151526  | -0.013788   | 0.663928     | -0.956935    | 0.595623   | -0.869592   | 1.0         | -0.914012   | -0.870078   | 0.0714974   | -0.01409    | 0.128918    | 0.00196633   | NaN         | NaN         | -0.00504411  | -0.00442889  | -0.00504411  | -0.00504411  | NaN         | NaN         | NaN         | NaN         | NaN         | 0.663928     | -0.956935    | -0.95723     | 0.595623    | 0.999996    | -0.999863   | 0.809715     | -0.869592   | -0.914012   | 0.662478     |
| 0.0117098   | 0.0112564   | -0.56427     | 0.810607     | -0.731925  | 0.992489    | -0.914012   | 1.0         | 0.99262     | -0.0652715  | 0.0249974   | -0.0975301  | -0.00250568  | NaN         | NaN         | 0.00549949   | 0.00498696   | 0.00549949   | 0.00549949   | NaN         | NaN         | NaN         | NaN         | NaN         | -0.56427     | 0.810607     | 0.81102      | -0.731925   | -0.914011   | 0.911738    | -0.747921    | 0.992489    | 1.0         | -0.56258     |
| 0.00654296  | 0.00645206  | -0.55303     | 0.747339     | -0.780268  | 0.999999    | -0.870078   | 0.99262     | 1.0         | -0.0638194  | 0.0292435   | -0.0892724  | -0.00272261  | NaN         | NaN         | 0.00586694   | 0.00533001   | 0.00586694   | 0.00586694   | NaN         | NaN         | NaN         | NaN         | NaN         | -0.55303     | 0.747339     | 0.747943     | -0.780268   | -0.870078   | 0.866647    | -0.736761    | 0.999999    | 0.99262     | -0.551294    |
| -0.0253404  | -0.0285418  | 0.0723017    | -0.073676    | 0.0426342  | -0.0638113  | 0.0714974   | -0.0652715  | -0.0638194  | 1.0         | 0.0857464   | 0.726517    | 0.00178959   | NaN         | NaN         | 0.00669621   | 0.00645262   | 0.00669621   | 0.00669621   | NaN         | NaN         | NaN         | NaN         | NaN         | 0.0723017    | -0.073676    | -0.073784    | 0.0426342   | 0.0715001   | -0.0708053  | 0.0829994    | -0.0638113  | -0.0652715  | 0.0721675    |
| -0.057184   | -0.0552827  | -0.0134677   | 0.00550605   | -0.0379171 | 0.0292745   | -0.01409    | 0.0249974   | 0.0292435   | 0.0857464   | 1.0         | 0.0732356   | 8.6319e-5    | NaN         | NaN         | 0.000322984  | 0.000311235  | 0.000322984  | 0.000322984  | NaN         | NaN         | NaN         | NaN         | NaN         | -0.0134677   | 0.00550605   | 0.0055472    | -0.0379171  | -0.0140918  | 0.0139428   | -0.0157071   | 0.0292745   | 0.0249974   | -0.0134488   |
| 0.27811     | 0.286104    | 0.111031     | -0.131457    | 0.0610719  | -0.0891828  | 0.128918    | -0.0975301  | -0.0892724  | 0.726517    | 0.0732356   | 1.0         | -0.00166599  | NaN         | NaN         | -0.00623373  | -0.00600696  | -0.00623373  | -0.00623373  | NaN         | NaN         | NaN         | NaN         | NaN         | 0.111031     | -0.131457    | -0.131593    | 0.0610719   | 0.128918    | -0.128368   | 0.128072     | -0.0891828  | -0.09753    | 0.110884     |
| -0.00995485 | -0.00959656 | 0.00125107   | -0.000926795 | 0.00394229 | -0.00272243 | 0.00196633  | -0.00250568 | -0.00272261 | 0.00178959  | 8.6319e-5   | -0.00166599 | 1.0          | NaN         | NaN         | -1.4764e-5   | -1.42269e-5  | -1.4764e-5   | -1.4764e-5   | NaN         | NaN         | NaN         | NaN         | NaN         | 0.00125107   | -0.000926795 | -0.00093342  | 0.00394229  | 0.0019575   | -0.00195316 | 0.00178942   | -0.00272243 | -0.00250568 | 0.00124731   |
| NaN         | NaN         | NaN          | NaN          | NaN        | NaN         | NaN         | NaN         | NaN         | NaN         | NaN         | NaN         | NaN          | 1.0         | NaN         | NaN          | NaN          | NaN          | NaN          | NaN         | NaN         | NaN         | NaN         | NaN         | NaN          | NaN          | NaN          | NaN         | NaN         | NaN         | NaN          | NaN         | NaN         | NaN          |
| NaN         | NaN         | NaN          | NaN          | NaN        | NaN         | NaN         | NaN         | NaN         | NaN         | NaN         | NaN         | NaN          | NaN         | 1.0         | NaN          | NaN          | NaN          | NaN          | NaN         | NaN         | NaN         | NaN         | NaN         | NaN          | NaN          | NaN          | NaN         | NaN         | NaN         | NaN          | NaN         | NaN         | NaN          |
| -0.0154086  | -0.0143002  | -0.00147573  | -0.000248697 | -0.0136253 | 0.00586596  | -0.00504411 | 0.00549949  | 0.00586694  | 0.00669621  | 0.000322984 | -0.00623373 | -1.4764e-5   | NaN         | NaN         | 1.0          | 0.963622     | 1.0          | 1.0          | NaN         | NaN         | NaN         | NaN         | NaN         | -0.00147573  | -0.000248697 | -0.000230515 | -0.0136253  | -0.00503879 | 0.00497214  | -0.000764138 | 0.00586596  | 0.00549949  | -0.00146796  |
| -0.0148404  | -0.013773   | -0.000257039 | -0.00102978  | -0.0134113 | 0.00532853  | -0.00442889 | 0.00498696  | 0.00533001  | 0.00645262  | 0.000311235 | -0.00600696 | -1.42269e-5  | NaN         | NaN         | 0.963622     | 1.0          | 0.963622     | 0.963622     | NaN         | NaN         | NaN         | NaN         | NaN         | -0.000257039 | -0.00102978  | -0.00101481  | -0.0134113  | -0.00442583 | 0.00438086  | 0.000483058  | 0.00532853  | 0.00498696  | -0.000252665 |
| -0.0154086  | -0.0143002  | -0.00147573  | -0.000248697 | -0.0136253 | 0.00586596  | -0.00504411 | 0.00549949  | 0.00586694  | 0.00669621  | 0.000322984 | -0.00623373 | -1.4764e-5   | NaN         | NaN         | 1.0          | 0.963622     | 1.0          | 1.0          | NaN         | NaN         | NaN         | NaN         | NaN         | -0.00147573  | -0.000248697 | -0.000230515 | -0.0136253  | -0.00503879 | 0.00497214  | -0.000764138 | 0.00586596  | 0.00549949  | -0.00146796  |
| -0.0154086  | -0.0143002  | -0.00147573  | -0.000248697 | -0.0136253 | 0.00586596  | -0.00504411 | 0.00549949  | 0.00586694  | 0.00669621  | 0.000322984 | -0.00623373 | -1.4764e-5   | NaN         | NaN         | 1.0          | 0.963622     | 1.0          | 1.0          | NaN         | NaN         | NaN         | NaN         | NaN         | -0.00147573  | -0.000248697 | -0.000230515 | -0.0136253  | -0.00503879 | 0.00497214  | -0.000764138 | 0.00586596  | 0.00549949  | -0.00146796  |
| NaN         | NaN         | NaN          | NaN          | NaN        | NaN         | NaN         | NaN         | NaN         | NaN         | NaN         | NaN         | NaN          | NaN         | NaN         | NaN          | NaN          | NaN          | NaN          | 1.0         | NaN         | NaN         | NaN         | NaN         | NaN          | NaN          | NaN          | NaN         | NaN         | NaN         | NaN          | NaN         | NaN         | NaN          |
| NaN         | NaN         | NaN          | NaN          | NaN        | NaN         | NaN         | NaN         | NaN         | NaN         | NaN         | NaN         | NaN          | NaN         | NaN         | NaN          | NaN          | NaN          | NaN          | NaN         | 1.0         | NaN         | NaN         | NaN         | NaN          | NaN          | NaN          | NaN         | NaN         | NaN         | NaN          | NaN         | NaN         | NaN          |
| NaN         | NaN         | NaN          | NaN          | NaN        | NaN         | NaN         | NaN         | NaN         | NaN         | NaN         | NaN         | NaN          | NaN         | NaN         | NaN          | NaN          | NaN          | NaN          | NaN         | NaN         | 1.0         | NaN         | NaN         | NaN          | NaN          | NaN          | NaN         | NaN         | NaN         | NaN          | NaN         | NaN         | NaN          |
| NaN         | NaN         | NaN          | NaN          | NaN        | NaN         | NaN         | NaN         | NaN         | NaN         | NaN         | NaN         | NaN          | NaN         | NaN         | NaN          | NaN          | NaN          | NaN          | NaN         | NaN         | NaN         | 1.0         | NaN         | NaN          | NaN          | NaN          | NaN         | NaN         | NaN         | NaN          | NaN         | NaN         | NaN          |
| NaN         | NaN         | NaN          | NaN          | NaN        | NaN         | NaN         | NaN         | NaN         | NaN         | NaN         | NaN         | NaN          | NaN         | NaN         | NaN          | NaN          | NaN          | NaN          | NaN         | NaN         | NaN         | NaN         | 1.0         | NaN          | NaN          | NaN          | NaN         | NaN         | NaN         | NaN          | NaN         | NaN         | NaN          |
| -0.0254087  | -0.023928   | 1.0          | -0.662724    | 0.511542   | -0.552908   | 0.663928    | -0.56427    | -0.55303    | 0.0723017   | -0.0134677  | 0.111031    | 0.00125107   | NaN         | NaN         | -0.00147573  | -0.000257039 | -0.00147573  | -0.00147573  | NaN         | NaN         | NaN         | NaN         | NaN         | 1.0          | -0.662724    | -0.66584     | 0.511542    | 0.663927    | -0.655599   | 0.928852     | -0.552908   | -0.56427    | 0.999995     |
| 0.0579617   | 0.0560461   | -0.662724    | 1.0          | -0.360671  | 0.746766    | -0.956935   | 0.810607    | 0.747339    | -0.073676   | 0.00550605  | -0.131457   | -0.000926795 | NaN         | NaN         | -0.000248697 | -0.00102978  | -0.000248697 | -0.000248697 | NaN         | NaN         | NaN         | NaN         | NaN         | -0.662724    | 1.0          | 0.999991     | -0.360671   | -0.956932   | 0.957817    | -0.783734    | 0.746766    | 0.810607    | -0.661431    |
| 0.0577764   | 0.0558593   | -0.66584     | 0.999991     | -0.362531  | 0.747371    | -0.95723    | 0.81102     | 0.747943    | -0.073784   | 0.0055472   | -0.131593   | -0.00093342  | NaN         | NaN         | -0.000230515 | -0.00101481  | -0.000230515 | -0.000230515 | NaN         | NaN         | NaN         | NaN         | NaN         | -0.66584     | 0.999991     | 1.0          | -0.362531   | -0.957227   | 0.958057    | -0.78614     | 0.747371    | 0.81102     | -0.664551    |
| 0.075628    | 0.0743083   | 0.511542     | -0.360671    | 1.0        | -0.780447   | 0.595623    | -0.731925   | -0.780268   | 0.0426342   | -0.0379171  | 0.0610719   | 0.00394229   | NaN         | NaN         | -0.0136253   | -0.0134113   | -0.0136253   | -0.0136253   | NaN         | NaN         | NaN         | NaN         | NaN         | 0.511542     | -0.360671    | -0.362531    | 1.0         | 0.595621    | -0.58938    | 0.610495     | -0.780447   | -0.731925   | 0.510465     |
| -0.0151351  | -0.0137711  | 0.663927     | -0.956932    | 0.595621   | -0.869592   | 0.999996    | -0.914011   | -0.870078   | 0.0715001   | -0.0140918  | 0.128918    | 0.0019575    | NaN         | NaN         | -0.00503879  | -0.00442583  | -0.00503879  | -0.00503879  | NaN         | NaN         | NaN         | NaN         | NaN         | 0.663927     | -0.956932    | -0.957227    | 0.595621    | 1.0         | -0.999859   | 0.809714     | -0.869592   | -0.914011   | 0.662476     |
| 0.0153484   | 0.0139646   | -0.655599    | 0.957817     | -0.58938   | 0.866149    | -0.999863   | 0.911738    | 0.866647    | -0.0708053  | 0.0139428   | -0.128368   | -0.00195316  | NaN         | NaN         | 0.00497214   | 0.00438086   | 0.00497214   | 0.00497214   | NaN         | NaN         | NaN         | NaN         | NaN         | -0.655599    | 0.957817     | 0.958057     | -0.58938    | -0.999859   | 1.0         | -0.801214    | 0.866149    | 0.911738    | -0.654157    |
| -0.0227598  | -0.0215132  | 0.928852     | -0.783734    | 0.610495   | -0.73663    | 0.809715    | -0.747921   | -0.736761   | 0.0829994   | -0.0157071  | 0.128072    | 0.00178942   | NaN         | NaN         | -0.000764138 | 0.000483058  | -0.000764138 | -0.000764138 | NaN         | NaN         | NaN         | NaN         | NaN         | 0.928852     | -0.783734    | -0.78614     | 0.610495    | 0.809714    | -0.801214   | 1.0          | -0.73663    | -0.747921   | 0.927859     |
| 0.00657505  | 0.00648779  | -0.552908    | 0.746766     | -0.780447  | 1.0         | -0.869592   | 0.992489    | 0.999999    | -0.0638113  | 0.0292745   | -0.0891828  | -0.00272243  | NaN         | NaN         | 0.00586596   | 0.00532853   | 0.00586596   | 0.00586596   | NaN         | NaN         | NaN         | NaN         | NaN         | -0.552908    | 0.746766     | 0.747371     | -0.780447   | -0.869592   | 0.866149    | -0.73663     | 1.0         | 0.992489    | -0.551171    |
| 0.0117098   | 0.0112564   | -0.56427     | 0.810607     | -0.731925  | 0.992489    | -0.914012   | 1.0         | 0.99262     | -0.0652715  | 0.0249974   | -0.09753    | -0.00250568  | NaN         | NaN         | 0.00549949   | 0.00498696   | 0.00549949   | 0.00549949   | NaN         | NaN         | NaN         | NaN         | NaN         | -0.56427     | 0.810607     | 0.81102      | -0.731925   | -0.914011   | 0.911738    | -0.747921    | 0.992489    | 1.0         | -0.56258     |
| -0.0252874  | -0.0238004  | 0.999995     | -0.661431    | 0.510465   | -0.551171   | 0.662478    | -0.56258    | -0.551294   | 0.0721675   | -0.0134488  | 0.110884    | 0.00124731   | NaN         | NaN         | -0.00146796  | -0.000252665 | -0.00146796  | -0.00146796  | NaN         | NaN         | NaN         | NaN         | NaN         | 0.999995     | -0.661431    | -0.664551    | 0.510465    | 0.662476    | -0.654157   | 0.927859     | -0.551171   | -0.56258    | 1.0          |

Cada valor de la matriz indica el grado de relación lineal entre dos variables: un valor cercano a 1 significa una correlación positiva fuerte, un valor cercano a -1 indica una correlación negativa fuerte, y un valor cercano a 0 significa poca o ninguna correlación.

En cuanto a los elementos y estructura de la matriz, se pueden hacer algunas observaciones:

1. **Valores cercanos a 1 o -1**: Los valores cercanos a 1 o -1 en las columnas 1 y 2, por ejemplo, indican una relación muy fuerte entre esas dos variables. En este caso, el valor 0.998624 en la posición (1, 2) sugiere una alta correlación positiva entre las columnas 1 y 2.

2. **Valores cercanos a 0**: En algunas posiciones, como la correlación entre la columna 3 y otras columnas, se encuentran valores cercanos a 0, como el 0.00657505 en la posición (1, 6), lo que indica una relación débil o nula.

3. **Valores NaN**: La matriz contiene varios valores "NaN", lo que indica que no se puede calcular la correlación entre ciertos pares de columnas. 
Al sacar la desviación estándar de cada columna hay algunas que tienen desviación estándar de 0, significa que es constante y puede generar problemas al calcular la correlación.


### Visualización de Correlación (`displayCorrelation`)
Se generó un mapa de calor para visualizar las correlaciones:

```julia
# Gráficamos la matriz de correlación en un mapa de calor 
function displayCorrelation(df::DataFrame, correlation_matrix::Matrix)

    # Nombre se las columnas númericas.
    numeric_columns = filter( 
        col -> eltype(df[!, col]) <: Union{Missing, Number},
        names(df)
        )

    # Crear el heatmap con etiquetas.
    corr_heatmap =heatmap(correlation_matrix, color=cgrad([:green, :yellow, :red]), 
            title="Correlation Heatmap",
            xticks=(1:length(numeric_columns), numeric_columns), yticks=(1:length(numeric_columns), numeric_columns))
            
    return corr_heatmap
end
```

![heatmap_EDA_1.png](../fig/heatmap_EDA_1.png)

### Filtrado por Correlación (`filterColumnsByCorrelation`)

```julia
function filterColumnsByCorrelation(df::DataFrame, target::String, threshold::Float64, relation::Bool)
    # Verificar que la columna objetivo exista
    if !(target in names(df))
        throw(ArgumentError("La columna '$target' no existe en el DataFrame."))
    end

    # Seleccionar solo columnas numéricas o Union{Missing, Number}
    numeric_columns = filter(
        col -> eltype(df[!, col]) <: Union{Missing, Number},
        names(df)
    )

    # Verificar que la columna objetivo sea numérica
    if !(target in numeric_columns)
        throw(ArgumentError("La columna objetivo '$target' no es numérica."))
    end

    # Calcular la matriz de correlación
    corr_matrix, _ = calculateCorrelation(df)

    # Obtener el índice de la columna objetivo
    target_idx = findfirst(Symbol.(numeric_columns) .== Symbol(target))

    # Obtener la correlación con la columna objetivo
    target_corr = corr_matrix[:, target_idx]

    # Filtrar las columnas según la relación
    if relation
        keep_columns = numeric_columns[target_corr .>= threshold]
    else
        keep_columns = numeric_columns[target_corr .<= threshold]
    end

    # Agregar la columna objetivo a las columnas seleccionadas (si no está incluida ya)
    if !(target in keep_columns)
        push!(keep_columns, target)
    end

    # Seleccionar las columnas filtradas del DataFrame original
    return select(df, keep_columns)
end
```
Puede haber ligeras desviaciones debido a errores numéricos, lo que podría hacer que no coincidan exactamente con el umbral esperado. Para manejar esto, se usa una tolerancia

Se seleccionaron columnas con una correlación mayor a 0.5 con la columna `T_degC`.

Analizar las correlaciones con `T_degC` puede ayudar a identificar variables que tienen relaciones fuertes y lineales con la temperatura, lo cual es útil para desarrollar modelos predictivos.Por otra parte, la temperatura es un resultado de múltiples factores en el océano, por lo que es lógico usarla como la variable dependiente al investigar relaciones en los datos.

Un umbral de 0.5 permite escoger sólo aquellas variables que presentan correlaciones moderadas o fuertes con `T_degC`De esta manera, se desechan aquellas que tengan correlaciones débiles o nulas; en la práctica, esto también ayuda a reducir el ruido y simplificar el análisis. Por otra parte, un filtro por correlaciones fuertes permite identificar de manera rápida las variables clave que tienen el mayor impacto en la temperatura, lo cual es útil para modelos de regresión o análisis predictivo.


El resultado final incluye:
- **Número de columnas seleccionadas**: 9
- **Número de filas seleccionadas**: 222,428

Se mostraran las **primeras 13** y las **últimas 13** filas debido a la gran cantidad de filas.

| **T\_degC**<br>`Float64` | **O2ml\_L**<br>`Float64` | **O2Sat**<br>`Float64` | **Oxy\_µmol/Kg**<br>`Float64` | **R\_TEMP**<br>`Float64` | **R\_POTEMP**<br>`Float64` | **R\_SVA**<br>`Float64` | **R\_O2**<br>`Float64` | **R\_O2Sat**<br>`Float64` |
|-------------------------:|-------------------------:|-----------------------:|------------------------------:|-------------------------:|---------------------------:|------------------------:|-----------------------:|--------------------------:|
| 10.29                    | 6.04                     | 95.0                   | 263.089                       | 10.29                    | 10.29                      | 266.1                   | 6.04                   | 95.0                      |
| 10.29                    | 6.06                     | 95.3                   | 263.952                       | 10.29                    | 10.29                      | 263.3                   | 6.06                   | 95.3                      |
| 10.33                    | 6.04                     | 95.1                   | 263.08                        | 10.33                    | 10.33                      | 262.9                   | 6.04                   | 95.1                      |
| 10.39                    | 6.01                     | 94.8                   | 261.766                       | 10.39                    | 10.39                      | 260.4                   | 6.01                   | 94.8                      |
| 10.4                     | 6.01                     | 94.8                   | 261.765                       | 10.4                     | 10.4                       | 260.2                   | 6.01                   | 94.8                      |
| 10.36                    | 5.78                     | 91.1                   | 251.729                       | 10.36                    | 10.35                      | 253.2                   | 5.78                   | 91.1                      |
| 10.35                    | 5.76                     | 90.8                   | 250.854                       | 10.35                    | 10.34                      | 251.8                   | 5.76                   | 90.8                      |
| 10.25                    | 5.6                      | 88.1                   | 243.864                       | 10.25                    | 10.24                      | 243.6                   | 5.6                    | 88.1                      |
| 10.05                    | 5.07                     | 79.5                   | 220.757                       | 10.05                    | 10.04                      | 231.6                   | 5.07                   | 79.5                      |
| 9.54                     | 3.82                     | 59.3                   | 166.283                       | 9.54                     | 9.53                       | 204.7                   | 3.82                   | 59.3                      |
| 9.5                      | 3.76                     | 58.3                   | 163.668                       | 9.5                      | 9.49                       | 202.9                   | 3.76                   | 58.3                      |
| 9.05                     | 3.2                      | 49.2                   | 139.266                       | 9.05                     | 9.04                       | 185.0                   | 3.2                    | 49.2                      |
| 8.93                     | 3.1                      | 47.5                   | 134.908                       | 8.93                     | 8.92                       | 181.1                   | 3.1                    | 47.5                      |
| ⁝                    | ⁝                   | ⁝                  |⁝                      | ⁝                        | ⁝                     |⁝                      | ⁝                     |⁝ 
| 7.58                     | 1.12                     | 16.7                   | 48.7191                       | 7.58                     | 7.55                       | 139.9                   | 1.12                   | 16.7                      |
| 6.95                     | 0.72                     | 10.6                   | 31.3161                       | 6.95                     | 6.91                       | 130.8                   | 0.72                   | 10.6                      |
| 6.03                     | 0.4                      | 5.7                    | 17.3949                       | 6.03                     | 5.99                       | 115.1                   | 0.4                    | 5.7                       |
| 7.75                     | 1.47                     | 22.0                   | 63.948                        | 7.75                     | 7.73                       | 145.3                   | 1.47                   | 22.0                      |
| 7.44                     | 1.01                     | 15.0                   | 43.9334                       | 7.44                     | 7.41                       | 138.0                   | 1.01                   | 15.0                      |
| 6.65                     | 0.59                     | 8.6                    | 25.6604                       | 6.65                     | 6.61                       | 125.2                   | 0.59                   | 8.6                       |
| 5.93                     | 0.4                      | 5.7                    | 17.3947                       | 5.93                     | 5.89                       | 113.4                   | 0.4                    | 5.7                       |
| 8.38                     | 1.75                     | 26.5                   | 76.1388                       | 8.38                     | 8.36                       | 157.9                   | 1.75                   | 26.5                      |
| 7.83                     | 1.51                     | 22.6                   | 65.6901                       | 7.83                     | 7.81                       | 148.5                   | 1.51                   | 22.6                      |
| 7.09                     | 1.18                     | 17.4                   | 51.3277                       | 7.09                     | 7.06                       | 136.9                   | 1.18                   | 17.4                      |
| 6.5                      | 0.62                     | 9.0                    | 26.965                        | 6.5                      | 6.46                       | 124.3                   | 0.62                   | 9.0                       |
| 5.84                     | 0.4                      | 5.7                    | 17.3946                       | 5.84                     | 5.8                        | 112.9                   | 0.4                    | 5.7                       |
| 18.05                    | 6.4                      | 118.4                  | 279.077                       | 18.05                    | 18.05                      | 373.1                   | 6.4                    | 118.4                     |

![heatmap_EDA_2.png](../fig/heatmap_EDA_2.png)
 Mapa de calor de `filtered_data`


---

## Estadísticas Descriptivas (`describe`)
A continuación se presenta un resumen estadístico de las columnas seleccionadas:

```julia
describe(filtered_data)
```


| **variable**<br>`Symbol` | **mean**<br>`Float64` | **min**<br>`Float64` | **median**<br>`Float64` | **max**<br>`Float64` | **nmissing**<br>`Int64` | **eltype**<br>`DataType` |
|-------------------------:|----------------------:|---------------------:|------------------------:|---------------------:|------------------------:|-------------------------:|
| T\_degC                  | 11.3149               | 4.06                 | 10.42                   | 22.85                | 0                       | Float64                  |
| O2ml\_L                  | 3.34265               | 0.0                  | 3.38                    | 9.8                  | 0                       | Float64                  |
| O2Sat                    | 55.9635               | 0.0                  | 52.9                    | 157.8                | 0                       | Float64                  |
| Oxy\_µmol/Kg             | 145.6                 | 0.0                  | 147.098                 | 426.715              | 0                       | Float64                  |
| R\_TEMP                  | 11.3149               | 4.06                 | 10.42                   | 22.85                | 0                       | Float64                  |
| R\_POTEMP                | 11.2974               | 4.02                 | 10.41                   | 22.85                | 0                       | Float64                  |
| R\_SVA                   | 224.36                | 93.6                 | 204.9                   | 494.0                | 0                       | Float64                  |
| R\_O2                    | 3.34265               | 0.0                  | 3.38                    | 9.8                  | 0                       | Float64                  |
| R\_O2Sat                 | 55.9635               | 0.0                  | 52.9                    | 157.8                | 0                       | Float64                  |
---

## Conclusiones
1. **Valores Missing**: Se identificaron y eliminaron columnas y filas con altos porcentajes de datos faltantes.
2. **Valores Atípicos**: Se manejaron los outliers mediante el uso del rango intercuartílico.
3. **Correlación**: Se analizó la correlación entre columnas numéricas para identificar relaciones significativas.
4. **Estadísticas Descriptivas**: Se calculó un resumen estadístico de las columnas seleccionadas.

