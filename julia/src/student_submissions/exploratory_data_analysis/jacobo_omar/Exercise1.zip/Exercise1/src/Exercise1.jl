using CSV,  DataFrames, Statistics, Plots, FileIO, Images
# Valores usados para el filtrado de datos
threshold_missings = 20
threshold_correlation = 0.5
column_name = :R_PRES
df_bottle = CSV.read("/mnt/c/Users/omarm/Downloads/bottle/bottle.csv", DataFrame);
nothing
#first(df_bottle, 3)## dataShape: to get shape of the data

size_df = size(df_bottle)
println("Las dimensiones del dataframe son: $size_df")

## dataType: gives data type of each column in the dataset
data_bottle = [(name, eltype(column), round(count(ismissing, column)/length(column)*100, digits=3)) for (name, column) in zip(names(df_bottle), eachcol(df_bottle))]

println("Los nombres de las columas con su respectivo tipo de dato son:")
for (name, dtype, _) in data_bottle
    println("$name: $dtype")
end

## count_missing(col) : counts number of missing data in a given col (Column).
println("A continuación se muestran la cantidad de valores faltantes por columna")
missing_values = describe(df_bottle, :nmissing)
println(missing_values)
m_columns = length([row["nmissing"] for row in eachrow(missing_values) if row["nmissing"] > 0])[1]
println("Existen $m_columns columnas con datos faltantes que son las siguientes: ")
for row in eachrow(missing_values)
    col = row["variable"]
    n_missing = row["nmissing"]
    if n_missing > 0
        println("$col: $n_missing")
    end
end

## dataMissingPercentage(): finds missing percentage of each column.
function dataMissingPercentage(df)
    missing_percent_by_col = [(name, round(count(ismissing, column)/length(column)*100, digits=3))
    for (name, column) in zip(names(df), eachcol(df))]
    return missing_percent_by_col
end

percent_by_col = dataMissingPercentage(df_bottle)
println("El porcentaje de datos faltantes de cada columna es:")
for (name, p) in percent_by_col
    println("$name: $p%")
end

## deleteColumns(threshold) : delete all the columns which have missing percent less than given threshold.
function deleteColumns(df, threshold)
    new_df = df[!, [round(count(ismissing, column)/length(column)*100) <= threshold for column in eachcol(df)]]
    return new_df
end

# Quitar las columnas con un porcentaje mayor a 50
df_filtered_threshold = deleteColumns(df_bottle, threshold_missings)
size_df_f = size(df_filtered_threshold)
println("El dataframe filtrado tiene de dimensiones: $size_df_f ")

percent_by_col = dataMissingPercentage(df_filtered_threshold)
println("El porcentaje de datos faltantes de las columnas que permanecen es:")
for (name, p) in percent_by_col
    println("$name: $p%")
end

## calculateCorrelation() : creates correlation matrix between columns.
function calculate_correlation(df)
    numeric_df = dropmissing(df[!, [eltype(col) <: Union{Number, Missing} for col in eachcol(df)]])
    cor_matrix = cor(Matrix(numeric_df))
    columns_names = names(numeric_df)
    correlation_df = rename(DataFrame(cor_matrix, :auto), Symbol.(columns_names))
    return cor_matrix, correlation_df
end

correlation_matrix, correlation_as_df = calculate_correlation(df_filtered_threshold)
correlation_matrix

## displayCorrelation() : display correlation using heatmap.
pl = heatmap(correlation_matrix,
        title="Correlation matrix heatmap",
        xlabel="Columns", ylabel="Columns",
        color=:YlGnBu_5,
        xticks=(1:length(names(correlation_as_df)), names(correlation_as_df)),
        yticks=(1:length(names(correlation_as_df)), names(correlation_as_df)),
        xrot=1000,
        yrot=0,
        colorrange=(0, 1),
    )
path = pwd()
path = path[1:length(path)-3]
savefig(pl,"$path" * "fig/graph.png")
img = FileIO.load("$path" * "fig/graph.png")

## removeOutliersIQR() : using interquartile range delete all the outliers from the numerical columns.

function remove_outliersIQR(df)
    numeric_df = df[:, [eltype(col) <: Union{Number, Missing} for col in eachcol(df)]]
    rows_ind = trues(nrow(df))
    for name in names(numeric_df)
        column = df[!, name]
        col_wo_mis = skipmissing(column)
        Q1 = quantile(col_wo_mis, 0.25)
        Q3 = quantile(col_wo_mis, 0.75)
        IQR = Q3 - Q1
        condition = ((column .< (Q1 - 1.5 * IQR)) .| (column .> (Q3 + 1.5 * IQR)))
        rows_ind .&= .~condition .| ismissing.(column)
    end

    return df[rows_ind, :]
end

df_filtered_threshold_IQR = remove_outliersIQR(df_filtered_threshold)

size_df_iqr = size(df_filtered_threshold_IQR)
println("El dataframe filtrado por IQR tiene de dimensiones: $size_df_iqr")

## deleteRow(column): for a given column delete all the null data points.

function delete_null_rows(df, column)
    dff = filter(x -> ~ismissing(x[column]), df)
    return dff
end

df_filtered_threshold_IQR_without_nulls=delete_null_rows(df_filtered_threshold_IQR, column_name)

println("Antes de quitar los nulos, tenemos:")
missing_values = filter(row -> row.variable == column_name, describe(df_filtered_threshold_IQR, :nmissing))
println(missing_values)

println("\nDespues de quitar los nulos para la columna $column_name tenemos: ")
missing_values = filter(row -> row.variable == column_name, describe(df_filtered_threshold_IQR_without_nulls, :nmissing))
println(missing_values)

## filterColumnsByCorrelation(target,threshold, relation) : delete all the columns on the basis of given threshold for a target column and relation .
function filter_columns_by_correlation(df, correlation_df, target_column, threshold)
    column_names_index = Dict(name => index for (index, name) in enumerate(names(correlation_df)))
    correlation_column = correlation_df[:, target_column]
    new_df = df[!, [name in keys(column_names_index) && abs(correlation_column[column_names_index[name]]) >= threshold for name in names(df)]]
    return new_df
end

df_filtered_threshold_IQR_without_nulls_correlation=filter_columns_by_correlation(df_filtered_threshold_IQR_without_nulls, correlation_as_df, column_name, threshold_correlation)

size_df_f = size(df_filtered_threshold_IQR_without_nulls)
println("El dataframe inicial tiene de dimensiones: $size_df_f ")
size_df_f = size(df_filtered_threshold_IQR_without_nulls_correlation)
println("El dataframe filtrado tiene de dimensiones: $size_df_f ")

## describe() : it is used to describe data by giving following for each column/
describe(df_filtered_threshold_IQR_without_nulls_correlation)

CSV.write("/mnt/c/Users/omarm/Downloads/bottle/bottle_clean.csv", df_filtered_threshold_IQR_without_nulls_correlation, header=true )
correlation_matrixf, correlation_as_dff = calculate_correlation(df_filtered_threshold_IQR_without_nulls_correlation)
print(names(df_filtered_threshold_IQR_without_nulls_correlation))
pl = heatmap(correlation_matrixf,
        title="Correlation matrix heatmap",
        xlabel="Columns", ylabel="Columns",
        color=:YlGnBu_5,
        xticks=(1:length(names(correlation_as_dff)), names(correlation_as_dff)),
        yticks=(1:length(names(correlation_as_dff)), names(correlation_as_dff)),
        xrot=1000,
        yrot=0,
        colorrange=(0, 1),
    )
path = pwd()
path = path[1:length(path)-3]
savefig(pl,"$path" * "fig/graph2.png")
img = FileIO.load("$path" * "fig/graph2.png")
