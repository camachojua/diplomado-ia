"""
Exploratory data analysis of the bottle datadrame in Julia

dataShape: to get shape of the data
dataType: gives data type of each column in the dataset
count_missing(col) : counts number of missing data in a given col (Column).
dataMissingPercentage(): finds missing percentage of each column.
deleteColumns(threshold) : delete all the columns which have missing percent less than given threshold.
calculateCorrelation() : creates correlation matrix between columns.
displayCorrelation() : dislpay correlation using heatmap.
removeOutliersIQR() : using interquartile range delete all the outliers from the numerical columns.
deleteRow(column): for a given column delete all the null data points.
filterColumnsByCorrelation(target,threshold, realtion) : delete all the columns on the basis of given threshold for a target column and relation .
describe() : it is used to describe data by giving following for each column/
"""

using DataFrames, CSV
using Statistics
using Plots
using StatsBase

# Read the bottle csv file
bottle = CSV.read("/Users/marbazua/Documents/Diplomado/Mar_Bazua/exploratory_data_analysis/bazua_mar/dat/bottle.csv", DataFrame, delim=',', header=true)
nothing

### 1. dataShape: to get shape of the data
function dataShape(data) 
    
    data_shape=size(data)

    return data_shape
end

data_shape = dataShape(bottle)
println("dataShape:", data_shape)

### 2. dataType: gives data type of each column in the dataset
# Create a readable list of column names and types
function dataType(data)
    column_types_list = [(name, eltype(column)) for (name, column) in zip(names(data), eachcol(data))]

    return column_types_list
end

column_types_list = dataType(bottle)
println("Column names and their data types:")
for (name, dtype) in column_types_list
    println("$name: $dtype")
end

#We have some variables of type string, let's encode them so we can use them later in the regression model

# Function to perform frequency encoding on string columns
function frequency_encode!(df::DataFrame)
    for col in names(df)
        # Check if column is of type String or Missing
        if eltype(df[!, col]) <: AbstractString || eltype(df[!, col]) == Union{Missing, String}
            
            # Separate the non-missing values and their indices
            non_missing_values = df[!, col]
            non_missing_indices = findall(!ismissing, non_missing_values)

            # Get only the non-missing values for frequency encoding
            non_missing_data = non_missing_values[non_missing_indices]

            # Calculate frequency of each category for non-missing values
            freqs = combine(groupby(DataFrame(value=non_missing_data), :value), nrow => :freq)

            # Map frequencies back to the original non-missing values using a Dict
            freq_dict = Dict(freqs.value .=> freqs.freq)

            # Create a copy of the original column to update, keeping the type as String
            encoded_column = copy(non_missing_values)

            # Replace non-missing values with their frequencies (as Strings)
            for i in non_missing_indices
                encoded_column[i] = string(get(freq_dict, non_missing_values[i], 0))  # Convert frequency to string
            end

            # Assign the encoded column back to the dataframe
            df[!, col] .= encoded_column
        end
    end
    return df
end

bottle = frequency_encode!(bottle)

#Let's see if it worked
column_types_list = dataType(bottle)
println("Column names and their data types:")
for (name, dtype) in column_types_list
    println("$name: $dtype")
end

# Cast the string-encoded values to Int64 (or Float64) after encoding, handling missing values
for col in names(bottle)
    if eltype(bottle[!, col]) <: AbstractString || eltype(bottle[!, col]) == Union{Missing, String}
        # Safely parse the values, preserving missing values
        bottle[!, col] .= map(x -> ismissing(x) ? missing : parse(Int64, x), bottle[!, col])
    end
end

column_types_list = dataType(bottle)
println("Column names and their data types:")
for (name, dtype) in column_types_list
    println("$name: $dtype")
end

### 3. count_missing(col) : counts number of missing data in a given col (Column)
function count_missing(data)
    missing_col_list = [(name, count(ismissing,column)) for (name, column) in zip(names(data), eachcol(data))]
    return missing_col_list
end

missing_col_list = count_missing(bottle)
println("Número de missings por variable:")
for (name, missingc) in missing_col_list
    println("$name: $missingc")
end

### 4. dataMissingPercentage(): finds missing percentage of each column.
function dataMissingPercentage(data)
    missing_col_perc_list = [(name, round(count(ismissing,column)/length(column) * 100, digits=2)) for (name, column) in zip(names(data), eachcol(data))]
    return missing_col_perc_list
end

missing_col_perc_list = dataMissingPercentage(bottle)
println("Porcentaje de missings por variable:")
for (name, missingc) in missing_col_perc_list
    println("$name: $missingc")
end

### 5. deleteColumns(threshold) : delete all the columns which have missing percent less more given threshold.
function deleteColumns(df, threshold)
    missing_percent = map(col -> count(ismissing, col) / length(col) * 100, eachcol(df))
    return df[:, missing_percent .< threshold]
end

bottle_threshold = deleteColumns(bottle,70)

# Comprobar con la funcion de Porcentaje de Missing
missing_col_perc_list = dataMissingPercentage(bottle_threshold)
println("Porcentaje de missings por variable:")
for (name, missingc) in missing_col_perc_list
    println("$name: $missingc")
end

dataShape(bottle_threshold)

### 6. calculateCorrelation() : creates correlation matrix between columns.
### calculateCorrelation() : creates correlation matrix between columns.
### With mean imputation 
function calculateCorrelation(data, impute_type)
    
    # Step 1: Select only numeric columns
    numeric_data = data#select(data, [name for (name, col) in zip(names(data), eachcol(data)) if eltype(col) <: Union{Missing, Real}])
    
    # Step 2: Handle missing values
    if impute_type==1
    #Drop rows with missing values
        numeric_data = dropmissing(numeric_data)
    
    elseif impute_type==2
    #Impute missing values (replace missing with column mean)
        for name in names(numeric_data)
            col = numeric_data[!, name]
            # Replace missing values with column mean
            numeric_data[!, name] = coalesce.(col, mean(skipmissing(col)))  # Using skipmissing to compute mean ignoring missing
        end 
    else 
        error("Error: Options for Impute_type are 1 or 2")
    end

    # Step 3: Compute the correlation matrix
    correlation_matrix = cor(Matrix(numeric_data))

    # Step 3: Convert the correlation matrix to a labeled DataFrame
    column_names = names(numeric_data)
    correlation_df = DataFrame(correlation_matrix, :auto)
    rename!(correlation_df, Symbol.(column_names))  # Set column names
    insertcols!(correlation_df, 1, :Column => column_names)  # Add row labels

    return correlation_matrix, correlation_df

end

correlation_matrix1, correlation_df1= calculateCorrelation(bottle_threshold,1)

### 7. displayCorrelation() : dislpay correlation using heatmap.
# Make sure the PlotlyJS backend is set
plotlyjs()
# Step 3: Create an interactive heatmap using PlotlyJS
heatmap(correlation_matrix1, 
        title="Interactive Correlation Matrix Heatmap", 
        xlabel="Columns", ylabel="Columns", 
        color=:RdBu,   # Color palette
        colorscale="Viridis",
        c=:auto,       # Automatically scale color axis
        colorrange=(-1, 1), # Correlation values range from -1 to 1
        xticks=(1:length(names(correlation_df1)), names(correlation_df1)),   # Set column names on x-axis
        yticks=(1:length(names(correlation_df1)), names(correlation_df1)),   # Set column names on y-axis
        hoverinfo="z",  # Show correlation value when hovering over the heatmap cells
        showscale=true,  # Display the color scale,
        xrot=45
    )

### 8. removeOutliersIQR() : using interquartile range delete all the outliers from the numerical columns.
function removeOutliersIQR(df::DataFrame)
    # Filtrar solo columnas que son Real o Union{Missing, Real}
    numeric_columns = [name for (name, col) in zip(names(df), eachcol(df)) if eltype(col) <: Union{Missing, Real}]
    rows_to_keep = trues(nrow(df))  # Inicializar un vector booleano con `true` para todas las filas
    
    for col in numeric_columns
        # Quitar valores faltantes para calcular los cuartiles
        col_data = skipmissing(df[!, col])
        Q1 = quantile(col_data, 0.25)
        Q3 = quantile(col_data, 0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR

        outliers = (df[!, col] .< lower_bound) .| (df[!, col] .> upper_bound)

        # Actualizar las filas a mantener (conservar valores dentro del rango o `missing`)
        rows_to_keep .&= .~outliers .| ismissing.(df[!, col])
        
    end
    
    return df[rows_to_keep, :]

end

bottle_Threshold_withoutOutliers = removeOutliersIQR(bottle_threshold)

# Comprobar con Shape antes y despues
# Antes
data_shape = dataShape(bottle_threshold)
println("dataShape Antes:", data_shape)

# Despues
data_shape = dataShape(bottle_Threshold_withoutOutliers)
println("dataShape Despues:", data_shape)

### 9. deleteRow(column): for a given column delete all the null data points.
### deleteRow(column): for a given column delete all the null data points.
function deleteRow(data, column)
    data_aux=copy(data)
    # Remove missing values from column A
    filter!(row -> ~ismissing(row[column]), data_aux)
    return data_aux
end

bottle_Threshold_withoutOutliers_TargetNotNull=deleteRow(bottle_Threshold_withoutOutliers,:T_degC)
nothing

### 10. filterColumnsByCorrelation(target,threshold, realtion) : delete all the columns on the basis of given threshold for a target column and relation .
function delete_columns_by_correlation(data::DataFrame, correlation_df::DataFrame, target_col::Symbol, threshold::Float64)
    
    # Step 1: Select only numeric columns
   #numeric_data = select(data, [name for (name, col) in zip(names(data), eachcol(data)) if eltype(col) <: Union{Missing, Real}])

   # Step 2: Extract correlations for the target column
   correlations_with_target = correlation_df[:, target_col] 

   # Step 3: Identify columns to keep based on the threshold
   keep_columns = [names(correlation_df)[i] for i in 1:length(correlations_with_target) if abs(correlations_with_target[i]) >= threshold]

   # Step 4: Retain only the selected columns in the original DataFrame
   #filtered_data=select(data, unique([target_col; keep_columns]))
   # Ensure all columns (including target_col) are symbols
   keep_columns = unique([target_col; Symbol.(keep_columns)])

   #Delete the column "Columns"
   # Remove all occurrences of value "Column"
   filter!(x -> x != Symbol(:Column), keep_columns)

   # Retain only the selected columns in the original DataFrame
   filtered_data = select(data, keep_columns)

   
   #return keep_columns
   return filtered_data
end

bottle_cleanData=delete_columns_by_correlation(bottle_Threshold_withoutOutliers_TargetNotNull, correlation_df1, :T_degC, 0.5)
nothing

### 11. describe() : it is used to describe data by giving following for each column

##Option 1:
describe(bottle_cleanData, :mean, :std, :eltype)

##Option 2
function describe_own(df)
    result = DataFrame(
        column=String[], min=Float64[], max=Float64[], mean=Float64[], median=Float64[], missing_count=Int[], std=Float64[] ,type=String[])
    for col in names(df)
        col_type = eltype(df[!, col]) <: Union{Missing, Real} ? "Numeric" : "Non-numeric"
        if col_type == "Numeric"
            col_data = skipmissing(df[!, col])
            push!(result, (
                col, 
                minimum(col_data), 
                maximum(col_data), 
                mean(col_data), 
                median(col_data), 
                count(ismissing, df[!, col]),
                std(col_data), 
                col_type
            ))
        else
            push!(result, (
                col, 
                NaN, 
                NaN, 
                NaN, 
                NaN, 
                count(ismissing, df[!, col]),
                NaN, 
                col_type
            ))
        end
    end
    
    return result
end

describe_own(bottle_cleanData)

### Remove constant columns (columns that have standard deviation of zero)
# Compute the standard deviation for all columns at once
stds = [std(skipmissing(bottle_cleanData[!, col])) for col in names(bottle_cleanData)]

# Filter out columns with zero standard deviation
bottle_cleanData_filtered= bottle_cleanData[:, stds .> 0]

dataShape(bottle_cleanData_filtered)

## Save the final df
### On the excercise 1 folder
CSV.write("/Users/marbazua/Documents/Diplomado/Mar_Bazua/exploratory_data_analysis/bazua_mar/dat/bottle_cleanData.csv", bottle_cleanData_filtered, delim=',', header=true )

### On the excercise 2 folder to be used for the linear regression
CSV.write("/Users/marbazua/Documents/Diplomado/Mar_Bazua/regression/bazua_mar/dat/bottle_cleanData.csv", bottle_cleanData_filtered, delim=',', header=true )
