using DataFrames, CSV, Statistics, Plots, StatsBase

################################################################################
#                             PROCESAMIENTO DE DATOS                            #
################################################################################

# 1. Lectura de los datos (bottle.csv)
bottle = CSV.read("../dat/bottle.csv", DataFrame, delim=',', header=true)


################################################################################
# 1. dataShape: Obtener la forma (número de filas y columnas) del DataFrame
################################################################################
function dataShape(data)
    data_shape = size(data)
    return data_shape
end

data_shape = dataShape(bottle)
println("Forma de los datos (dataShape): ", data_shape)


################################################################################
# 2. dataType: Obtener el tipo de dato de cada columna en el DataFrame
################################################################################
function dataType(data)
    column_types_list = [(name, eltype(column)) for (name, column) in zip(names(data), eachcol(data))]
    return column_types_list
end

column_types_list = dataType(bottle)
println("Nombres de columnas y sus tipos de datos:")
for (name, dtype) in column_types_list
    println("$name: $dtype")
end


################################################################################
# Codificación por frecuencia (Frequency Encoding)
# Convertiremos las columnas de tipo String a valores numéricos basados en su frecuencia
################################################################################
function frequency_encode!(df::DataFrame)
    for col in names(df)
        # Verificamos si la columna es de tipo String o Missing
        if eltype(df[!, col]) <: AbstractString || eltype(df[!, col]) == Union{Missing, String}
            # Extraemos los valores no faltantes y sus índices
            non_missing_values = df[!, col]
            non_missing_indices = findall(!ismissing, non_missing_values)

            # Obtenemos solo los valores no faltantes para calcular frecuencia
            non_missing_data = non_missing_values[non_missing_indices]

            # Calculamos la frecuencia de cada categoría
            freqs = combine(groupby(DataFrame(value=non_missing_data), :value), nrow => :freq)

            # Creamos un Diccionario para mapear valor -> frecuencia
            freq_dict = Dict(freqs.value .=> freqs.freq)

            # Copiamos la columna original para actualizarla
            encoded_column = copy(non_missing_values)

            # Reemplazamos cada valor no faltante con su frecuencia
            for i in non_missing_indices
                encoded_column[i] = string(get(freq_dict, non_missing_values[i], 0))
            end

            # Asignamos la columna codificada de vuelta al DataFrame
            df[!, col] .= encoded_column
        end
    end
    return df
end

# Aplicamos la codificación por frecuencia
bottle = frequency_encode!(bottle)

# Verifiquemos los tipos después de la codificación
column_types_list = dataType(bottle)
println("Nombres de columnas y sus tipos de datos (después de codificación):")
for (name, dtype) in column_types_list
    println("$name: $dtype")
end

# Convertimos las columnas de tipo String a valores enteros (Int64), manejando los missing
for col in names(bottle)
    if eltype(bottle[!, col]) <: AbstractString || eltype(bottle[!, col]) == Union{Missing, String}
        bottle[!, col] .= map(x -> ismissing(x) ? missing : parse(Int64, x), bottle[!, col])
    end
end

column_types_list = dataType(bottle)
println("Nombres de columnas y sus tipos de datos (después de convertir a Int64):")
for (name, dtype) in column_types_list
    println("$name: $dtype")
end


################################################################################
# 3. count_missing(col): Contar el número de datos faltantes en cada columna
################################################################################
function count_missing(data)
    missing_col_list = [(name, count(ismissing, column)) for (name, column) in zip(names(data), eachcol(data))]
    return missing_col_list
end

missing_col_list = count_missing(bottle)
println("Número de valores faltantes por variable:")
for (name, missingc) in missing_col_list
    println("$name: $missingc")
end


################################################################################
# 4. dataMissingPercentage(): Calcular el porcentaje de datos faltantes por columna
################################################################################
function dataMissingPercentage(data)
    missing_col_perc_list = [(name, round(count(ismissing, column) / length(column) * 100, digits=2)) 
                             for (name, column) in zip(names(data), eachcol(data))]
    return missing_col_perc_list
end

missing_col_perc_list = dataMissingPercentage(bottle)
println("Porcentaje de valores faltantes por variable:")
for (name, missingc) in missing_col_perc_list
    println("$name: $missingc")
end


################################################################################
# 5. deleteColumns(threshold): Eliminar columnas con porcentaje de Missing 
#    mayor o igual a un valor umbral
################################################################################
function deleteColumns(df, threshold)
    missing_percent = map(col -> count(ismissing, col) / length(col) * 100, eachcol(df))
    # Nos quedamos solo con columnas que tienen menos del 'threshold' de valores faltantes
    return df[:, missing_percent .< threshold]
end

# Eliminamos columnas con un threshold de 70% de datos faltantes
bottle_threshold = deleteColumns(bottle, 70)

# Verificamos nuevamente el porcentaje de faltantes luego de eliminar columnas
missing_col_perc_list = dataMissingPercentage(bottle_threshold)
println("Porcentaje de valores faltantes por variable (después de deleteColumns):")
for (name, missingc) in missing_col_perc_list
    println("$name: $missingc")
end

# Revisamos la forma del DataFrame
data_shape = dataShape(bottle_threshold)
println("Forma de los datos después de eliminar columnas con más del 70% de valores faltantes: ", data_shape)


################################################################################
# 6. calculateCorrelation(data, impute_type): 
#    - Crea una matriz de correlación entre columnas numéricas.
#    - Permite imputar valores faltantes de dos formas:
#        1. Eliminar filas con missing
#        2. Imputar con la media de la columna
################################################################################
function calculateCorrelation(data, impute_type)
    # Filtramos solo columnas numéricas; 
    # en este caso asumimos que todas son numéricas tras conversiones previas.
    numeric_data = data

    # Manejo de valores faltantes
    if impute_type == 1
        # 1. Eliminar filas con missing
        numeric_data = dropmissing(numeric_data)
    elseif impute_type == 2
        # 2. Imputar valores faltantes con la media
        for name in names(numeric_data)
            col = numeric_data[!, name]
            numeric_data[!, name] = coalesce.(col, mean(skipmissing(col)))
        end
    else
        error("Error: Las opciones para impute_type son 1 o 2")
    end

    # Calculamos la matriz de correlación
    correlation_matrix = cor(Matrix(numeric_data))

    # Convertimos la matriz a un DataFrame etiquetado
    column_names = names(numeric_data)
    correlation_df = DataFrame(correlation_matrix, :auto)
    rename!(correlation_df, Symbol.(column_names))
    insertcols!(correlation_df, 1, :Column => column_names)

    return correlation_matrix, correlation_df
end

# Obtenemos la matriz de correlación para el método 1 (eliminar filas con missing)
correlation_matrix1, correlation_df1 = calculateCorrelation(bottle_threshold, 1)


################################################################################
# 7. displayCorrelation(): Visualizar la correlación usando un heatmap
################################################################################
# Ajustamos el backend de PlotlyJS para Plots
plotlyjs()

# Graficamos un mapa de calor interactivo
# Construimos el heatmap y lo guardamos en una variable 'plt'
plt = heatmap(
    correlation_matrix1, 
    title="Matriz de Correlación Interactiva", 
    xlabel="Columnas", ylabel="Columnas", 
    color=:RdBu,            
    colorscale="Viridis",   
    c=:auto,                
    colorrange=(-1, 1),     
    xticks=(1:length(names(correlation_df1)), names(correlation_df1)),
    yticks=(1:length(names(correlation_df1)), names(correlation_df1)),
    hoverinfo="z",
    showscale=true,
    xrot=45
)  # Mostrar el gráfico
# Guardamos como PNG 
savefig(plt, "heatmap.png")

################################################################################
# 8. removeOutliersIQR(): Eliminar outliers en columnas numéricas usando IQR
################################################################################
function removeOutliersIQR(df::DataFrame)
    # Filtramos solo columnas numéricas (Real o Union{Missing, Real})
    numeric_columns = [name for (name, col) in zip(names(df), eachcol(df)) if eltype(col) <: Union{Missing, Real}]
    rows_to_keep = trues(nrow(df))  # Vector booleano para mantener filas válidas
    
    for col in numeric_columns
        col_data = skipmissing(df[!, col])
        Q1 = quantile(col_data, 0.25)
        Q3 = quantile(col_data, 0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR

        outliers = (df[!, col] .< lower_bound) .| (df[!, col] .> upper_bound)

        # Mantener los valores dentro del rango o que sean missing
        rows_to_keep .&= .~outliers .| ismissing.(df[!, col])
    end
    
    return df[rows_to_keep, :]
end

bottle_Threshold_withoutOutliers = removeOutliersIQR(bottle_threshold)

# Comprobamos la forma antes y después de eliminar outliers
println("Forma de los datos antes de eliminar outliers:", dataShape(bottle_threshold))
println("Forma de los datos después de eliminar outliers:", dataShape(bottle_Threshold_withoutOutliers))


################################################################################
# 9. deleteRow(data, column): Eliminar filas con valores faltantes para una 
#    columna específica
################################################################################
function deleteRow(data, column)
    data_aux = copy(data)
    # Eliminamos filas con missing en la columna indicada
    filter!(row -> ~ismissing(row[column]), data_aux)
    return data_aux
end

bottle_Threshold_withoutOutliers_TargetNotNull = deleteRow(bottle_Threshold_withoutOutliers, :T_degC)



################################################################################
# 10. delete_columns_by_correlation(data, correlation_df, target_col, threshold):
#     Eliminar columnas basadas en su correlación con una columna objetivo
################################################################################
function delete_columns_by_correlation(data::DataFrame, 
                                       correlation_df::DataFrame, 
                                       target_col::Symbol, 
                                       threshold::Float64)
    
    # Extraemos la columna de correlaciones con el target
    correlations_with_target = correlation_df[:, target_col]

    # Identificamos las columnas que cumplen con el umbral
    keep_columns = [names(correlation_df)[i] for i in 1:length(correlations_with_target) 
                    if abs(correlations_with_target[i]) >= threshold]

    # Aseguramos que la columna objetivo esté en la lista de columnas a mantener
    keep_columns = unique([target_col; Symbol.(keep_columns)])

    # Eliminamos "Column" de la lista (esa columna es sólo para etiquetas en la matriz de correlación)
    filter!(x -> x != Symbol(:Column), keep_columns)

    # Retenemos solo las columnas seleccionadas en el DataFrame original
    filtered_data = select(data, keep_columns)

    return filtered_data
end

# Eliminamos las columnas con correlación menor a 0.5 con la columna :T_degC
bottle_cleanData = delete_columns_by_correlation(
    bottle_Threshold_withoutOutliers_TargetNotNull, 
    correlation_df1, 
    :T_degC, 
    0.5
)



################################################################################
# 11. describe(): Describir el DataFrame
################################################################################

# Opción 1: Utilizando la función describe de Julia
describe(bottle_cleanData, :mean, :std, :eltype)

################################################################################
# 12. Eliminación de columnas constantes (std = 0)
################################################################################
stds = [std(skipmissing(bottle_cleanData[!, col])) for col in names(bottle_cleanData)]
bottle_cleanData_filtered = bottle_cleanData[:, stds .> 0]

# Comprobamos la forma final de los datos
final_shape = dataShape(bottle_cleanData_filtered)
println("Forma de los datos finales (sin columnas constantes): ", final_shape)


################################################################################
# 13. Guardar el DataFrame final en CSV
#     Se guarda en la carpeta '../dat/'
################################################################################
CSV.write("../dat/bottle_cleanData.csv", bottle_cleanData_filtered, delim=',', header=true)
