# Procesamiento y Limpieza de Datos con Julia
Este repositorio contiene un script en Julia para el procesamiento y limpieza de datos a partir de un archivo CSV denominado bottle.csv. El script realiza distintas funciones y transformaciones, desde la lectura de datos hasta la exportación de resultados finales a un archivo bottle_cleanData.csv.

## Contenido
Pasos Realizados
1. Lectura de Datos
El archivo bottle.csv fue cargado como un DataFrame utilizando la librería CSV.

2. Forma del DataFrame
Se determinó la forma inicial de los datos (número de filas y columnas):
Resultado: n_filas x n_columnas.

3. Tipos de Datos por Columna
Se identificaron los tipos de datos de cada columna. Esto permitió verificar las variables categóricas y numéricas.

4. Codificación por Frecuencia
Las columnas categóricas se codificaron utilizando la frecuencia de sus valores. Esto transformó las categorías en valores numéricos basados en su frecuencia relativa.

5. Manejo de Valores Faltantes
Conteo de Valores Faltantes: Se calculó el número y porcentaje de valores faltantes por columna.
Eliminación de Columnas: Se eliminaron columnas con más del 70% de valores faltantes.
6. Matriz de Correlación
Se calculó una matriz de correlación para las columnas numéricas:

Método de Imputación: Se eliminaron filas con valores faltantes.
Visualización: La matriz se representó como un mapa de calor interactivo y se guardó como un archivo PNG.
7. Eliminación de Outliers
Se eliminaron los outliers utilizando el rango intercuartílico (IQR). Esto permitió mantener únicamente los valores dentro de un rango válido.

8. Selección de Filas con Datos Completos
Se eliminaron filas con valores faltantes en la columna objetivo (:T_degC).

9. Selección de Columnas Basada en Correlación
Se retuvieron únicamente las columnas con una correlación absoluta mayor a 0.5 respecto a la columna objetivo (:T_degC).

10. Descripción de los Datos
Se utilizó la función describe() para obtener estadísticas descriptivas (media, desviación estándar, tipo de dato) de las columnas restantes.

11. Eliminación de Columnas Constantes
Se eliminaron columnas con desviación estándar igual a 0, ya que no aportan información útil al análisis.

12. Guardado de Datos Limpios
El DataFrame final, filtrado y limpio, se guardó en un archivo CSV en la carpeta ../dat/.