# Data Analysis Report

## **Overview**
This script performs a comprehensive data preprocessing and analysis pipeline on the `bottle.csv` dataset. The key objectives are to clean the data, remove unnecessary columns, and extract meaningful insights using descriptive and exploratory data analysis techniques.

## **Steps and Methodology**

### 1. **Data Loading**
The dataset is loaded using the `CSV.read` function from the `CSV` package and stored in a `DataFrame`. The initial dimensions of the dataset are displayed to understand the scale of the data.

### 2. **Column Types**
The data types for all columns are extracted and displayed using a custom function `printDictPretty`. This ensures a clear understanding of the dataset's structure, especially distinguishing numerical from non-numerical columns.

### 3. **Missing Values Analysis**
A function `dataMissingPercentage` calculates the percentage of missing values for each column. Columns with more than 30% missing data are dropped using a threshold (`thresh_missingPct = 30.0`). This threshold is selected to retain a balance between data quality and the number of features preserved for analysis.

#### **Why 30% as a Threshold?**
Columns with over 30% missing data likely contribute little to the analysis and can introduce bias or instability in models. Retaining columns with less missing data ensures the dataset remains rich and diverse. However, we only consider columns without missing data for the correlation analysis. 

### 4. **Correlation Analysis**
A function `calculateCorrelation` computes a Pearson correlation matrix for all numeric columns. This involves:
- Dropping rows with missing values (as correlation calculations cannot handle `missing` values).
- Creating a heatmap to visually represent correlations between columns. The heatmap is saved as `fig/heatmap.png`.

#### **Visualization**
The correlation heatmap uses a gradient color scheme (`:RdBu`) to distinguish positive and negative correlations, with a range between -1 and 1.

### 5. **Outlier Removal**
Outliers in numeric columns are identified and removed using the **Interquartile Range (IQR)** method:
- Outliers are defined as values outside the range `[Q1 - 1.5 * IQR, Q3 + 1.5 * IQR]`.
- This ensures that the data is free of extreme values that may skew analyses.

### 6. **Handling Missing Rows**
Rows with missing values in the target column `Depthm` are dropped using the `deleteRow!` function. The target column is crucial for subsequent steps and must not contain missing data.

### 7. **Column Filtering by Correlation**
The `filterColumnsByCorrelation!` function removes columns that have a high absolute correlation (`> 0.9`) with the target column `Depthm`. This reduces multicollinearity, ensuring that the analysis focuses on unique and independent variables.

#### **Why Use `Depthm` as the Target?**
`Depthm` represents depth measurements, which are likely a key variable influencing other features in the dataset. Selecting it as the target allows for focused analysis and reduces redundancy.

#### **Why Use 0.9 as a Threshold?**
Columns with correlations greater than 0.9 are highly collinear and do not provide additional information. By removing these columns, we simplify the dataset without losing valuable insights.

### 8. **Statistical Description**
A summary of the dataset is generated using `describe`, providing key statistics such as mean, standard deviation, and range for each column.

## **Key Insights**
1. **Missing Data Management:**
   - Columns with >30% missing data were removed, reducing noise and improving data quality.
   - Rows with missing values in `Depthm` were also dropped, preserving the target's integrity.

2. **Correlation Analysis:**
   - The heatmap reveals strong relationships between several variables.
   - Highly correlated columns (|correlation| > 0.9) with `Depthm` were dropped, simplifying the dataset.

3. **Outlier Handling:**
   - Outliers in numerical data were removed, reducing variability caused by extreme values.

4. **Target Column:**
   - `Depthm` was selected as the target due to its relevance in understanding other variables' relationships.

## **Conclusion**
This script effectively preprocesses the dataset by addressing missing values, outliers, and multicollinearity. The threshold values used (30% for missing data and 0.9 for correlation) were chosen to strike a balance between data retention and quality. The cleaned dataset is now ready for further analysis or modeling tasks.
