using DataFrames
using CSV
using Statistics
using StatsBase
using Plots
using StatsPlots

function printDictPretty(d::Dict)
    for (key, value) in d
        println("""    "$key" => $value,""")
    end
end

function printCorrelationMatrixPretty(cols::Vector{String}, corr_matrix::Matrix{Float64})
    println("Correlation Matrix:")
    header = "       " * join(cols, "  ")
    println(header)
    for (i, row) in enumerate(eachrow(corr_matrix))
        row_str = join([string(round(x, digits=3)) for x in row], "  ")
        println(rpad(cols[i], 8, ' ') * row_str)
    end
end

function printNewSection()
    println()
    println("-------------------------------------------------------------------")    
    println()
end

# Load data
df = CSV.read("dat/bottle.csv", DataFrame)
printNewSection()

# Get the number of rows and columns
println("Dataset dimensions: ", size(df))
printNewSection()

# Get each DataFrame column type
println("Dataset column types:")
eltypes = Dict(col => eltype(df[!, col]) for col in names(df))
printDictPretty(eltypes)
printNewSection()

# Count the number of missing data in a given column
count_missing(col::AbstractVector) = count(ismissing, col)
# Try the function on "Depthm" column 
println("Count of missing values in 'Depthm' column: ", count_missing(df.Depthm))
printNewSection()

# Function that finds the percentage of missing values for each column
function dataMissingPercentage(df::DataFrame)
    total_rows = nrow(df)
    percs = Dict()
    for c in names(df)
        miss = count_missing(df[!, c])
        percs[c] = (miss / total_rows) * 100
    end
    return percs
end
# Display the missing percentages by column
println("Percentage of missing values in all columns:")
printDictPretty(dataMissingPercentage(df))
printNewSection()

# Function that deletes all columns where the missing percentage exceeds the given threshold
function deleteColumns!(df::DataFrame, threshold::Float64)
    percs = dataMissingPercentage(df)
    cols_to_keep = [c for c in names(df) if percs[c] ≤ threshold]
    return df[:, cols_to_keep]
end
# Setting the threshold to keep columns that have less than 15% missing data
thresh_missingPct = 15.0
println("Missing percentage threshold: ", thresh_missingPct, "%")
prev_shape = size(df)[2]
df = deleteColumns!(df, thresh_missingPct)
current_shape = size(df)[2]
println("Columns before missing percentage threshold: ", prev_shape)
println("Columns after missing percentage threshold: ", current_shape)
println("Columns dropped: ", prev_shape - current_shape)
println("Current column names:")
# Printing the names of the columns that survived the missing value threshold condition
println(names(df))
printNewSection()

# Function that calculates correlation between numeric-like columns
# This function drops rows with missing data before correlation because correlation cannot handle missing values
function calculateCorrelation(df::DataFrame)
    numeric_cols = [c for c in names(df) if eltype(df[!, c]) <: Number]
    numeric_df = df[:, numeric_cols]
    dropped_df = dropmissing(numeric_df)
    mat = Matrix(dropped_df)
    corr_matrix = cor(mat, dims=1) # Pearson correlation by default
    return numeric_cols, corr_matrix
end
# Display the correlation as a matrix
cols, corr_matrix = calculateCorrelation(df)
printCorrelationMatrixPretty(cols, corr_matrix)
printNewSection()

# Function that displays the matrix with a heatmap
function displayCorrelation(cols::Vector{String}, corr_matrix::Matrix{Float64})
    heatmap(
        cols, cols, corr_matrix,
        title="Correlation Heatmap",
        color=:bluesreds,   # Gradient colors
        c=:RdBu,            # Color palette
        clim=(-1, 1)        # Value range limits
    )

    savefig("fig/heatmap.png")

end
# Heatmap displayed
displayCorrelation(cols, corr_matrix)

# Remove values considered outliers that meet the following criteria: if value < Q1 - 1.5*IQR or value > Q3 + 1.5*IQR.
function removeOutliersIQR!(df::DataFrame)
    numeric_cols = [c for c in names(df) if eltype(df[!, c]) <: Number]
    for c in numeric_cols
        col_data = skipmissing(df[!, c])
        q1 = quantile(col_data, 0.25)
        q3 = quantile(col_data, 0.75)
        iqr = q3 - q1
        lower_bound = q1 - 1.5*iqr
        upper_bound = q3 + 1.5*iqr
        df = df[(df[!, c] .≥ lower_bound) .& (df[!, c] .≤ upper_bound) .| (ismissing.(df[!, c])), :]
    end
    return df
end
# Remove outliers
prev_shape = size(df)[1]
df = removeOutliersIQR!(df)
current_shape = size(df)[1]
println("Data with outliers: ", prev_shape)
println("Data without outliers: ", current_shape)
println("Data dropped: ", prev_shape - current_shape)
printNewSection()

# Function that deletes all rows with missing values in a specific column
function deleteRow!(df::DataFrame, colname::Symbol)
    return df[.!ismissing.(df[!, colname]), :]
end
# Drop all values in the column 'Depthm'
prev_shape = size(df)[1]
df = deleteRow!(df, :Depthm)
current_shape = size(df)[1]
println("Data with missing values: ", prev_shape)
println("Data without missing values: ", current_shape)
println("Data dropped: ", prev_shape - current_shape)
printNewSection()

# Function that drops all columns that do not meet a threshold value for the correlation between all columns in the DataFrame and a target column
function filterColumnsByCorrelation!(df::DataFrame, target::String, threshold::Float64, relation::String)
    if !(target in names(df))
        error("Target column $target not found in DataFrame.")
    end

    numeric_cols = [c for c in names(df) if eltype(df[!, c]) <: Number && c != target]
    complete_rows = .!ismissing.(df[!, target])
    for c in numeric_cols
        complete_rows .&= .!ismissing.(df[!, c])
    end
    
    filtered_df = df[complete_rows, [target; numeric_cols]]
    mat = Matrix(filtered_df)
    target_data = mat[:, 1]
    
    corr_values = Dict()
    for (i, c) in enumerate(numeric_cols)
        col_data = mat[:, i + 1]
        corr_val = cor(target_data, col_data)
        corr_values[c] = corr_val
    end

    if relation == "greater"
        cols_to_keep = [c for c in names(df) if c == target || !(c in numeric_cols) || abs(corr_values[c]) < threshold]
    elseif relation == "less"
        cols_to_keep = [c for c in names(df) if c == target || !(c in numeric_cols) || abs(corr_values[c]) > threshold]
    else
        error("Relation must be 'greater' or 'less'.")
    end

    return df[:, cols_to_keep]
end
# Setting 'Depthm' as the target value
prev_shape = size(df)[2]
df = filterColumnsByCorrelation!(df, "Depthm", 0.9, "greater")
current_shape = size(df)[2]
println("Columns in the DataFrame: ", prev_shape)
println("Columns that meet the correlation condition: ", current_shape)
println("Columns dropped: ", prev_shape - current_shape)
printNewSection()

# Statistical description of the Dataset
print(describe(df))
