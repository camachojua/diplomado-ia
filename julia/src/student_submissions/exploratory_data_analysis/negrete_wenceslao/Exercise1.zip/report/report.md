# Exploratory Data Analysis Report
================================

## 1. Data Shape
The dataset contains 864,863 rows and 74 columns.

## 2. Data Types
Notable variable types include:
- Numeric measurements (Float64): Temperature, Salinity, Oxygen, etc.
- Quality indicators (Int64): Various quality flags
- Identifiers (String): Station IDs, Depth IDs
- Many variables allow for missing values (Union{Missing, Float64/Int64})

## 3. Missing Data Percentages
Key findings on missing data:
- Variables with no missing data (0%):
  - Cst_Cnt
  - Sta_ID
  - Depth_ID
  - Depthm
  - RecInd
  - R_Depth
  - R_PRES
  - Btl_Cnt

- Variables with high missing percentages:
  - pH2: 100.0%
  - pH1: 99.99%
  - DIC Quality Comment: 99.99%
  - TA2: 99.97%
  - DIC2: 99.97%
  - DIC1: 99.77%
  - TA1: 99.76%

## 4. Data Description
Key statistics for main variables:

- T_degC (Temperature):
  - Mean: 10.80°C
  - Range: 1.44°C to 31.14°C
  - Missing: 10,963 values

- Salnty (Salinity):
  - Mean: 33.84
  - Range: 28.431 to 37.034
  - Missing: 47,354 values

## 5. Data Cleaning Results
Outlier removal using the IQR method:
- Original dataset: 864,863 rows
- After outlier removal: 790,980 rows
- Removed outliers: 73,883 rows (8.54% of original data)

## Correlation Analysis
The relationships between variables are visualized in the correlation heatmap:

![Correlation Heatmap](../fig/correlation_heatmap.png)
