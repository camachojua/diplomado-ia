# Install dependencies
using Pkg
Pkg.add("DataFrames")
Pkg.add("CSV")
Pkg.add("Plots")
Pkg.add("StatsBase")

# Initialize script
using DataFrames
using CSV
using Statistics
using Plots
using StatsBase
using Plots.PlotMeasures

# Read the data
df = CSV.read("dat/bottle.csv", DataFrame)

# Function to get shape of the data
function dataShape(df::DataFrame)
    return size(df)
end

# Function to get data type of each column
function dataType(df::DataFrame)
    return Dict(names(df) .=> eltype.(eachcol(df)))
end

# Function to count missing values in a column
function count_missing(col)
    return sum(ismissing.(col))
end

# Function to find missing percentage of each column
function dataMissingPercentage(df::DataFrame)
    n_rows = nrow(df)
    missing_percentages = Dict{String, Float64}()
    
    for col in names(df)
        missing_count = count_missing(df[!, col])
        missing_percentages[col] = (missing_count / n_rows) * 100
    end
    
    return missing_percentages
end

# Function to delete columns based on missing percentage threshold
function deleteColumns(df::DataFrame, threshold::Float64)
    missing_percentages = dataMissingPercentage(df)
    cols_to_keep = [col for (col, pct) in missing_percentages if pct <= threshold]
    return df[!, cols_to_keep]
end

# Function to calculate correlation matrix
function calculateCorrelation(df::DataFrame)
    # Select only numeric columns
    numeric_cols = names(df)[eltype.(eachcol(df)) .<: Union{Missing, Number}]
    numeric_df = df[!, numeric_cols]
    
    # Drop missing values
    complete_df = dropmissing(numeric_df)
    
    # Calculate correlation matrix
    cor_matrix = cor(Matrix(complete_df))
    return cor_matrix, numeric_cols
end

# Function to display correlation heatmap
function displayCorrelation(df::DataFrame)
    cor_matrix, col_names = calculateCorrelation(df)
    
    # Create heatmap
    heatmap(cor_matrix,
            xticks=(1:length(col_names), col_names),
            yticks=(1:length(col_names), col_names),
            xrotation=90,
            size=(800, 600),
            margin=20mm,
            aspect_ratio=:equal,
            color=:viridis,
            title="Correlation Heatmap")
end

# Function to remove outliers using IQR method
function removeOutliersIQR(df::DataFrame)
    df_clean = copy(df)
    numeric_cols = names(df)[eltype.(eachcol(df)) .<: Union{Missing, Number}]
    
    for col in numeric_cols
        # Skip if column has missing values
        if any(ismissing.(df_clean[!, col]))
            continue
        end
        
        q1 = quantile(df_clean[!, col], 0.25)
        q3 = quantile(df_clean[!, col], 0.75)
        iqr = q3 - q1
        lower_bound = q1 - 1.5 * iqr
        upper_bound = q3 + 1.5 * iqr
        
        df_clean = df_clean[.!((df_clean[!, col] .< lower_bound) .| (df_clean[!, col] .> upper_bound)), :]
    end
    
    return df_clean
end

# Function to delete rows with null values in a specific column
function deleteRow(df::DataFrame, column::String)
    return dropmissing(df, column)
end

# Function to filter columns based on correlation with target
function filterColumnsByCorrelation(df::DataFrame, target::String, threshold::Float64, relation::String)
    cor_matrix, col_names = calculateCorrelation(df)
    target_idx = findfirst(==(target), col_names)
    
    if target_idx === nothing
        error("Target column not found in numeric columns")
    end
    
    correlations = cor_matrix[target_idx, :]
    
    if relation == "greater"
        cols_to_keep = col_names[abs.(correlations) .>= threshold]
    elseif relation == "less"
        cols_to_keep = col_names[abs.(correlations) .<= threshold]
    else
        error("Invalid relation. Use 'greater' or 'less'")
    end
    
    return df[!, cols_to_keep]
end

# Generate report
println("Exploratory Data Analysis Report")
println("================================\n")

println("1. Data Shape:")
println(dataShape(df))
println("\n2. Data Types:")
for (col, type) in dataType(df)
    println("$col: $type")
end

println("\n3. Missing Data Percentages:")
for (col, pct) in dataMissingPercentage(df)
    println("$col: $(round(pct, digits=2))%")
end

# Save correlation heatmap
displayCorrelation(df)
savefig("fig/correlation_heatmap.png")

println("\n4. Data Description:")
println(describe(df))

# Clean data example
println("\n5. Data Cleaning Example:")
println("Original rows: $(nrow(df))")
clean_df = removeOutliersIQR(df)
println("Rows after removing outliers: $(nrow(clean_df))")
