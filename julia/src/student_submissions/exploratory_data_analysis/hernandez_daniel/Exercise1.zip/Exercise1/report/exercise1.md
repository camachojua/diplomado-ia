# Reporte de ejercicio 1
Hernández Vela Daniel

Para comenzar se descarga previamente el dataset, este se localizará en el directorio Exercise1/dat/bottle.csv listo para usarse.

Para leer el archivo .csv se utiliza la función `CSV.read()` de la siguiente manera:

```julia
calcofi_bottle = CSV.read("calcofi/bottle.csv", DataFrame)
```

Así, se obtiene un DataFrame con el que se trabajará.

A continuación se describen las funciones creadas para realizr el EDA:

## `dataShape`

```julia
function dataShape(df::DataFrame)
    shape = size(df)
    return "$(shape[1]) rows, $(shape[2]) columns"
end
```

Mediante la función `size()` es posible obtener las filas y las columnas del DataFrame, entonces, la función `dataShape()` devuelve una cadena que muestra estos datos.

## `dataType`

```julia
function dataType(df::DataFrame)
    for name in (names(df))
        println("Column: $name, Type: $(eltype(df[!, name]))")
    end
end
```

Se obtiene un arreglo que contiene los nombres de todas las columnas del DataFrame, luego, se itera sobre este arreglo utilizando la función `eltype()`para obtener el tipo de cada una de las columnas. Para cada columna se imprime su nombre y su tipo.

## `countMissing`

```julia
function countColMissing(df::DataFrame, col::String)
    col in names(df) && return count(ismissing, df[! , col])
    error("Column not in dataframe")
end
```

Función auxiliar. Se pasa como parámetro el nombre de una columna, cuando esta no existe en el DataFrame se obtiene un error, en el caso contrario, se utiliza la función `count()` aplicando `ismissing()` sobre la columna indicada, se devuelve un entero que indica todos los elementos de tipo Missing en la columna.

```julia
function countMissing(df::DataFrame)
    for name in names(df)
        bad_cols = countColMissing(df, name)
        println("$bad_cols missing in column $name")
    end
end
```

Hace uso de la función auxiliar `countColMissing` iterando sobre todas las columnas del DataFrame,así mostrando la cantidad de elementos marcados como Missing en cada columna.

## `dataMissingPercentage`

```julia
function colMissingPercentage(df::DataFrame, col::String)
    col in names(df) && return count(ismissing, df[! , col]) / nrow(df) * 100
    error("Column not in dataframe")
end
```

Función auxiliar. Se pasa como parámetro el nombre de una columna, cuando esta no existe en el DataFrame se obtiene un error, en el caso contrario, se utiliza la función `count()` aplicando `ismissing()` sobre la columna indicada, para luego dividirlo entre el número total de elementos, se devuelve un número que indica el porcentaje de Missing en la columna.

```julia
function dataMissingPercentage(df::DataFrame)
    for name in names(df)
        bad_cols = colMissingPercentage(df, name)
        println("$bad_cols% missing in column $name")
    end
end
```
Hace uso de la función auxiliar `colMissingPercentage` iterando sobre todas las columnas del DataFrame,así mostrando el porcentaje de elementos marcados como Missing en cada columna.

## `deleteColumns`

```julia
function deleteColumns(df::DataFrame, threshold::Number)
    return df[:, [col for col in names(df) if (colMissingPercentage(df, col) <= threshold)]]
end
```

Se pasa como parámetro un límite permitido para el porcentaje que una columna puede tener de Missing, se construye y devuelve un nuevo dataframe que filtra todas las columnas que superen el límite permitido.

## `calculateCorrelation`

```julia
function calculateCorrelation(df::DataFrame)
    numeric_cols = [col for col in names(df) if eltype(df[!, col]) <: Number]
    numeric_data = Matrix(df[:, numeric_cols])
    correlation_matrix = cor(numeric_data)
    return correlation_matrix
end
```
Calcula la matriz de correlación de las columnas numéricas del DataFrame filtrando aquellas que no son de tipo `Number`, convirtiendo el DataFrame resultante en matriz y utilizando la función `cor()`, se devuelve la matriz resultante.

## `displayCorrelation`

```julia
function displayCorrelation(matrix::Matrix)
    heatmap(matrix, title="Correlation Matrix", size=(400, 400))
end
```

Hace uso de la función `heatmap()` proporcionada por el paquete Plots, la cual toma como parámetro la matriz devuelta por la función `calculateCorrelation()`.

## `removeOutliersIQR`

```julia
function removeOutliersIQR(df::DataFrame)
    numeric_cols = [col for col in names(df) if eltype(df[!, col]) <: Number]
    
    for col in numeric_cols
        Q1 = quantile(df[!, col], 0.25)
        Q3 = quantile(df[!, col], 0.75)
        IQR = Q3 - Q1
        
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        
        df = df[(df[!, col] .>= lower_bound) .& (df[!, col] .<= upper_bound), :]
    end
    
    return df
end
```
Elimina los valores atípicos del DataFrame utilizando el método del rango intercuartílico (IQR). A continuación se describe el proceso paso a paso:

- Identificación de columnas numéricas: Se crea una lista numeric_cols que contiene los nombres de las columnas cuyo tipo de elemento (eltype) es un subtipo de Number.
- Cálculo del IQR y eliminación de valores atípicos: Para cada columna numérica, se calculan el primer cuartil (Q1) y el tercer cuartil (Q3).
- Se calcula el rango IQR como la diferencia entre Q3 y Q1.
- Se determinan los límites inferior (lower_bound) y superior (upper_bound) para identificar los valores atípicos.
- Se filtran las filas del DataFrame que tienen valores dentro de los límites establecidos.
Finalmente se devuelve un DataFrame sin los valores atípicos.

## `deleteRow`

```julia
function deleteRow(df::DataFrame, col::String)
    df = df[.!ismissing.(df[!, col]), :]
    return df
end
```

Devuelve un nuevo DataFrame el cual elimina todas las filas que contengan algun Missing.

## `FilterColumnsByCorrelation`

```julia
function filterColumnsByCorrelation(df::DataFrame, target::String, threshold::Number, relation::Symbol)
    # Verificar que la columna objetivo sea numérica
    if !(eltype(df[!, target]) <: Number)
        error("La columna objetivo debe ser numérica")
    end
    
    # Calcular las correlaciones de las columnas numéricas con la columna objetivo
    numeric_cols = [col for col in names(df) if eltype(df[!, col]) <: Number]
    correlations = Dict{String, Number}()
    
    for col in numeric_cols
        if col != target
            correlations[col] = cor(df[!, target], df[!, col])
        end
    end
    
    # Filtrar las columnas según la relación y el umbral
    if relation == :greater
        cols_to_keep = [target; [col for col in keys(correlations) if correlations[col] > threshold]]
    elseif relation == :less
        cols_to_keep = [target; [col for col in keys(correlations) if correlations[col] < threshold]]
    else
        error("La relación debe ser :greater o :less")
    end
    
    return df[:, cols_to_keep]
end
```
Filtra las columnas del DataFrame en función de su correlación con una columna objetivo. A continuación se describe el proceso paso a paso:

- Se verifica que la columna objetivo sea numérica. Si no lo es, se lanza un error.
- Se identifican las columnas numéricas del DataFrame.
- Se calcula la correlación de cada columna numérica con la columna objetivo, excluyendo la columna objetivo en sí.
- Si la relación es mayor, se seleccionan las columnas cuya correlación con la columna objetivo es mayor que el límite permitido.
- Si la relación es menor, se seleccionan las columnas cuya correlación con la columna objetivo es menor que el límite permitido.
Finalmente se devuelve un DataFrame que contiene solo la columna objetivo y las columnas que cumplen con el criterio de correlación.

