using CSV, DataFrames, Flux, Statistics, Random, CUDA, Plots, GLM, MLBase

# Cargar y preparar datos
df = CSV.read("../dat/Churn_Modelling.csv", DataFrame)

# Asegurarse de que los valores sean de tipo String antes de realizar el reemplazo
df.Gender = string.(df.Gender)  # Convertir todos los elementos de la columna Gender a String
df.Geography = string.(df.Geography)  # Convertir todos los elementos de la columna Geography a String

# One Hot Encoding para 'Gender' y 'Geography'
replace!(df.Gender, "Female" => "1")
replace!(df.Gender, "Male" => "0")
replace!(df.Geography, "France" => "2")
replace!(df.Geography, "Germany" => "1")
replace!(df.Geography, "Spain" => "0")

# Convertir a tipo numérico (Int) después de la codificación
df.Gender = parse.(Int, df.Gender)
df.Geography = parse.(Int, df.Geography)

# Eliminar columnas innecesarias
select!(df, Not([:RowNumber, :CustomerId, :Surname]))

# Preparar datos para Flux
function prepare_data(df)
    X = Matrix(df[:, 1:end-1])' .|> Float32  # Transponer para tener las características en filas
    y = Vector(df[:, end]) .|> Float32  # Objetivo
    return (X .- mean(X, dims=2)) ./ std(X, dims=2), y
end

X, y = prepare_data(df)

# Dividir datos en entrenamiento y prueba
train_indices = Random.shuffle(1:size(X, 2))[1:floor(Int, 0.8 * size(X, 2))]
test_indices = setdiff(1:size(X, 2), train_indices)
X_train, y_train = X[:, train_indices], y[train_indices]
X_test, y_test = X[:, test_indices], y[test_indices]

# Modelo y función de pérdida
model = Chain(Dense(size(X', 2) => 20, relu), Dense(20 => 1, σ)) |> gpu

function loss_fn(x, y)
    ŷ = model(x)
    weights = [mean(y .== 0), mean(y .== 1)]
    sample_weights = [weights[Int(yi) + 1] for yi in y]
    return mean(Flux.logitbinarycrossentropy(vec(ŷ), y) .* sample_weights)
end

# Entrenamiento sin @showprogress
function train_model!(model, X, y; epochs=1000, batch_size=32)
    loader = Flux.DataLoader((X, y) |> gpu, batchsize=batch_size, shuffle=true)
    optim = Flux.setup(Flux.Adam(0.0005), model)
    losses = []
    
    for epoch in 1:epochs
        for (x, y) in loader
            loss, grads = Flux.withgradient(model) do m
                Flux.logitbinarycrossentropy(vec(m(x)), y)
            end
            Flux.update!(optim, model, grads[1])
            push!(losses, loss)
        end
    end
    return losses
end

losses = train_model!(model, X_train, y_train)

# Predicciones y métricas
function predict_flux(model, X; threshold=0.5)
    probs = model(X |> gpu) |> cpu
    return probs, (probs .>= threshold)[1, :] .|> Bool
end

# Función para calcular la matriz de confusión
function confusion_matrix(y_true, y_pred)
    # Convertir a valores booleanos si no están ya en ese formato
    y_true = y_true .|> Bool
    y_pred = y_pred .|> Bool

    # Calcular los valores de la matriz de confusión
    tp = sum(y_pred .& y_true)  # Verdaderos positivos
    tn = sum(.!y_pred .& .!y_true)  # Verdaderos negativos
    fp = sum(y_pred .& .!y_true)  # Falsos positivos
    fn = sum(.!y_pred .& y_true)  # Falsos negativos

    # Calcular métricas de evaluación
    accuracy = (tp + tn) / (tp + tn + fp + fn)
    
    # Crear la matriz de confusión
    conf_matrix = [
        "TP: $tp" "FN: $fn";
        "FP: $fp" "TN: $tn"
    ]
    
    return Dict(
        "confusion_matrix" => conf_matrix,
        "accuracy" => accuracy,
        "raw_counts" => (tp=tp, tn=tn, fp=fp, fn=fn)
    )
end


y_probs, y_pred = predict_flux(model, X_test)
metrics = confusion_matrix(y_test, y_pred)
println("Confusion Matrix:", metrics["confusion_matrix"])
println("Accuracy: $(round(metrics["accuracy"], digits=4))")

# Curva ROC
function plot_roc(y_true, y_probs, savepath)
    sorted_indices = sortperm(vec(y_probs), rev=true)
    tpr, fpr = Float64[], Float64[]
    tp, fp = 0, 0
    push!(tpr, 0.0)
    push!(fpr, 0.0)
    for i in 1:length(y_true)
        if y_true[sorted_indices[i]] == 1
            tp += 1
        else
            fp += 1
        end
        push!(tpr, tp / sum(y_true .== 1))
        push!(fpr, fp / sum(y_true .== 0))
    end
    auc = sum((tpr[2:end] + tpr[1:end-1]) .* (fpr[2:end] - fpr[1:end-1])) / 2
    p = Plots.plot(fpr, tpr, label="ROC Curve (AUC = $(round(auc, digits=3)))")
    savefig(p, savepath)  # Guardar el gráfico en la carpeta ../fig
end

plot_roc(y_test, y_probs, "../fig/roc_curve_flux.png")

# GLM - Ajuste y evaluación
df = CSV.read("../dat/Churn_Modelling.csv", DataFrame)
replace!(df.Gender, "Female" => "1")
replace!(df.Gender, "Male" => "0")
replace!(df.Geography, "France" => "2")
replace!(df.Geography, "Germany" => "1")
replace!(df.Geography, "Spain" => "0")
select!(df, Not([:RowNumber, :CustomerId, :Surname]))

function SplitTrainTestSets(df, split_ratio)
    # Calcula el número de filas para entrenamiento
    nrows = size(df, 1)
    nrows_train = round(Int, nrows * split_ratio)
    nrows_test = nrows - nrows_train

    # Dividir el dataframe en conjuntos de entrenamiento y prueba
    df_train = df[1:nrows_train, :]
    df_test = df[nrows_train+1:end, :]

    return df_train, df_test
end

dftrn, dftst = SplitTrainTestSets(df, 0.8)
fm = @formula(Exited ~ CreditScore + Age + Tenure + Balance + NumOfProducts + HasCrCard + IsActiveMember + EstimatedSalary + Gender + Geography)
logit = glm(fm, dftrn, Binomial(), LogitLink())

prediction = predict(logit, dftst)
prediction_class = [x < 0.5 ? 0 : 1 for x in prediction]

cm = MLBase.roc(DataFrame(y_actual=dftst.Exited, y_predicted=prediction_class).y_actual, prediction_class)
println("Confusion Matrix:", cm)

# Curva ROC GLM
function plot_roc_glm(data::DataFrame, formula::FormulaTerm, target_variable::Symbol, savepath)
    model = glm(formula, data, Binomial(), LogitLink())
    probs = predict(model, data)
    sorted_indices = sortperm(probs, rev=true)
    sorted_probs = probs[sorted_indices]
    sorted_labels = data[sorted_indices, target_variable]

    tpr, fpr = Float64[], Float64[]
    tp, fp = 0, 0
    p = sum(sorted_labels)  
    n = length(sorted_labels) - p

    for i in 1:length(sorted_probs)
        if sorted_labels[i] == 1
            tp += 1
        else
            fp += 1
        end
        push!(tpr, tp / p)
        push!(fpr, fp / n)
    end

    auc = sum((tpr[2:end] + tpr[1:end-1]) .* (fpr[2:end] - fpr[1:end-1])) / 2
    p = Plots.plot(fpr, tpr, label="ROC Curve (AUC = $(round(auc, digits=3)))")
    savefig(p, savepath)  # Guardar el gráfico en la carpeta ../fig
end

plot_roc_glm(dftst, fm, :Exited, "../fig/roc_curve_glm.png")
