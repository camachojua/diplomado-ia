# FLUX: Análisis de Modelos de Predicción para el Churn de Clientes

Este proyecto implementa y evalúa dos modelos de predicción sobre el dataset de churn de clientes (`Churn_Modelling.csv`). Los modelos son:
1. **Red Neuronal utilizando Flux** - Modelo de red neuronal para predecir si un cliente abandonará la empresa (churn).
2. **Regresión Logística utilizando GLM** - Modelo de regresión logística para realizar la misma predicción.

### Requisitos

Este proyecto requiere las siguientes librerías de Julia:
- CSV
- DataFrames
- Flux
- Statistics
- Random
- CUDA
- Plots
- GLM
- MLBase

Puedes instalarlas utilizando el siguiente comando en Julia:

```julia
using Pkg
Pkg.add(["CSV", "DataFrames", "Flux", "Statistics", "Random", "CUDA", "Plots", "GLM", "MLBase"])

## Descripción del Proyecto
Carga de Datos: El dataset Churn_Modelling.csv es cargado utilizando la librería CSV. Las columnas de género y geografía son transformadas a formato numérico utilizando One Hot Encoding.

Modelo Flux (Red Neuronal): Se entrena una red neuronal con la librería Flux. El modelo tiene una capa oculta con activación ReLU y una capa de salida con activación sigmoide. El objetivo es predecir si un cliente abandonará la empresa.

Modelo GLM (Regresión Logística): Se entrena un modelo de regresión logística utilizando la librería GLM. El modelo realiza la misma predicción que el de la red neuronal.

Evaluación de Modelos: Ambos modelos son evaluados utilizando las métricas de precisión (accuracy), matriz de confusión y curva ROC. La curva ROC se guarda en archivos PNG dentro de la carpeta ../fig/.