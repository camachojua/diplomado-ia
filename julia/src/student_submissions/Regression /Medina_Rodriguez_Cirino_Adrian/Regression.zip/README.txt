Ya que el archivo .csv que contiene los datos necesarios para correr el código es demasiado pesado
se pide por favor descargar el archivo bottle.csv del siguiente link https://drive.google.com/file/d/1zfT3Of9nguxCP3pemy2FCaBBKydY7aX7/view?usp=sharing
y colocarlo en la carpeta dat para poder ejecutar Regression.ipynb de manera correcta

Asegurarse de que el nombre del archivo descargado sea bottle.csv

Gracias