# --------------------------------------------------------------- PAQUETES ----------------------------------------------------------------------

#using Pkg
#Pkg.add("Flux")
#Pkg.add("Statistics")
#Pkg.add("GLM")
#Pkg.add("DataFrames")
#Pkg.add("OneHotArrays")
#Pkg.add("CSV")
#Pkg.add("Random")
#Pkg.add("Plots")
#Pkg.add(MLBase"")

using Statistics, DataFrames, OneHotArrays, CSV, GLM, Random, MLBase, Plots

# ---------------------------------------------------------------- DATOS ------------------------------------------------------------------------

churn = CSV.read("Churn_Modelling.csv", DataFrame)
DF = copy(churn)            #Creamos una copia para no alterar el Dataframe original
#@show(describe(DF))

println(GLM.countmap(DF.Exited))
println(GLM.countmap(DF.Surname))
println(GLM.countmap(DF.Geography))
println(GLM.countmap(DF.Gender))

df = select(DF, Not([:Surname, :CustomerId, :RowNumber]))

# One Hot encoding para Gender
replace!(df.Gender, "Female" => "1")
replace!(df.Gender, "Male"  => "2")
df[!, :Gender] = parse.(Int,df[!, :Gender])

# One Hot encoding for Geography
replace!(df.Geography, "France"  => "3")
replace!(df.Geography, "Germany" => "2")
replace!(df.Geography, "Spain"   => "1")
df[!, :Geography] = parse.(Int,df[!, :Geography])


# --------------------------------------------------- CONJUNTOS DE PRUEBA Y ENTRENAMIENTO -------------------------------------------------------

Random.seed!(1234)                       # Semilla para reproducibilidad
df = df[randperm(nrow(df)), :]

n = floor(Int, 0.8 * nrow(df))           # Tomamos el 90%, el cálculo redondea hacia abajo
train_df = df[1:n, :]                    # Almacenamos nuestro 90%
test_df = df[n+1:end, :]                 # Almacenamos nuestro 10%


# --------------------------------------------------------- CREACIÓN DEL MODELO -----------------------------------------------------------------

fm = @formula(Exited ~ CreditScore + Age + Tenure + Balance + NumOfProducts + HasCrCard + IsActiveMember + EstimatedSalary + Gender + Geography)
logit = glm(fm, train_df, Binomial(), ProbitLink())

prediction = predict(logit,test_df)


# Convertimos la probabilidad en clases
prediction_class = [if x < 0.5 0 else 1 end for x in prediction];

prediction_df = DataFrame(y_actual = test_df.Exited, y_predicted = prediction_class, prob_predicted = prediction);
prediction_df.correctly_classified = prediction_df.y_actual .== prediction_df.y_predicted

accuracy = mean(prediction_df.correctly_classified)

# --------------------------------------------------------- MATRIZ DE CONFUSIÓN -----------------------------------------------------------------

cm = MLBase.roc(prediction_df.y_actual, prediction_df.y_predicted)

acc = (cm.tp + cm.tn)/ (cm.p + cm.n)
println("Precisión según la matriz de confusión =", acc)


# -------------------------------------------------------------- CURVA ROC ----------------------------------------------------------------------
# FUBCIÓN TOMADA DE LA CLASE DE GLM

function plot_roc_from_scratch(data::DataFrame, formula::FormulaTerm, target_variable::Symbol)
    # Fit GLM model
    model = glm(formula, data, Binomial(), LogitLink())

    # Predicted probabilities
    probs = predict(model, data)

    # Sort by predicted probabilities in descending order
    sorted_indices = sortperm(probs, rev=true)
    sorted_probs = probs[sorted_indices]
    sorted_labels = data[sorted_indices, target_variable]

    # Initialize variables
    tpr = Float64[]
    fpr = Float64[]
    tp = 0
    fp = 0
    p = sum(sorted_labels)  # Number of positives
    n = length(sorted_labels) - p  # Number of negatives

    # Calculate TPR and FPR at each threshold
    for i in 1:length(sorted_probs)
        if sorted_labels[i] == 1
            tp += 1
        else
            fp += 1
        end
        push!(tpr, tp / p)
        push!(fpr, fp / n)
    end

    # Calculate AUC using trapezoidal rule
    auc = sum((tpr[2:end] + tpr[1:end-1]) .* (fpr[1:end-1] - fpr[2:end])) / 2

    # Plot ROC curve
    Plots.plot(fpr, tpr, 
         label="ROC Curve (AUC = $(round(auc, digits=3)))", 
         xlabel="False Positive Rate", 
         ylabel="True Positive Rate")
end

plot_roc_from_scratch(df, fm, :Exited)


# --------------------------------------------------------------- PAQUETES ----------------------------------------------------------------------


# --------------------------------------------------------------- PAQUETES ----------------------------------------------------------------------


# --------------------------------------------------------------- PAQUETES ----------------------------------------------------------------------