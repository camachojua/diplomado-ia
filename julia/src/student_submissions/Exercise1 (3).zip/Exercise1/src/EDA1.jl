using CSV
using DataFrames
using Printf 
using Statistics
using Plots

file_path = "C:/Users/Usuario/Desktop/bottle.csv"  
bottle_data = CSV.read(file_path, DataFrame)

println("Primeras 10 filas del dataset:")
println(first(bottle_data, 5))



function dataShape(data)
    return size(data)
end


println("Tamaño de los datos: ", dataShape(bottle_data))


function dataType(data)
    return eltype.(eachcol(data))
end

println("Tipos de datos de cada columna: ", dataType(bottle_data))


function count_missing(data, col)
    return count(ismissing, data[!, col])
end


col = "Oxy_µmol/Kg"  
println("Valores nulos en columna $col: ", count_missing(bottle_data, col))


function count_missing_all_with_percentage(data)
    missing_count = Dict()
    total_rows = nrow(data)  
    for col in names(data)
        null_count = count(ismissing, data[!, col])
        null_percentage = (null_count / total_rows) * 100  
        missing_count[col] = (null_count, null_percentage)
    end
    return missing_count
end


missing_data = count_missing_all_with_percentage(bottle_data)
sorted_missing_data = sort(collect(missing_data), by = x -> x[2][1])


println("Número de valores nulos y porcentaje por columna (ordenados de menor a mayor):")

for (col, (null_count, null_percentage)) in sorted_missing_data
    println("$col: $null_count nulos, $(@sprintf("%.2f", null_percentage))%")
end


function dataMissingPercentage(data)
    missing_percent = Dict()
    total_rows = nrow(data)  
    for col in names(data)
        missing_count = count(ismissing, data[!, col])
        missing_percent[col] = (missing_count / total_rows) * 100  
    end
    return missing_percent
end

function deleteColumns(data, threshold)
    missing_percent = dataMissingPercentage(data)
    cols_to_delete = [col for col in names(data) if missing_percent[col] > threshold]
    return select(data, Not(cols_to_delete))
end


threshold = 30
bottle_data_clean = deleteColumns(bottle_data, threshold)
println("Datos después de eliminar columnas con mas del $threshold% de nulos:")
println(first(bottle_data_clean, 5))


missing_data = count_missing_all_with_percentage(bottle_data_clean)
sorted_missing_data = sort(collect(missing_data), by = x -> x[2][1])

println("Número de valores nulos y porcentaje por columna (ordenados de menor a mayor):")
for (col, (null_count, null_percentage)) in sorted_missing_data
    println("$col: $null_count nulos, $(@sprintf("%.2f", null_percentage))%")
end

function calculateCorrelation(data)
    numeric_cols = names(data)[map(x -> eltype(data[!, x]) <: Real, names(data))]
    numeric_data = data[:, numeric_cols]
    return cor(Matrix(numeric_data))
end

# Llamar a la función para obtener la matriz de correlación
println("Matriz de correlación: ", calculateCorrelation(bottle_data_clean))


function calculateCorrelation(data)
    numeric_cols = names(data)[map(x -> eltype(data[!, x]) <: Real, names(data))]
    numeric_data = data[:, numeric_cols]
    
    return cor(Matrix(numeric_data))
end


function displayCorrelation(data)
    
    corr_matrix = calculateCorrelation(data)
    
    
    heatmap(corr_matrix, 
            title="Matriz de Correlación", 
            xlabel="Columnas", 
            ylabel="Columnas", 
            xticks=(1:length(names(data)), names(data)),  
            yticks=(1:length(names(data)), names(data)),  
            color=:blues)  
end


displayCorrelation(bottle_data_clean)


function removeOutliersIQR(data)
    cleaned_data = copy(data)
    for col in names(data)
        if eltype(data[!, col]) <: Real
            # Calcular los valores Q1 y Q3
            Q1 = quantile(data[!, col], 0.25)
            Q3 = quantile(data[!, col], 0.75)
            IQR = Q3 - Q1
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR
            
            cleaned_data = filter(row -> row[col] >= lower_bound && row[col] <= upper_bound, cleaned_data)
        end
    end
    return cleaned_data
end


bottle_data_no_outliers = removeOutliersIQR(bottle_data_clean)
println("Datos después de eliminar outliers: ")
println(first(bottle_data_no_outliers, 5))


function removeOutliersIQR(data)
    
    cleaned_data = copy(data)
    
    numeric_cols = names(data)[map(x -> eltype(data[!, x]) <: Real, names(data))]
    numeric_data = data[:, numeric_cols]

    for col in numeric_cols
        # Calcular el Q1 (cuartil 25) y Q3 (cuartil 75)
        Q1 = quantile(numeric_data[!, col], 0.25)
        Q3 = quantile(numeric_data[!, col], 0.75)

        IQR = Q3 - Q1

        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        
        cleaned_data = filter(row -> row[col] >= lower_bound && row[col] <= upper_bound, cleaned_data)
    end
    
    return cleaned_data
end

bottle_data_no_outliers = removeOutliersIQR(bottle_data_clean)

println("Datos después de eliminar los outliers:")
println(first(bottle_data_no_outliers, 5))


function deleteRow(data, column)
    return filter(row -> !ismissing(row[column]), data)
end

bottle_data_no_nulls = deleteRow(bottle_data_no_outliers, "Oxy_µmol/Kg")  
println("Datos después de eliminar filas con valores nulos: ")
println(first(bottle_data_no_nulls, 5))

function deleteRowsWithMissing(data)
    return filter(row -> !any(ismissing, row), data)
end

bottle_data_no_nulls = deleteRowsWithMissing(bottle_data_no_outliers)

println("Datos después de eliminar filas con valores nulos en cualquier columna: ")
println(first(bottle_data_no_nulls, 5)) 

function selectNumericColumns(data)
    # Seleccionar las columnas cuyo tipo de dato sea numérico (y manejar missing)
    numeric_cols = names(data)[map(x -> eltype(data[!, x]) <: Real || eltype(data[!, x]) <: Union{Missing, Real}, names(data))]
    return data[:, numeric_cols] 
end


bottle_data_numeric = selectNumericColumns(bottle_data_no_nulls)

println("Datos con solo las columnas numéricas:")
println(first(bottle_data_numeric, 5))  


function calculateCorrelation(data)
    numeric_cols = names(data)[map(x -> eltype(data[!, x]) <: Real || eltype(data[!, x]) <: Union{Missing, Real}, names(data))]
    numeric_data = data[:, numeric_cols]

    return cor(Matrix(numeric_data))
end


function filterColumnsByCorrelation(data, target, threshold)
    # Verificar si la columna objetivo existe
    if !(target in names(data))
        error("La columna objetivo '$target' no se encuentra en el DataFrame.")
    end
    
    
    corr_matrix = calculateCorrelation(data)
    target_idx = findfirst(x -> x == target, names(data))
    
    if target_idx == nothing
        error("La columna objetivo '$target' no se encuentra en el DataFrame.")
    end
    
    target_corr = corr_matrix[:, target_idx]
    
    cols_to_delete = names(data)[abs.(target_corr) .< threshold]

    filtered_data = select(data, Not(cols_to_delete))
    
    return filtered_data
end




target_column = "Cst_Cnt"  
threshold = 0.5  


filtered_data = filterColumnsByCorrelation(bottle_data_numeric, target_column, threshold)

println("Datos después de filtrar las columnas con baja correlación: ")
println(first(filtered_data, 5))  


summary = describe(bottle_data_no_nulls)

println(summary)





