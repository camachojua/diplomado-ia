#Use the EDA you already have done in Julia
##Importing packages to clean data quickly:

cd("/Users/zoe/drv3/hm3/code/julia/hmw_diplo")
include("/Users/zoe/drv3/hm3/code/julia/hmw_diplo/Exercise1/src/ExerciseN1.jl") ## the "package" I just made just in case...

using Pkg
Pkg.add("DataFrames")
Pkg.add("PlotlyJS")
Pkg.add("NamedArrays")
Pkg.add("GLM")
Pkg.add("Random")
Pkg.add("StatsBase")

using CSV
using DataFrames
using Statistics
using Printf
using PlotlyJS
using NamedArrays
using Random
using GLM
using StatsBase

## Quickly Cleaning data with my package:

### uploading cleaned data to DR
bottle = CSV.read("Exercise1/dat/clean_bottle.csv", DataFrame)

### looking at datashape and data
describe(bottle)

### making a copy bc I have enough memory to do it and because it's a good idea 
### to work with images instead of original in case that something strange is detected
cbottle = copy(bottle)


## First try adjusting models:
### Im going to use p < 0.01 to say that someghin is statistically significant, so anything greater than that would not be...

### partitionning data into Training and Test datasets:

function split_data(data::DataFrame, train_ratio::Float64 = 0.8, seed::Int = 1234)
    # Set the random seed for reproducibility
    Random.seed!(seed)
    
    # Number of rows in the dataset
    n = nrow(data)
    
    # Generate shuffled indices
    indices = shuffle(1:n)
    
    # Calculate the split index
    split_idx = Int(round(train_ratio * n))
    
    # Create training and testing sets
    train_data = data[indices[1:split_idx], :]
    test_data = data[indices[split_idx+1:end], :]
    
    return train_data, test_data
end

trainBottle, testBottle = split_data(cbottle, 0.8, 1234)

nrow(trainBottle) + nrow(testBottle) #result with the same number of rows than cbottle :D


    ### now, I would like to shuffle some variables, I have at least 14 presumable explanatory variables to predict T_degC,
    ### this would give me: 2047 (2**11) combinations of columns! but as it can be noticeable, that can take a great amount of time...
    ### starting simple with just one single variable (eating the frog):

LRM = lm(@formula(T_degC ~ STheta), trainBottle)

rsqr = r2(LRM)

prediction = predict(LRM, testBottle);

accuracy_testdf = DataFrame(y_actual = testBottle[!,:T_degC], y_predicted = prediction)
accuracy_testdf.non_abs_erorr = accuracy_testdf.y_actual - accuracy_testdf.y_predicted  
MAE_1 = mean(abs.(accuracy_testdf.non_abs_erorr))

println("Mean absolute error on test dataset: ", MAE_1)
println("r2 for the data set is: ", rsqr)


    ### looking to do it for every explanatory variable:
    ### creatin a function to term sum every variable in my dataset:
function termnsSymbol(DataFrame, target::Symbol)
    
    selected_columns = names(DataFrame)
    selected_columns = filter(x -> x != string(target), selected_columns)
    
    return sum(Term.(Symbol.(selected_columns)))

end
    
terms = termnsSymbol(trainBottle, :T_degC)

LRM = lm(Term(:T_degC) ~ termnsSymbol(trainBottle, :T_degC), trainBottle)

rsqr = r2(LRM)

prediction = predict(LRM, testBottle);

accuracy_testdf = DataFrame(y_actual = testBottle[!,:T_degC], y_predicted = prediction)
accuracy_testdf.non_abs_erorr = accuracy_testdf.y_actual - accuracy_testdf.y_predicted  
MAE_2 = mean(abs.(accuracy_testdf.non_abs_erorr))

println("Mean absolute error on test dataset: ", MAE_2)
println("r2 for the data set is: ", rsqr)

## we can see that training with more data reduced the MAE_1 in -0.63 units!


### iteration N3: Filtering out non-significant rows:

# LRM = lm(Term(:T_degC) ~ sum(Term.(Symbol.(["Depthm", "Salnty", "STheta", "Oxy_µmol/Kg", "R_SALINITY", "R_SIGMA", "R_DYNHT", "R_PRES"]))), trainBottle)
LRM = lm(Term(:T_degC) ~ sum(Term.(Symbol.(["Depthm", "Salnty", "STheta", "O2Sat", "Oxy_µmol/Kg", "R_SALINITY", "R_SIGMA", "R_DYNHT", "R_O2", "R_PRES", "R_O2Sat"]))), trainBottle)

rsqr = r2(LRM)

prediction = predict(LRM, testBottle);

prediction

accuracy_testdf = DataFrame(y_actual = testBottle[!,:T_degC], y_predicted = prediction)

#ploting the first values if the model is ok we should expect to see a 1:1 line! :D
p = plot(last(accuracy_testdf, 1000), x = :y_actual, y= :y_predicted, mode="markers", Layout(title="predicted vs actual values"))
savefig(p, "Exercise2/fig/actual_vs_predicted_bottle.png")
## and that's what we see

accuracy_testdf.non_abs_erorr = accuracy_testdf.y_actual - accuracy_testdf.y_predicted  
MAE_3 = mean(abs.(accuracy_testdf.non_abs_erorr))

println("Mean absolute error on test dataset: ", MAE_3)
println("r2 for the data set is: ", rsqr)

MAE_2 - MAE_3 ## and also MAE 3 < MAE 2 so the result improved :)

###saving the output from prediction

CSV.write("Exercise2/dat/predict_vs_actual_bottle.csv", accuracy_testdf)
