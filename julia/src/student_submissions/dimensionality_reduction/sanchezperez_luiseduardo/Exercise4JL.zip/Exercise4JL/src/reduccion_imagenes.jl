#Autor: Luis Eduardo Sánchez Pérez

using Pkg
Pkg.add(["FileIO", "Plots", "LinearAlgebra","JpegTurbo"])
Pkg.instantiate()
using FileIO
using Plots
using LinearAlgebra

function creacionImagenAproximada(k::Int, F::SVD, contador::Int, archivo::String, miDirectorioSalida::String)
    #Se aproximará la matriz con k valores singulares
    
    #Se calula la aproximación de la matriz (M)
    M = F.U[:, 1:k] * Diagonal(F.S[1:k]) * F.V[:, 1:k]'
    
    #Para evitar valores negativos se aplica el valor absoluto
    M = abs.(M)

    #Se guarda el archivo
    save(miDirectorioSalida * string(contador) * "_Aprox" * string(k) * "_" * archivo, M)

    #Impresión del status
    println("Archivo creado con k= ",k," ", contador, "_Aprox",k,"_", archivo)
end


#Se define el directorio donde se van a leer las imágenes
miDirectorio = "../dat/"

#Se define el directorio sonde se van a colocar las imágenes procesadas
miDirectorioSalida = "../fig/"

#Se lee un directorio con todos los archivos jpg que se van a utilizar:
archivos = readdir(miDirectorio)
println("Solo se procesarán los archivos siguientes archivos (Solo JPEG o JPG):")

#Se hace un filtro de los archivos del directorio, colocando solo los jpg o jpeg
archivos_validos = [
    archivo for archivo in archivos 
    if endswith(lowercase(archivo), ".jpg") || endswith(lowercase(archivo), ".jpeg")
]

#Se imprimen los archivos que se van a procesar
println(archivos_validos)

global cont = 0
for archivo in archivos_validos
    global cont += 1
    println("Procesando archivo: ", archivo)

    #Se define la dirección del archivo a procesar
    arcProcesar=miDirectorio * archivo
    #Se carga en memoria el archivo
    imgCargada = load(arcProcesar)
    #Se cambia el archivo en escala de grises
    imgGris = Gray.(imgCargada)
    #Se convierte el archivo en escala de grises a una matriz de punto flotante
    imgMatriz = Float32.(imgGris)
    #Se aplica la descomposición en valores singulares de la matriz obtenida
    F = svd(imgMatriz)

    #Aproximación de la matriz con 5 valores singulares
    creacionImagenAproximada(5, F, cont, archivo, miDirectorioSalida)
    #Aproximación de la matriz con 50 valores singulares
    creacionImagenAproximada(50, F, cont, archivo, miDirectorioSalida)
    #Aproximación de la matriz con 100 valores singulares
    creacionImagenAproximada(100, F, cont, archivo, miDirectorioSalida)
end