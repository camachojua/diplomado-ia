using Images
using LinearAlgebra
using Plots

# Lista de archivos de imágenes con rutas relativas
image_files = [
    "../fig/1.jpg",
    "../fig/2.jpg",
    "../fig/3.jpg",
    "../fig/4.jpg",
    "../fig/5.jpg"
]

# Función para aplicar SVD a cada imagen
function process_image(file_path::String)
    img = load(file_path)
    img = Gray.(img)  # Convertir a escala de grises
    img = convert(Matrix{Float64}, img)  # Convertir a matriz de valores flotantes
    img = img ./ maximum(img)  # Normalizar los valores
    return svd(img)
end

# Función para aproximar la imagen utilizando los primeros k componentes
function FindApproxImg(F::SVD, k::Int)
    M = F.U[:, 1:k] * Diagonal(F.S[1:k]) * F.Vt[1:k, :]
    M = M .- minimum(M)
    M = M ./ maximum(M)  # Escalar los valores entre 0 y 1
    return M
end

# Procesar y guardar las imágenes aproximadas
for (file_path, image_name) in zip(image_files, ["1","2","3","4","5"])
    F = process_image(file_path)
    for k in [5, 50, 100]
        output_path = "../fig/$(image_name)_k$(k).png"
        M = FindApproxImg(F, k)
        save(output_path, colorview(Gray, M))
        println("Saved approximation for $(image_name) with k=$(k) components to $(output_path)")
    end
end
