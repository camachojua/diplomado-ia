# Dimensionality Reduction

Este proyecto aplica la Descomposición en Valores Singulares (SVD) a un conjunto de imágenes, genera aproximaciones de las mismas con diferentes valores de componentes `k`, y guarda las imágenes resultantes en un directorio específico. El código está escrito en Julia.

## Requisitos

- Julia 1.x o superior
- Paquetes:
  - `Images` para cargar y guardar imágenes.
  - `LinearAlgebra` para realizar la descomposición SVD.
  - `Plots` para la visualización (si se requiere).
  
Instalar los paquetes necesarios:

```julia
using Pkg
Pkg.add("Images")
Pkg.add("LinearAlgebra")
Pkg.add("Plots")
Descripción del Proyecto
Estructura de Archivos
julia.jl: Script principal que procesa las imágenes mediante SVD.
fig/: Carpeta que contiene las imágenes originales y donde se guardan las imágenes procesadas.
Las imágenes procesadas se guardarán en el mismo directorio con nombres que reflejan el valor de k (número de componentes).
¿Qué hace el código?
Carga las imágenes: El código carga un conjunto de imágenes desde la carpeta ../fig/.
Convierte a escala de grises: Cada imagen se convierte a escala de grises para simplificar el proceso.
Normaliza y aplica SVD: Se aplica la Descomposición en Valores Singulares (SVD) a cada imagen.
Genera aproximaciones: Se genera una aproximación de la imagen original utilizando los primeros k componentes (donde k puede ser 5, 50 o 100).
