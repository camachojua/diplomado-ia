# Reducción de dimensionalidad

### **Introducción**
Este ejercicio tiene como objetivo procesar imágenes, convertirlas a escala de grises, realizar la descomposición en valores singulares (SVD), y generar aproximaciones de las imágenes originales utilizando un número reducido de valores singulares. Lo que permite comprimir imágenes reteniendo las características visuales más importantes.

---
### Carga de Librerías
``` julia
using Glob, Images, FileIO, LinearAlgebra, Statistics
using DataFrames, PrettyTables
```	
- **`Glob`**: Facilita el uso de patrones para buscar archivos en directorios.
- **`Images`**: Manipulación y procesamiento de imágenes en Julia.
- **`FileIO`**: Proporciona una interfaz uniforme para cargar y guardar archivos de diversos formatos.
- **`LinearAlgebra`**: Proporciona herramientas para álgebra lineal, incluidas operaciones como SVD.
- **`Statistics`**: Para realizar cálculos estadísticos.
- **`DataFrames`**: Manipulación de datos tabulares.
- **`PrettyTables`**: Visualización tabular más estética.
- **`OrderedCollections`**: Asegurar que los elementos mantengan el orden de inserción.

---

### **Estructura del Código**

#### **1. Función `CreateArrayFromImgFile`**
Convierte una imagen de entrada en una matriz numérica de tipo `Float32` en escala de grises.
- **Parámetro:** 
  - `srcFile`: Ruta de la imagen de entrada.

```julia
function CreateArrayFromImgFile(srcFile::String)
    # Carga la imagen original
    imgOri = load(srcFile)

    # Convierte la imagen a escala de grises 
    imgGr = Gray.(imgOri)  

    # Convierte la imagen a una matriz flotante 
    imgMatiz = convert(Matrix{Float32}, imgGr)

    println("Dimensiones imagen original:", size(imgOri))
    return imgMatiz
end
```

- **Salida:** Devuelve una matriz de flotantes que representa la imagen en escala de grises.
<br>

#### **2. Función `FindSVD`**
Calcula la descomposición en valores singulares (SVD) de una matriz.
- **Parámetro:** 
  - `M`: Matriz a descomponer.

```julia
function FindSVD(M::Matrix)
    return svd(M)
end
```

- **Salida:** Retorna un objeto `SVD` con las matrices \( U \), \( S \), \( V \) de la descomposición.
<br>

#### **3. Función `ApproximateImage`**
Genera una aproximación de la imagen original utilizando los primeros \( k \) valores singulares.
- **Parámetros:** 
  - `F`: Resultado de la SVD.
  - `k`: Número de valores singulares utilizados.
  - `outputFile`: Ruta donde se guardará la imagen aproximada.


```julia
function ApproximateImage(F::SVD, k::Int, outputFile::String)
    # Calcula la matriz aproximada M_k
    M = F.U[:, 1:k] * Diagonal(F.S[1:k]) * F.V[:, 1:k]'
    
    # Normaliza los valores de la matriz para asegurarse de 
    # que estén en el rango [0,1].
    M = abs.(M .* 0.99) 

    # Guardar la imagen reconstruida 
    # Controla la calidad de compresión (quanlity)
	save(outputFile, M, quality=75)  
    
    println("Dimensiones imagen reconstruida:", size(M))
    println("Imagen aproximada con k=$k guardada en: $outputFile")
end
  ```
<br>

#### **4. Función `FindImages`**
Encuentra todas las imágenes en un directorio específico con extensión `.jpg`.
- **Parámetro:** 
  - `SourceDir`: Directorio fuente.

```julia
function FindImages(SourceDir::String)
    # Devuelve la lista de archivos .jpg
    return glob("*.jpg", SourceDir)  
end
```
- **Salida:** Lista de archivos de imágenes.
<br>

#### 5. Funciones para el tamaño de las imagenes 

- **Función `get_image_size_kb`**

    Obteniene el tamaño en KB de un archivo.
    ```julia
    function get_image_size_kb(filepath::String)
        # Tamaño en bytes
        file_size_bytes = filesize(filepath)  

        # Convertir a KB
        file_size_kb = file_size_bytes / 1024  #
        
        # Redondear a 0 decimales
        return round(file_size_kb, digits=0)  
    end
    ```
    <br>

- **Función `create_size_table`**
Genera un DataFrame que compara los tamaños de los archivos originales y sus aproximaciones.
    - **Parámetros:** 
        - `image_sizes`: Diccionario donde las claves son nombres de archivos y los valores son tuplas con el tamaño original y el de la aproximación.
    ```julia
    function create_size_table(image_sizes::OrderedDict{String, Tuple{Int64, Int64}})
        fileName = String[]
        imgOriKB = Int64[]
        imgAproxKB = Int64[]
        for (file, sizes) in image_sizes
            push!(fileName, basename(file))
            push!(imgOriKB, sizes[1])
            push!(imgAproxKB, sizes[2])
        end
        tabla = DataFrame(fileName = fileName, imgOriKB = imgOriKB, imgAproxKB = imgAproxKB) 
        rename!(tabla, ["Archivo", "Original (KB)", "Aproximación (KB)"]) 
        return tabla
    end
    ```

<br>

#### **7. Función `ProcessImages`**
Procesa todas las imágenes en un directorio, realizando SVD y generando aproximaciones para múltiples valores de \( k \).
- **Parámetros:**
  - `SourceDir`: Directorio fuente de imágenes.
  - `k_values`: Lista de valores de \( k \) para las aproximaciones.

```julia
function ProcessImages(SourceDir::String, k_values::Vector{Int})
    # Encuentra todas las imágenes.
    files = FindImages(SourceDir)
    println("Imágenes encontradas en '$SourceDir': ", files)
	println("Total de imagenes: ", length(files))

    image_sizes = OrderedDict{String, Tuple{Int64, Int64}}()

    # Procesa cada imagen
    for file in files
        # Nombre de la imagen
        name,_= splitext(basename(file))
        println("Procesando imagen: $name")

        # Convierte a matriz
        imgArray = CreateArrayFromImgFile(file)

        # SVD
        F = FindSVD(imgArray)

        # Tamaños de imagenes originales.
        original_size = get_image_size_kb(file)
        # Genera y guarda aproximaciones para cada k
        for k in k_values
            outputFile = joinpath(SourceDir,"$(name)_k_values/$(name)_k_$k.jpg")
            ApproximateImage(F, k, outputFile)

            # Tamaños de imagenes aproximadas.
            approx_size = get_image_size_kb(outputFile)
            image_sizes[outputFile] = (original_size, approx_size)
        end
    end
    KB = create_size_table(image_sizes)
	pretty_table(KB)
end
```

#### **8. Función `main`**
Función iniciadora
```julia
function main()
    # Directorio de imágenes
	SourceDir = "../fig"  

    # Valores de k para aproximación
	k_values = [5, 50, 100]  

    # Llamamos a ProcessImages para procesar las imágenes.
	ProcessImages(SourceDir, k_values)

	println("Tarea completada.")
end
```
---

### **Resultados**
#### **Entrada:**
- Directorio de imágenes: `./fig`
- Valores de \( k \): [5, 50, 100]

#### **Salida:**
1. Para cada imagen en el directorio, se generaron tres versiones aproximadas utilizando los valores de \( k \).
    <br>
2. Ejemplo de imágenes reconstruidas con `pets.jpg`:
    <br>
   - **Imagen original:**
   ![pets.jpg](../fig/pets.jpg)
        * Tamaño: 160 KB
        * Dimensiones: 960 \(\times\) 1280
    

    <br>

   - **Aproximación con \( k=5 \):** `pets_k_5.jpg` 
        * Tamaño: 50 KB (31.25% del original).
        * Muy comprimida, con pérdida significativa de detalle.
   ![pets_k_5.jpg](../fig/pets_k_values/pets_k_5.jpg)

    <br>

   - **Aproximación con \( k=50 \):** `pets_k_50.jpg`
        * Tamaño: 96 KB (60% del original).
        * Buena calidad y compresión moderada.
   ![pets_k_50.jpg](../fig/pets_k_values/pets_k_50.jpg)

    <br>

   - **Aproximación con \( k=100 \):** `pets_k_100.jpg` 
        * Tamaño: 122 KB (76.25% del original).
        * Conserva la mayoría de los detalles visuales.
   ![pets_k_100.jpg](../fig/pets_k_values/pets_k_100.jpg)



**Tabla Comparativa:**
 | **Archivo**<br>`String` | **Original (KB)**<br>`Int64` | **Aproximación (KB)**<br>`Int64` |
|------------------------:|------------------------------------:|--------------------------------------:|
| pets\_k\_5.jpg  | 160 | 49   |
| pets\_k\_50.jpg  | 160   |96 |
| pets\_k\_100.jpg  |160 |123|


---

### **Conclusión**

Las aproximaciones basadas en SVD permiten reducir significativamente el tamaño de las imágenes, especialmente con valores bajos de k. Sin embargo, esto viene con una pérdida de detalle visual. Al integrar un análisis cuantitativo, como los tamaños de los archivos, podemos evaluar mejor la efectividad de la compresión.

Esta implementación es una excelente herramienta para entender el equilibrio entre la calidad visual y la eficiencia en el almacenamiento.