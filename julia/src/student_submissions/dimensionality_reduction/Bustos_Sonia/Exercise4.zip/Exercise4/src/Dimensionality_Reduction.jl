using Glob, Images, FileIO, LinearAlgebra, Statistics
using DataFrames, PrettyTables, OrderedCollections


# Convierte una imagen a escala de grises y matriz Float32
function CreateArrayFromImgFile(srcFile::String)
    # Carga la imagen original
    imgOri = load(srcFile)

    # Convierte la imagen a escala de grises 
    imgGr = Gray.(imgOri)  

    # Convierte la imagen a una matriz flotante 
    imgMatiz = convert(Matrix{Float32}, imgGr)

    println("Dimensiones imagen original:", size(imgOri))
    return imgMatiz
end

# Realiza SVD sobre una matriz
function FindSVD(M::Matrix)
    return svd(M)
end

# Genera una aproximación de la imagen original con los primeros k valores singulares
function ApproximateImage(F::SVD, k::Int, outputFile::String)
    # Calcula la matriz aproximada M_k
    M = F.U[:, 1:k] * Diagonal(F.S[1:k]) * F.V[:, 1:k]'
    
    # Normaliza los valores de la matriz para asegurarse de que estén en el rango [0,1].
    M = abs.(M .* 0.99) 

    # Guardar la imagen reconstruida 
	save(outputFile, M, quality=75)  # Controla la calidad de compresión
    
    println("Dimensiones imagen reconstruida:", size(M))
    println("Imagen aproximada con k=$k guardada en: $outputFile")
end

# Encuentra todas las imágenes en un directorio dado
function FindImages(SourceDir::String)
    # Devuelve la lista de archivos .jpg
    return glob("*.jpg", SourceDir)  
end


# Obteniene el tamaño en KB de un archivo.
function get_image_size_kb(filepath::String)
    # Tamaño en bytes
    file_size_bytes = filesize(filepath)  

    # Convertir a KB
    file_size_kb = file_size_bytes / 1024  #
    
    # Redondear a 0 decimales
    return round(file_size_kb, digits=0)  
end

# Función para crear una tabla con los tamaños de las imágenes
function create_size_table(image_sizes::OrderedDict{String, Tuple{Int64, Int64}})
    fileName = String[]
    imgOriKB = Int64[]
    imgAproxKB = Int64[]
    for (file, sizes) in image_sizes
        push!(fileName, basename(file))
        push!(imgOriKB, sizes[1])
        push!(imgAproxKB, sizes[2])
    end
    tabla = DataFrame(fileName = fileName, imgOriKB = imgOriKB, imgAproxKB = imgAproxKB) 
    rename!(tabla, ["Archivo", "Original (KB)", "Aproximación (KB)"]) 
    return tabla
end


# Procesa todas las imágenes en un directorio
function ProcessImages(SourceDir::String, k_values::Vector{Int})
# Encuentra todas las imágenes.
files = FindImages(SourceDir)
println("Imágenes encontradas en '$SourceDir': ", files)
println("Total de imagenes: ", length(files))

image_sizes = OrderedDict{String, Tuple{Int64, Int64}}()

# Procesa cada imagen
for file in files
    # Nombre de la imagen
    name,_= splitext(basename(file))
    println("Procesando imagen: $name")

    # Convierte a matriz
    imgArray = CreateArrayFromImgFile(file)

    # SVD
    F = FindSVD(imgArray)

    # Tamaños de imagenes originales.
    original_size = get_image_size_kb(file)
    # Genera y guarda aproximaciones para cada k
    for k in k_values
        outputFile = joinpath(SourceDir,"$(name)_k_values/$(name)_k_$k.jpg")
        ApproximateImage(F, k, outputFile)

        # Tamaños de imagenes aproximadas.
        approx_size = get_image_size_kb(outputFile)
        image_sizes[outputFile] = (original_size, approx_size)

		
    end
end
KB = create_size_table(image_sizes)
pretty_table(KB)
end


# Función iniciadora
function main()
    # Directorio de imágenes
	
	SourceDir = "../fig"  

    # Valores de k para aproximación
	k_values = [5, 50, 100]  

    # Llamamos a ProcessImages para procesar las imágenes.
	ProcessImages(SourceDir, k_values)

	println("Tarea completada.")
end