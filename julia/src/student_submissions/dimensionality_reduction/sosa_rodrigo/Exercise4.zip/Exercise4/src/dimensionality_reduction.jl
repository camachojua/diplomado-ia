#using Pkg
#Pkg.add(["Images", "ImageIO", "LinearAlgebra", "Plots"]
#Pkg.add("ImageTransformations")
#Pkg.add("JpegTurbo")

using Images, ImageIO, LinearAlgebra, Plots, FileIO
using ImageTransformations, JpegTurbo, Statistics

function preprocess_image(img, target_size)
    gray_img = Gray.(img)  # Convertir a escala de grises
    resized_img = imresize(gray_img, target_size)  # Redimensionar
    return resized_img
end

# Función para aplicar SVD y reducir la dimensionalidad
function apply_svd(image_matrix, k)
    U, S, V = svd(image_matrix)  # Descomposición SVD
    reduced = U[:, 1:k] * Diagonal(S[1:k]) * V[:, 1:k]'  # Reconstrucción con k componentes principales
    return reduced
end

# Función para guardar imágenes reconstruidas
function reconstruct_and_save(images, k, output_folder)
    isdir(output_folder) || mkdir(output_folder)  # Crea la carpeta de salida si no existe

    for (i, img) in enumerate(images)
        img_matrix = float.(img)  # Convierte a tipo flotante para los cálculos
        reduced = apply_svd(img_matrix, k)  # Aplica SVD
        
        # Ruta de salida para la imagen reconstruida
        output_path = joinpath(output_folder, "reduced_$(i).jpg")
        save(output_path, reduced)  # Guarda la imagen reconstruida
        
        # Tamaño original y reducido
        original_size = stat(sorted_paths[i]).size
        reduced_size = stat(output_path).size

        println("Imagen $(i):")
        println("  Tamaño original: $(original_size) bytes")
        println("  Tamaño reducido: $(reduced_size) bytes")
        println("  Compresión: $(100 * (1 - reduced_size / original_size))% reducción\n")

    end
end

# Función para reconstruir y mostrar imágenes con diferentes valores de k
function reconstruct_and_compare(images, ks, output_folder)
    for (i, img) in enumerate(images)
        println("Procesando imagen $(i)...")
        img_matrix = float.(img)
       
        # Crear una cuadrícula para mostrar las imágenes
        plot_grid = plot(layout = (1, length(ks)), size = (1200, 300), title = "Comparación para imagen")
    
        for (j, k) in enumerate(ks)
            reconstructed_image = apply_svd(img_matrix, k)

            # Corregir la orientación de la imagen (invertir verticalmente)
            corrected_image = reconstructed_image[end:-1:1, :]
        
            # Mostrar la imagen reconstruida
            heatmap!(
                plot_grid,
                corrected_image,
                color=:grays,
                title="k = $k",
                axis=false,
                ratio=:equal,
                subplot=j,
                colorbar=false
            )

        end
        display(plot_grid)
        # Guardar el gráfico en el directorio de salida
        output_path = joinpath(output_folder, "comparacion_imagen_$(i).png")
        savefig(plot_grid, output_path)
        println("Imagen comparativa guardada en: $output_path")
    end
end

# Directorio donde están las imágenes
image_dir = "./fig/img_in"

# Obtener los nombres de los archivos
image_files = readdir(image_dir)

println("Archivos encontrados: ", image_files)

# Construir las rutas completas a los archivos
image_paths = [joinpath(image_dir, file) for file in image_files]

println("Rutas completas: ", image_paths)

# Ordenar los archivos alfabéticamente
sorted_paths = sort(image_paths)

println("Rutas ordenadas: ", sorted_paths)

# Cargar imágenes y mostrar una como ejemplo
images = [load(img) for img in sorted_paths]

# Preprocesar todas las imágenes
processed_images = [preprocess_image(img, (512, 512)) for img in images]

# Guardar imagenes con k fijado

println("Reduciendo dimensionalidad de las imágenes...")
k=50
reconstruct_and_save(processed_images, k, "./fig/img_out/SVD")

# Comparar imagenes con distintos valores de k
# Valores de k para comparar
ks = [10, 20, 50, 100]

# Reconstruir y comparar
reconstruct_and_compare(processed_images, ks, "./fig/img_out/SVD/compared_k")

# Convierte una imagen a una fila de una matriz (vectoriza la imagen)
function flatten_images(images)
    data = [vec(float.(img)) for img in images]  # Vectoriza cada imagen
    return hcat(data...)  # Cada imagen es una columna en la matriz
end

function apply_pca(data_matrix, k)
    # 1. Centrar los datos
    mean_vector = mean(data_matrix, dims=2)
    mean_vector = float.(mean_vector) 
    centered_data = data_matrix .- mean_vector

    # 2. Aplicar SVD
    U, S, V = svd(centered_data)

    principal_components = U[:, 1:k]  # Seleccionamos las primeras k columnas de U
    reduced_data = principal_components' * centered_data  # Proyección a subespacio reducido

    return reduced_data, mean_vector, principal_components
end

# Reconstruir la matriz desde los componentes principales
function reconstruct_data(reduced_data, mean_vector, principal_components)
    reconstructed = principal_components * reduced_data
    return reconstructed .+ mean_vector
end

# Guardar imágenes reconstruidas
function reconstruct_and_save_PCA(images, reduced_data, mean_vector, principal_components, output_folder)
    isdir(output_folder) || mkdir(output_folder)

    for i in 1:size(reduced_data, 2)
        reconstructed_image = principal_components * reduced_data[:, i] .+ mean_vector
        img = reshape(reconstructed_image, size(images[1]))  # Reconstituye la imagen original

        # Ruta de salida para la imagen reconstruida
        output_path = joinpath(output_folder, "reduced_$(i).jpg")
        save(output_path, img)  # Guarda la imagen reconstruida
        
        # Tamaño original y reducido
        original_size = stat(sorted_paths[i]).size
        reduced_size = stat(output_path).size

        println("Imagen $(i):")
        println("  Tamaño original: $(original_size) bytes")
        println("  Tamaño reducido: $(reduced_size) bytes")
        println("  Compresión: $(100 * (1 - reduced_size / original_size))% reducción\n")
        
    end
end

println("Vectorizando imágenes...")
data_matrix = flatten_images(processed_images)
k=7
println("Dimensiones de la matriz de datos: ", size(data_matrix))

println("Aplicando PCA...")
reduced_data, mean_vector, principal_components = apply_pca(data_matrix, k)
println("Dimensiones de los componentes principales: ", size(principal_components))
println("Dimensiones de los datos reducidos: ", size(reduced_data))
println("Dimensiones de la media: ", size(mean_vector))

println("Reconstruyendo imágenes y guardando resultados...")
reconstruct_and_save_PCA(processed_images, reduced_data, mean_vector, principal_components, "./fig/img_out/PCA")

println("Imágenes reducidas guardadas")
