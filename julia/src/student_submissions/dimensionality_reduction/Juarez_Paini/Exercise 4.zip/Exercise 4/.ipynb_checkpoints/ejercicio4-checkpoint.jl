using Images
using FileIO
using ImageIO
using Plots
using LinearAlgebra

#Instrucciones:
#1.Recolecta un conjunto de entre 5 y 10 imágenes con dimensiones de al menos [512, 512] píxeles para realizar reducción de dimensionalidad.
#2.Puedes utilizar fotos de tu familia, amigos, mascotas, etc.
#3.Aplica PCA o SVD utilizando los lenguajes Go o Julia.
#4.Obtendrás puntos extra si implementas el ejercicio en ambos lenguajes (Go y Julia).
#5.Si realizas ambas implementaciones, envíalas como entregas separadas con los siguientes nombres:
	#a)Exercise4JL para la implementación en Julia.
	#b)Exercise4GO para la implementación en Go.
#6.Presenta tu proyecto cumpliendo con las pautas de entrega establecidas.

function FindSVD( M::Matrix )
	F = svd( M )
	return F
end
 
function PrintSVDInfo( F::SVD )
	println("PrintSVDInfo")
	println("F.U  Info: Type = ", typeof(F.U),  "  size=", size(F.U))
	println("F.S  Info: Type = ", typeof(F.S),  "  size=", size(F.S))
	println("F.V  Info: Type = ", typeof(F.V),  "  size=", size(F.V))
	println("F.Vt Info: Type = ", typeof(F.Vt), "  size=", size(F.Vt))
end
 
function FindApproxImg(F::SVD)
	k = 5
	M = F.U[:, 1:k] * Diagonal(F.S[1:k]) * F.V[:, 1:k]'
	M = abs.( M .* 0.99)
	println("M Info: Type = ", typeof(M), "  size=", size(M))
	save("Aprox5.jpg", M)
 
	k = 50
	M = F.U[:, 1:k] * Diagonal(F.S[1:k]) * F.V[:, 1:k]'
	M = abs.( M .* 0.99)
	println("M Info: Type = ", typeof(M), "  size=", size(M))
	save("Aprox50.jpg", M)
 
	k = 100
	M = F.U[:, 1:k] * Diagonal(F.S[1:k]) * F.V[:, 1:k]'
	M = abs.( M .* 0.99)
	println("M Info: Type = ", typeof(M), "  size=", size(M))
	save("Aprox100.jpg", M)

	k = 300
	M = F.U[:, 1:k] * Diagonal(F.S[1:k]) * F.V[:, 1:k]'
	M = abs.( M .* 0.99)
	println("M Info: Type = ", typeof(M), "  size=", size(M))
	save("Aprox400.jpg", M)
end
 
function CreateArrayFromImgFile(filename::String)
    img = load(filename)
    gray_img = Gray.(img)
    matrix = convert(Matrix{Float64}, gray_img)
    return matrix
end

function PlotNormalizedSum(sv::Vector{Float32}, output_filename::String, k::Int)
    normalized_cumsum = cumsum(sv) ./ sum(sv)
    plot(1:length(normalized_cumsum), normalized_cumsum,
         label="Normalized Cumsum",
         xlabel="Index",
         ylabel="Normalized Cumulative Sum",
         title="Normalized Sum for k = $k",
         legend=:bottomright)
    savefig(output_filename)
    println("Plot saved to $output_filename")
end

function PlotNormalizedSumgsOfAppoxImgs()
	xImg = CreateArrayFromImgFile("Aprox5.jpg")
	println("Size of Jasiu K=5 Img=", size(xImg))
	F = FindSVD( xImg )
	sv =  convert( Vector{Float32}, F.S)
	PlotNormalizedSum( sv, "NormalizedSum5.png", 5)
 
	xImg = CreateArrayFromImgFile("Aprox50.jpg")
	println("Size of Jasiu K=50 Img=", size(xImg))
	F = FindSVD( xImg )
	sv =  convert( Vector{Float32}, F.S)
	PlotNormalizedSum( sv, "NormalizedSum50.png", 50)
 
	xImg = CreateArrayFromImgFile("Aprox100.jpg")
	println("Size of Jasiu K=100 Img=", size(xImg))
	F = FindSVD( xImg )
	sv =  convert( Vector{Float32}, F.S)
	PlotNormalizedSum( sv, "NormalizedSum100.png", 100)
end


bFile = "img1.jpg"
img0 = load(bFile)
img1 = Gray.(img0)
img2 = convert( Matrix{Float64}, img1)
F = FindSVD( img2 )

PrintSVDInfo(F)

FindApproxImg(F)

#PlotNormalizedSumgsOfAppoxImgs()