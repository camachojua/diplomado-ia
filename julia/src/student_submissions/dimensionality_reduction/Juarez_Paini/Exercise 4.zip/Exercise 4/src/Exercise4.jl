using Images, LinearAlgebra

function FindSVD( M::Matrix )
	F = svd( M )
	return F
end
 
function PrintSVDInfo( F::SVD )
	println("PrintSVDInfo")
	println("F.U  Info: Type = ", typeof(F.U),  "  size=", size(F.U))
	println("F.S  Info: Type = ", typeof(F.S),  "  size=", size(F.S))
	println("F.V  Info: Type = ", typeof(F.V),  "  size=", size(F.V))
	println("F.Vt Info: Type = ", typeof(F.Vt), "  size=", size(F.Vt))
end

function FindApproxImg(F::SVD)
	k = 10
	M = F.U[:, 1:k] * Diagonal(F.S[1:k]) * F.V[:, 1:k]'
	M = abs.( M .* 0.99)

	save("Aprox10.jpg", M)
 
	k = 50
	M = F.U[:, 1:k] * Diagonal(F.S[1:k]) * F.V[:, 1:k]'
	M = abs.( M .* 0.99)

	save("Aprox50.jpg", M)
 
	k = 100
	M = F.U[:, 1:k] * Diagonal(F.S[1:k]) * F.V[:, 1:k]'
	M = abs.( M .* 0.99)

	save("Aprox100.jpg", M)

	k = 400
	M = F.U[:, 1:k] * Diagonal(F.S[1:k]) * F.V[:, 1:k]'
	M = abs.( M .* 0.99)

	save("Aprox400.jpg", M)
end

File = "TestImage.jpg"
TestImage = load(File)
TestImageGray = Gray.(TestImage)
TestImageGrayMatrix = convert( Matrix{Float64}, TestImageGray)
F = FindSVD( TestImageGrayMatrix )

PrintSVDInfo(F)

FindApproxImg(F)