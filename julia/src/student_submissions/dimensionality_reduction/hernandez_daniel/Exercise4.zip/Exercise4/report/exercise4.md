# Reporte de ejercicio 4
Hernández Vela Daniel

```julia
function svd_pca_image(img_path, factor)
    img = load(img_path)
    img_channels = channelview(img)
    compressed_image = zeros(Float32, size(img_channels))
    
    for c in 1:size(img_channels, 1)
        img_svd = svd(float(img_channels[c, :, :]))
        U, S, V = img_svd.U, img_svd.S, img_svd.V
        num_sv = size(S)[1]
        use_sv = fld(num_sv, factor)
        
        for i in 1:use_sv
            compressed_image[c, :, :] += S[i] * U[:, i] * V[:, i]'
        end
    end
    
    compressed_image = clamp01nan.(compressed_image)
    colorview(RGB, N0f8.(compressed_image))
end
```

La función toma dos parámetros: img_path, que es la ruta de la imagen que se va a procesar, y factor, que determina la cantidad de valores singulares.

A continuación se describe el proceso de SVD:

1. La función comienza cargando la imagen desde la ruta especificada usando `load()`.

2. Se convierte la imagen en una vista de canales con `channelview()`, lo que permite trabajar con cada canal de color por separado.

3. Se crea una matriz vacía compressed_image del mismo tamaño que img_channels para almacenar la imagen comprimida. Esta matriz se inicializa con ceros y se especifica que los elementos serán de tipo Float32.

4. La función itera sobre cada canal de color de la imagen usando un bucle for. Para cada canal, se utiliza la función `svd()` Esto descompone el canal en tres matrices: U, S y V.

5. Se determina el número de valores singulares num_sv y se calcula cuántos de estos valores se usarán para la compresión con `fld()`.

6. Se reconstruye el canal comprimido sumando los productos de los valores singulares seleccionados y las columnas correspondientes de U y V. Esto se hace dentro de otro bucle for que itera desde 1 hasta use_sv.

7. La función `clamp01nan.()` asegura que los valores de la imagen comprimida estén en el rango [0, 1].

8. Finalmente, se convierte la imagen comprimida a un formato de color adecuado con `colorview()`.

Este proceso se realiza tres veces para cada imagen, eligiendo diferentes factores (25, 50, 100), cada imágen original se encuentra en `dat` y los resultados se encuentran en `fig`.

## Resultados

Se puede observar que con una mayor cantidad de valores singulares se obtiene una imagen menos detallada, mientas que al disminuir los valores singulares la imagen pierde menos información.

- Para 100 valores singulares en la mayoría de los casos la pérdida de información es importante y puede llegar a ser complicado incluso para el  ojo humano reconocer los detalles.
- Para 50 valores singulares si puede llegar a ser agresiva la pérdida de información, sin embargo, los detalles más relevantes tienden a preservarse, por lo que es un nivel de compresión interesante.
- para 25 valores singulares se observa que el detalle en las imagenes se preserva en su mayoría, por lo que no se pierde demasiada información, sin embargo, el proceso puede llegar a ser bastante más tardado que en valores más altos.