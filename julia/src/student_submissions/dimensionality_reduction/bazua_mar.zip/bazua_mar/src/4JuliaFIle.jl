using DataFrames, CSV, FileIO, ImageIO, ImageMagick, Colors, LinearAlgebra , Glob, Plots

# Mostrar la imagen original y la comprimida
function mostrar_imagen_simple(ruta::String, titulo::String)
    img = load(ruta)  # Carga la imagen desde la ruta
    p = plot(img, legend=false, axis=false, grid=false, title=titulo)
    display(p)  # Muestra la imagen en el reporte
end

function compress_images(input_folder::String, output_folder::String, k::Int)
    # Crear la carpeta de salida si no existe
    isdir(output_folder) || mkdir(output_folder)

    # Listar todas las imágenes en la carpeta de entrada
    image_files = glob("*.jpeg", input_folder)

    for img_file in image_files
        # Cargar la imagen
        img0 = load(img_file)
        # Convertir la imagen a escala de grises
        img_gray = Gray.(img0)
        # Convertir la imagen a matriz de tipo Float64
        img_matrix = Float64.(img_gray)
        # Realizar la descomposición SVD
        F = svd(img_matrix)
        # Recuperar la imagen con las primeras k componentes
        approx_img_matrix = F.U[:, 1:k] * Diagonal(F.S[1:k]) * F.Vt[1:k, :]
        # Convertir la matriz de nuevo a imagen
        approx_img = reinterpret(Gray{Float64}, approx_img_matrix)
        # Construir el nombre del archivo de salida
        img_name = splitext(basename(img_file))[1]  # Obtener nombre base sin extensión
        output_file = joinpath(output_folder, "approx_$img_name.jpeg")
        # Guardar la imagen aproximada
        save(output_file, approx_img)

        # Mostrar antes vs despues
        mostrar_imagen_simple(img_file, "Antes")
        mostrar_imagen_simple(output_file, "Despues")
    end

end

# Ejecucion
input_folder = "/Users/marbazua/Documents/Diplomado/Mar_Bazua/dimensionality_reduction/bazua_mar/dat"
output_folder = "/Users/marbazua/Documents/Diplomado/Mar_Bazua/dimensionality_reduction/bazua_mar/fig"
k = 100

compress_images(input_folder, output_folder, k) 