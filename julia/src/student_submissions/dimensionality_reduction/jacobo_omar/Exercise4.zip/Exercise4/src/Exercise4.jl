using DataFrames, CSV, FileIO, LinearAlgebra, Plots, Images

path = pwd()
path = path[1:length(path)-3]
path = "$path" * "fig/"
images_names = ["1", "2", "3", "4", "5"]
println(path)

function compress_image(path, names, k)
    outs = String[]
    for name in names
        # Cragar la imágen
        file = path * name * ".jpg"
        img = load(file)
        # Pasarla a escala de grises
        img_gray = Gray.(img)
        # Convertirla a una matriz
        img_matrix = convert(Matrix{Float64}, img_gray)
        # Se aplica SVD y las primeras k componentes
        F = svd(img_matrix)
        M = F.U[:, 1:k] * Diagonal(F.S[1:k]) * F.Vt[1:k, :]
        imagef = colorview(Gray, M)
        out_file = path * name * "_K_$k" * ".jpg"
        # Guardar las imagenes generadas
        println(out_file)
        save(out_file, imagef)
        push!(outs, out_file)
    end
    return outs
end

images_generated = compress_image(path, images_names, 10)
for file in images_generated
    img = FileIO.load(file)
    display(img)
end

images_generated = compress_image(path, images_names, 50)
for file in images_generated
    img = FileIO.load(file)
    display(img)
end