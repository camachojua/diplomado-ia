using Images
using ImageIO
using ImageTransformations
using Colors
using Plots
using LinearAlgebra
using Statistics

# Set the backend for Plots.jl to GR for better compatibility
gr()

# Function to Process a Single Image
function process_single_image(file_path::String, target_size::Tuple{Int, Int})
    # Step 1: Load the Image
    img = load(file_path)
    println("Image loaded successfully from '$file_path'.")

    # Step 2: Convert Image to Grayscale
    img_gray = Gray.(img)
    
    # Step 3: Resize the Image
    img_resized = imresize(img_gray, target_size)
    
    # Step 4: Normalize Pixel Values to [0, 1]
    img_normalized = Float64.(img_resized) ./ maximum(img_resized)
    println("Pixel values normalized to the [0, 1] range.")
    
    # Step 5: Flatten the Image into a Vector
    img_vector = vec(img_normalized)
    println("Image flattened into a vector of length $(length(img_vector)).")
    
    return img_vector
end

# Define the directory containing images
image_dir = "dat/"
save_pth = "fig/"

# List of image filenames
image_filenames = ["O1.jpeg", "O2.jpeg", "O3.jpeg", "O4.jpeg", "O5.jpeg"]

# Construct full file paths
image_paths = [joinpath(image_dir, fname) for fname in image_filenames]

# Define the target size (width, height)
target_dimensions = (512, 512)

# Initialize an empty array to store flattened image vectors
# Each column corresponds to an image
println("\nProcessing multiple images...")
image_matrix = []

for path in image_paths
    if !isfile(path)
        error("Image file does not exist: $path")
    end
    img_vector = process_single_image(path, target_dimensions)
    # Stack as columns
    if isempty(image_matrix)
        image_matrix = reshape(img_vector, :, 1)
    else
        image_matrix = hcat(image_matrix, img_vector)
    end
    println()  # For better readability
end

println("All images processed. Image matrix size: ", size(image_matrix))

# Mean Centering
println("\nMean centering the data...")
mean_image = mean(image_matrix, dims=2)
centered_matrix = image_matrix .- mean_image
println("Mean centering completed.")

# Perform Singular Value Decomposition (SVD)
println("\nPerforming Singular Value Decomposition (SVD)...")
U, S, V = svd(centered_matrix)
println("SVD completed.")

# Select Top k Components
k = 2  # Number of principal components to retain
max_k = size(U, 2)
if k > max_k
    println("Requested k=$k exceeds the maximum number of available components ($max_k). Setting k=$max_k.")
    k = max_k
end

U_k = U[:, 1:k]
S_k = S[1:k]
V_k = V[:, 1:k]

println("Selected top $k principal components.")

# Project Data onto Principal Components
println("\nProjecting data onto the top $k principal components...")
projected_data = U_k' * centered_matrix
println("Data projected successfully.")

# Reconstruct the Images Using Selected Principal Components
println("\nReconstructing images using the selected principal components...")
reconstructed_matrix = U_k * Diagonal(S_k) * V_k' .+ mean_image
println("Image reconstruction completed.")

# Plot Singular Values
println("\nPlotting singular values...")
singular_values_plot = plot(
    1:length(S),
    S,
    xlabel="Component",
    ylabel="Singular Value",
    title="Singular Values",
    marker=:circle,
    linewidth=2
)
savefig(singular_values_plot, joinpath(save_pth, "singular_values.png"))
println("Singular values plot saved as 'singular_values.png' in '$image_dir' directory.")

# Calculate and Plot Cumulative Explained Variance
println("\nCalculating cumulative explained variance...")
explained_variance = (S .^ 2) ./ sum(S .^ 2)
cumulative_variance = cumsum(explained_variance)

println("Plotting cumulative explained variance...")
cumulative_variance_plot = plot(
    1:length(cumulative_variance),
    cumulative_variance,
    xlabel="Number of Components",
    ylabel="Cumulative Explained Variance",
    title="Cumulative Explained Variance by Components",
    marker=:circle,
    linewidth=2
)
savefig(cumulative_variance_plot, joinpath(save_pth, "cumulative_variance.png"))
println("Cumulative explained variance plot saved as 'cumulative_variance.png' in '$image_dir' directory.")

# Display Explained Variance for Each Component
println("\nExplained Variance by Each Principal Component:")
for i in 1:length(explained_variance)
    println("Component $i: $(round(explained_variance[i] * 100, digits=2))%")
end

# Visualize Original and Reconstructed Images
println("\nVisualizing all original and reconstructed images...")

# Define a layout with 5 rows and 2 columns (Original vs Reconstructed)
p = plot(
    layout = (5, 2),
    size = (1600, 2000),
    title = "Original vs Reconstructed Images"
)
for i in 1:length(image_filenames)
    # Reshape the original and reconstructed vectors back to image dimensions
    original_image = reshape(image_matrix[:, i], target_dimensions)
    reconstructed_image = reshape(reconstructed_matrix[:, i], target_dimensions)    
    # Plot the original image
    plot!(p[2i-1],
        original_image,
        seriestype = :heatmap,
        color=:grays,
        title="Original Image $(i)",
        axis=false
    )
    
    # Plot the reconstructed image
    plot!(p[2i],
        reconstructed_image,
        seriestype = :heatmap,
        color=:grays,
        title="Reconstructed Image $(i) (k=$k)",
        axis=false
    )
end

# Save the comparison plot
savefig(p, joinpath(save_pth, "all_original_vs_reconstructed.png"))
println("All original vs reconstructed images saved as 'all_original_vs_reconstructed.png' in '$image_dir' directory.")
