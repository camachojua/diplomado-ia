# Dimensionality Reduction Report

## **Overview**

This report presents the methodology and results of a dimensionality reduction analysis conducted on a collection of high-resolution images. Utilizing Principal Component Analysis (PCA) via Singular Value Decomposition (SVD) in Julia, the objective was to reduce the dimensionality of image data while preserving significant features. The analysis involved processing a set of 5 high-resolution images, applying PCA/SVD, and visualizing the effects of dimensionality reduction through reconstructed images and variance explanations.

## **Data Preprocessing**

### 1. **Data Acquisition**
A collection of 5 images, each with a resolution of 512x512 pixels, was selected for analysis. The images are snapshots of my cat. The images were stored in the `dat/` directory with filenames `O1.jpeg` to `O5.jpeg`.

### 2. **Image Processing Pipeline**
Each image underwent the following processing steps to prepare the data for dimensionality reduction:

#### a. **Loading Images**
- Utilized Julia's `Images` and `ImageIO` packages to load each image from the specified directory.
- Verified successful loading by confirming the image dimensions.

#### b. **Grayscale Conversion**
- Converted each loaded image to grayscale using the `Gray` color space to simplify the data and reduce computational complexity.

#### c. **Resizing**
- Resized each grayscale image to a uniform dimension of 512x512 pixels using the `imresize` function from the `ImageTransformations` package. This standardization ensures consistency across all images for accurate analysis.

#### d. **Normalization**
- Normalized pixel values to a range of [0, 1] by dividing each pixel intensity by the maximum pixel value in the image. This step facilitates numerical stability during subsequent computations.

#### e. **Flattening**
- Flattened each 2D image matrix into a 1D vector, resulting in a vector of length 262,144 (512x512). This transformation allows for the construction of a data matrix where each column represents a flattened image.

### 3. **Data Matrix Construction**
- Compiled all flattened image vectors into a single matrix (`image_matrix`), where each column corresponds to a different image.
- The resulting `image_matrix` has dimensions `[262144 x 5]`, representing the pixel data of all images.

### 4. **Mean Centering**
- Calculated the mean image vector across all images.
- Subtracted the mean vector from each image vector in the `image_matrix` to center the data. Mean centering is essential for PCA as it ensures that the principal components capture the directions of maximum variance.

## **Dimensionality Reduction**

### 1. **Singular Value Decomposition (SVD)**
- Performed SVD on the mean-centered `image_matrix` using Julia's `LinearAlgebra` package.
- Decomposed the matrix into three components: `U`, `S`, and `V`, where `U` contains the left singular vectors, `S` contains the singular values, and `V` contains the right singular vectors.

### 2. **Principal Component Selection**
- Selected the top `k=2` principal components based on the largest singular values in `S`.
- Ensured that the chosen `k` does not exceed the maximum number of available components.
  
### 3. **Data Projection**
Projected the original image data onto the selected principal components to obtain a lower-dimensional representation. This projection captures the most critical variations in the data while reducing computational complexity.

### 4. **Extra - Image Reconstruction**
Reconstructed the images from the reduced-dimensional data by reversing the projection process. This reconstruction serves to evaluate the effectiveness of the dimensionality reduction in preserving essential image information.

## **Results**

### 1. **Singular Values Plot**
A plot of singular values was generated to visualize the distribution of variance captured by each principal component.

![Singular Values](fig/singular_values.png)

**Observation:** The plot illustrates a rapid decline in singular values, indicating that the first few components capture a significant portion of the total variance in the dataset.

### 2. **Cumulative Explained Variance**
Calculated and plotted the cumulative explained variance to assess how much of the total variance is retained as more principal components are included.

![Cumulative Explained Variance](fig/cumulative_variance.png)

### 4. **Original vs. Reconstructed Images**
Visualized the original and reconstructed images side-by-side to evaluate the fidelity of the reconstruction from the reduced-dimensional data.

![Original vs Reconstructed Images](fig/all_original_vs_reconstructed.png)

**Observation:** The reconstructed images retain the essential features and overall structure of the original images despite the significant reduction in dimensionality. Loss of detail is observed, which is expected given the dimensionality reduction.

## **Key Findings**

1. **Effective Dimensionality Reduction:**
   - The application of PCA/SVD successfully reduced the dimensionality of high-resolution images from 262,144 pixels to just 2 principal components.

2. **Variance Concentration:**
   - A substantial portion of the variance was captured by the first two principal components, indicating that the most critical information in the images is concentrated in these dimensions.

3. **Image Reconstruction Fidelity:**
   - Reconstructed images closely resemble the original images, demonstrating that the dimensionality reduction process preserves essential visual information despite the loss of some details.

4. **Computational Efficiency:**
   - Reducing the dimensionality significantly decreases the computational resources required for storage and processing, facilitating more efficient handling of large image datasets.

5. **Potential for Further Applications:**
   - The reduced-dimensional representations can be effectively used in downstream tasks such as image classification, clustering, and retrieval, enabling faster and more scalable machine learning workflows.

## **Conclusion**

The dimensionality reduction analysis on high-resolution images utilizing PCA/SVD in Julia proved to be highly effective. By reducing the data from 262,144 dimensions to just 2 principal components, the analysis retained most of the original variance, ensuring that the most significant features of the images were preserved. The reconstructed images affirmed the fidelity of the reduction process, maintaining essential visual elements necessary for recognition and interpretation.

This reduction not only enhances computational efficiency but also opens avenues for advanced image processing and machine learning applications. Future work may explore the optimal number of principal components required for different levels of variance retention and the impact of dimensionality reduction on various image-based tasks.

---

**Note:** All plots and reconstructed images generated from this analysis are saved in the `fig/` directory for further reference and visualization.
