using CSV, DataFrames

#1. Get the Churn_Modelling.csv data that was used to demonstrate the GLM package. The data is available at  https://github.com/selva86/datasets/tree/master
#Uploading the Churn data set:
cd("/Users/zoe/drv3/hm3/code/julia/hmw_diplo")
churn = CSV.read("Exercise5/dat/Churn_Modelling.csv", DataFrame, delim=',', header=true)

#2. Following the steps shown during the session:

using PlotlyJS
using MLBase
using CSV
using DataFrames
using Statistics
using Printf
using PlotlyJS
using NamedArrays
using Random
using GLM
using StatsBase

using GLMNet
using LinearAlgebra
using LIBSVM
using Distances
using DataStructures
using DecisionTree
using MLBase
using NearestNeighbors
using EvalMetrics
using ROCAnalysis
# Cleaning data
##describing the data set
describe(churn)
##keeping only with valuable data: reason, while trying to predict a value we really don't care about surname, the id of the customer or the index...
churn = select(churn, Not([:RowNumber,:CustomerId,:Surname]))
describe(churn)


#=Preparing data for being analyzed, again we need data to be label-encoded
do not confuse this label-enconding with one-hot-encoding, one hot requeries to have 
a "binary" array to describe a features ie matrix when the categories in the Cat columns
are >2 ...
=#

# Making a function to label mapping categorical data:

#including my tools to clean data:
include("/Users/zoe/drv3/hm3/code/julia/hmw_diplo/Exercise1/src/ExerciseN1.jl")

function labelEncoder(DataFrame)

    for i in stringCols(DataFrame)
        vec = DataFrame[!, Symbol(i)]
        en_vec = labelencode(labelmap(vec), vec)
        DataFrame[!, Symbol(i)] = en_vec
    end
    
end

labelEncoder(churn)
describe(churn)

#looking at heatmap
p = displayCorrelation(churn)
# savefig(p, "Exercise5/fig/cor_churn.png")
##it seems that Age, Geography, isActiveMember, Balance,  and Gender have an abs(cor) >10%!

#cleaning IQR
# iqrchurn = removeOutliersIQR(churn)
# describe(iqrchurn) #still having 70% of data, which is great
## note: while doing some testing I catched that the 1's in :Exited were actually "outliers" for the DataFRame, so I'm not working with this DataFRame...

#perfect, now everithing is a Int or a Float, so we can play with numbers and vectors and matrix!

#= 2.1 Flux:
So in this case I'll train a model that tries to predict the "Exited" state
=#

using Pkg
using Flux, Statistics, ProgressMeter, Plots, Random, CUDA, cuDNN
# pkgversion(Flux) - v"0.16.0", in case is useful, as I've seen the documentation is laking in the package...

# Shaping data to got it in the shape Flux need it:
X = Matrix(select(churn, Not(:Exited)))'  .|> Float32 # Transponer para tener features en filas
y = Vector(churn[!, :Exited]) .|> Float32  # Target

# normalizing data:
# this to reduce the risk of large, unstable gradients or vanishing/exploding gradients!
X = (X .- mean(X, dims=2)) ./ std(X, dims=2)

#let's calculate X's length
X_l = size(X)[2]
## shuffling indexes to get samples from X an Y:
index_train = Random.shuffle(1:X_l)[1:floor(Int, 0.75*X_l)]
index_test = setdiff(1:X_l, index_train)

#Setting the train and test sets:
X_train = X[:, index_train]
Y_train = y[index_train]

X_test = X[:, index_test]
y_test = y[index_test]

#= Creating a model:
Creating a model with Flux isn't a challenging task
but some considerations have to be taken:
If the features are N, then the first layer have to be of N layers
you can add as many dense layers as your unit (PC) supports
If the output to predict is a binary then the last layer most be 1
Else it has to be equal to the size of labels to predict

In this case, we have 10 features and a binary output:
=#

# Selected Model
model = Chain(
    Dense(size(X', 2) => 20, tanh),  # Capa oculta con activación ReLU
    Dense(20 => 1, sigmoid)
) |> gpu

#= 
I've chosen leakyrelu as the activation function of the 
first layer

I've chosen softsign as the activation function of the 
last layer
=#

#############

#the loss function we're going to use in this case is logitbinarycrossentropy, as we're going to predict binary values
using Flux: logitbinarycrossentropy
loss(model, x, y) = logitbinarycrossentropy(vec(model(x)), y)

#the optimizer in this case is going to be ADAM with a learning rate of 0.0005
lr = 0.0005
opt = ADAM(0.0005)

#reshaping the data:
data = [(X_train, Y_train)]

# selecting the epochs to train the model:
for epoch in 1:1000
    Flux.train!(loss, model, data, opt)
    if epoch % 500 == 0 # take a loot every 500 steps
    println("Epoch $epoch - Loss: ", loss(model, X_train, Y_train)) 
    end
end

prediction = (model(X_test) .>= 0.5)[1, :] .|> Bool

using EvalMetrics

#Printing the confusion matrix for the data:
println("The confusion matrix of the model looks like this: ")
display(ConfusionMatrix(Int64.(y_test), prediction);)
acc_Flux = accuracy(ConfusionMatrix(Int64.(y_test), prediction))
println("The accuracy of the model is: $(acc_Flux)")


#calculating the ROC curve:
function dfROC(y_observable, y_calc)

    #sorting probabilities and indexes
    sorted_indices = sortperm(vec(y_calc), rev=true)
    y_obs_sort= vec(y_observable[sorted_indices])
    n_pos = sum(y_observable)
    n_neg = length(y_observable) - n_pos
    
    #calculating ROC curve
    tp, fp = 0, 0
    tpr = Float64[]
    fpr = Float64[]
    
    y_l = length(y_obs_sort)
    
    for i in 1:y_l
        if y_obs_sort[i] == 1
            tp += 1
        else
            fp += 1
        end
        push!(tpr, tp/n_pos)
        push!(fpr, fp/n_neg)
    end
    
    #defining the DF

    df = DataFrame(FPR = fpr, TPR = tpr)
    df.FPR = Float64.(df.FPR)
    df.TPR = Float64.(df.TPR)
    
    return df
end

#the DF for the ROC curve is like follows:
ROCdf = dfROC(Int64.(y_test), prediction)

#Plotting ROC curve

#this value is going to be needed to plot a line in plotlyJL
t = 0:0.01:1 
fpr = ROCdf.FPR
tpr = ROCdf.TPR
# Calculating the AUC value:
auC = 0.0
for i in 1:length(fpr)-1
    auC += (fpr[i+1] - fpr[i]) * (tpr[i+1] + tpr[i]) / 2
end

p = plot([
    PlotlyJS.scatter(x = ROCdf.FPR , y = ROCdf.TPR, name = "ROC curve"),
    PlotlyJS.scatter(x = t, y = t, name = "reference curve")
    ], 
    Layout(
        autosize=false,
        width=700,
        height=500,
        title = "ROC Curve, AUC:$(round(auC, digits = 3))",
        xlabel = "TPR",
        ylabel = "FPR"
    )
)

savefig(p, "Exercise5/fig/ROC_churn_flux.png")
display(p)
####################################

#= 2.2 GLM:
So in this case I'll train a model that tries to predict the "Exited" state
=#

using GLM, GLMNet, GLMakie

#uploading the df again:
cd("/Users/zoe/drv3/hm3/code/julia/hmw_diplo")
churn = CSV.read("Exercise5/dat/Churn_Modelling.csv", DataFrame, delim=',', header=true)

#2. Following the steps shown during the session:

# Cleaning data
##keeping only with valuable data: reason, while trying to predict a value we really don't care about surname, the id of the customer or the index...
churn = select(churn, Not([:RowNumber,:CustomerId,:Surname]))
describe(churn)

#label encoding categorical columns
labelEncoder(churn)
describe(churn)



#selecting non-target variables:
function termnsSymbol(DataFrame, target::Symbol)
    
    selected_columns = names(DataFrame)
    selected_columns = filter(x -> x != string(target), selected_columns)
    
    return sum(Term.(Symbol.(selected_columns)))

end

#setting a random index:
DFs = size(churn)[1]
index_train = Random.shuffle(1:DFs)[1:floor(Int, 0.75*DFs)]
index_test = setdiff(1:DFs, index_train)

#setting the training and test data:
churn_test = churn[index_test, :]
churn_train = churn[index_train, :]

#let's choose a p value of 0.05!
LRmod = glm(Term(:Exited) ~ termnsSymbol(churn_train, :Exited), churn_train, Binomial(), ProbitLink())

#=notes:
by looking at the P value, the columns: 

:Tenure
:NumOfProducts
:HasCrCard
:EstimatedSalary

are non-significant
=#

#let's evaluate the model and then see how it performs without those columns:
y_prob = GLM.predict(LRmod, churn_test)
y_pred = (y_prob .>= 0.5) .|> Bool

y_true = churn_test.Exited

#Printing the confusion matrix for the data:
println("The confusion matrix of the model looks like this: ")
display(ConfusionMatrix(Int64.(y_true), y_pred);)
acc_GLM = accuracy(ConfusionMatrix(Int64.(y_true), y_pred))
println("The accuracy of the model is: $(acc_GLM)")

#the DF for the ROC curve is like follows:
ROCdf = dfROC(Int64.(y_true), y_pred)


#Plotting ROC curve
#this value is going to be needed to plot a line in plotlyJL
t = 0:0.01:1 
fpr = ROCdf.FPR
tpr = ROCdf.TPR
# Calculating the AUC value:
auC = 0.0
for i in 1:length(fpr)-1
    auC += (fpr[i+1] - fpr[i]) * (tpr[i+1] + tpr[i]) / 2
end

p = plot([
    PlotlyJS.scatter(x = ROCdf.FPR , y = ROCdf.TPR, name = "ROC curve"),
    PlotlyJS.scatter(x = t, y = t, name = "reference curve")
    ], 
    Layout(
        autosize=false,
        width=700,
        height=500,
        title = "ROC Curve, AUC:$(round(auC, digits = 3))",
        xlabel = "TPR",
        ylabel = "FPR"
    )
)

savefig(p, "Exercise5/fig/ROC_churn_GLM.png")
display(p)

######################################### pt2 evaluating the model without non-significant parameters:

cd("/Users/zoe/drv3/hm3/code/julia/hmw_diplo")
churn = CSV.read("Exercise5/dat/Churn_Modelling.csv", DataFrame, delim=',', header=true)

#2. Following the steps shown during the session:

# Cleaning data
##keeping only with valuable data: reason, while trying to predict a value we really don't care about surname, the id of the customer or the index...
churn = select(churn, Not([:RowNumber,:CustomerId,:Surname]))
churn = select(churn, Not([:Tenure,:NumOfProducts,:HasCrCard,:EstimatedSalary]))
describe(churn)

#label encoding categorical columns
labelEncoder(churn)
describe(churn)

#setting a random index:
DFs = size(churn)[1]
index_train = Random.shuffle(1:DFs)[1:floor(Int, 0.75*DFs)]
index_test = setdiff(1:DFs, index_train)

#setting the training and test data:
churn_test = churn[index_test, :]
churn_train = churn[index_train, :]

#let's choose a p value of 0.05!

LRmod = glm(Term(:Exited) ~ termnsSymbol(churn_train, :Exited), churn_train, Binomial(), ProbitLink())

#let's evaluate the model and then see how it performs without those columns:
y_prob = GLM.predict(LRmod, churn_test)
y_pred = (y_prob .>= 0.5) .|> Bool

y_true = churn_test.Exited

#Printing the confusion matrix for the data:
println("The confusion matrix of the model looks like this: ")
display(ConfusionMatrix(Int64.(y_true), y_pred);)
pred_enhaced = accuracy(ConfusionMatrix(Int64.(y_true), y_pred))
println("The accuracy of the model is: $(pred_enhaced)")

#the DF for the ROC curve is like follows:
ROCdf = dfROC(Int64.(y_true), y_pred)



#Plotting ROC curve
#this value is going to be needed to plot a line in plotlyJL
t = 0:0.01:1 
fpr = ROCdf.FPR
tpr = ROCdf.TPR
# Calculating the AUC value:
auC = 0.0
for i in 1:length(fpr)-1
    auC += (fpr[i+1] - fpr[i]) * (tpr[i+1] + tpr[i]) / 2
end

p = plot([
    PlotlyJS.scatter(x = ROCdf.FPR , y = ROCdf.TPR, name = "ROC curve"),
    PlotlyJS.scatter(x = t, y = t, name = "reference curve")
    ], 
    Layout(
        autosize=false,
        width=700,
        height=500,
        title = "ROC Curve, AUC:$(round(auC, digits = 3))",
        xlabel = "TPR",
        ylabel = "FPR"
    )
)

savefig(p, "Exercise5/fig/ROC_churn_GLM_improved.png")
display(p)