### A Pluto.jl notebook ###
# v0.20.4

using Markdown
using InteractiveUtils

# ╔═╡ 3b3769a6-c99a-11ef-13a2-9f284abdcd87
begin
	using Pkg
	Pkg.add("DataFrames")
	Pkg.add("CSV")
	Pkg.add("Plots")
	Pkg.add("StatsPlots")
	Pkg.add("Distributions")
end

# ╔═╡ 69f6dfbf-bae5-401a-959e-6b54e37888ca
begin
	using DataFrames
	using CSV
	using Plots
	using StatsPlots
	using Distributions
end

# ╔═╡ a0a19fe4-03ba-4c34-9bbb-97d148efde9a
md"""
# Exploratory Data Analysis Report 
## Alan Eduardo Aquino Rosas

"""

# ╔═╡ d4815a66-7484-4780-b730-e5387e457a9d
md"""
Durante este reporte se realizará un análisis exploratorio de datos (EDA) al conjunto de datos CalCOFI.

El conjunto de datos CalCOFI es una de las series más largas y completas sobre datos oceanográficos y larvas de peces (1949-presente), con información de más de 50,000 estaciones. Incluye datos de abundancia de larvas, huevos de peces comerciales, y parámetros físicos, químicos y biológicos, siendo clave para estudiar ciclos climáticos, como “El Niño”, y cambios en la Corriente de California.

El conjunto de datos, para referencia futura, se puede encontrar en el siguiente enlace:
https://www.kaggle.com/datasets/sohier/calcofi?resource=download&select=cast.csv

Primero, se comenzará el EDA obteniendo insights generales de los datos para su mejor comprensión, y en caso de ser necesario, se realizará una limpieza de estos.
"""

# ╔═╡ 35a4398b-f508-4195-8b5d-ec2d4844ded8
md"""### Instalación e Inicialización de Paquetes Requeridos

Para el análisis de los datos se utilizarán los siguientes paquetes:

	1.	DataFrames
	2.	CSV
"""

# ╔═╡ b4a78d98-bc13-4dd9-bf6b-49946f45ee8b
md"""A continuación, se leerá el archivo dat/bottle.csv como un DataFrame."""

# ╔═╡ 84a23fde-722a-48f8-a047-1d67957e6b9a
df = CSV.read("../dat/bottle.csv", DataFrame)

# ╔═╡ f4d58460-eb72-4cd4-8772-b774fc99bcad
md"""Para comprobar que la lectura fue correcta, se imprimirán los últimos 10 registros del DataFrame."""

# ╔═╡ 56513f5c-d480-4d8d-a606-046fa937934b
df[end-9:end,:]

# ╔═╡ 93bef50b-871b-4a12-ac48-6c050cfc51b7
md""" #### DataShape
A continuación, se obtendrán las dimensiones de la matriz de datos.
"""



# ╔═╡ 133a13a2-9f60-4162-a17a-62d1854e902a
begin
	dataShape(dataframe) = size(dataframe)
	dataShape(df)
end

# ╔═╡ 11c6ebd2-8e10-40e1-89f6-4217d37cabff
md"""Usando la función size, podemos identificar las dimensiones del dataset con el que se trabaja, obteniendo un total de 864,863 filas (o ejemplos) y 74 columnas (o características).

Para esto utilizaremos la función describe.
"""

# ╔═╡ f44302b9-067f-4022-a118-512dc422c97e
md"""
#### DataTypes

Ahora obtendremos los tipos de datos de cada característica de nuestra matriz para su futuro análisis.

En este caso, se utilizará la función describe(). Esta función, además de indicarnos los tipos de datos de cada columna, nos proporcionará estadísticas descriptivas que serán de utilidad para el análisis de los datos.
"""

# ╔═╡ af53d265-8f13-435f-b0bd-b6b7c1a43551
begin
	dataType(dataframe) = describe(df)
	dataType(df)
end


# ╔═╡ 40cbf3bc-3902-41fc-8280-c9f2a2f11332
md"""
#### CountMissing

A continuación, se contarán los valores nulos o missing de cada columna. En caso de ser necesario, se realizará una imputación o llenado de datos."""

# ╔═╡ cb8e67a8-7add-498f-a7df-27a2d1c93c84
begin
	countMissing(dataframe, column_to_count) = count(ismissing, dataframe[!,column_to_count])

	function get_missing_values(dataframe)
		missing_values_per_column = Dict()
		return get_missing_values_rec(dataframe,1,missing_values_per_column)
	end
		
	
	function get_missing_values_rec(dataframe, i, missing_values_per_column)
		#For fun :)
		if i >= length(names(dataframe))
			return missing_values_per_column
		end
		
		column_name = names(dataframe)[i]
		missing_values_per_column[column_name] = countMissing(dataframe,column_name)
		return get_missing_values_rec(dataframe,i + 1, missing_values_per_column)
			
	end
		
	for (column_name, missing_values) in get_missing_values(df)
		println("Column: ", column_name," has: ", missing_values, " missing values")
	end
	
		
end

# ╔═╡ 97b1daf5-3157-48c9-94ca-f995c827cd3f
md"""
#### DataMissingPercentage
Se calculará el porcentaje de valores nulos de cada columna.

"""

# ╔═╡ fb36a3fe-c337-4b6a-8dca-56cff2ea644e
begin
	function getMissingPorcentagePerColumn(dataframe)
		missing_percentage_per_column = Dict()
		for (column_name, missing_values_freq) in get_missing_values(df)
			missing_percentage_per_column[column_name] = missing_values_freq/length(dataframe[!,column_name])
		end
		return missing_percentage_per_column
	end
	
	for (column_name, prob_missing) in getMissingPorcentagePerColumn(df)
		println("Column: ", column_name," has: ", prob_missing, " of missing values")
	end
	
end

# ╔═╡ 69364e6d-16b3-4715-8d30-ef65d934431c
md"""
#### DeleteColumns
Se eliminarán las columnas que no cumplan con un cierto porcentaje aceptable de valores nulos (missing).
"""

# ╔═╡ aada15d3-214a-4186-96be-1631f4a19a24
function deleteColumns(dataframe, threshold)
	for (column_name, prob_missing) in getMissingPorcentagePerColumn(dataframe)
		if prob_missing >= threshold
			println("Deleting column: ", column_name, "with prob of: ", prob_missing)
			dataframe = select(dataframe,Not(Symbol(column_name)))
		end
	end
	return dataframe
end	

# ╔═╡ e9559474-ea94-4873-946e-87a7ab0899ec
md"""En este caso, se utilizará un umbral (threshold) de 0.5."""

# ╔═╡ 959e721b-9463-45d3-a13f-3c536c52f1d1
delete_df = deleteColumns(df,0.5)

# ╔═╡ c49dab1c-fd41-45f1-b4d2-8c53532e9702
md"""
#### Procesamiento Extra
Antes de continuar con nuestro EDA, realizaremos un procesamiento adicional para obtener información relevante.
"""

# ╔═╡ fd50fffb-d240-4ade-9b3f-782a93b77239
md"""
Como primer paso, se obtendrá información relevante de la columna DepthId.

Esta variable consta de ejemplos que siguen la siguiente convención:
[Century]-[YY][MM][ShipCode]-[CastType][Julian Day]-[CastTime]-[Line][Sta][Depth][Bottle]-[Rec_Ind]

De esta columna se generarán las siguientes nuevas características:

	1.	Century
	2.	YY
	3.	MM

Se considera que estas tres características pueden proporcionar información adicional relevante para el aprendizaje y la generalización de nuestro modelo.

"""

# ╔═╡ e18be274-6511-44cc-af6c-f93618dc1b6d
begin
	regex_depth= r"^(\d{2})-(\d{2})(\d{2})"
	
	# Extract [Century], [YY], [MM] into separate columns
	delete_df[!, :Century] = parse.(Int, match.(regex_depth, delete_df.Depth_ID) .|> x -> x[1])  # First group
	delete_df[!, :YY] = parse.(Int, match.(regex_depth, delete_df.Depth_ID) .|> x -> x[2])       # Second group
	delete_df[!, :MM] = parse.(Int, match.(regex_depth, delete_df.Depth_ID) .|> x -> x[3]) # Third group
	delete_df
	
end

# ╔═╡ bc51cd57-d7a1-48a9-a799-8252f183dd86
md"""
Obteniendo las características mencionadas anteriormente de la columna DepthId, de tipo String, podemos eliminar las demás columnas que no sean numéricas, ya que no serán utilizadas para nuestro modelo. Se considera que estas columnas no aportarán información relevante adicional."""

# ╔═╡ eb976d01-a978-408f-bb6f-48c9a15c3c3d
function getDFOnlyNumerical(dataframe)
	numerical_cols = [col for col in names(dataframe) if eltype(skipmissing(dataframe[!,col]))<:Number]

	numeric_df = select(dataframe, numerical_cols)

	return numeric_df
end


# ╔═╡ 41e711dc-f821-407d-87ef-ae03bf44203c
num_df = getDFOnlyNumerical(delete_df)

# ╔═╡ 81cee0f9-207b-443c-83ce-e8f0ef910a70
md"""
#### Borrar Datos Nulos Temporalmente

Se eliminarán todos los registros del dataset que contengan un valor missing o NaN. Esto se realiza con el objetivo de obtener datos limpios y compatibles para los siguientes tres pasos, los cuales ayudarán a determinar si es posible aplicar algún método de imputación a los datos.
"""

# ╔═╡ bab149a2-22d4-4fe0-b0d4-4f6f9f5c2532
function deleteRow(dataframe::DataFrame, column_name::String)
    clean_df = filter(row -> begin
        val = row[column_name]
        !(ismissing(val) || (val isa Float64 && isnan(val)))
    end, dataframe)
    return clean_df
end

# ╔═╡ 88203b94-ad10-41b8-bdb1-0b9d45ec7815
function getDFWithoutMissingAndNan(dataframe)
	modified_df = copy(dataframe)
	for col_names in names(dataframe)
		modified_df = deleteRow(modified_df, col_names)
	end
	return modified_df
end
		

# ╔═╡ 0ac83e8e-b9bd-4fa4-9096-7a530e7464a0
df_numerical = getDFWithoutMissingAndNan(num_df)

# ╔═╡ e9a4a5fd-2360-46b5-992f-b420a77cdd57
md"""Ahora, teniendo un DataFrame limpio y sin ningún tipo de valores nulos, eliminaremos los outliers para posteriormente obtener una idea de la distribución de nuestros datos."""

# ╔═╡ 51eeaa7c-dbdf-4cdb-b20b-7211b6e86ef3
md"""
#### RemoveOutliersIQR
Debemos eliminar los outliers de cada una de nuestras características para asegurarnos de que no existan datos que impidan que nuestros modelos generalicen de manera correcta, así como eliminar datos que podrían generar ruido.
"""

# ╔═╡ 3d81eff1-7b47-4a1e-8a95-5bedf74d8857
md"""Primero, graficaremos boxplots de la matriz de datos para identificar cuáles de nuestras características podrían tener outliers."""

# ╔═╡ 10d39150-fbed-41d2-9fe1-b625770c2d43
function graphBoxPlotsDataframe(dataframe)
	box_plots = []
	for (col_name, col_data) in pairs(eachcol(dataframe))
		bp = boxplot(collect(col_data), title = "Boxplot for column $col_name")
				push!(box_plots, bp)
	end
	return box_plots
end

# ╔═╡ 27630a30-c316-4b79-88fc-fefc9a6533e7
begin
	box_plots = graphBoxPlotsDataframe(df_numerical)
	box_plots
end

# ╔═╡ 02a15cc2-137a-48ef-91b0-976cfd9aaf6c
md"""Al graficar nuestros datos, podemos observar que existen ciertas variables con un número considerable de outliers. A continuación, se procederá a eliminar los valores outliers utilizando el método IQR."""

# ╔═╡ c786a86e-e956-4eb1-af43-df9d654bc9e2
function removeOutliersIQR(original_df::DataFrame)
    # Make a copy so as not to mutate the original
    df = deepcopy(original_df) #Expensive, but i want to threat the dataframes as inmutables :(
    
    # Loop over each column in df
    for col_name in names(df)
        # Extract the column
        col_data = df[!, col_name]
		Q1 = quantile(col_data, 0.25)
		Q3 = quantile(col_data, 0.75)
		iqr_value = Q3 - Q1
		
		lower_bound = Q1 - 1.5 * iqr_value
		upper_bound = Q3 + 1.5 * iqr_value
                
                # Filter in place: remove rows where col_name is outside the bounds
                df = filter(row ->lower_bound ≤ row[col_name] ≤ upper_bound, df)
    end
    return df
end

# ╔═╡ c702ac3d-4016-4905-8fce-66e9e0db1ae9
begin
	df_without_outliers  = removeOutliersIQR(df_numerical)
	df_without_outliers
end

# ╔═╡ 3a83b7ac-39ee-430a-afa7-be9495c1543f
md"""#### Graficación de Histogramas/QQ-Plots y Determinación de Imputación

Ahora se graficarán los histogramas de cada una de las características de nuestro dataset para determinar si alguna sigue una distribución específica. Asimismo, se realizarán QQ-plots, considerando como distribución ideal la normal, para identificar si existe una mejor manera de manejar los datos nulos o missing.

Es importante considerar que, debido a la naturaleza del dataset, existe una alta probabilidad de que los valores faltantes se deban a MCAR (Missing Completely at Random) o MAR (Missing at Random), por lo que explorar la opción de imputar los datos resulta viable.

Por ejemplo:
Si notamos en nuestros histogramas y QQ-plots que alguna variable sigue una distribución normal, podríamos imputar los datos faltantes de esa variable utilizando el valor de la media de dicha característica, ya que este es el valor con la mayor probabilidad de aparecer. También sería posible utilizar métodos más avanzados de imputación, como KNN imputación o incluso entrenar un modelo para completar estos datos. Sin embargo, debido al alcance de este reporte, estas técnicas no se explorarán en detalle.
"""

# ╔═╡ 91a94a6e-1dab-4e70-83f9-94393034ae50
function graphDataframeHistograms(dataframe)
	histograms = []
	for (col_name, col_data) in pairs(eachcol(dataframe))
			hist = histogram(collect(col_data), title = string("Histograma de ",col_name), xlabel = string(col_name), bins = 18)
			push!(histograms, hist)
	end
	return histograms
end

# ╔═╡ 0060f7bf-b7ca-4010-bb7f-a707fef5d7f2
begin
	gr()
	histograms = graphDataframeHistograms(df_without_outliers)
	histograms
end

# ╔═╡ 1057ac78-5d3d-48ea-9634-715dec57273c
md"""
#### QQ-Plot Test para Verificar Normalidad

Al analizar visualmente, no encontramos ninguna característica que siga una distribución normal. Para corroborar esto, se graficarán los QQ-plots de cada una de las características.

También se podrían realizar pruebas estadísticas, como el Shapiro-Wilk Test y el Kolmogorov-Smirnov Test, para confirmar los resultados.
"""

# ╔═╡ 1fc48e6f-2af3-4762-a1f9-5f36c3a205ce
function graphDataframeQQPlots(dataframe)
	qq_plots = []
	for (col_name, col_data) in pairs(eachcol(dataframe))
			qq = qqplot(collect(col_data), Normal(0, 1), title=string("Q-Q Plot for ", col_name), xlabel="Theoretical Quantiles", ylabel="Sample Quantiles")
			push!(qq_plots, qq)
	end
	return qq_plots
end

# ╔═╡ 09335053-5f79-4699-b657-eaa742f37d15
begin
	qq_plots = graphDataframeQQPlots(df_without_outliers)
	qq_plots
end

# ╔═╡ 718957fd-c2ef-4468-afec-5f2222506ecf
md"""Al graficar los QQ-plots, podemos observar que ninguna variable sigue una distribución normal. Por lo tanto, no se realizará ningún tipo de imputación especial; únicamente se mantendrá el dataset con los registros que no tienen valores missing ni NaN.

A continuación, se procederá con el cálculo de las correlaciones."""

# ╔═╡ 9f8196b4-9774-4262-a262-eb2b2f90d067
md"""#### CalculateCorrelation

Se calculará la correlación de todas las variables de nuestra matriz de datos para identificar si existe algún tipo de dependencia entre las variables independientes. Esto será de utilidad al momento de realizar regresiones y clasificaciones.

Esto se debe a que, para que algunos métodos estadísticos funcionen de manera óptima, es necesario que los datos cumplan con ciertos supuestos.

Entre estos supuestos, se encuentra que no existan correlaciones significativas entre las variables independientes. Asimismo, se verificará la homocedasticidad y la normalidad de cada una de las características.
"""

# ╔═╡ 970960e9-fa23-48e2-83e8-f364ccc1428c
function calculateCorr(dataframe)
	numeric_df = dataframe[:, [col for col in names(dataframe) if std(skipmissing(dataframe[!, col])) > 0]]
	return cor(Matrix(numeric_df))
end

# ╔═╡ 32478766-0f2c-4ee5-b255-73ad45717ee6
begin
	cor_matrix = calculateCorr(df_without_outliers)
	cor_matrix
end

# ╔═╡ 7f75b12c-759a-4577-92f8-61c8e6b1a737
md"""#### CorrelationHeatMap

Ahora se graficará el heatmap de las correlaciones.
"""

# ╔═╡ 31244469-80ff-4849-92fe-19f1c089504a
begin
	numeric_cols = [col_name for col_name in names(df_without_outliers) if eltype(skipmissing(df_without_outliers[!, col_name])) <: Number]
	heatmap(cor_matrix, 
	    xticks=(1:length(numeric_cols), string.(numeric_cols)), 
	    yticks=(1:length(numeric_cols), string.(numeric_cols)),
	    color=:coolwarm, 
	    title="Correlation Heatmap", 
	    xlabel="Columns", 
	    ylabel="Columns",
		size = (2600,1400),
		tickfontsize =9
	)
end

# ╔═╡ 08ba4171-f45d-4944-90ad-93c26af6cba4
md"""Al observar el heatmap, se puede notar que existen algunas variables independientes que comparten correlación con otras variables independientes, ya sea negativa (representada con colores azules) o positiva (representada con colores rojos).

De estas variables que tienen relaciones con otras, se podría mantener la variable que represente de mejor manera la variabilidad de todas las variables con las que se relaciona y eliminar las demás variables relacionadas. Sin embargo, por el alcance de este ejercicio, se dejarán las variables correlacionadas intactas y se tendrá en cuenta al momento de elegir el modelo de regresión.

Debido a este antecedente, se buscará utilizar modelos como Ridge, Lasso y Elastic Net, que combinan regularización L1 y L2, ayudando a mitigar el impacto de las correlaciones y evitando que el modelo caiga en overfitting."""

# ╔═╡ 1592313c-7a7c-4eeb-aa9b-ab4beba7d5b1
md"""#### Escritura del Dataset Preprocesado a CSV

Se procederá a guardar el dataset preprocesado en un archivo CSV para su posterior análisis o uso en modelos de machine learning."""

# ╔═╡ 0166b040-8a79-454e-a335-fc75eef68e6c
CSV.write("processed-bottle.csv", df_without_outliers)

# ╔═╡ Cell order:
# ╟─a0a19fe4-03ba-4c34-9bbb-97d148efde9a
# ╠═d4815a66-7484-4780-b730-e5387e457a9d
# ╠═35a4398b-f508-4195-8b5d-ec2d4844ded8
# ╠═3b3769a6-c99a-11ef-13a2-9f284abdcd87
# ╠═69f6dfbf-bae5-401a-959e-6b54e37888ca
# ╠═b4a78d98-bc13-4dd9-bf6b-49946f45ee8b
# ╠═84a23fde-722a-48f8-a047-1d67957e6b9a
# ╠═f4d58460-eb72-4cd4-8772-b774fc99bcad
# ╠═56513f5c-d480-4d8d-a606-046fa937934b
# ╠═93bef50b-871b-4a12-ac48-6c050cfc51b7
# ╠═133a13a2-9f60-4162-a17a-62d1854e902a
# ╠═11c6ebd2-8e10-40e1-89f6-4217d37cabff
# ╠═f44302b9-067f-4022-a118-512dc422c97e
# ╠═af53d265-8f13-435f-b0bd-b6b7c1a43551
# ╠═40cbf3bc-3902-41fc-8280-c9f2a2f11332
# ╠═cb8e67a8-7add-498f-a7df-27a2d1c93c84
# ╠═97b1daf5-3157-48c9-94ca-f995c827cd3f
# ╠═fb36a3fe-c337-4b6a-8dca-56cff2ea644e
# ╠═69364e6d-16b3-4715-8d30-ef65d934431c
# ╠═aada15d3-214a-4186-96be-1631f4a19a24
# ╠═e9559474-ea94-4873-946e-87a7ab0899ec
# ╠═959e721b-9463-45d3-a13f-3c536c52f1d1
# ╠═c49dab1c-fd41-45f1-b4d2-8c53532e9702
# ╠═fd50fffb-d240-4ade-9b3f-782a93b77239
# ╠═e18be274-6511-44cc-af6c-f93618dc1b6d
# ╠═bc51cd57-d7a1-48a9-a799-8252f183dd86
# ╠═eb976d01-a978-408f-bb6f-48c9a15c3c3d
# ╠═41e711dc-f821-407d-87ef-ae03bf44203c
# ╠═81cee0f9-207b-443c-83ce-e8f0ef910a70
# ╠═bab149a2-22d4-4fe0-b0d4-4f6f9f5c2532
# ╠═88203b94-ad10-41b8-bdb1-0b9d45ec7815
# ╠═0ac83e8e-b9bd-4fa4-9096-7a530e7464a0
# ╠═e9a4a5fd-2360-46b5-992f-b420a77cdd57
# ╠═51eeaa7c-dbdf-4cdb-b20b-7211b6e86ef3
# ╠═3d81eff1-7b47-4a1e-8a95-5bedf74d8857
# ╠═10d39150-fbed-41d2-9fe1-b625770c2d43
# ╠═27630a30-c316-4b79-88fc-fefc9a6533e7
# ╠═02a15cc2-137a-48ef-91b0-976cfd9aaf6c
# ╠═c786a86e-e956-4eb1-af43-df9d654bc9e2
# ╠═c702ac3d-4016-4905-8fce-66e9e0db1ae9
# ╠═3a83b7ac-39ee-430a-afa7-be9495c1543f
# ╠═91a94a6e-1dab-4e70-83f9-94393034ae50
# ╠═0060f7bf-b7ca-4010-bb7f-a707fef5d7f2
# ╠═1057ac78-5d3d-48ea-9634-715dec57273c
# ╠═1fc48e6f-2af3-4762-a1f9-5f36c3a205ce
# ╠═09335053-5f79-4699-b657-eaa742f37d15
# ╠═718957fd-c2ef-4468-afec-5f2222506ecf
# ╠═9f8196b4-9774-4262-a262-eb2b2f90d067
# ╠═970960e9-fa23-48e2-83e8-f364ccc1428c
# ╠═32478766-0f2c-4ee5-b255-73ad45717ee6
# ╠═7f75b12c-759a-4577-92f8-61c8e6b1a737
# ╠═31244469-80ff-4849-92fe-19f1c089504a
# ╠═08ba4171-f45d-4944-90ad-93c26af6cba4
# ╠═1592313c-7a7c-4eeb-aa9b-ab4beba7d5b1
# ╠═0166b040-8a79-454e-a335-fc75eef68e6c
