## Exercise 1. EDA using Julia with CalCofi bottle.csv https://www.kaggle.com/datasets/sohier/calcofi
## Carolina Bernal Rodríguez 

using Pkg
#Pkg.add(["CSV","DataFrames","Printf","Statistics","StatsBase", "PlotlyJS"])
using CSV
using DataFrames
using Printf
using Statistics
using StatsBase
using PlotlyJS
using FileIO
using NamedArrays


#=
The functions below re included in this code :) 

    dataShape: to get shape of the data
    dataType: gives data type of each column in the dataset
    count_missing(col) : counts number of missing data in a given col (Column).
    dataMissingPercentage(): finds missing percentage of each column.
    deleteColumns(threshold) : delete all the columns which have missing percent less than given threshold.
    calculateCorrelation() : creates correlation matrix between columns.
    displayCorrelation() : display correlation using heatmap.
    removeOutliersIQR() : using interquartile range delete all the outliers from the numerical columns.
    deleteRow(column): for a given column delete all the null data points.
    filterColumnsByCorrelation(target,threshold, realtion) : delete all the columns on the basis of given threshold for a target column and relation .
    describe() : it is used to describe data by giving following for each column/
=#

# ----- Functions ----------

# names retrieve a vector with the names (as string) of the dataframe columns --> names(df)
## Dict to create a dictionary key - value here is an example:  Dict2 = Dict("a" => 1, "b" => 2, "c" => 3)
## Notes regarding the dot syntax  Julia is not vectorized, but a "dot" is used to broadcast function calls over the arguments 
#Dict(names(df) .=> eltype.(eachcol(df)))

# Acording to documentation with eachcol() we can return a vector-like object, allowing us to inreract with df column by column 


# dataShape: to get shape of the data 
function  dataShape(df::DataFrame)
    dfShape = size(df)
    return dfShape
end;
#dataShape retrieves rows x col


# dataType: gives data type of each column in the dataset, retieves a data Dictionary
function dataType(df::DataFrame)
   dataTypes =  Dict(names(df) .=> eltype.(eachcol(df)))
   return dataTypes
end;


# count_missing(col) : counts number of missing data in a given col (Column).
# Here is needed df[!,col] instead of df.col since in the funcion col should be a String parameter
function count_missing(col::String)
    missing_cnt = count(ismissing,df[!,col])
    return missing_cnt 
end;


# dataMissingPercentage(): finds missing percentage of each column.
function dataMissingPercentage(df::DataFrame, col::String)
    
    df_original = df
    row_cnt = size(df_original,1)
    missing_cnt =  count_missing(col)
    missing_pct = missing_cnt/row_cnt
    
    return missing_pct
end;


# showMissingPercCols(df) : Funntion to display de missing percentage from each column using dataMissingPercentage(..)
function showMissingPercCols(df::DataFrame)
    for col_name in names(df)  
        missing_percentage = dataMissingPercentage(df, col_name)
        println("Column: $col_name - Missing percentage value: $missing_percentage")
    end
end;

# validateMissingData(df::DataFrame, threshold::Float64) 
# Function to validate that the percentage of missing values is less than the threshold
function validateMissingPerc(df::DataFrame, threshold::Float64)
    for col_name in names(df)  
        missing_percentage = dataMissingPercentage(df, col_name)
        #println("Column: $col_name - Missing percentage value: $missing_percentage")
        
        # Validation here
        if missing_percentage > threshold
            println("¡Warning! The column:  $col_name has a missing data percentage greater than: ($threshold)")  
        end
    end
end;


#deleteColumns(threshold) : delete all the columns which have missing percent less than given threshold.
#Using broadcast operator help us to use the operation per row
function deleteColumns(df::DataFrame,threshold::Float64)

    df_clean = df
    row_cnt = size(df,1)
    missing_cnt = [count(ismissing,col) for col in eachcol(df)]
    missing_pct = missing_cnt./row_cnt
    missing_pct .< threshold

    excedes_trh_dict = Dict(names(df) .=> missing_pct .< threshold)
    exceedes_trh_df = DataFrame(excedes_trh_dict)

    # filtered_df = exceedes_trh_df[:, all.((x -> x .== true), eachcol(exceedes_trh_df))]

    falsefiltered_df = exceedes_trh_df[:, all.((x -> x .== false), eachcol(exceedes_trh_df))]
    falsefiltered_col_names = names(falsefiltered_df)
    columns_rm_trh = falsefiltered_col_names
    select!(df_clean, Not(columns_rm_trh))

    return df_clean

end;

# findCategoricalColsNames(df) to find the no numeric cols to calculate corr matrix 
function findCategoricalColsNames(df_clean::DataFrame)

    df_wo_miss = coalesce.(df_clean,0)
    wo_miss_Dict = dataType(df_wo_miss)
    dict_values_df = values(wo_miss_Dict)
    unique(dict_values_df)
    # Once we find the unique value type for the columns we can search for the ones that contain string 
    string_columns_v2 = filter(col -> eltype(df_wo_miss[!, col]) == String || eltype(df_wo_miss[!, col]) == String15 , names(df_wo_miss))

    return string_columns_v2

end;
# Once you have your df clean you need to delete String-value or categorical columns 
# Since corr matrix needs only numerical columns to operate 
# filterCategoricalCols(df) uses findCategoricalColsNames(df) to retrieve a df with only numerical columns 
function filterCategoricalCols(df_clean::DataFrame)
   
    df_numeric = df_clean  # copy to not modify the original
    string_col_names =  findCategoricalColsNames(df_numeric)
    select!(df_numeric, Not(string_col_names))

    return df_numeric
    
end;

# calculateCorrelation() : creates correlation matrix between columns.
function calculateCorrelation(df_clean::DataFrame)
    
    df_numerical = filterCategoricalCols(df_clean)
    df_numerical_wo_miss = coalesce.(df_numerical,0)
    corMartrix = cor(Matrix(df_numerical_wo_miss))  
    
    return corMartrix
end;


# displayCorrelation() : display correlation using heatmap.
# The code is based on this one https://discourse.julialang.org/t/how-can-i-plot-a-correlation-heatmap/78411/9
function displayCorrelation(df::DataFrame; colorscale="Magma", fontcolor="#FFFFFF", fontsize=1.5, title="Correlation Matrix")
    
    m = calculateCorrelation(df)
    annotations = [
        attr(text=@sprintf("%.2f", m[i,j]), x=names(df)[i], y=names(df)[j], 
        showarrow=false, font=attr(size=fontsize, color=fontcolor)) for i in 1:size(m)[1] for j in 1:size(m)[2]
    ]
    t = PlotlyJS.heatmap(z=m, x=names(df), y=names(df), colorscale=colorscale)

    layout = Layout(;
        title=title,
        annotations
    )

    return PlotlyJS.plot(t, layout)
end;

# removeOutliersIQR() : using interquartile range delete all the outliers from the numerical columns.
# iqr(v)  : Compute the interquartile range (IQR) of an array, i.e. the 75th percentile minus the 25th percentile.
# percentile(v, p) Return the pth percentile of a real-valued array v, i.e. quantile(x, p / 100).

#iqr(mtr)

function removeOutliersIQR(df_clean::DataFrame)

    df_numerical = filterCategoricalCols(df_clean)
    df =coalesce.(df_numerical,0)
    
    for col in names(df)
        # Calculate the Q1 & Q3 quartiles
        q1 = quantile(df[!, col], 0.25)
        q3 = quantile(df[!, col], 0.75)
        iqr_func = iqr(df[!, col])
            
        # Calculate IQR
        iqr_calc = q3 - q1
        # Calculate lower and upper bound limits 
        lower_bound_calc = q1 - 1.5 * iqr_calc
        upper_bound_calc = q3 + 1.5 * iqr_calc   
        # Filter the rows wthin the limits 
        df = df[(df[!, col] .>= lower_bound_calc) .& (df[!, col] .<= upper_bound_calc), :] 
            
    end

    return df

end;

#deleteRow(column): for a given column delete all the null data points.

function deleteRow(df::DataFrame, column::String)
    
    df = dropmissing(df, Symbol(column))
    return df
    
end;


#filterColumnsByCorrelation(target,threshold, realtion) : delete all the columns on the basis of given threshold for a target column and relation .
function filterColumnsByCorrelation(df::DataFrame, target:: Symbol, threshold, relation)
    
    #Clean the dataframe to only numerical and no missings columns data
    df = filterCategoricalCols(df)
    df = coalesce.(df,0) 
    corrs = [cor(df[!, target], df[!, col]) for col in names(df) if col != target]

    if relation == true
        sel_cols = names(df)[findall(x -> abs(x) <= threshold, corrs)]
        
    else 
        sel_cols = names(df)[findall(x -> x >= threshold, corrs)]
        sel_cols = filter(x -> x != string(target), sel_cols)

    end

    non_rel_cols = names(df)[findall(x -> isnan(x) , corrs)]

    filtered_df = select!(df, Not(sel_cols))

    if size(non_rel_cols)[1] > 0
        filtered_df = select!(filtered_df, Not(non_rel_cols))
    end 

    return filtered_df

end;

# Here we go! :)

# Use the correct directory to run the code :)
cd("/Users/carolinabernal/Documents/DiplomadoExercises")
bottle_file = "Exercise1/dat/bottle.csv"



# In Julia we can materialize a csv file as a DataFrame, copying columns from CSV.File
#bottle_df = CSV.File(bottle) |> DataFrame
#describe(bottle_df)
# to avoid making a copy of parsed columns, use CSV.read

#df = CSV.read(bottle, DataFrame) 
df = CSV.File(bottle_file) |> DataFrame

dataShape(df) #Get the dataShape of the DF
# dataType(df)  #Get the dataType 

describe(df)

dataMissingPercentage(df, "STheta" )
names(df)

showMissingPercCols(df)


dforiginal = copy(df) # To keep the original dataframe
df =  deleteColumns(df,0.75) #Delete Columns were the threshold of missing data 
showMissingPercCols(df)
df =  deleteColumns(df,0.25) #Delete Columns were the threshold of missing data 
showMissingPercCols(df)
describe(df)


validateMissingPerc(df, 0.25)

# df_bottle =coalesce.(df_bottle,0)
bottleOriginal = copy(df)
bottleOSize = size(bottleOriginal)[1] #864863 rows

bottle = dropmissing(df) #454322×30
bottlewoMissSize = size(bottle)[1]

dropMissRatio = bottlewoMissSize / bottleOSize

## More than 50% of the data is eliminated 

#Display and calculate correlation 
corr_displ = displayCorrelation(bottle)
calculateCorrelation(bottle)

## Save correlation img heatmap
save_dir = "Exercise1/fig/output_figs"
corrDispPath = string(save_dir,"/corrDisp.png")
savefig( corr_displ , corrDispPath )


### Filtering correlations with abs() less than 0.1
bottle = filterColumnsByCorrelation(bottle, :T_degC, 0.1, true)
mtdCbottle = NamedArray(cor(Matrix(bottle)), (names(bottle), names(bottle)))
mtdCbottle[:, "T_degC"]


corrdisp = displayCorrelation(bottle)

#Filtering correlations with cor more than >0.9 (or >90% cor)
# to be sure not to include dups (redundancy) and do not overfit the model 


bottle = filterColumnsByCorrelation(bottle, :T_degC, 0.9, false)
mtdCbottle = NamedArray(cor(Matrix(bottle)), (names(bottle), names(bottle)))
mtdCbottle[:, "T_degC"]
corrDispClean = displayCorrelation(bottle)
names(bottle)
savefig(corrDispClean, string(save_dir,"/corrClean.png"))

bottle = removeOutliersIQR(bottle)

CSV.write("Exercise1/dat/bottle_clean.csv", bottle)