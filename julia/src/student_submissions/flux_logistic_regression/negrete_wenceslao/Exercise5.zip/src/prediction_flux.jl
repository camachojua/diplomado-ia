# # Install dependencies
# using Pkg
# Pkg.add("CSV")
# Pkg.add("DataFrames")
# Pkg.add("Flux")
# Pkg.add("Statistics")
# Pkg.add("Random")
# Pkg.add("StatsBase")
# Pkg.add("Plots")
# Pkg.add("ROCAnalysis")

# Initialize script
using CSV
using DataFrames
using Flux
using Statistics
using Random
using StatsBase
using Plots
using ROCAnalysis

function SplitTrainValTestSets(df, train_split, val_split)
    Random.seed!(42)
    nrows = size(df, 1)
    indices = shuffle(1:nrows)
    
    # Calculate split points
    nrowsTrain = round(Int, nrows * train_split)
    nrowsVal = round(Int, nrows * val_split)
    
    # Split the data using shuffled indices
    dfTrain = df[indices[1:nrowsTrain], :]
    dfVal = df[indices[nrowsTrain+1:nrowsTrain+nrowsVal], :]
    dfTest = df[indices[nrowsTrain+nrowsVal+1:end], :]
    
    return dfTrain, dfVal, dfTest
end

# Early stopping utility
mutable struct EarlyStopping
    patience::Int
    min_delta::Float32
    best_loss::Float32
    counter::Int
    should_stop::Bool
    
    EarlyStopping(patience=5, min_delta=0.001) = new(patience, min_delta, Inf32, 0, false)
end

function update!(es::EarlyStopping, val_loss::Float32)
    if val_loss < es.best_loss - es.min_delta
        es.best_loss = val_loss
        es.counter = 0
    else
        es.counter += 1
        if es.counter >= es.patience
            es.should_stop = true
        end
    end
end

# Load data
df = DataFrame(CSV.File("dat/Churn_Modelling.csv"))

# Handle any missing values
df = dropmissing(df)

# Print unique values for categorical variables
println("\nUnique Surnames:", unique(df.Surname))
println("\nGender distribution:", unique(df.Gender))
println("\nGeography distribution:", unique(df.Geography))

# Data preprocessing
# Convert Gender to binary
df.Gender = Float32.(df.Gender .== "Female")

# One-hot encode Geography
geography_dummies = DataFrame(
    Geography_France = Float32.(df.Geography .== "France"),
    Geography_Spain = Float32.(df.Geography .== "Spain"),
    Geography_Germany = Float32.(df.Geography .== "Germany")
)
df = hcat(df, geography_dummies)

# Remove unnecessary columns
select!(df, Not([:Surname, :RowNumber, :CustomerId, :Geography]))

# Split into training (60%), validation (20%), and testing (20%) sets
train_df, val_df, test_df = SplitTrainValTestSets(df, 0.6, 0.2)

println("\nTraining set size: ", size(train_df, 1))
println("Validation set size: ", size(val_df, 1))
println("Testing set size: ", size(test_df, 1))

# Prepare data for Flux
function prepare_data(df)
    X = Float32.(Matrix(select(df, Not(:Exited))))
    y = reshape(Float32.(df.Exited), 1, :)
    return X, y
end

X_train, y_train = prepare_data(train_df)
X_val, y_val = prepare_data(val_df)
X_test, y_test = prepare_data(test_df)

# Normalize features using training statistics
train_mean = mean(X_train, dims=1)
train_std = std(X_train, dims=1)

function normalize_data!(X, mean, std)
    return Float32.((X .- mean) ./ std)
end

X_train = normalize_data!(X_train, train_mean, train_std)
X_val = normalize_data!(X_val, train_mean, train_std)
X_test = normalize_data!(X_test, train_mean, train_std)

# Transpose for Flux
X_train = X_train'
X_val = X_val'
X_test = X_test'

# Create improved model with hidden layers and dropout
input_size = size(X_train, 1)
model = Chain(
    Dense(input_size => 32, relu),
    Dropout(0.2),
    Dense(32 => 16, relu),
    Dropout(0.1),
    Dense(16 => 1, σ)
)

# Define loss function
function loss(model, x, y)
    predictions = model(x)
    return Flux.logitbinarycrossentropy(predictions, y)
end

# Calculate accuracy
function accuracy(model, x, y)
    predictions = model(x)
    return mean((predictions .>= 0.5) .== y)
end

# Training parameters
batch_size = 32
optimizer = ADAM(0.001)
state = Flux.setup(optimizer, model)

# Create data loaders
train_data = Flux.DataLoader((X_train, y_train), batchsize=batch_size, shuffle=true)
val_data = Flux.DataLoader((X_val, y_val), batchsize=batch_size)

# Initialize early stopping
early_stopping = EarlyStopping(10, 0.001f0)  # 10 epochs patience

# Training loop
num_epochs = 200

println("\nStarting training...")
println("Epoch\tTrain Loss\tTrain Acc\tVal Loss\tVal Acc")
println("-" ^ 65)

let
    best_val_loss = Inf32
    best_model_state = nothing
    
    for epoch in 1:num_epochs
    # Training
    Flux.trainmode!(model)
    train_losses = Float32[]
    train_accs = Float32[]
    
    for (x, y) in train_data
        gradients = gradient(m -> loss(m, x, y), model)
        Flux.update!(state, model, gradients[1])
        push!(train_losses, loss(model, x, y))
        push!(train_accs, accuracy(model, x, y))
    end
    
    # Validation
    Flux.testmode!(model)
    val_losses = Float32[]
    val_accs = Float32[]
    
    for (x, y) in val_data
        push!(val_losses, loss(model, x, y))
        push!(val_accs, accuracy(model, x, y))
    end
    
    # Calculate epoch metrics
    epoch_train_loss = mean(train_losses)
    epoch_train_acc = mean(train_accs)
    epoch_val_loss = mean(val_losses)
    epoch_val_acc = mean(val_accs)
    
    # Print progress every 10 epochs
    if epoch % 10 == 0
        println("$epoch\t",
                "$(round(epoch_train_loss, digits=4))\t",
                "$(round(epoch_train_acc * 100, digits=2))%\t",
                "$(round(epoch_val_loss, digits=4))\t",
                "$(round(epoch_val_acc * 100, digits=2))%")
    end
    
    # Save best model
    if epoch_val_loss < best_val_loss
        best_val_loss = epoch_val_loss
        best_model_state = deepcopy(model)
    end
    
    # Early stopping check
    update!(early_stopping, epoch_val_loss)
    if early_stopping.should_stop
        println("\nEarly stopping triggered at epoch $epoch")
        break
    end
    end
    
    # Use best model for final evaluation
    global model = best_model_state
end

# Final evaluation on test set
Flux.testmode!(model)
test_predictions = model(X_test)
predicted_classes = Int.(vec(test_predictions) .>= 0.5)
actual_classes = vec(y_test)
test_accuracy = mean(predicted_classes .== actual_classes)

println("\nTest Accuracy: ", round(test_accuracy * 100, digits=2), "%")

# Generate confusion matrix
tn = sum((actual_classes .== 0) .& (predicted_classes .== 0))
fp = sum((actual_classes .== 0) .& (predicted_classes .== 1))
fn = sum((actual_classes .== 1) .& (predicted_classes .== 0))
tp = sum((actual_classes .== 1) .& (predicted_classes .== 1))

println("\nConfusion Matrix:")
println("True Positive: ", tp)
println("True Negative: ", tn)
println("False Positive: ", fp)
println("False Negative: ", fn)

# Calculate and plot ROC curve
roc = ROCAnalysis.roc(vec(test_predictions), actual_classes)
auc_score = ROCAnalysis.auc(roc)

# Create and save ROC curve plot
p = plot(xlabel="False Positive Rate", ylabel="True Positive Rate", title="ROC Curve - Logistic Regression")
plot!([0,1], [0,1], label="Random", linestyle=:dash, color=:gray)

# Plot ROC curve with calculated AUC
plot!(roc, label="ROC (AUC = $(round(auc_score, digits=3)))")

# Save the plot with explicit format
savefig(p, "fig/flux_roc_curve.png")
