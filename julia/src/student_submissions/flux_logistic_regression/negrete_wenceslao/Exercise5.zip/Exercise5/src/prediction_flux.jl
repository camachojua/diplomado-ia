# # Install dependencies
# using Pkg
# Pkg.add("CSV")
# Pkg.add("DataFrames")
# Pkg.add("Flux")
# Pkg.add("Statistics")
# Pkg.add("Random")
# Pkg.add("StatsBase")
# Pkg.add("Plots")

using CSV
using DataFrames
using Flux
using Statistics
using Random
using StatsBase
using Plots

# Data loading and preprocessing
function load_data(path)
    df = DataFrame(CSV.File(path))
    df = dropmissing(df)
    return df
end

function preprocess_data!(df)
    # Convert Gender to binary
    df.Gender = Float32.(df.Gender .== "Female")

    # One-hot encode Geography
    geography_dummies = DataFrame(
        Geography_France = Float32.(df.Geography .== "France"),
        Geography_Spain = Float32.(df.Geography .== "Spain"),
        Geography_Germany = Float32.(df.Geography .== "Germany")
    )
    df = hcat(df, geography_dummies)

    # Remove unnecessary columns
    select!(df, Not([:Surname, :RowNumber, :CustomerId, :Geography]))
    return df
end

function split_data(df, train_split, val_split)
    Random.seed!(42)
    nrows = size(df, 1)
    indices = shuffle(1:nrows)
    
    nrowsTrain = round(Int, nrows * train_split)
    nrowsVal = round(Int, nrows * val_split)
    
    dfTrain = df[indices[1:nrowsTrain], :]
    dfVal = df[indices[nrowsTrain+1:nrowsTrain+nrowsVal], :]
    dfTest = df[indices[nrowsTrain+nrowsVal+1:end], :]
    
    return dfTrain, dfVal, dfTest
end

function prepare_features(df)
    X = Float32.(Matrix(select(df, Not(:Exited))))
    y = reshape(Float32.(df.Exited), 1, :)
    return X, y
end

function normalize_features(X_train, X_val, X_test)
    train_mean = mean(X_train, dims=1)
    train_std = std(X_train, dims=1)
    
    X_train_norm = Float32.((X_train .- train_mean) ./ train_std)
    X_val_norm = Float32.((X_val .- train_mean) ./ train_std)
    X_test_norm = Float32.((X_test .- train_mean) ./ train_std)
    
    return X_train_norm', X_val_norm', X_test_norm'
end

# Logistic Regression model
function build_model(input_size)
    # Single dense layer without sigmoid activation - this outputs raw logits
    return Chain(
        Dense(input_size => 1, bias=true)  # Single layer with bias term
        # No activation function here
    )
end

# Training utilities
mutable struct EarlyStopping
    patience::Int
    min_delta::Float32
    best_loss::Float32
    counter::Int
    should_stop::Bool
    
    EarlyStopping(patience=5, min_delta=0.001) = new(patience, min_delta, Inf32, 0, false)
end
function update!(es::EarlyStopping, val_loss::Float32)
    if val_loss < es.best_loss - es.min_delta
        es.best_loss = val_loss
        es.counter = 0
    else
        es.counter += 1
        if es.counter >= es.patience
            es.should_stop = true
        end
    end
end

# Loss and metrics
function loss(model, x, y)
    predictions = model(x)
    return Flux.logitbinarycrossentropy(predictions, y)
end

function accuracy(model, x, y)
    predictions = model(x)
    return mean((predictions .>= 0.5) .== y)
end

# Training function
function train_model!(model, train_data, val_data; 
                     epochs=100, optimizer=Descent(0.1), patience=10)  # Using simple gradient descent for logistic regression
    state = Flux.setup(optimizer, model)
    early_stopping = EarlyStopping(patience, 0.001f0)
    best_val_loss = Inf32
    best_model_state = nothing
    
    println("\nStarting training...")
    println("Epoch\tTrain Loss\tTrain Acc\tVal Loss\tVal Acc")
    println("-" ^ 65)
    
    for epoch in 1:epochs
        # Training
        Flux.trainmode!(model)
        train_losses = Float32[]
        train_accs = Float32[]
        
        for (x, y) in train_data
            gradients = gradient(m -> loss(m, x, y), model)
            Flux.update!(state, model, gradients[1])
            push!(train_losses, loss(model, x, y))
            push!(train_accs, accuracy(model, x, y))
        end
        
        # Validation
        Flux.testmode!(model)
        val_losses = Float32[]
        val_accs = Float32[]
        
        for (x, y) in val_data
            push!(val_losses, loss(model, x, y))
            push!(val_accs, accuracy(model, x, y))
        end
        
        # Calculate epoch metrics
        epoch_train_loss = mean(train_losses)
        epoch_train_acc = mean(train_accs)
        epoch_val_loss = mean(val_losses)
        epoch_val_acc = mean(val_accs)
        
        # Print progress every 10 epochs
        if epoch % 10 == 0
            println("$epoch\t",
                    "$(round(epoch_train_loss, digits=4))\t",
                    "$(round(epoch_train_acc * 100, digits=2))%\t",
                    "$(round(epoch_val_loss, digits=4))\t",
                    "$(round(epoch_val_acc * 100, digits=2))%")
        end
        
        # Save best model
        if epoch_val_loss < best_val_loss
            best_val_loss = epoch_val_loss
            best_model_state = deepcopy(model)
        end
        
        # Early stopping check
        update!(early_stopping, epoch_val_loss)
        if early_stopping.should_stop
            println("\nEarly stopping triggered at epoch $epoch")
            break
        end
    end
    
    return best_model_state
end

# Evaluation functions
function evaluate_model(model, X_test, y_test)
    Flux.testmode!(model)
    test_predictions = model(X_test)
    predicted_classes = Int.(vec(test_predictions) .>= 0.5)
    actual_classes = vec(y_test)
    
    # Calculate accuracy
    test_accuracy = mean(predicted_classes .== actual_classes)
    println("\nTest Accuracy: ", round(test_accuracy * 100, digits=2), "%")
    
    # Generate confusion matrix
    tn = sum((actual_classes .== 0) .& (predicted_classes .== 0))
    fp = sum((actual_classes .== 0) .& (predicted_classes .== 1))
    fn = sum((actual_classes .== 1) .& (predicted_classes .== 0))
    tp = sum((actual_classes .== 1) .& (predicted_classes .== 1))
    
    println("\nConfusion Matrix:")
    println("True Positive: ", tp)
    println("True Negative: ", tn)
    println("False Positive: ", fp)
    println("False Negative: ", fn)
    
    return vec(test_predictions), actual_classes
end

function plot_roc_curve(predictions, actual_classes)
    # Convert predictions and actuals to vectors to ensure correct format
    predictions = vec(predictions)
    actual_classes = vec(actual_classes)
    
    # Plot ROC curve
    p = plot(xlabel="False Positive Rate", 
             ylabel="True Positive Rate", 
             title="ROC Curve - Logistic Regression")
    
    # Plot random classifier line
    plot!([0,1], [0,1], label="Random", linestyle=:dash, color=:gray)
    
    # Plot ROC curve using the points from the curve object
    thresholds = reverse(sort(unique(predictions)))
    tpr = Float64[]
    fpr = Float64[]

    for threshold in thresholds
        pred_classes = Int.(predictions .>= threshold)
        push!(tpr, sum((pred_classes .== 1) .& (actual_classes .== 1)) / sum(actual_classes .== 1))
        push!(fpr, sum((pred_classes .== 1) .& (actual_classes .== 0)) / sum(actual_classes .== 0))
    end

    # Calculate AUC using trapezoidal rule
    global auc = 0.0
    for i in 1:length(fpr)-1
        global auc += (fpr[i+1] - fpr[i]) * (tpr[i+1] + tpr[i]) / 2
    end
    plot!(fpr, tpr, label="ROC (AUC = $(round(auc, digits=3)))")
    
    savefig(p, "fig/flux_roc_curve.png")
end

# Main execution
function main()
    # Load and preprocess data
    df = load_data("dat/Churn_Modelling.csv")
    df = preprocess_data!(df)
    
    # Split data
    train_df, val_df, test_df = split_data(df, 0.6, 0.2)
    println("\nDataset splits:")
    println("Training set size: ", size(train_df, 1))
    println("Validation set size: ", size(val_df, 1))
    println("Testing set size: ", size(test_df, 1))
    
    # Prepare features
    X_train, y_train = prepare_features(train_df)
    X_val, y_val = prepare_features(val_df)
    X_test, y_test = prepare_features(test_df)
    
    # Normalize features
    X_train_norm, X_val_norm, X_test_norm = normalize_features(X_train, X_val, X_test)
    
    # Create data loaders
    batch_size = 32
    train_data = Flux.DataLoader((X_train_norm, y_train), batchsize=batch_size, shuffle=true)
    val_data = Flux.DataLoader((X_val_norm, y_val), batchsize=batch_size)
    
    # Build and train model
    model = build_model(size(X_train_norm, 1))
    best_model = train_model!(model, train_data, val_data)
    
    # Evaluate model
    predictions, actuals = evaluate_model(best_model, X_test_norm, y_test)
    
    # Plot ROC curve
    plot_roc_curve(predictions, actuals)
end

# Run the pipeline
main()
