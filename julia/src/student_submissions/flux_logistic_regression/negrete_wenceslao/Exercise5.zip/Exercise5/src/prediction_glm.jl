# Install dependencies
# using Pkg
# Pkg.add("DataFrames")
# Pkg.add("CSV")
# Pkg.add("StatsBase")
# Pkg.add("GLM")
# Pkg.add("Statistics")
# Pkg.add("Distributions")
# Pkg.add("Random")
# Pkg.add("MultivariateStats")
# Pkg.add("MLBase")
# Pkg.add("Plots")
# Pkg.add("ROCAnalysis")

# Initialize script
using CSV
using DataFrames
using StatsBase
using GLM
using Statistics
using Distributions
using Random
using MultivariateStats
using MLBase
using Plots
using ROCAnalysis

function SplitTrainTestSets(df, split)
    # Set random seed for reproducibility
    Random.seed!(42)
    
    # Get number of rows
    nrows = size(df, 1)
    
    # Create shuffled indices
    indices = shuffle(1:nrows)
    
    # Calculate split points
    nrowsTrain = round(Int, nrows * split)
    
    # Split the data using shuffled indices
    dfTrain = df[indices[1:nrowsTrain], :]
    dfTest = df[indices[nrowsTrain+1:end], :]
    
    return dfTrain, dfTest
end

# Create fig directory if it doesn't exist
mkpath("fig")

# Load data
df = DataFrame(CSV.File("dat/Churn_Modelling.csv"))

# Handle any missing values
df = dropmissing(df)

# Analyze categorical variables
println("\nSurname distribution:")
println(countmap(df.Surname))
println("\nGender distribution:")
println(countmap(df.Gender))
println("\nGeography distribution:")
println(countmap(df.Geography))

# Data preprocessing
# Convert Gender to binary
df.Gender = (df.Gender .== "Female")

# Remove unnecessary columns
select!(df, Not([:Surname, :RowNumber, :CustomerId]))

# Split into training (75%) and testing (25%) sets
train_df, test_df = SplitTrainTestSets(df, 0.75)

println("\nTraining set size: ", size(train_df, 1))
println("Testing set size: ", size(test_df, 1))

# Create and train logistic regression model using contrasts for Geography
fm = @formula(Exited ~ CreditScore + Age + Tenure + Balance + NumOfProducts + HasCrCard + IsActiveMember + EstimatedSalary + Gender + Geography)
logit = glm(fm, train_df, Binomial(), LogitLink())
predictions = predict(logit, test_df)

# Convert probabilities to binary predictions
predicted_classes = Int.(predictions .>= 0.5)
actual_classes = test_df.Exited

# Calculate accuracy
accuracy = mean(predicted_classes .== actual_classes)
println("\nAccuracy: ", round(accuracy * 100, digits=2), "%")

# Create confusion matrix
tp = sum((predicted_classes .== 1) .& (actual_classes .== 1))
tn = sum((predicted_classes .== 0) .& (actual_classes .== 0))
fp = sum((predicted_classes .== 1) .& (actual_classes .== 0))
fn = sum((predicted_classes .== 0) .& (actual_classes .== 1))

println("\nConfusion Matrix:")
println("True Positive: ", tp)
println("True Negative: ", tn)
println("False Positive: ", fp)
println("False Negative: ", fn)

# Print model coefficients and their significance
println("\nModel Summary:")
println(logit)

# Plot ROC curve using raw probabilities
p = plot(xlabel="False Positive Rate", ylabel="True Positive Rate", title="ROC Curve")
plot!([0, 1], [0, 1], label="Random", linestyle=:dash, color=:gray)

# Calculate ROC points manually
thresholds = reverse(sort(unique(predictions)))
tpr = Float64[]
fpr = Float64[]

for threshold in thresholds
    pred_classes = Int.(predictions .>= threshold)
    push!(tpr, sum((pred_classes .== 1) .& (actual_classes .== 1)) / sum(actual_classes .== 1))
    push!(fpr, sum((pred_classes .== 1) .& (actual_classes .== 0)) / sum(actual_classes .== 0))
end

# Calculate AUC using trapezoidal rule
global auc = 0.0
for i in 1:length(fpr)-1
    global auc += (fpr[i+1] - fpr[i]) * (tpr[i+1] + tpr[i]) / 2
end

# Plot ROC curve with calculated AUC
plot!(fpr, tpr, label="ROC (AUC = $(round(auc, digits=3)))")
savefig(p, "fig/glm_roc_curve.png")
