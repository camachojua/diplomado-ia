#Exercise N1
#Cleaning the bottle.csv data

##getting the shape of data

using Pkg
# Pkg.add("DataFrames")
# Pkg.add("PlotlyJS")
# Pkg.add("NamedArrays")

using CSV
using DataFrames
using Statistics
using Printf
using PlotlyJS
using NamedArrays
using Random

cd("/Users/zoe/drv3/hm3/code/julia/hmw_diplo")
bottle = CSV.read("Exercise1/dat/bottle.csv", DataFrame)

#defining dataShape
function dataShape(DataFrame)
    s = size(DataFrame)
    return s
end

dataShape(bottle) #
#output -> 864863 rows x 74 columns

##getting the datatype of bottle columns

function colType(DataFrame)
    lty = describe(DataFrame)[!, [:variable ,:eltype]]
    return lty
end

colType(bottle)

##Counting missing values from data: count_missing

## for all the dataframe version
function countMissingDF(DataFrame)
    lty = describe(DataFrame)[!, [:variable ,:nmissing]]
    return lty
end

countMissingDF(bottle)

## for column version
function countMissing(colname::String, DataFrame)
    missingb = countMissingDF(DataFrame)
    lty = missingb[string.(missingb[!, "variable"]) .== colname, :]
    return lty.nmissing[1]

end

## example
countMissing("T_degC", bottle)



## Calculating the percentage of missing data per column: dataMissingPercentage()

function dataMissingPercentage(DataFrame)

    mDataFrame = countMissingDF(DataFrame)
    mDataFrame[!, :pp_missing] .= mDataFrame[!, :nmissing]/dataShape(DataFrame)[1]
    return mDataFrame


end

dataMissingPercentage(bottle)


##Filtering Columns that are above a threshold of missing values: deleteColumns(threshold)

# bottle

function deleteColumns(DataFrame, threshold)
    
    fDataFrame = dataMissingPercentage(DataFrame)
    name = string.(fDataFrame[fDataFrame.pp_missing .>= threshold, :].variable)
    DataFrame = select!(DataFrame, Not(name))
    
    return DataFrame
    
end 


deleteColumns(bottle, 0.25)


## Calculating correlation between data: calculateCorrelation()


###replacing missing values on data to get a single type column:
function replaceMissing(DataFrame)
    cDataFrame = coalesce.(DataFrame, 0)
    return cDataFrame
    
end

### getting the names of columns that have a String-like data type
function stringCols(DataFrame)
    counter = 1
    catNames = String[]
    dDataFrame = describe(DataFrame)

    for k in dDataFrame.eltype

        if match(r"String", string(k)) != nothing
            push!(catNames, string(dDataFrame.variable[counter]))
        end
        counter += 1
    end

    return catNames

end

###check to see if worked!
# bottle = CSV.read("Exercise1/dat/bottle.csv", DataFrame)
stringCols(bottle) #it worked!


###filtering out categorical data. Note: this is a permanent change, so in case this is needed on cat datasets
###I'd probably need to do a filterCatCols() function...

function filterNumCols(DataFrame)

    names = stringCols(DataFrame)
    
    if size(names)[1] > 0
        DataFrame = select!(DataFrame, Not(names))
        return DataFrame
    
    else
        return DataFrame
    
    end
end

filterNumCols(bottle)

## Creating a correlation matrix between columns with calculateCorrelation()

function calculateCorrelation(DataFrame)

    corr = cor(replaceMissing(Matrix(filterNumCols(DataFrame)))) 
    #replaceMissing(cor(Matrix(filterNumCols(DataFrame)))) ## personally I don't like this version so much...
    ## I will prefeer cor(replaceMissing(Matrix(filterNumCols(bottle)))) instead, comment this in case you regret my decision
    return corr

end

calculateCorrelation(bottle)




function displayCorrelation(DataFrame, colorscale="Viridis", fontcolor="#aabbcc", fontsize=1)
    
    m = calculateCorrelation(DataFrame)
    annotations = [
        attr(text=@sprintf("%.2f", m[i,j]), x=names(DataFrame)[i], y=names(DataFrame)[j], showarrow=false, font=attr(size=fontsize, color=fontcolor)) for i in 1:size(m)[1] for j in 1:size(m)[2]
    ]
    t = heatmap(z=m, x=names(DataFrame), y=names(DataFrame), colorscale=colorscale)

    layout = Layout(;
        annotations
    )

    return plot(t, layout)
end

displayCorrelation(bottle)


## Now we remove outliers with removeOutliersIQR:

# function removeOutliersIQR()

# |   names = #names of non-categorical data-cols

#     for i in names
#         #do IQR filter
#         value = 
#     end 



# end

## Using IQ Range to delete outliers from data:

function removeOutliersIQR(DataFrame)

    rDataFrame = replaceMissing(DataFrame)

    for i in names(rDataFrame)

        Q1 = quantile(rDataFrame[!, i], 0.25)
        Q3 = quantile(rDataFrame[!, i], 0.75)

        IQR = Q3 - Q1

        lowerB = Q1 - (1.5 * IQR)
        upperB = Q3 + (1.5 * IQR)

        rDataFrame = rDataFrame[(rDataFrame[!, i] .>= lowerB) .& (rDataFrame[!, i] .<= upperB) , :]

    end

    return rDataFrame

end


### testing to see if it works:

IQRbottle = removeOutliersIQR(bottle)
IQRbottle ##it works

## Creating a function to remove null data points from a column:

function dataMissingPercentage(bottle, column)
    
    bottle = dropmissing(bottle, Symbol(column))
    return bottle
    
end


dataMissingPercentage(bottle, "T_degC") #it worked



# replaceMissing(cor(Matrix(fbottle)))
# fbottle = filterNumCols(bottle)
# mbottle = NamedArray(cor(Matrix(fbottle)), (names(fbottle), names(fbottle)))

# mbottle[:, "T_degC"]


# Add the target column to ensure it's included in the filtered DataFrame
# Filter the DataFrame

function filterColumnsByCorrelation(DataFrame, target:: Symbol, threshold, relation)
    
    DataFrame = filterNumCols(DataFrame) ## in case it receives a non-cleaned DF
    DataFrame = replaceMissing(DataFrame) ## in case it receives a non-cleaned DF
    correlations = [cor(DataFrame[!, target], DataFrame[!, col]) for col in names(DataFrame) if col != target]

    if relation == true
        selected_columns = names(DataFrame)[findall(x -> abs(x) <= threshold, correlations)]
        
    else 
        selected_columns = names(DataFrame)[findall(x -> x >= threshold, correlations)]
        selected_columns = filter(x -> x != string(target), selected_columns)

    end

    non_related_columns = names(DataFrame)[findall(x -> isnan(x) , correlations)]

    filtered_df = select!(DataFrame, Not(selected_columns))

    if size(non_related_columns)[1] > 0
        filtered_df = select!(filtered_df, Not(non_related_columns))
    end 

    return filtered_df

end

filterColumnsByCorrelation(bottle, :T_degC, 0.4, true)

## Using the describe function. As it is already on Julia there's no need to re-made it. 
##it is used to describe data by giving following for each column with describe()

describe(bottle)


# Now implementing everything I've just done:

### uploading data to DR
bottle = CSV.read("Exercise1/dat/bottle.csv", DataFrame)
### looking at datashape
describe(bottle)

### looking at missing percentage
dataMissingPercentage(bottle)

### keeping columns which have less than 25% of missing values
deleteColumns(bottle, 0.25)
dataMissingPercentage(bottle)

### EXTRA STEP: Handling missing values. In this case 
### I will just simply drop any missing value before keeping with the columns wich have at least 75% of non missing-data
### While doing this I'll still have enough values in this case ~450K rows of data...

cbottle = copy(bottle)
original_length = size(cbottle)[1]

cbottle = dropmissing(cbottle)
cropped_length = size(cbottle)[1]


size_comparison = cropped_length/original_length
    #Data after manipulation is at least ~50% less when compared with the original with this approach
    #in other cases I could use the replaceMissing() function I made in the Ex1. I can still do it 
    #after choosing my explanatory variables to see how the model behaves

### Looking at Correlation:
displayCorrelation(cbottle)
calculateCorrelation(cbottle)

### Filtering correlations with abs() less than 0.1
cbottle = filterColumnsByCorrelation(cbottle, :T_degC, 0.1, true)
mbottle = NamedArray(cor(Matrix(cbottle)), (names(cbottle), names(cbottle)))
mbottle[:, "T_degC"]

### Filtering correlations with cor more than >0.9 (or >90% cor)
    ### personally I'd be just fine with this data, but I know Calcofi has some "duplicated" data,
    ### so included stuff like R_Temp (which is == "T_degC") would decrease overfiting and increase redundancy

cbottle = filterColumnsByCorrelation(cbottle, :T_degC, 0.9, false)
mbottle = NamedArray(cor(Matrix(cbottle)), (names(cbottle), names(cbottle)))
mbottle[:, "T_degC"]
image = displayCorrelation(cbottle)
savefig(image, "Exercise1/fig/corHeatmap_bottle.png")

### filterin out the IQR from the data: 

cbottle = removeOutliersIQR(cbottle)

## Looking at results:

describe(cbottle)
first(cbottle, 20)

## outputting the cleaned DataFrame to my path:

CSV.write("Exercise1/dat/clean_bottle.csv", cbottle)
println("el dataFrame se ha limpiado y guardado!")