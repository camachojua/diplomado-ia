#Exercise 4: Dimensionality Reduction

using Pkg
Pkg.add(["FileIO","Plots", "Images","Distributions","GLM","ImageView", "ColorTypes", "ImageTransformations"]); 

using Images
using Plots
using FileIO
using Distributions
using LinearAlgebra
using Statistics
using GLM
using ImageView
using ImageTransformations
using ColorTypes

#changin the directory
cd("/Users/zoe/drv3/hm3/code/julia/hmw_diplo/")

#giving the names of my files:
files = [ "$(i)"*".png" for i in 1:5]
directory = "Exercise4/fig/"

#creating a function to load imgs into Julia:
function inputImg(files, originPath, heroKey::String ="")
    #heroKey is an extrakey in case a manipulated Img has to be opened...
    #making arrays to store information
    finalPath = []
    loadArrImg = []
    
    for i in 1:length(files)
        img_i_path = string(originPath,files[i],heroKey)
        img_path_fn = img_i_path
        load_i = load(img_i_path)

        #pushing pathfiles and images to arrays
        push!(loadArrImg,load_i)  
        push!(finalPath,img_path_fn)

    end 

    return finalPath, loadArrImg
end

x, y = inputImg(files, directory)

#now making a function to resize images:
function reSizeInputImg(files, pixelNumber, originPath, outPath)
    
    imgPath , img = inputImg(files, originPath)
    resizedImgs = []

    for i in 1:length(files)

        resizedImg = ImageTransformations.imresize(img[i],(pixelNumber,pixelNumber))
        imgOut = string(i)  * "_resized"  *  ".png"
        fullOutpath = string(outPath,imgOut)
        save(fullOutpath,resizedImg)
        push!(resizedImgs, fullOutpath)
        
    end

    println("$(length(files)) files where resized and saved in $(outPath)")
    return  resizedImgs
end

outputDirectory = "Exercise4/fig/resized/"
p = reSizeInputImg(files, 400, directory, outputDirectory)

#now making a function to gray-scale images:

function grayScale(files, originPath, outPath, resize::Bool = false, pixelNumber::Int64 = 300)

    grayImages = []
    imgPath , img = inputImg(files, originPath)

    for i in 1:length(files)
    
        if resize == true
            resizedImg = ImageTransformations.imresize(img[i],(pixelNumber,pixelNumber))
            imgGray = Gray.(resizedImg)
            imgOut = string(i)  * "_gray_resized"  *  ".png"
        else
            imgGray = Gray.(img[i])
            imgOut = string(i)  * "_gray"  *  ".png"
        end
    
    fullOutpath = string(outPath,imgOut)
    save(fullOutpath,imgGray)
    push!(grayImages, imgGray)

    end

    if resize == true
        println("$(length(files)) files where gray-scaled & resized and saved in $(outPath)")
    else 
        println("$(length(files)) files where gray-scaled and saved in $(outPath)")
    end 

    return grayImages

end

#gray-scaling images:
outpuGraytDirectory = "Exercise4/fig/gray/" #resized/"
p = grayScale(files, directory, outpuGraytDirectory)

#gray-scaling and resizing:

outpuGraytDirectory = "Exercise4/fig/gray_resize/"
pr = grayScale(files, directory, outpuGraytDirectory, true, 300)

# now making a function to SVDecompose images:

function findApproxImg(imgArray, k, outPath)
"""
Warning: this function work with already uploaded-images and not with paths!
"""

    #generating a SVD arr
    SVD_arr = []

    for i in 1:length(imgArray)
 
        imgi = imgArray[i]
        nRows = length(imgi)
 
        M = Matrix{Float64}(undef, nRows, nRows)
        M = convert(Array{Float64}, imgi)
        F = svd( M ) 

        push!(SVD_arr,F)
 
    end

    output_file = string(outPath,"output_SVD/")
    kDirectory = output_file * "k=" * string(k) * "/"

    for i in 1:length(imgArray)
     
        imgName = string(i) *  ".jpg"
        final_path_k = string(kDirectory, imgName)   

        Fi = SVD_arr[i]
        Mi = Fi.U[:, 1:k] * Diagonal(Fi.S[1:k]) * Fi.V[:, 1:k]'
        Mi = abs.( Mi .* 0.99)

        save(final_path_k, Mi)
        #push!(M_arr, Mi)
        
    end 
    println("$(length(files)) files where Singule-Value-Decomposed with k-value: $(k). Files were saved in $(output_file)k=$(k) as jpg")
    
    #return M_arr

end

#SVD-ing the images:
output_img_path  =  "Exercise4/fig/output_img/"

ks = [5, 10, 50, 100]
for i in 1:length(ks)
    findApproxImg(pr, ks[i], output_img_path)
end


# printing SVD information:

function SVDInfo(imgArray)

    #generating a SVD arr
    SVD_arr = []

    for i in 1:length(imgArray)
 
        imgi = imgArray[i]
        nRows = length(imgi)
 
        M = Matrix{Float64}(undef, nRows, nRows)
        M = convert(Array{Float64}, imgi)
        F = svd( M ) 

        push!(SVD_arr,F)
 
    end

    for i in 1:length(SVD_arr)

        F = SVD_arr[i]    
        println("PrintSVDInfo for image ", i)
        println("F.U  Info: Type = ", typeof(F.U),  "  size=", size(F.U))
        println("F.S  Info: Type = ", typeof(F.S),  "  size=", size(F.S))
        println("F.V  Info: Type = ", typeof(F.V),  "  size=", size(F.V))
        println("F.Vt Info: Type = ", typeof(F.Vt), "  size=", size(F.Vt))
        println("")

    end

end

#printing SCD data
SVDInfo(pr)


#now plotting the Normalized Sums:

function PlotNormalizedSum(imgArray, output_img_path, k)

    #generating a SVD arr
    SVD_arr = []

    for i in 1:length(imgArray)
    
        imgi = imgArray[i]
        nRows = length(imgi)
    
        M = Matrix{Float64}(undef, nRows, nRows)
        M = convert(Array{Float64}, imgi)
        F = svd( M ) 

        push!(SVD_arr,F)
    
    end

    m = string(k)
    output_file_k =  "k=" * m
    

    for j in 1:length(SVD_arr)

        F = SVD_arr[j]
        S = convert( Vector{Float64}, F.S) 
        println("Image" , j , " info: ")
        println("The size of the vector is: ", length(S))
        # sum, normSum = FindNormalizedSum(S)

        nn = length(S)
        svx = 0.0
        normSum = Vector{Float64}(undef, nn)
    
        for i in 1:nn
            svx += S[i]
        end    
    
        svx = svx / nn 
        sum = 0.0
    
        for i in 1:nn 
            normSum[i] = S[i] / (svx*nn)
            sum += normSum[i]
        end 

        #
        n = length(normSum)
        println("Sum = ", sum, "  size n: ", n)
        println("")

        # Select the first k items to compare the normalized sum
        if k!= 0 
            n = k
        end     

        y = Vector{Float64}(undef, n)
        x = Vector{Float64}(undef, n)

        for i in 1:n
        
            y[i] = i
            x[i] = 1.0 - normSum[i]

         end
    
        pplot = plot(y, x)

        graph_path  = output_img_path * "output_graphs/" * output_file_k * "/plot_img" * string(j) * ".png"
        savefig(pplot, graph_path)

    end

end

#plotting the lines:
#!!!!note, plots. do not make directories, so generete them before running this:
ks = [5, 10, 50, 100]
for i in 1:length(ks)
    PlotNormalizedSum(pr, output_img_path, ks[i])
end
