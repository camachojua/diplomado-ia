#= using Pkg

Pkg.add("DataFramesMeta")
Pkg.add("GLM")
 =#
 using DataFramesMeta
 using CSV
 using DataFrames
 using GLM
 using Statistics
 using Plots
 
 # Lectura del archivo de datos con formato CSV y generación del DataFrame
 file_path = "../dat/bottle.csv"
 data = CSV.read(file_path, DataFrame)
 
# Se asegura que todas las columnas convalores missing son limpiados:

# Remplazo de nothing con missing
transform!(data, names(data) .=> ByRow(x -> x === nothing ? missing : x))

# Eliminación de filas con valores faltantes en T_degC y columnas numericas
data_clean = dropmissing(data, [:T_degC])


# Filtrado de columnas numericas
numerical_cols = filter(c -> eltype(data_clean[!, c]) <: Number, names(data_clean))


# Subconjunto de datos numericos
data_numeric = data_clean[:, numerical_cols]

#describe(data)
#describe(data_numeric)

# Construcción de la formula: T_degC ~ de todas las demás columnas numéricas
formula = @formula(T_degC ~ Cst_Cnt + Btl_Cnt + Depthm + RecInd + R_Depth + R_PRES) 

model = lm(formula, data_numeric)

println(model)


println(" Los coeficientes indican la contribución de cada característica para predecir T_degC")
println(" Valores absolutos mayores implican mayor importancia.")

println(coef(model))

# R²: Bondad de ajuste
r_squared = r2(model)
println("R^2 es una metrica que mide que tan bien un modelo de regresión lineal")
println("ajusta los datos:", r_squared)

# Clasificación de las características por la magnitud absoluta de sus coeficientes

# Extracción de coeficientes
coefficients = coef(model)[2:end]

# Clasificación de características por importancia
importance = sort(collect(zip(numerical_cols[2:end], abs.(coefficients))), by=x->x[2], rev=true)

# Impresión de factores más importantes
for (factor, value) in importance
    println("Factor: $factor, Importancia: $value")
end


# Graficación de características importantes

# Preparación de datos para impresión
factors = [factor for (factor, _) in importance]
importance_values = [value for (_, value) in importance]

# Graficación de barra
bar(factors, importance_values, xlabel="Factores", ylabel="Importancia", title="Importancia de los factores para T_degC", legend=false, xticks=:auto, orientation=:horizontal)
 