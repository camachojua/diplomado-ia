# Regression

Use the bottle.csv data from the CalCofi dataset to determine the most important factors of T_degC 


## 1. Carga de Datos:
Se cargó el conjunto de datos bottle.csv utilizando la biblioteca CSV y se almacenó en un DataFrame llamado C.

```julia
C = CSV.read("../dat/bottle.csv", DataFrame);
```
En este ejercicio,debido al consumo de memoria, se decidió trabajar con un subconjunto de las columnas del dataset.
```julia
#obtener conjunto de datos para pruebas del código
# Definir el porcentaje deseado
porcentaje = 0.2  # 200%

# Calcular el número de índices a seleccionar
num_indices = Int(round(porcentaje * nrow(C)))

# Obtener índices aleatorios
indices_aleatorios = sample(1:nrow(C), num_indices, replace=false)

# Imprimir los índices seleccionados
#println("Índices aleatorios seleccionados")
#println(indices_aleatorios)
length(indices_aleatorios)
C = C[indices_aleatorios, :]
```


## 2. Con base al ejercicio anterior, tomamos las siguientes columnas, las cuales resultan ser las más relevantes para el análisis de la temperatura del agua.

```julia
c_working = select(C, [:T_degC, :O2Sat, :R_TEMP, :R_POTEMP, :R_SVA, :R_O2Sat]);
```
6-element Vector{Any}:
 ("T_degC", Real)
 ("O2Sat", Real)
 ("R_TEMP", Real)
 ("R_POTEMP", Real)
 ("R_SVA", Real)
 ("R_O2Sat", Real)


//
Observar las relaciones entre las variables respecto a T_degC

```julia
# Obtener todas las columnas excepto T_degC
otras_columnas = filter(x -> x != "T_degC", names(c_working))

# Crear un plot para cada columna vs T_degC
plots = []
for columna in otras_columnas
    p = scatter( c_working.T_degC,c_working[!, columna], 
               xlabel="T_degC", 
               ylabel=columna,
               title="$columna vs T_degC",
               legend=false,
               alpha=0.5)
    push!(plots, p)
end
x = plot(plots..., layout=(3,3), size=(1200,1000))
savefig(x, "plots.png") 

```

![plots](../fig/plots.png)    

Dadas las relaciones entre las variables respecto a T_degC, se puede observar que las variables R_TEMP y R_POTEMP son basicamente el mismos dato de temperatura, por lo que se decide trabajar con: R_SVA y O2Sat(parece  ser la misma variable R_O2Sat) para localizar la relación lineal con T_degC.

Se crea la siguientes funciones para encontrar la relación lineal entre las variables:

```julia
function find_best_fit(xvals,yvals)
    meanx = mean(xvals)
    meany = mean(yvals)
    stdx = std(xvals)
    stdy = std(yvals)
    r = cor(xvals,yvals)
    a = r*stdy/stdx
    b = meany - a*meanx
    return a,b
end
```

Primero, creamos los sets de datos para las variables R_SVA y T_degC:
```julia
xvals = c_working[!, "T_degC"]
yvals = c_working[!, "R_SVA"]
```

Luego, se llama a la función find_best_fit para obtener los coeficientes a y b:
```julia
a, b = find_best_fit(xvals, yvals)
ynew = a .* xvals_ .+ b
```
y utilizamos la función plot para graficar los datos originales y la recta de regresión:
```julia
x = scatter(xvals_, ynew,
    markersize=2, 
    label="Ajuste lineal",
    color=:red)

    scatter!(xvals_, yvals_,
    markersize=1,
    label="Datos originales", 
    color=:blue)
```

Se hizo el mismo procedimiento para las variables O2Sat y T_degC, y se obtuvo el siguiente resultado:



![plots](../fig/regresionLineal.png)  

![plots](../fig/regresionLineal_O2Sat.png)  

Resumen:
Se puede observar que la variable R_SVA es la que tiene una mayor correlación con T_degC, por lo que se puede decir que es la variable más importante para determinar la temperatura del agua.
