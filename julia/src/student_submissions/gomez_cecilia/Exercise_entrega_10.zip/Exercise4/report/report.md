# Análisis de Reducción de Dimensionalidad

En este reporte analizaremos los diferentes métodos de reducción de dimensionalidad implementados en el código fuente ubicado en `src/DimensionalityReduction`.

## PCA (Principal Component Analysis)

El análisis de componentes principales es una técnica de reducción de dimensionalidad que transforma los datos a un nuevo sistema de coordenadas donde la varianza es maximizada. En la implementación se utilizó:

- Estandarización de los datos
- Descomposición en valores singulares (SVD)
- Proyección de los datos al nuevo espacio

Liga a reporte completo porque no se puede subir las imagenes completas al git: [Reporte completo](https://drive.google.com/file/d/15CWl1fy3-xzJqZLbQFbaArGGqwbizR7a/view?usp=sharing)


Resultados visuales:


<table>

<tbody>
    <tr>
    	<td>
		<figure>
	  <image src="../fig/img01/img_gray.jpg">
	 <figcaption>Imagen es escala de grises 4.1MB</figcaption>
	</figure>
	  </td>
      <td>      </td>
      <td></td>
    </tr>
	<tr>
    	<td>
          <figure>
		        <image src="../fig/img01/img_k_1000.jpg" >
		        <figcaption>K=1000 3.7MB</figcaption>
		      </figure>
      </td>
      <td>
          <figure>
		        <image src="../fig/img01/img_k_500.jpg" >
		        <figcaption>K=500 3.5MB</figcaption>
		      </figure>
      </td>
      <td>
          <figure>
		        <image src="../fig/img01/img_k_250.jpg">
		        <figcaption>K=250 3.0MB</figcaption>
		      </figure>
      </td>
    </tr>
    <tr>
    	<td>
          <figure>
		        <image src="../fig/img01/img_k_100.jpg">
		        <figcaption>k=100 2.4MB</figcaption>
		      </figure>
      </td>
      <td>
          <figure>
		        <image src="../fig/img01/img_k_50.jpg">
		        <figcaption>k=50 31.9MB</figcaption>
		      </figure>
      </td>
      <td>
          <figure>
		        <image src="../fig/img01/img_k_10.jpg" >
		        <figcaption>k=10 1.2MB</figcaption>
		      </figure>
      </td>
    </tr>    
</tbody>
</table>

<table>

<tbody>
    <tr>
    	<td>
		<figure>
	  <image src="../fig/img02/img_gray.jpg">
	 <figcaption>Imagen es escala de grises 6.01MB</figcaption>
	</figure>
	  </td>
      <td>      </td>
      <td></td>
    </tr>
	<tr>
    	<td>
          <figure>
		        <image src="../fig/img02/img_k_1000.jpg" >
		        <figcaption>K=1000 5.0MB</figcaption>
		      </figure>
      </td>
      <td>
          <figure>
		        <image src="../fig/img02/img_k_500.jpg" >
		        <figcaption>K=500 4.5MB</figcaption>
		      </figure>
      </td>
      <td>
          <figure>
		        <image src="../fig/img02/img_k_250.jpg">
		        <figcaption>K=250 3.9MB</figcaption>
		      </figure>
      </td>
    </tr>
    <tr>
    	<td>
          <figure>
		        <image src="../fig/img02/img_k_100.jpg">
		        <figcaption>k=100 3.1MB</figcaption>
		      </figure>
      </td>
      <td>
          <figure>
		        <image src="../fig/img02/img_k_50.jpg">
		        <figcaption>k=50 2.6MB</figcaption>
		      </figure>
      </td>
      <td>
          <figure>
		        <image src="../fig/img02/img_k_10.jpg" >
		        <figcaption>k=10 1.8MB</figcaption>
		      </figure>
      </td>
    </tr>    
</tbody>
</table>

<table>

<tbody>
    <tr>
    	<td>
		<figure>
	  <image src="../fig/img03/img_gray.jpg">
	 <figcaption>Imagen es escala de grises 3.1MB</figcaption>
	</figure>
	  </td>
      <td>      </td>
      <td></td>
    </tr>
	<tr>
    	<td>
          <figure>
		        <image src="../fig/img03/img_k_1000.jpg" >
		        <figcaption>K=1000 2.9MB</figcaption>
		      </figure>
      </td>
      <td>
          <figure>
		        <image src="../fig/img03/img_k_500.jpg" >
		        <figcaption>K=500 2.9MB</figcaption>
		      </figure>
      </td>
      <td>
          <figure>
		        <image src="../fig/img03/img_k_250.jpg">
		        <figcaption>K=250 2.9MB</figcaption>
		      </figure>
      </td>
    </tr>
    <tr>
    	<td>
          <figure>
		        <image src="../fig/img03/img_k_100.jpg">
		        <figcaption>k=100 2.6MB</figcaption>
		      </figure>
      </td>
      <td>
          <figure>
		        <image src="../fig/img03/img_k_50.jpg">
		        <figcaption>k=50 2.2MB</figcaption>
		      </figure>
      </td>
      <td>
          <figure>
		        <image src="../fig/img03/img_k_10.jpg" >
		        <figcaption>k=10 1.6MB</figcaption>
		      </figure>
      </td>
    </tr>    
</tbody>
</table>

<table>

<tbody>
    <tr>
    	<td>
		<figure>
	  <image src="../fig/img04/img_gray.jpg">
	 <figcaption>Imagen es escala de grises 4.8MB</figcaption>
	</figure>
	  </td>
      <td>      </td>
      <td></td>
    </tr>
	<tr>
    	<td>
          <figure>
		        <image src="../fig/img04/img_k_1000.jpg" >
		        <figcaption>K=1000 3.9MB</figcaption>
		      </figure>
      </td>
      <td>
          <figure>
		        <image src="../fig/img04/img_k_500.jpg" >
		        <figcaption>K=500 3.3MB</figcaption>
		      </figure>
      </td>
      <td>
          <figure>
		        <image src="../fig/img04/img_k_250.jpg">
		        <figcaption>K=250 2.8MB</figcaption>
		      </figure>
      </td>
    </tr>
    <tr>
    	<td>
          <figure>
		        <image src="../fig/img04/img_k_100.jpg">
		        <figcaption>k=100 2.2MB</figcaption>
		      </figure>
      </td>
      <td>
          <figure>
		        <image src="../fig/img04/img_k_50.jpg">
		        <figcaption>k=50 1.9MB</figcaption>
		      </figure>
      </td>
      <td>
          <figure>
		        <image src="../fig/img04/img_k_10.jpg" >
		        <figcaption>k=10 1.3MB</figcaption>
		      </figure>
      </td>
    </tr>    
</tbody>
</table>

<table>

<tbody>
    <tr>
    	<td>
		<figure>
	  <image src="../fig/img05/img_gray.jpg">
	 <figcaption>Imagen es escala de grises 4.4MB</figcaption>
	</figure>
	  </td>
      <td>      </td>
      <td></td>
    </tr>
	<tr>
    	<td>
          <figure>
		        <image src="../fig/img05/img_k_1000.jpg" >
		        <figcaption>K=1000 4.3MB</figcaption>
		      </figure>
      </td>
      <td>
          <figure>
		        <image src="../fig/img05/img_k_500.jpg" >
		        <figcaption>K=500 4.2MB</figcaption>
		      </figure>
      </td>
      <td>
          <figure>
		        <image src="../fig/img05/img_k_250.jpg">
		        <figcaption>K=250 3.9MB</figcaption>
		      </figure>
      </td>
    </tr>
    <tr>
    	<td>
          <figure>
		        <image src="../fig/img05/img_k_100.jpg">
		        <figcaption>k=100 3.3MB</figcaption>
		      </figure>
      </td>
      <td>
          <figure>
		        <image src="../fig/img05/img_k_50.jpg">
		        <figcaption>k=50 2.9MB</figcaption>
		      </figure>
      </td>
      <td>
          <figure>
		        <image src="../fig/img05/img_k_10.jpg" >
		        <figcaption>k=10 2.0MB</figcaption>
		      </figure>
      </td>
    </tr>    
</tbody>
</table>



