# Exploratory Data Analysis

This exercise is about building the exploratory data analysis of the dataset `dat/bottle.csv`.


## 1. Carga de Datos:
Se cargó el conjunto de datos bottle.csv utilizando la biblioteca CSV y se almacenó en un DataFrame llamado C.

```julia
C = CSV.read("../dat/bottle.csv", DataFrame);
```

## 2. Conocer el tamaño del conjunto de datos:
dataShape(C): Devuelve las dimensiones del conjunto de datos.


```julia
function dataShape(C)
    return size(C)
end
```
Ejemplo de uso
```julia
dataShape(C)
Resultado:
Shape of the data: (864863, 74)
```
## 2. Conocer el tipo de datos de cada columna:
dataType(C, output): Devuelve el tipo de datos de cada columna, ya sea en formato de diccionario o lista.

Podemos usar la función describe para obtener el tipo de datos de cada columna.

```julia
function dataType(C, output)
    return describe(C, :eltype)
end
```

Sin embargo, se creo la funcion dataShape, para obtener una lista que solo contenga el tipo de datos de cada columna. La salida puede ser en formato de diccionario o lista dependiendo de la variable output.

```julia
function dataType(C, output = "dict")
    if output == "dict"
        column_info = Dict(names(C) .=> [eltype(C[!, col]) for col in names(C)])

    else
        column_info = []
        for i in 1:size(C, 2)
            push!(column_info, (names(C)[i], eltype(C[!, i])))
        end
    end
    return column_info
end
```
Ejemplo de uso:
```julia
info_columns = dataType(C, "list")
Resultado:
74-element Vector{Any}:
 ("Cst_Cnt", Int64)
 ("Btl_Cnt", Int64)
 ("Sta_ID", String15)
 ("Depth_ID", String)
 ("Depthm", Int64)
 ("T_degC", Union{Missing, Float64})
 ("Salnty", Union{Missing, Float64})
 ("O2ml_L", Union{Missing, Float64})
 ("STheta", Union{Missing, Float64})
 ("O2Sat", Union{Missing, Float64})
 ⋮
 ("R_PRES", Int64)
 ("R_SAMP", Union{Missing, Int64})
 ("DIC1", Union{Missing, Float64})
 ("DIC2", Union{Missing, Float64})
 ("TA1", Union{Missing, Float64})
 ("TA2", Union{Missing, Float64})
 ("pH2", Union{Missing, Float64})
 ("pH1", Union{Missing, Float64})
 ("DIC Quality Comment", Union{Missing, String})
```

## 3. Contar el número de datos faltantes en cada columna

dataMissingPercentage(C): Calcula el porcentaje de datos faltantes para cada columna.

```julia
function count_missing(C, col)
    return sum(ismissing.(C[:, col]))
end
```
Ejemplo de uso:
```julia
count_missing(C, "Cst_Cnt")
Resultado:
0
```

## 4. Calcular por columna el porcentaje de datos faltantes

```julia
function dataMissingPercentage(C)
    length_C = size(C, 1)
    missing_percentage = []
    for i in 1:size(C, 2)
        push!(missing_percentage, (names(C)[i], sum(ismissing.(C[:, i])) / length_C))
    end
    return missing_percentage
end
```
Ejemplo de uso:
```julia
dataMissingPercentage(C)
Resultado:
74-element Vector{Any}:
 ("Cst_Cnt", 0.0)
 ("Btl_Cnt", 0.0)
 ("Sta_ID", 0.0)
 ("Depth_ID", 0.0)
 ("Depthm", 0.0)
 ("T_degC", 0.012675996082616553)
 ("Salnty", 0.054753180561545586)
 ("O2ml_L", 0.19501585800294383)
 ("STheta", 0.06092178761260454)
 ("O2Sat", 0.2354002888318728)
 ⋮
 ("R_PRES", 0.0)
 ("R_SAMP", 0.8589302583183694)
 ("DIC1", 0.9976886512661542)
 ("DIC2", 0.99974099944153)
 ("TA1", 0.9975903698042349)
 ("TA2", 0.9997294369165983)
 ("pH2", 0.9999884374750683)
 ("pH1", 0.9999028747905737)
 ("DIC Quality Comment", 0.9999364061128757)
```
## 5. Eliminar columnas con un porcentaje de datos faltantes menor al 50%

```julia
function deleteColumns(C,threshold)
   length_C = size(C, 1)
          
    return C[:, [count_missing(C, i) / length_C < threshold for i in 1:size(C, 2)]]
end
```
Ejemplo de uso:
```julia
c_working = deleteColumns(C, 0.4)
Resultado:
En este ejemplo, guardamos el reusltado en un dataset llamado c_working donde se ira alamcenando los datos que finalmente serán analizados.

tamaño de c_working: 864863×34 por lo que se eliminaron 40 columnas.
```

## 5.1 Función para columnas seleccionadas
Usamos la función #9 deleteSelectedColumns para eliminar las columnas que no se necesitan para el análisis. Esta función elimina las columnas que no se necesitan para el análisis.

```julia
function deleteSelectedColumns(C, deleteColumns)
    return C[:, deleteColumns]
end
``` 

Con el siguiente paso se localiza para eliminar aquellas columnas con datos tipo string, de manea adicional se reemplazan los datos faltantes con el valor 0.

```julia
columnas_string = names(c_working)[eltype.(eachcol(c_working)) .<: Union{String, Missing, String15}]

c_working= deleteSelectedColumns(c_working, columnas_string)

# Reemplazar valores missing con la media de cada columna o valor 0
for col in names(c_working)
    valores_no_missing = skipmissing(c_working[!, col])
    media = 0
    c_working[!, col] = coalesce.(c_working[!, col], media)
end
```
Ejemplo de uso:

```julia
Resultado:
Ahora el tamaño de c_working es de 864863×33 por lo que se eliminaron 2 columnas más.
```
## 6. Calcular la matriz de correlación

```julia
function calculateCorrelation(C)
    return cor(C)
end
```
Ejemplo de uso:
```julia
calculateCorrelation(c_working)
Resultado:
32×32 Matrix{Float64}:
  1.0         0.999345   -0.162222   …   0.191619    0.22442    -0.161961
  0.999345    1.0        -0.161617       0.191053    0.223831   -0.161348
 -0.162222   -0.161617    1.0           -0.440918   -0.44045     0.999994
  0.100735    0.101639   -0.639525       0.580629    0.625449   -0.638287
  0.222286    0.22134    -0.0399072      0.055398    0.194554   -0.0402077
  0.191604    0.191037   -0.440918   …   0.999999    0.959315   -0.439661
  0.207768    0.206726    0.0457082     -0.0175562   0.113498    0.0452192
  0.228822    0.227982   -0.434974       0.949177    0.985164   -0.433815
  0.239783    0.238842   -0.421239       0.951564    0.97992    -0.42008
 -0.100142   -0.100828    0.0823158     -0.0804611  -0.0792346   0.0821835
  ⋮                                  ⋱               ⋮          
  0.100742    0.101647   -0.639525       0.58063     0.62545    -0.638288
  0.187184    0.187816   -0.590847       0.541414    0.660366   -0.589806
  0.222287    0.22134    -0.0399091  …   0.0554018   0.194557   -0.0402097
  0.229878    0.228961    0.0321388     -0.0229417   0.111728    0.0316632
  0.214995    0.214225   -0.578759       0.601788    0.706429   -0.577604
 -0.0671139  -0.0674926   0.798042      -0.49695    -0.472972    0.796774
  0.191619    0.191053   -0.440918       1.0         0.959314   -0.439661
  0.22442     0.223831   -0.44045    …   0.959314    1.0        -0.439283
 -0.161961   -0.161348    0.999994      -0.439661   -0.439283    1.0

```
## 7. Visualizar la matriz de correlación

```julia
function displayCorrelation(C)
    
    return heatmap(correlation_mat, colormap=:bam , axis=(title="Mapa de calor de matriz de correlacion",))
end
```
Resultado:

![correlation_mat](../fig/correlation_mat.png)

## 8. Eliminar los outliers de una columna  
se crea una función para eliminar los outliers de una columna dada.

```julia
    data = C[:,column]  # Ejemplo de datos
    rango_iqr = iqr(C[:,column])
    # Calcular Q1 y Q3
    Q1 = quantile(data, 0.25)
    Q3 = quantile(data, 0.75)

    println("El rango intercuartílico es: ", rango_iqr)
    println("El Q1 es: ", Q1)
    println("El Q3 es: ", Q3)

    # Definir límites para outliers
    limite_inferior = Q1 - 1.5 * rango_iqr
    limite_superior = Q3 + 1.5 * rango_iqr

    # Encontrar índices de outliers
    indices_outliers = findall(x -> x < limite_inferior || x > limite_superior, data)
    println("Número de outliers encontrados: ", length(indices_outliers))

    # Eliminar filas con outliers
    data_outliers = C[setdiff(1:nrow(C), indices_outliers), :]  
    return data_outliers
```
Ejemplo de uso:
```julia
removeOutliers(C, "T_degC")

```
Resultado:
``` julia
El rango intercuartílico es: 6.26
El Q1 es: 7.57
El Q3 es: 13.83
Número de outliers encontrados: 3692

El tamaño del dataset resultante es: (864863, 6)
```

## 10. Seleccionar las columnas con una alta correlación con T_degC
Se crea una funcion para localizar las columans donde la correlación con una columna dada, en el ejemplo T_degC, es mayor a un umbral, en el ejemplo se considera mayor a 0.60.

```julia
function filterColumnsByCorrelation(C, target, threshold, relation)

target_index = findfirst(isequal(target), names(c_working))
indices_mayor_correlacion = findall(x -> x > threshold, correlation_mat[:, target_index])
c_working_2 =select(c_working, indices_mayor_correlacion)


    return select(c_working, indices_mayor_correlacion)
end
```
Ejemplo de uso:
```julia
filterColumnsByCorrelation(c_working, "T_degC", 0.60, correlation_mat)
Resultado:
6-element Vector{Any}:
 ("T_degC", Real)
 ("O2Sat", Real)
 ("R_TEMP", Real)
 ("R_POTEMP", Real)
 ("R_SVA", Real)
 ("R_O2Sat", Real)
```

# 11. Describe el dataset resultante
Finalmente se describe el dataset resultante.

```julia
describeData(c_working_2)
```
resultado:
| Row | variable | mean | min | median | max | nmissing | eltype |
|-----|----------|------|-----|--------|-----|----------|--------|
| 1 | T_degC | 10.6628 | 0.0 | 9.99 | 31.14 | 0 | Real |
| 2 | O2Sat | 43.6615 | -0.1 | 34.0 | 214.1 | 0 | Real |
| 3 | R_TEMP | 10.6628 | 0.0 | 9.99 | 31.14 | 0 | Real |
| 4 | R_POTEMP | 10.265 | 0.0 | 9.81 | 31.14 | 0 | Real |
| 5 | R_SVA | 207.458 | 0.0 | 192.3 | 683.4 | 0 | Real |
| 6 | R_O2Sat | 44.0719 | -0.1 | 34.8 | 214.1 | 0 | Real |


Resumen:
Este notebook proporciona un flujo de trabajo básico para realizar un análisis exploratorio de datos, incluyendo la limpieza de datos, el manejo de valores faltantes, y el análisis de correlación.
