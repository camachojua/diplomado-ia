# Use Flux for Logistic Regression

En este ejercicio se implementa un modelo de regresión logística usando Flux. El conjunto de datos utilizado es Churn Modelling el cual contiene información de clientes de un banco y si han cancelado su cuenta o no.

## Preparación del entorno

Para este ejercicio se utiliza el entorno de Julia 1.10.0 y el paquete Flux 0.15.10.

## Preparación del conjunto de datos

El conjunto de datos se encuentra en el archivo `Churn_Modelling.csv` y se encuentra en el directorio `data`. A continuación se describe el contenido del archivo:

El conjunto de datos contiene 14 columnas, las cuales son las siguientes:

- RowNumber: Número de fila.
- CustomerId: Identificador del cliente.
- Surname: Apellido del cliente.
- CreditScore: Puntuación de crédito del cliente.
- Geography: Región geográfica del cliente.
- Gender: Género del cliente.
- Age: Edad del cliente.
- Tenure: Años de pertenencia al banco.
- Balance: Saldo en la cuenta del cliente.
- NumOfProducts: Número de productos bancarios del cliente.
- HasCrCard: Si el cliente tiene una tarjeta de crédito.
- IsActiveMember: Si el cliente es activo.
- EstimatedSalary: Salario estimado del cliente.
- Exited: Si el cliente ha cancelado su cuenta (1 si ha cancelado, 0 si no ha cancelado).

En este ejercicio se busca estimar si un cliente cancelará su cuenta en base a las características del cliente.
Para este ejercicio se utiliza el conjunto de datos como conjunto de entrenamiento y se divide en 80% para entrenamiento y 20% para prueba.
## Limpieza de datos
Se realizo un preprocesamiento de los datos, se eliminaron las columnas `RowNumber`, `CustomerId` y `Surname` ya que no son relevantes para el modelo. Se calcularon las columnas `Geography` y `Gender` para pasarlas a un formato numérico, 

Para el entremiento con 10 caracteriticas se utilizaron las columnas `CreditScore`, `Age`, `Tenure`, `Balance`, `NumOfProducts`, `HasCrCard`, `IsActiveMember`, `EstimatedSalary`, `num_Geography` y `num_Gender`

Y para el entrenamiento con 5 caracteristicas se utilizaron las columnas `Tenure`, `Balence` , `hasCrCard`, `IsActiveMember` y `EstimatedSalary`

A continuación se muestra el código para el preprocesamiento de los datos:

```julia
# Verificar países únicos en Geography
países_únicos = unique(C.Geography)
println("Países únicos en el dataset: ", países_únicos)

# Crear columnas numéricas para Geography y Gender
C.Geography_num = map(x -> if x == "France" 
                            1 
                         elseif x == "Spain"
                            2
                         elseif x == "Germany"
                            3
                         end, C.Geography)

# Convertir Gender a valores numéricos (0 para Female, 1 para Male)
C.Gender_num = map(x -> x == "Male" ? 1 : 0, C.Gender)
if numeroatributos == 10
C=C[!, [:Geography_num, :Gender_num, :CreditScore, :Age, :Tenure, :Balance, :NumOfProducts, :HasCrCard, :IsActiveMember, :EstimatedSalary, :Exited]]  
elseif numeroatributos == 5
C=C[!, [ :Tenure, :Balance, :HasCrCard, :IsActiveMember, :EstimatedSalary, :Exited]]  
end
```
Elegir el conjunto   de datos para el entrenamiento y prueba
```julia
@show size(C)
#obtener conjunto de datos para pruebas del código
# Definir el porcentaje deseado
porcentaje = 0.8 

# Calcular el número de índices a seleccionar
num_indices = Int(round(porcentaje * nrow(C)))

# Obtener índices aleatorios
indices_aleatorios = sample(1:nrow(C), num_indices, replace=false)

c_train = C[indices_aleatorios, :]
c_test = C[setdiff(1:nrow(C), indices_aleatorios), :]
```

## Implementación del modelo

Primero se define la función de activación sigmoide:

```julia
m(W, b, x) = W*x .+ b
W = rand(Float32, 2, numeroatributos);
b = [0.0f0, 0.0f0];


```

Luego se crea el modelo de regresión logística:

```julia
flux_model = Chain(Dense(numeroatributos => 2), softmax)
```

Luego se define la función de pérdida:

```julia
function flux_loss(flux_model, features, labels_onehot)
    ŷ = flux_model(features)
    Flux.logitcrossentropy(ŷ, labels_onehot)
end;
```

Luego se define la función de optimización:

```julia

flux_accuracy(x, y) = mean(Flux.onecold(flux_model(x), classes) .== y);
```

Luego se define la función de entrenamiento:

```julia
function train_flux_model!(f_loss, model, features, labels_onehot)
    dLdm, _, _ = gradient(f_loss, model, features, labels_onehot)
    @. model[1].weight = model[1].weight - 0.1 * dLdm[:layers][1][:weight]
    @. model[1].bias = model[1].bias - 0.1 * dLdm[:layers][1][:bias]
end;
for i = 1:500
    train_flux_model!(flux_loss, flux_model, x, flux_y_onehot);
    flux_accuracy(x, y) >= 0.98 && break
end
```
En este caso se entrena el modelo 500 veces y se detiene cuando la precisión es mayor a 0.98.

## Resultados
Se probo el modelo con 10 atributos y 5 atributos, los resultados se muestran en las siguientes figuras:
Con  10 atributos este fue un  el resultado de lo matriz de confusión y la curva ROC.

### Entrenamiento con 10 atributos
Matriz de confusión:
| | NO CANCELA | SI CANCELA |
|-------------|------------|------------|
| NO CANCELA | 1611 | 1 |
| SI CANCELA | 388 | 0 |

Encontramos que el modelo no es muy bueno, ya que tiene muchas más posibilidades de clasificar correctamente los datos de prueba. Aunque la precision fue de:0.8055
![ROC Curve 10 atributos](../fig/roc_curve_10.png)
### Entrenamiento con 5 atributos
Matriz de confusión:
| | NO CANCELA | SI CANCELA |
|-------------|------------|------------|
| NO CANCELA | 1597 | 0 |
| SI CANCELA | 403 | 0 |

Encontramos que el modelo no es muy bueno, ya que tiene muchas más posibilidades de clasificar correctamente los datos de prueba. Aunque la precision fue de:0.7985, menor que el modelo con 10 atributos.
![ROC Curve 5 atributos](../fig/roc_curve_5.png)
