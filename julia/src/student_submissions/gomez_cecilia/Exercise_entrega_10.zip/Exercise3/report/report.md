# Classification
En este ejercicio, se utilizan los datos del dataset Market de ISL para realizar la clasificación de los datos. 

Se define a continuación el conjunto de características que se utilizarán para la clasificación y se extrae le set de etiquetas.

```julia
x = Matrix(market[!, [:Lag1, :Lag2, :Lag3, :Lag4, :Lag5, :Volume, :Today]])
market_labels = Matrix(market[!, [:Direction]])
```
Las etiquetas son las que se encuentran en la columna Direction del mercado: UP y DOWN.

```julia
#Valores unicos de la columna Direction
marketLabelsMap = labelmap(market_labels)
y = map(v -> v == "Down" ? 0 : 1, market_labels)
# Como la clasificación es binaria, se puede usar el mapeo de etiquetas para codificar las etiquetas
```

Ahora, se procede a separar los datos en conjuntos de entrenamiento y prueba.

```julia
#Separar los datos en conjuntos de entrenamiento y prueba
train_ids = perclass_splits(y, 0.7)
test_ids = setdiff(1:length(y,), train_ids)

train_x = x[train_ids,:]
train_y = y[train_ids]
test_x = x[test_ids,:]
test_y = y[test_ids]    
```

Con este preprocesamiento, se realiza la clasificación de los datos utilizando los siguientes algoritmos:
-LASSO
-Ridge
-Elastic Net
-Decision Tree
-Random Forest
-Nearest Neighbors
-Support Vector Machines (SVM)


## LASSO

```julia
path = glmnet(train_x, train_y )
cv = glmnetcv(train_x, train_y)
mylambda = path.lambda[argmin(cv.meanloss)]
path = glmnet(train_x, train_y, lambda=[mylambda])
q = x[test_ids,:]
predictions_lasso_prob   =GLMNet.predict(path, q)
predictions_lasso = map(v -> v > .5 ? 1 : 0, predictions_lasso_prob)
```
Matriz de confusión:

| | UP | DOWN |
| --- | --- | --- |
| UP | 181 | 1 |
| DOWN | 8 | 72 |

Presicion: 0.9751

![ROC LASSO](../fig/ROC_LASSO.png) 


## Ridge

```julia
#We will use the same function but set alpha to zero.
# choose the best lambda to predict with.
path = glmnet(train_x, train_y,alpha=0);
cv = glmnetcv(train_x, train_y,alpha=0)
mylambda = path.lambda[argmin(cv.meanloss)]
path = glmnet(train_x, train_y,alpha=0,lambda=[mylambda]);
q = test_x;
predictions_ridge_prob   = GLMNet.predict(path,q)
predictions_ridge = map(v -> v > .5 ? 1 : 0, predictions_ridge_prob)
findaccuracy(predictions_ridge,test_y)
```
Matriz de confusión:

| | UP | DOWN |
| --- | --- | --- |
| UP | 181 | 1 |
| DOWN | 21 | 159 |

Presicion: 0.9392

![ROC RIDGE](../fig/ROC_RIDGE.png) 


## Elastic Net

```julia
#We will use the same function but set alpha to 0.5 (it's the combination of lasso and ridge).

#choose the best lambda to predict with.
path = glmnet(train_x, train_y,alpha=0.5);
cv = glmnetcv(train_x, train_y,alpha=0.5)
mylambda = path.lambda[argmin(cv.meanloss)]
path = glmnet(train_x, train_y,alpha=0.5,lambda=[mylambda]);
q = test_x;
predictions_EN_prob = GLMNet.predict(path,q)
predictions_EN = map(v -> v > .5 ? 1 : 0, predictions_EN_prob)
findaccuracy(predictions_EN,test_y)
```
Matriz de confusión:

| | UP | DOWN |
| --- | --- | --- |
| UP | 182 | 0 |
| DOWN | 18 | 162 |

Presicion: 0.9502

![ROC ELASTIC NET](../fig/ROC_ELASTIC_NET.png) 


## Decision Tree

```julia
Pkg.add("DecisionTree"); using DecisionTree
model = DecisionTreeClassifier(max_depth=2)
DecisionTree.fit!(model, train_x, train_y)
q = test_x;
predictions_DT_prob = DecisionTree.predict(model, q)
predictions_DT = map(v -> v > .5 ? 1 : 0, predictions_DT_prob)
findaccuracy(predictions_DT,test_y)
```
Matriz de confusión:

| | UP | DOWN |
| --- | --- | --- |
| UP | 182 | 0 |
| DOWN | 0 | 180 |

Presicion: 1

![ROC DECISION TREE](../fig/ROC_DECISION_TREE.png) 


## Random Forest

```julia
#The RandomForestClassifier is available through the DecisionTree package as well.

model = RandomForestClassifier(n_trees=20)
DecisionTree.fit!(model, train_x, train_y)
q = test_x;
predictions_RF_prob = DecisionTree.predict(model, q)
predictions_RF = map(v -> v > .5 ? 1 : 0, predictions_RF_prob)
findaccuracy(predictions_RF,test_y)

```
Matriz de confusión:

| | UP | DOWN |
| --- | --- | --- |
| UP | 182 | 0 |
| DOWN | 0 | 180 |

Presicion: 1

![ROC RANDOM FOREST](../fig/ROC_RANDOM_FOREST.png) 



## Nearest Neighbors

```julia
#We will use the NearestNeighbors package here.
Pkg.add("NearestNeighbors"); using NearestNeighbors
kdtree = KDTree(train_x')
queries = test_x
idxs, dists = knn(kdtree, queries', 5, true)
c = train_y[hcat(idxs...)]
#possible_labels = map(i->counter(c[:,i]),1:size(c,2))
predictions_NN = map(i->parse(Float32,string(string(argmax(c[i])))),1:size(c,2))
findaccuracy(predictions_NN,test_y)
```
Matriz de confusión:

| | UP | DOWN |
| --- | --- | --- |
| UP | 182 | 0 |
| DOWN | 180 | 0 |

Presicion: .50

## Support Vector Machines (SVM)


```julia
#We will use the LIBSVM package here.
Pkg.add("LIBSVM"); using LIBSVM
model = svmtrain(train_x', train_y)
predictions_SVM, decision_values  = svmpredict(model, test_x')
findaccuracy(predictions_SVM,test_y)

```
Matriz de confusión:

| | UP | DOWN |
| --- | --- | --- |
| UP | 178 | 4 |
| DOWN | 15 | 165 |

Presicion: 94



# Tabla comparativa de los algoritmos

Ejercicio 1 - usando todo el dataset
<table>
    <tr>
        <th>Algoritmo</th>
        <th>Accuracy</th>
   </tr>   
    <tr>
        <td>LASSO</td>
        <td>0.9751</td>     
    </tr>
    <tr>
        <td>RIDGE</td>
        <td>0.9392</td>     
    </tr>
    <tr>
        <td>ELASTIC NET</td>
        <td>0.9502</td>     
    </tr>
    <tr>
        <td>DECISION TREE</td>
        <td>1</td>     
    </tr>
    <tr>
        <td>RANDOM FOREST</td>
        <td>1</td>     
    </tr>
    <tr>
        <td>NearestNeighbors</td>
        <td>0.50</td>     
    </tr>
    <tr>
        <td>SVM</td>
        <td>0.94</td>     
    </tr>
</table>
