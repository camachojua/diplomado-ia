# Visualización de grafos

## Grafo aleatorio

Se crea un grafo aleatorio con n nodos y se grafica.

Para crear el grafo se creo  la función `create_random_geometric_graph`  haciendo uso del paquete `LightGraphs`.

```julia
using LightGraphs
function create_random_geometric_graph(n, radius)
    G = SimpleGraph(n)  # Crear un grafo vacío con n nodos
    positions = rand(n, 2)  # Generar posiciones aleatorias en un cuadrado [0, 1] x [0, 1]

    # Inicializar dmin y ncenter
    dmin = Inf
    ncenter = 0

    for i in 1:n
        d = norm(positions[i, :] - [0.5, 0.5])  # Calcular la distancia al centro (0.5, 0.5)
        if d < dmin
            ncenter = i
            dmin = d
        end
    end

    for i in 1:n
        for j in (i+1):n  # Evitar conexiones duplicadas
            dist = norm(positions[i, :] - positions[j, :])  # Calcular la distancia
            if dist <= radius
                add_edge!(G, i, j)  # Conectar los nodos si están dentro del radio
            end
        end
    end

    return G, positions, ncenter  # Devolver también el nodo más cercano al centro
end
```
En el ejemplo se crea un grafo con 100 nodos y un radio de 0.3.

```julia
n = 100
radius = 0.3
G, pos, ncenter = create_random_geometric_graph(n, radius)
```

Se utilizo Plots para graficar el grafo, utilizando el siguiente código:

```julia
using Plots
for e in edges(G)
   
    # Calcular la distancia entre los nodos
 
    # Calcular el punto medio de la arista
    mid_x = (pos[src(e), 1] + pos[dst(e), 1])/2
    mid_y = (pos[src(e), 2] + pos[dst(e), 2])/2
    # Calcular distancia del punto medio al centro
    dist_to_center = norm([mid_x, mid_y] - pos[ncenter, :])
    # Definir color basado en la distancia (más cercano = más oscuro)
    edge_color = RGB(0.6*dist_to_center, 0.2*dist_to_center, 0.2*dist_to_center)

    # Graficar la arista con el color calculado basado en la distancia
    scatter!([pos[src(e), 1]], [pos[src(e), 2]], color=edge_color, markersize=6 ,legend=false) 
    # Graficar la arista con el color calculado
    plot!([pos[src(e), 1], pos[dst(e), 1]], [pos[src(e), 2], pos[dst(e), 2]], color=:gray, alpha=0.2, legend=false)
    
end

# Resaltar el nodo más cercano al centro
scatter!([pos[ncenter, 1]], [pos[ncenter, 2]], color=:red, markersize=7 ,legend=false)
```
# El resultado es el siguiente:
![Grafo aleatorio](../fig/random_geometric_graph.png)

