# Produce a plot similar to the one shown below in Julia. You may use the Plots or the Makie Package.

#= 
First, what are we seeing in the graph shown?
We're seeing a geometric array of a graph with 200 nodes
witha r = 0.125 units.

The closer to the center the node is, the darker is the hue.
=#

#changing the dorectory
cd("/Users/zoe/drv3/hm3/code/julia/hmw_diplo")

#lets replicate the same:
using Pkg
Pkg.add("LightGraphs")
Pkg.add("Plots")
Pkg.add("Random")
Pkg.add("Distances")


using LightGraphs
using Plots
using Random
using Distances

# 1. Create the random geometric graph
function randGeometricGraph(n, radius)
    positions = rand(2, n)  # Random positions for n nodes in a 2D plane
    graph = Graphs.SimpleGraph(n)
    
    for i in 1:n
        for j in i+1:n
            dist = euclidean(positions[:, i], positions[:, j])
            if dist <= radius
                Graphs.add_edge!(graph, i, j)
            end
        end
    end
    
    return graph, positions
end

# 2. Find the node nearest to the center (0.5, 0.5)
function findNodeCenter(positions)
    center = [0.5, 0.5]
    min_dist = Inf
    center_node = 0
    
    for i in 1:size(positions, 2)
        dist = euclidean(center, positions[:, i])
        if dist < min_dist
            min_dist = dist
            center_node = i
        end
    end
    
    return center_node
end

# 3. Generate the random geometric graph and positions
n = 200  # number of nodes
radius = 0.125  # connection radius
graph, positions = randGeometricGraph(n, radius)

# 4. Find the node closest to the center (0.5, 0.5)
center_node = findNodeCenter(positions)

# 5. Calculate the shortest path lengths from the center node
function shortestLengthPath(graph, center_node)
    dist = Graphs.dijkstra_shortest_paths(graph, center_node)
    return dist.dists
end



path_lengths = shortestLengthPath(graph, center_node)

# 6. Plotting the graph
P = Plots.scatter(positions[1, :], positions[2, :], zcolor=path_lengths, color=:afmhot, 
        xlabel="X", ylabel="Y", title="Random Geometric Graph", 
        size=(800, 800), marker=:circle, markersize = 8, legend=false)

# Add edges
for e in Graphs.edges(graph)
    u = Graphs.src(e)  # Starting node of the edge
    v = Graphs.dst(e)  # Ending node of the edge
    Plots.plot!([positions[1, u], positions[1, v]], [positions[2, u], positions[2, v]], 
          color=:black, linewidth=0.5)  # Add edge in gray color
end

##adding the center of it:
Plots.scatter!([positions[1, center_node]], [positions[2, center_node]], 
         color=:white, markersize=20, marker = :circle)  # Highlight the center node

#seeing the result and saving the graph
display(P)
Plots.savefig(P, "Exercise6/fig/randomGeometricalGraph.png")