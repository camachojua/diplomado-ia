using CSV, DataFrames

# Cargar base
df = CSV.read("/Users/nmedina/Documents/UNAM/Diplomado_IA/Proyectos/HM_Diciembre/use_flux_for_logistic_regression/medina_nestor/dat/Churn_Modelling.csv", DataFrame, delim=',', header=true)

# Describe de los datos
@show(describe(df))

# Preparar base 
## One Hot encoding for Gender
replace!(df.Gender, "Female" => "1")
replace!(df.Gender, "Male"  => "0")
df[!, :Gender] = parse.(Int,df[!, :Gender])

## One Hot encoding for Geography
replace!(df.Geography, "France"  => "2")
replace!(df.Geography, "Germany" => "1")
replace!(df.Geography, "Spain"   => "0")
df[!, :Geography] = parse.(Int,df[!, :Geography])

df = select(df, Not([:RowNumber,:CustomerId,:Surname]))

############################################################
#######                   FLUX                       #######
############################################################

using Flux, Statistics, ProgressMeter, Plots, Random, CUDA, cuDNN

# 1. Preparar los datos
function prepare_data(df)
    X = Matrix(df[:, 1:end-1])'  .|> Float32 # Transponer para tener features en filas
    y = Vector(df[:, end]) .|> Float32  # Target
    return X, y
end

X, y = prepare_data(df)
X = (X .- mean(X, dims=2)) ./ std(X, dims=2)

# 2. Dividir en conjuntos de entrenamiento y prueba
train_indices = Random.shuffle(1:size(X,2))[1:floor(Int, 0.8*size(X,2))]
test_indices = setdiff(1:size(X,2), train_indices)

X_train = X[:, train_indices]
y_train = y[train_indices]
X_test = X[:, test_indices]
y_test = y[test_indices]

# 3. Entrenar el modelo
# Funcion de perdida
function loss_fn(x, y)
    ŷ = model(x)
    # Calcular pesos basados en la frecuencia de clases
    n_pos = sum(y .== 1)
    n_neg = sum(y .== 0)
    pos_weight = n_neg / (n_pos + n_neg)
    neg_weight = n_pos / (n_pos + n_neg)
    
    weights = [neg_weight, pos_weight]
    sample_weights = [weights[Int(yi) + 1] for yi in y]
    
    return mean(Flux.logitbinarycrossentropy(vec(ŷ), y) .* sample_weights)
end

# Función para entrenar el modelo
function train_model!(model, X, y; epochs=1000, batch_size=32)
    # Preparar los datos - modificando cómo manejamos el target
    target = y |> gpu  # Ya no usamos onehotbatch
    loader = Flux.DataLoader((X, target) |> gpu, batchsize=batch_size, shuffle=true)
    
    # Optimizador
    optim = Flux.setup(Flux.Adam(0.0005), model)
    
    # Training loop
    losses = []
    @showprogress for epoch in 1:epochs
        for (x, y) in loader
            loss, grads = Flux.withgradient(model) do m
                ŷ = m(x)
                Flux.logitbinarycrossentropy(vec(ŷ), y)  # Usando vec para asegurar dimensiones correctas
            end
            Flux.update!(optim, model, grads[1])
            push!(losses, loss)
        end
    end
    return losses
end

# Inicilizar modelo
model = Chain(
    Dense(size(X', 2) => 20, relu),  # Capa oculta con activación ReLU
    Dense(20 => 1, σ)
) |> gpu

losses = train_model!(model, X_train, y_train)

# 4. Hacer predicciones en el conjunto de prueba
# Función para hacer predicciones
function predict_flux(model, X; threshold=0.5)
    probs = model(X |> gpu) |> cpu
    return probs, (probs .>= threshold)[1, :] .|> Bool  # Convertir a Bool
end

# Probabilidades y target estimado
y_probs, y_pred = predict_flux(model, X_test, threshold = 0.5)

# 5. Calcular y mostrar las métricas de rendimiento
# Funcion para matriz de confusión
function confusion_matrix(y_true, y_pred)
    # Convertir a Bool
    y_true = y_true .|> Bool

    tp = sum(y_pred .& y_true)
    tn = sum(.!y_pred .& .!y_true)
    fp = sum(y_pred .& .!y_true)
    fn = sum(.!y_pred .& y_true)
    
    # Calcular métricas con manejo de casos especiales
    accuracy = (tp + tn) / (tp + tn + fp + fn)
    
    # Crear la matriz de confusión para visualización
    conf_matrix = [
        "TP: $tp" "FN: $fn";
        "FP: $fp" "TN: $tn"
    ]
    
    return Dict(
        "confusion_matrix" => conf_matrix,
        "accuracy" => accuracy,
        "raw_counts" => (tp=tp, tn=tn, fp=fp, fn=fn)
    )
end

metrics = confusion_matrix(y_test, y_pred)

println("Matriz de Confusión:")
display(metrics["confusion_matrix"])
println("Accuracy: $(round(metrics["accuracy"], digits=4))")


# Función para calcular curva ROC y AUC
function plot_roc_from_scratch_Flux(y_true, y_probs)
    # Ordenar las probabilidades y etiquetas
    sorted_indices = sortperm(vec(y_probs), rev=true)
    y_true_sorted = y_true[sorted_indices]
    
    n_pos = sum(y_true)
    n_neg = length(y_true) - n_pos
    
    # Calcular puntos de la curva ROC
    tpr = Float64[]
    fpr = Float64[]
    tp = 0
    fp = 0
    
    push!(tpr, 0.0)
    push!(fpr, 0.0)
    
    for i in 1:length(y_true_sorted)
        if y_true_sorted[i] == 1
            tp += 1
        else
            fp += 1
        end
        push!(tpr, tp/n_pos)
        push!(fpr, fp/n_neg)
    end
    
    # Calcular AUC usando la regla del trapecio
    auc = 0.0
    for i in 1:length(fpr)-1
        auc += (fpr[i+1] - fpr[i]) * (tpr[i+1] + tpr[i]) / 2
    end
    
    #return fpr, tpr, auc
    # Plot ROC curve
    Plots.plot(fpr, tpr, 
    label="ROC Curve (AUC = $(round(auc, digits=3)))", 
    xlabel="False Positive Rate", 
    ylabel="True Positive Rate")
end

# Curva de raw_counts
y_test_val = y_test .|> Float64
y_pred_val = y_pred .|> Float64
plot_roc_from_scratch_Flux(y_test_val, y_pred_val)

############################################################
#######                   GLM                       #######
############################################################
using DataFrames, StatsPlots, GLM, Distributions, MultivariateStats, MLBase, Makie, GLMakie

# Cargar la base de nuevo
df = CSV.read("/Users/nmedina/Documents/UNAM/Diplomado_IA/Proyectos/HM_Diciembre/use_flux_for_logistic_regression/medina_nestor/dat/Churn_Modelling.csv", DataFrame, delim=',', header=true)

# Preparar base 
## One Hot encoding for Gender
replace!(df.Gender, "Female" => "1")
replace!(df.Gender, "Male"  => "0")
df[!, :Gender] = parse.(Int,df[!, :Gender])

## One Hot encoding for Geography
replace!(df.Geography, "France"  => "2")
replace!(df.Geography, "Germany" => "1")
replace!(df.Geography, "Spain"   => "0")
df[!, :Geography] = parse.(Int,df[!, :Geography])

df = select(df, Not([:RowNumber,:CustomerId,:Surname]))

# Con GLM se pueden contar los elementos que pertenecen a cada una de las clases de la variable targe
GLM.countmap(df.Exited)

# 1. Preparar datos
function SplitTrainTestSets( df, split )

    dfSize = size(df)
    nrows = dfSize[1]
    nrowsTrain = round(Int, (nrows*split))
    nrowsTest = round(Int, (nrows - nrowsTrain))
    dfTrain = df[1:nrowsTrain, :]
    dfTest = df[nrowsTrain+1 : nrows ,: ]

    return dfTrain, dfTest
end

dftrn, dftst =  SplitTrainTestSets(df, 0.80)

trnsize = size(dftrn)
println("trnsize = ", trnsize)

tstsize = size(dftst)
println("tstsize = ", tstsize)

# 2. Ajuste del modelo
# Fórmula 
fm = @formula(Exited ~ CreditScore + Age + Tenure + Balance + NumOfProducts + HasCrCard + IsActiveMember + EstimatedSalary + Gender + Geography)

logit = glm(fm, dftrn, Binomial(), LogitLink())

# 3. Prediccion del modelo en conjunto de prueba
prediction = predict(logit,dftst)

# Convertir probabilidad en clase
prediction_class = [if x < 0.5 0 else 1 end for x in prediction];
prediction_df = DataFrame(y_actual = dftst.Exited, y_predicted = prediction_class, prob_predicted = prediction);
prediction_df.correctly_classified = prediction_df.y_actual .== prediction_df.y_predicted

# 4. Calcular y mostrar las métricas de rendimiento
# Matriz de confusion
cm = MLBase.roc(prediction_df.y_actual, prediction_df.y_predicted)

tp = cm.tp
fn = cm.fn
fp = cm.fp
tn = cm.tn

conf_matrix = [
    "TP: $tp" "FN: $fn";
    "FP: $fp" "TN: $tn"
]

println("Matriz de Confusión:")
display(conf_matrix)

# Accuracy
acc = (cm.tp + cm.tn)/ (cm.p + cm.n)
println("Accuracy: $(round(acc, digits=4))")

# Curva de ROC
function plot_roc_from_scratch_GLM(data::DataFrame, formula::FormulaTerm, target_variable::Symbol)
    # Fit GLM model
    model = glm(formula, data, Binomial(), LogitLink())

    # Predicted probabilities
    probs = predict(model, data)

    # Sort by predicted probabilities in descending order
    sorted_indices = sortperm(probs, rev=true)
    sorted_probs = probs[sorted_indices]
    sorted_labels = data[sorted_indices, target_variable]

    # Initialize variables
    tpr = Float64[]
    fpr = Float64[]
    tp = 0
    fp = 0
    p = sum(sorted_labels)  # Number of positives
    n = length(sorted_labels) - p  # Number of negatives

    # Calculate TPR and FPR at each threshold
    for i in 1:length(sorted_probs)
        if sorted_labels[i] == 1
            tp += 1
        else
            fp += 1
        end
        push!(tpr, tp / p)
        push!(fpr, fp / n)
    end

    # Calculate AUC using trapezoidal rule
    auc = sum((tpr[2:end] + tpr[1:end-1]) .* (fpr[2:end] - fpr[1:end-1])) / 2

    # Plot ROC curve
    Plots.plot(fpr, tpr, 
         label="ROC Curve (AUC = $(round(auc, digits=3)))", 
         xlabel="False Positive Rate", 
         ylabel="True Positive Rate")
end

plot_roc_from_scratch_GLM(dftst, fm, :Exited)
