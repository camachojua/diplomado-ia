using Flux, DataFrames, CSV, MLBase, Statistics, ROCAnalysis, Plots
using Flux: onehotbatch, onecold, logitcrossentropy, normalise
using Random: shuffle

# Cargar y preprocesar datos
function preprocess_data(file_path)
    df = DataFrame(CSV.File(file_path))

    # One-Hot Encoding para variables categóricas
    replace!(df.Gender, "Female" => "1", "Male" => "0")
    df[!, :Gender] = parse.(Int, df[!, :Gender])
    replace!(df.Geography, "France" => "2", "Germany" => "1", "Spain" => "0")
    df[!, :Geography] = parse.(Int, df[!, :Geography])
    
    # Normalizar variables numéricas
    features = [:CreditScore, :Age, :Tenure, :Balance, :NumOfProducts, :HasCrCard, 
                :IsActiveMember, :EstimatedSalary, :Gender, :Geography]
	
	X = Matrix(df[:, features])

    # Normalización por columnas
    X = normalise(X, dims=1)'  

    # One-Hot Encoding del Target
    y = onehotbatch(df.Exited, unique(df.Exited))  
	
    return Float32.(X), y
end

# Dividir datos en entrenamiento y prueba
function split_data(X, y, train_ratio=0.75)

    # Se calcula el tamaño del conjunto de entrenamiento 
    # en base a la proporción (train_ratio).
    n = size(X, 2)
    train_size = Int(round(train_ratio * n))

    # Se mezclan los índices y se dividen en entrenamiento y prueba
    indices = shuffle(1:n)
    train_idx, test_idx = indices[1:train_size], indices[train_size+1:end]
    return (X[:, train_idx], y[:, train_idx]), (X[:, test_idx], y[:, test_idx])
end

# Función de pérdida
function loss(model, x, y)
    ŷ = model(x)
    # logitcrossentropy para problemas de clasificación binaria
    return Flux.logitcrossentropy(ŷ, y)
end


# Construir y entrenar modelo
function train_model(X_train, y_train; lr=0.01, epochs=100)
    model = Chain(Dense(size(X_train, 1), 2, σ))  # 2 clases (salida binaria)
    
    # Descenso de gradiente
    optimizer = Descent(lr)

    # El modelo se entrena por un número definido de epochs
    for epoch in 1:epochs
        Flux.train!(loss, model, [(X_train, y_train)], optimizer)
        println("Epoch $epoch: Loss = ", loss(model, X_train, y_train))
    end
    return model
end



# **Evaluar el modelo**
function evaluate_model(model, X_test, y_test)
    preds = model(X_test)
    y_pred = onecold(preds)
    y_actual = onecold(y_test)

    # Porcentaje de predicciones correctas.
    acc = mean(y_pred .== y_actual)
    println("Accuracy: ", acc)

    # Matriz de Confusión
    cm = confusmat(2, y_actual, y_pred)
    println("Confusion Matrix:\n", cm)
    return y_actual, y_pred, cm
end

# Generar curva ROC
# Calcular la Tasa de Verdaderos Positivos (TPR) y 
# la Tasa de Falsos Positivos (FPR).
function TPR_FPR_roc(y_true, y_score)
	thresholds = sort(unique(y_score), rev=true)  # Umbrales
	tpr = Float64[]
	fpr = Float64[]
		
    # Se recorren diferentes umbrales
	for t in thresholds
		# Clasificar según el umbral actual
		y_pred = y_score .>= t
		
		# Calcular TP, FP, TN, FN
		TP = sum((y_pred .== 1) .& (y_true .== 1))
		FP = sum((y_pred .== 1) .& (y_true .== 0))
		TN = sum((y_pred .== 0) .& (y_true .== 0))
		FN = sum((y_pred .== 0) .& (y_true .== 1))
		
		# Calcular TPR y FPR
		push!(tpr, TP / (TP + FN))
		push!(fpr, FP / (FP + TN))
	end
		
	# Asegurarse de que el gráfico termine en (0, 0)
	push!(fpr, 0.0)
	push!(tpr, 0.0)
		
	return fpr, tpr
end

#Resultados
file_path = "../dat/Churn_Modelling.csv"
X, y = preprocess_data(file_path)
(train_data, test_data) = split_data(X, y)
(X_train, y_train) = train_data
(X_test, y_test) = test_data

model = train_model(X_train, y_train; lr=0.01, epochs=100)
y_actual, y_pred, cm = evaluate_model(model, X_test, y_test)

# Graficar curva ROC
y_actual_binary = y_actual .- 1
y_preds = model(X_test)
y_score = y_preds[2, :]
fpr, tpr = TPR_FPR_roc(y_actual_binary, y_score)

# Gráfica
plot(fpr, tpr, label="Curva ROC", xlabel="FPR", ylabel="TPR", legend=:bottomright)
plot!([0, 1], [0, 1], linestyle=:dash, label="Línea Base")
ROC_Curves = joinpath("..", "fig", "ROC_Curves.png")
savefig(ROC_Curves)
