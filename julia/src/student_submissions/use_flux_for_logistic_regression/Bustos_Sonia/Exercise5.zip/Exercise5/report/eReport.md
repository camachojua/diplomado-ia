# Flux para regresión logística

```julia
using Flux, DataFrames, CSV, MLBase, Statistics, ROCAnalysis, Plots
using Flux: onehotbatch, onecold, logitcrossentropy, normalise
using Random: shuffle
```
--- 
#### Preprocesamiento de Datos
Carga y preprocesa datos desde un archivo CSV.
- Convierte variables categóricas en codificaciones One-Hot.
 - Normaliza las variables continuas.

**Parámetros:**
    - `file_path::String`: Ruta del archivo CSV.

**Regresa:**
    - `Tuple`: Matrices de características (`X`) y etiquetas (`y`) normalizadas.

```julia
function preprocess_data(file_path)
    df = DataFrame(CSV.File(file_path))

    # One-Hot Encoding para variables categóricas
    replace!(df.Gender, "Female" => "1", "Male" => "0")
    df[!, :Gender] = parse.(Int, df[!, :Gender])
    replace!(df.Geography, "France" => "2", "Germany" => "1", "Spain" => "0")
    df[!, :Geography] = parse.(Int, df[!, :Geography])
    
    # Normalizar variables numéricas
    features = [:CreditScore, :Age, :Tenure, :Balance, :NumOfProducts, :HasCrCard, 
                :IsActiveMember, :EstimatedSalary, :Gender, :Geography]
	
	X = Matrix(df[:, features])

    # Normalización por columnas
    X = normalise(X, dims=1)'  

    # One-Hot Encoding del Target
    y = onehotbatch(df.Exited, unique(df.Exited))  
	
    return Float32.(X), y
end
```

---

#### División de Datos
Divide los datos en conjuntos de entrenamiento y prueba.

**Parámetros:**
- `X::Matrix`: Matriz de características.
- `y::Matrix`: Matriz de etiquetas.
- `train_ratio::Float64`: Proporción de datos para entrenamiento.

**Regresa:**
- `Tuple`: Conjuntos de entrenamiento y prueba.

```julia
function split_data(X, y, train_ratio=0.75)

    # Se calcula el tamaño del conjunto de entrenamiento 
    # en base a la proporción (train_ratio).
    n = size(X, 2)
    train_size = Int(round(train_ratio * n))

    # Se mezclan los índices y se dividen en entrenamiento y prueba
    indices = shuffle(1:n)
    train_idx, test_idx = indices[1:train_size], indices[train_size+1:end]
    return (X[:, train_idx], y[:, train_idx]), (X[:, test_idx], y[:, test_idx])
end
```

---

#### Entrenamiento del Modelo

```julia
function loss(model, x, y)
    ŷ = model(x)
    # logitcrossentropy para problemas de clasificación binaria
    return Flux.logitcrossentropy(ŷ, y)
end
```
Entrena un modelo con los datos de entrenamiento.

**Parámetros**:
- `X_train::Matrix`: Características de entrenamiento.
- `y_train::Matrix`: Etiquetas de entrenamiento.
- `lr::Float64`: Tasa de aprendizaje.
- `epochs::Int`: Número de épocas.

**Regresa**:
- `Chain`: Modelo entrenado.

```julia
function train_model(X_train, y_train; lr=0.01, epochs=100)
    model = Chain(Dense(size(X_train, 1), 2, σ))  # 2 clases (salida binaria)
    
    # Descenso de gradiente
    optimizer = Descent(lr)

    # El modelo se entrena por un número definido de epochs
    for epoch in 1:epochs
        Flux.train!(loss, model, [(X_train, y_train)], optimizer)
        println("Epoch $epoch: Loss = ", loss(model, X_train, y_train))
    end
    return model
end
```

---

#### Evaluación del Modelo
Evalúa el modelo entrenado con los datos de prueba.

**Parámetros**:
- `model::Chain`: Modelo entrenado.
- `X_test::Matrix`: Características de prueba.
- `y_test::Matrix`: Etiquetas de prueba.

**Regresa**:
- `Tuple`: Etiquetas reales, predicciones y matriz de confusión.

```julia
function evaluate_model(model, X_test, y_test)
    preds = model(X_test)
    y_pred = onecold(preds)
    y_actual = onecold(y_test)

    # Porcentaje de predicciones correctas.
    acc = mean(y_pred .== y_actual)
    println("Accuracy: ", acc)

    # Matriz de Confusión
    cm = confusmat(2, y_actual, y_pred)
    println("Confusion Matrix:\n", cm)
    return y_actual, y_pred, cm
end
```

---

#### Generación de Curva ROC
Calcula los valores TPR y FPR para generar la curva ROC.
**Parámetros**:
- `y_true`: Etiquetas reales.
- `y_score`: Puntajes de predicción.

**Salida:**
- `Tuple`: Vectores de FPR y TPR.


```julia
function TPR_FPR_roc(y_true, y_score)
	thresholds = sort(unique(y_score), rev=true)  # Umbrales
	tpr = Float64[]
	fpr = Float64[]
		
    # Se recorren diferentes umbrales
	for t in thresholds
		# Clasificar según el umbral actual
		y_pred = y_score .>= t
		
		# Calcular TP, FP, TN, FN
		TP = sum((y_pred .== 1) .& (y_true .== 1))
		FP = sum((y_pred .== 1) .& (y_true .== 0))
		TN = sum((y_pred .== 0) .& (y_true .== 0))
		FN = sum((y_pred .== 0) .& (y_true .== 1))
		
		# Calcular TPR y FPR
		push!(tpr, TP / (TP + FN))
		push!(fpr, FP / (FP + TN))
	end
		
	# Asegurarse de que el gráfico termine en (0, 0)
	push!(fpr, 0.0)
	push!(tpr, 0.0)
		
	return fpr, tpr
end
```
#### Visualización
Se genera y guarda la curva ROC en formato PNG.
```julia
ROC_Curves = plot(fpr, tpr, label="Curva ROC", xlabel="FPR", ylabel="TPR", legend=:bottomright)
	plot!([0, 1], [0, 1], linestyle=:dash, label="Línea Base")

	ROC_Curves_path = joinpath("..","fig","ROC_Curves.png")
	savefig(ROC_Curves,ROC_Curves_path)
```

![ROC_Curves](../fig/ROC_Curves.png)