# Comparación de Modelos con Flux y GLM en Julia

## Introducción

En este proyecto, se implementaron y compararon dos enfoques para la clasificación binaria en un dataset de "Churn Modeling":  
1. Una red neuronal utilizando **Flux.jl**.  
2. Un modelo de regresión logística con **GLM.jl**.

El objetivo fue predecir si un cliente de un banco abandonará la institución en el futuro cercano (variable `Exited`) con base en características como edad, género, saldo, etc.

## ¿Qué es una Red Neuronal Artificial?
Una red neuronal artificial (ANN, por sus siglas en inglés) es un programa de computadora inspirado en la estructura de los cerebros animales. Emula neuronas y conexiones que se ajustan durante el entrenamiento para identificar patrones en los datos de entrada y producir un resultado.

---

## Implementación de una Red Neuronal Artificial

### Importación de bibliotecas
Las siguientes bibliotecas se instalaron y cargaron:



```julia
using DataFrames
using Flux
using MLJ
using CUDA
using IterTools: ncycle
using ProgressMeter
using Images
using Glob
using MLUtils
using Augmentor
using CUDA: CuIterator
using ImageShow
using Statistics
using CSV
using GLM
```

## Dataset

Se utilizó el dataset `Churn_Modelling.csv`, que contiene información sobre 10,000 clientes de un banco. Las primeras 10 filas son las siguientes:


```julia
# Cargar el dataset
file_path = "Churn_Modelling.csv"  # Cambiar a la ruta donde está el archivo
df = CSV.read(file_path, DataFrame)
first(df, 10)
```




<div><div style = "float: left;"><span>10×14 DataFrame</span></div><div style = "clear: both;"></div></div><div class = "data-frame" style = "overflow-x: scroll;"><table class = "data-frame" style = "margin-bottom: 6px;"><thead><tr class = "header"><th class = "rowNumber" style = "font-weight: bold; text-align: right;">Row</th><th style = "text-align: left;">RowNumber</th><th style = "text-align: left;">CustomerId</th><th style = "text-align: left;">Surname</th><th style = "text-align: left;">CreditScore</th><th style = "text-align: left;">Geography</th><th style = "text-align: left;">Gender</th><th style = "text-align: left;">Age</th><th style = "text-align: left;">Tenure</th><th style = "text-align: left;">Balance</th><th style = "text-align: left;">NumOfProducts</th><th style = "text-align: left;">HasCrCard</th><th style = "text-align: left;">IsActiveMember</th><th style = "text-align: left;">EstimatedSalary</th><th style = "text-align: left;">Exited</th></tr><tr class = "subheader headerLastRow"><th class = "rowNumber" style = "font-weight: bold; text-align: right;"></th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "String31" style = "text-align: left;">String31</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "String7" style = "text-align: left;">String7</th><th title = "String7" style = "text-align: left;">String7</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Int64" style = "text-align: left;">Int64</th></tr></thead><tbody><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">15634602</td><td style = "text-align: left;">Hargrave</td><td style = "text-align: right;">619</td><td style = "text-align: left;">France</td><td style = "text-align: left;">Female</td><td style = "text-align: right;">42</td><td style = "text-align: right;">2</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1.01349e5</td><td style = "text-align: right;">1</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">2</td><td style = "text-align: right;">2</td><td style = "text-align: right;">15647311</td><td style = "text-align: left;">Hill</td><td style = "text-align: right;">608</td><td style = "text-align: left;">Spain</td><td style = "text-align: left;">Female</td><td style = "text-align: right;">41</td><td style = "text-align: right;">1</td><td style = "text-align: right;">83807.9</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1.12543e5</td><td style = "text-align: right;">0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">3</td><td style = "text-align: right;">3</td><td style = "text-align: right;">15619304</td><td style = "text-align: left;">Onio</td><td style = "text-align: right;">502</td><td style = "text-align: left;">France</td><td style = "text-align: left;">Female</td><td style = "text-align: right;">42</td><td style = "text-align: right;">8</td><td style = "text-align: right;">1.59661e5</td><td style = "text-align: right;">3</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0</td><td style = "text-align: right;">1.13932e5</td><td style = "text-align: right;">1</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">4</td><td style = "text-align: right;">4</td><td style = "text-align: right;">15701354</td><td style = "text-align: left;">Boni</td><td style = "text-align: right;">699</td><td style = "text-align: left;">France</td><td style = "text-align: left;">Female</td><td style = "text-align: right;">39</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">2</td><td style = "text-align: right;">0</td><td style = "text-align: right;">0</td><td style = "text-align: right;">93826.6</td><td style = "text-align: right;">0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">5</td><td style = "text-align: right;">5</td><td style = "text-align: right;">15737888</td><td style = "text-align: left;">Mitchell</td><td style = "text-align: right;">850</td><td style = "text-align: left;">Spain</td><td style = "text-align: left;">Female</td><td style = "text-align: right;">43</td><td style = "text-align: right;">2</td><td style = "text-align: right;">1.25511e5</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">79084.1</td><td style = "text-align: right;">0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">6</td><td style = "text-align: right;">6</td><td style = "text-align: right;">15574012</td><td style = "text-align: left;">Chu</td><td style = "text-align: right;">645</td><td style = "text-align: left;">Spain</td><td style = "text-align: left;">Male</td><td style = "text-align: right;">44</td><td style = "text-align: right;">8</td><td style = "text-align: right;">1.13756e5</td><td style = "text-align: right;">2</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0</td><td style = "text-align: right;">1.49757e5</td><td style = "text-align: right;">1</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">7</td><td style = "text-align: right;">7</td><td style = "text-align: right;">15592531</td><td style = "text-align: left;">Bartlett</td><td style = "text-align: right;">822</td><td style = "text-align: left;">France</td><td style = "text-align: left;">Male</td><td style = "text-align: right;">50</td><td style = "text-align: right;">7</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">2</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">10062.8</td><td style = "text-align: right;">0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">8</td><td style = "text-align: right;">8</td><td style = "text-align: right;">15656148</td><td style = "text-align: left;">Obinna</td><td style = "text-align: right;">376</td><td style = "text-align: left;">Germany</td><td style = "text-align: left;">Female</td><td style = "text-align: right;">29</td><td style = "text-align: right;">4</td><td style = "text-align: right;">1.15047e5</td><td style = "text-align: right;">4</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0</td><td style = "text-align: right;">1.19347e5</td><td style = "text-align: right;">1</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9</td><td style = "text-align: right;">9</td><td style = "text-align: right;">15792365</td><td style = "text-align: left;">He</td><td style = "text-align: right;">501</td><td style = "text-align: left;">France</td><td style = "text-align: left;">Male</td><td style = "text-align: right;">44</td><td style = "text-align: right;">4</td><td style = "text-align: right;">1.42051e5</td><td style = "text-align: right;">2</td><td style = "text-align: right;">0</td><td style = "text-align: right;">1</td><td style = "text-align: right;">74940.5</td><td style = "text-align: right;">0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">10</td><td style = "text-align: right;">10</td><td style = "text-align: right;">15592389</td><td style = "text-align: left;">H?</td><td style = "text-align: right;">684</td><td style = "text-align: left;">France</td><td style = "text-align: left;">Male</td><td style = "text-align: right;">27</td><td style = "text-align: right;">2</td><td style = "text-align: right;">1.34604e5</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">71725.7</td><td style = "text-align: right;">0</td></tr></tbody></table></div>




```julia
describe(df)
```




<div><div style = "float: left;"><span>14×7 DataFrame</span></div><div style = "clear: both;"></div></div><div class = "data-frame" style = "overflow-x: scroll;"><table class = "data-frame" style = "margin-bottom: 6px;"><thead><tr class = "header"><th class = "rowNumber" style = "font-weight: bold; text-align: right;">Row</th><th style = "text-align: left;">variable</th><th style = "text-align: left;">mean</th><th style = "text-align: left;">min</th><th style = "text-align: left;">median</th><th style = "text-align: left;">max</th><th style = "text-align: left;">nmissing</th><th style = "text-align: left;">eltype</th></tr><tr class = "subheader headerLastRow"><th class = "rowNumber" style = "font-weight: bold; text-align: right;"></th><th title = "Symbol" style = "text-align: left;">Symbol</th><th title = "Union{Nothing, Float64}" style = "text-align: left;">Union…</th><th title = "Any" style = "text-align: left;">Any</th><th title = "Union{Nothing, Float64}" style = "text-align: left;">Union…</th><th title = "Any" style = "text-align: left;">Any</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "DataType" style = "text-align: left;">DataType</th></tr></thead><tbody><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1</td><td style = "text-align: left;">RowNumber</td><td style = "text-align: left;">5000.5</td><td style = "text-align: left;">1</td><td style = "text-align: left;">5000.5</td><td style = "text-align: left;">10000</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Int64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">2</td><td style = "text-align: left;">CustomerId</td><td style = "text-align: left;">1.56909e7</td><td style = "text-align: left;">15565701</td><td style = "text-align: left;">1.56907e7</td><td style = "text-align: left;">15815690</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Int64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">3</td><td style = "text-align: left;">Surname</td><td style = "font-style: italic; text-align: left;"></td><td style = "text-align: left;">Abazu</td><td style = "font-style: italic; text-align: left;"></td><td style = "text-align: left;">Zuyeva</td><td style = "text-align: right;">0</td><td style = "text-align: left;">String31</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">4</td><td style = "text-align: left;">CreditScore</td><td style = "text-align: left;">650.529</td><td style = "text-align: left;">350</td><td style = "text-align: left;">652.0</td><td style = "text-align: left;">850</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Int64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">5</td><td style = "text-align: left;">Geography</td><td style = "font-style: italic; text-align: left;"></td><td style = "text-align: left;">France</td><td style = "font-style: italic; text-align: left;"></td><td style = "text-align: left;">Spain</td><td style = "text-align: right;">0</td><td style = "text-align: left;">String7</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">6</td><td style = "text-align: left;">Gender</td><td style = "font-style: italic; text-align: left;"></td><td style = "text-align: left;">Female</td><td style = "font-style: italic; text-align: left;"></td><td style = "text-align: left;">Male</td><td style = "text-align: right;">0</td><td style = "text-align: left;">String7</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">7</td><td style = "text-align: left;">Age</td><td style = "text-align: left;">38.9218</td><td style = "text-align: left;">18</td><td style = "text-align: left;">37.0</td><td style = "text-align: left;">92</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Int64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">8</td><td style = "text-align: left;">Tenure</td><td style = "text-align: left;">5.0128</td><td style = "text-align: left;">0</td><td style = "text-align: left;">5.0</td><td style = "text-align: left;">10</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Int64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9</td><td style = "text-align: left;">Balance</td><td style = "text-align: left;">76485.9</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">97198.5</td><td style = "text-align: left;">2.50898e5</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Float64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">10</td><td style = "text-align: left;">NumOfProducts</td><td style = "text-align: left;">1.5302</td><td style = "text-align: left;">1</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">4</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Int64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">11</td><td style = "text-align: left;">HasCrCard</td><td style = "text-align: left;">0.7055</td><td style = "text-align: left;">0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">1</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Int64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">12</td><td style = "text-align: left;">IsActiveMember</td><td style = "text-align: left;">0.5151</td><td style = "text-align: left;">0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">1</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Int64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">13</td><td style = "text-align: left;">EstimatedSalary</td><td style = "text-align: left;">1.0009e5</td><td style = "text-align: left;">11.58</td><td style = "text-align: left;">1.00194e5</td><td style = "text-align: left;">1.99992e5</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Float64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">14</td><td style = "text-align: left;">Exited</td><td style = "text-align: left;">0.2037</td><td style = "text-align: left;">0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Int64</td></tr></tbody></table></div>



## Preprocesmiento

Se eliminaron columnas irrelevantes como `RowNumber`, `CustomerId` y `Surname`.  


```julia
df = DataFrames.select(df, Not(["RowNumber", "CustomerId", "Surname"]))
```




<div><div style = "float: left;"><span>10000×11 DataFrame</span></div><div style = "float: right;"><span style = "font-style: italic;">9975 rows omitted</span></div><div style = "clear: both;"></div></div><div class = "data-frame" style = "overflow-x: scroll;"><table class = "data-frame" style = "margin-bottom: 6px;"><thead><tr class = "header"><th class = "rowNumber" style = "font-weight: bold; text-align: right;">Row</th><th style = "text-align: left;">CreditScore</th><th style = "text-align: left;">Geography</th><th style = "text-align: left;">Gender</th><th style = "text-align: left;">Age</th><th style = "text-align: left;">Tenure</th><th style = "text-align: left;">Balance</th><th style = "text-align: left;">NumOfProducts</th><th style = "text-align: left;">HasCrCard</th><th style = "text-align: left;">IsActiveMember</th><th style = "text-align: left;">EstimatedSalary</th><th style = "text-align: left;">Exited</th></tr><tr class = "subheader headerLastRow"><th class = "rowNumber" style = "font-weight: bold; text-align: right;"></th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "String7" style = "text-align: left;">String7</th><th title = "String7" style = "text-align: left;">String7</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Int64" style = "text-align: left;">Int64</th></tr></thead><tbody><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1</td><td style = "text-align: right;">619</td><td style = "text-align: left;">France</td><td style = "text-align: left;">Female</td><td style = "text-align: right;">42</td><td style = "text-align: right;">2</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1.01349e5</td><td style = "text-align: right;">1</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">2</td><td style = "text-align: right;">608</td><td style = "text-align: left;">Spain</td><td style = "text-align: left;">Female</td><td style = "text-align: right;">41</td><td style = "text-align: right;">1</td><td style = "text-align: right;">83807.9</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1.12543e5</td><td style = "text-align: right;">0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">3</td><td style = "text-align: right;">502</td><td style = "text-align: left;">France</td><td style = "text-align: left;">Female</td><td style = "text-align: right;">42</td><td style = "text-align: right;">8</td><td style = "text-align: right;">1.59661e5</td><td style = "text-align: right;">3</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0</td><td style = "text-align: right;">1.13932e5</td><td style = "text-align: right;">1</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">4</td><td style = "text-align: right;">699</td><td style = "text-align: left;">France</td><td style = "text-align: left;">Female</td><td style = "text-align: right;">39</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">2</td><td style = "text-align: right;">0</td><td style = "text-align: right;">0</td><td style = "text-align: right;">93826.6</td><td style = "text-align: right;">0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">5</td><td style = "text-align: right;">850</td><td style = "text-align: left;">Spain</td><td style = "text-align: left;">Female</td><td style = "text-align: right;">43</td><td style = "text-align: right;">2</td><td style = "text-align: right;">1.25511e5</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">79084.1</td><td style = "text-align: right;">0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">6</td><td style = "text-align: right;">645</td><td style = "text-align: left;">Spain</td><td style = "text-align: left;">Male</td><td style = "text-align: right;">44</td><td style = "text-align: right;">8</td><td style = "text-align: right;">1.13756e5</td><td style = "text-align: right;">2</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0</td><td style = "text-align: right;">1.49757e5</td><td style = "text-align: right;">1</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">7</td><td style = "text-align: right;">822</td><td style = "text-align: left;">France</td><td style = "text-align: left;">Male</td><td style = "text-align: right;">50</td><td style = "text-align: right;">7</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">2</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">10062.8</td><td style = "text-align: right;">0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">8</td><td style = "text-align: right;">376</td><td style = "text-align: left;">Germany</td><td style = "text-align: left;">Female</td><td style = "text-align: right;">29</td><td style = "text-align: right;">4</td><td style = "text-align: right;">1.15047e5</td><td style = "text-align: right;">4</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0</td><td style = "text-align: right;">1.19347e5</td><td style = "text-align: right;">1</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9</td><td style = "text-align: right;">501</td><td style = "text-align: left;">France</td><td style = "text-align: left;">Male</td><td style = "text-align: right;">44</td><td style = "text-align: right;">4</td><td style = "text-align: right;">1.42051e5</td><td style = "text-align: right;">2</td><td style = "text-align: right;">0</td><td style = "text-align: right;">1</td><td style = "text-align: right;">74940.5</td><td style = "text-align: right;">0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">10</td><td style = "text-align: right;">684</td><td style = "text-align: left;">France</td><td style = "text-align: left;">Male</td><td style = "text-align: right;">27</td><td style = "text-align: right;">2</td><td style = "text-align: right;">1.34604e5</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">71725.7</td><td style = "text-align: right;">0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">11</td><td style = "text-align: right;">528</td><td style = "text-align: left;">France</td><td style = "text-align: left;">Male</td><td style = "text-align: right;">31</td><td style = "text-align: right;">6</td><td style = "text-align: right;">1.02017e5</td><td style = "text-align: right;">2</td><td style = "text-align: right;">0</td><td style = "text-align: right;">0</td><td style = "text-align: right;">80181.1</td><td style = "text-align: right;">0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">12</td><td style = "text-align: right;">497</td><td style = "text-align: left;">Spain</td><td style = "text-align: left;">Male</td><td style = "text-align: right;">24</td><td style = "text-align: right;">3</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">2</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0</td><td style = "text-align: right;">76390.0</td><td style = "text-align: right;">0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">13</td><td style = "text-align: right;">476</td><td style = "text-align: left;">France</td><td style = "text-align: left;">Female</td><td style = "text-align: right;">34</td><td style = "text-align: right;">10</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">2</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0</td><td style = "text-align: right;">26261.0</td><td style = "text-align: right;">0</td></tr><tr><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9989</td><td style = "text-align: right;">775</td><td style = "text-align: left;">France</td><td style = "text-align: left;">Male</td><td style = "text-align: right;">30</td><td style = "text-align: right;">4</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">2</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0</td><td style = "text-align: right;">49337.8</td><td style = "text-align: right;">0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9990</td><td style = "text-align: right;">841</td><td style = "text-align: left;">Spain</td><td style = "text-align: left;">Male</td><td style = "text-align: right;">28</td><td style = "text-align: right;">4</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">2</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1.79437e5</td><td style = "text-align: right;">0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9991</td><td style = "text-align: right;">714</td><td style = "text-align: left;">Germany</td><td style = "text-align: left;">Male</td><td style = "text-align: right;">33</td><td style = "text-align: right;">3</td><td style = "text-align: right;">35016.6</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0</td><td style = "text-align: right;">53667.1</td><td style = "text-align: right;">0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9992</td><td style = "text-align: right;">597</td><td style = "text-align: left;">France</td><td style = "text-align: left;">Female</td><td style = "text-align: right;">53</td><td style = "text-align: right;">4</td><td style = "text-align: right;">88381.2</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0</td><td style = "text-align: right;">69384.7</td><td style = "text-align: right;">1</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9993</td><td style = "text-align: right;">726</td><td style = "text-align: left;">Spain</td><td style = "text-align: left;">Male</td><td style = "text-align: right;">36</td><td style = "text-align: right;">2</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0</td><td style = "text-align: right;">1.95192e5</td><td style = "text-align: right;">0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9994</td><td style = "text-align: right;">644</td><td style = "text-align: left;">France</td><td style = "text-align: left;">Male</td><td style = "text-align: right;">28</td><td style = "text-align: right;">7</td><td style = "text-align: right;">1.5506e5</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0</td><td style = "text-align: right;">29179.5</td><td style = "text-align: right;">0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9995</td><td style = "text-align: right;">800</td><td style = "text-align: left;">France</td><td style = "text-align: left;">Female</td><td style = "text-align: right;">29</td><td style = "text-align: right;">2</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">2</td><td style = "text-align: right;">0</td><td style = "text-align: right;">0</td><td style = "text-align: right;">1.67774e5</td><td style = "text-align: right;">0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9996</td><td style = "text-align: right;">771</td><td style = "text-align: left;">France</td><td style = "text-align: left;">Male</td><td style = "text-align: right;">39</td><td style = "text-align: right;">5</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">2</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0</td><td style = "text-align: right;">96270.6</td><td style = "text-align: right;">0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9997</td><td style = "text-align: right;">516</td><td style = "text-align: left;">France</td><td style = "text-align: left;">Male</td><td style = "text-align: right;">35</td><td style = "text-align: right;">10</td><td style = "text-align: right;">57369.6</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1.017e5</td><td style = "text-align: right;">0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9998</td><td style = "text-align: right;">709</td><td style = "text-align: left;">France</td><td style = "text-align: left;">Female</td><td style = "text-align: right;">36</td><td style = "text-align: right;">7</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0</td><td style = "text-align: right;">1</td><td style = "text-align: right;">42085.6</td><td style = "text-align: right;">1</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9999</td><td style = "text-align: right;">772</td><td style = "text-align: left;">Germany</td><td style = "text-align: left;">Male</td><td style = "text-align: right;">42</td><td style = "text-align: right;">3</td><td style = "text-align: right;">75075.3</td><td style = "text-align: right;">2</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0</td><td style = "text-align: right;">92888.5</td><td style = "text-align: right;">1</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">10000</td><td style = "text-align: right;">792</td><td style = "text-align: left;">France</td><td style = "text-align: left;">Female</td><td style = "text-align: right;">28</td><td style = "text-align: right;">4</td><td style = "text-align: right;">1.30143e5</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0</td><td style = "text-align: right;">38190.8</td><td style = "text-align: right;">0</td></tr></tbody></table></div>



**División de datos:**
   Se separaron las características (`X`) y la variable objetivo (`y`), eliminando columnas irrelevantes como `CustomerId`, `RowNumber` y `Surname`.


```julia
# Dividir datos en X (características) e "y" (objetivo)
X = DataFrames.select(df, Not(:Exited))
y = df.Exited
```




    10000-element Vector{Int64}:
     1
     0
     1
     0
     0
     1
     0
     1
     0
     0
     0
     0
     0
     ⋮
     0
     0
     0
     1
     0
     0
     0
     0
     0
     1
     1
     0




```julia
GLM.schema(X)
```




    StatsModels.Schema with 10 entries:
      CreditScore => CreditScore
      HasCrCard => HasCrCard
      IsActiveMember => IsActiveMember
      Tenure => Tenure
      EstimatedSalary => EstimatedSalary
      NumOfProducts => NumOfProducts
      Geography => Geography
      Age => Age
      Gender => Gender
      Balance => Balance




Las variables categóricas `Gender` y `Geography` fueron codificadas mediante One-Hot Encoding.  


```julia
X.Gender = coerce(X.Gender, Multiclass)
X.Geography = coerce(X.Geography, Multiclass)

hot_encoder = OneHotEncoder(features=[:Geography, :Gender])
mach = fit!(machine(hot_encoder, X))
X = MLJ.transform(mach, X)
GLM.schema(X)
```

    [36m[1m[ [22m[39m[36m[1mInfo: [22m[39mTraining machine(OneHotEncoder(features = [:Geography, :Gender], …), …).
    [36m[1m[ [22m[39m[36m[1mInfo: [22m[39mSpawning 3 sub-features to one-hot encode feature :Geography.
    [36m[1m[ [22m[39m[36m[1mInfo: [22m[39mSpawning 2 sub-features to one-hot encode feature :Gender.





    StatsModels.Schema with 13 entries:
      CreditScore => CreditScore
      HasCrCard => HasCrCard
      IsActiveMember => IsActiveMember
      Tenure => Tenure
      Gender__Female => Gender__Female
      EstimatedSalary => EstimatedSalary
      Geography__France => Geography__France
      NumOfProducts => NumOfProducts
      Age => Age
      Geography__Spain => Geography__Spain
      Gender__Male => Gender__Male
      Geography__Germany => Geography__Germany
      Balance => Balance





```julia
first(X, 10)
```




<div><div style = "float: left;"><span>10×13 DataFrame</span></div><div style = "clear: both;"></div></div><div class = "data-frame" style = "overflow-x: scroll;"><table class = "data-frame" style = "margin-bottom: 6px;"><thead><tr class = "header"><th class = "rowNumber" style = "font-weight: bold; text-align: right;">Row</th><th style = "text-align: left;">CreditScore</th><th style = "text-align: left;">Geography__France</th><th style = "text-align: left;">Geography__Germany</th><th style = "text-align: left;">Geography__Spain</th><th style = "text-align: left;">Gender__Female</th><th style = "text-align: left;">Gender__Male</th><th style = "text-align: left;">Age</th><th style = "text-align: left;">Tenure</th><th style = "text-align: left;">Balance</th><th style = "text-align: left;">NumOfProducts</th><th style = "text-align: left;">HasCrCard</th><th style = "text-align: left;">IsActiveMember</th><th style = "text-align: left;">EstimatedSalary</th></tr><tr class = "subheader headerLastRow"><th class = "rowNumber" style = "font-weight: bold; text-align: right;"></th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Float64" style = "text-align: left;">Float64</th></tr></thead><tbody><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1</td><td style = "text-align: right;">619</td><td style = "text-align: right;">1.0</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">1.0</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">42</td><td style = "text-align: right;">2</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1.01349e5</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">2</td><td style = "text-align: right;">608</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">1.0</td><td style = "text-align: right;">1.0</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">41</td><td style = "text-align: right;">1</td><td style = "text-align: right;">83807.9</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1.12543e5</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">3</td><td style = "text-align: right;">502</td><td style = "text-align: right;">1.0</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">1.0</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">42</td><td style = "text-align: right;">8</td><td style = "text-align: right;">1.59661e5</td><td style = "text-align: right;">3</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0</td><td style = "text-align: right;">1.13932e5</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">4</td><td style = "text-align: right;">699</td><td style = "text-align: right;">1.0</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">1.0</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">39</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">2</td><td style = "text-align: right;">0</td><td style = "text-align: right;">0</td><td style = "text-align: right;">93826.6</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">5</td><td style = "text-align: right;">850</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">1.0</td><td style = "text-align: right;">1.0</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">43</td><td style = "text-align: right;">2</td><td style = "text-align: right;">1.25511e5</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">79084.1</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">6</td><td style = "text-align: right;">645</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">1.0</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">1.0</td><td style = "text-align: right;">44</td><td style = "text-align: right;">8</td><td style = "text-align: right;">1.13756e5</td><td style = "text-align: right;">2</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0</td><td style = "text-align: right;">1.49757e5</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">7</td><td style = "text-align: right;">822</td><td style = "text-align: right;">1.0</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">1.0</td><td style = "text-align: right;">50</td><td style = "text-align: right;">7</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">2</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">10062.8</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">8</td><td style = "text-align: right;">376</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">1.0</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">1.0</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">29</td><td style = "text-align: right;">4</td><td style = "text-align: right;">1.15047e5</td><td style = "text-align: right;">4</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0</td><td style = "text-align: right;">1.19347e5</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9</td><td style = "text-align: right;">501</td><td style = "text-align: right;">1.0</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">1.0</td><td style = "text-align: right;">44</td><td style = "text-align: right;">4</td><td style = "text-align: right;">1.42051e5</td><td style = "text-align: right;">2</td><td style = "text-align: right;">0</td><td style = "text-align: right;">1</td><td style = "text-align: right;">74940.5</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">10</td><td style = "text-align: right;">684</td><td style = "text-align: right;">1.0</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">1.0</td><td style = "text-align: right;">27</td><td style = "text-align: right;">2</td><td style = "text-align: right;">1.34604e5</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">71725.7</td></tr></tbody></table></div>




```julia
X = coerce(X,
    :Geography__France => OrderedFactor,
    :Geography__Germany => OrderedFactor,
    :Geography__Spain => OrderedFactor,
    :Gender__Female => OrderedFactor,
    :Gender__Male => OrderedFactor,
    :HasCrCard => OrderedFactor,
    :IsActiveMember => OrderedFactor)
```




<div><div style = "float: left;"><span>10000×13 DataFrame</span></div><div style = "float: right;"><span style = "font-style: italic;">9975 rows omitted</span></div><div style = "clear: both;"></div></div><div class = "data-frame" style = "overflow-x: scroll;"><table class = "data-frame" style = "margin-bottom: 6px;"><thead><tr class = "header"><th class = "rowNumber" style = "font-weight: bold; text-align: right;">Row</th><th style = "text-align: left;">CreditScore</th><th style = "text-align: left;">Geography__France</th><th style = "text-align: left;">Geography__Germany</th><th style = "text-align: left;">Geography__Spain</th><th style = "text-align: left;">Gender__Female</th><th style = "text-align: left;">Gender__Male</th><th style = "text-align: left;">Age</th><th style = "text-align: left;">Tenure</th><th style = "text-align: left;">Balance</th><th style = "text-align: left;">NumOfProducts</th><th style = "text-align: left;">HasCrCard</th><th style = "text-align: left;">IsActiveMember</th><th style = "text-align: left;">EstimatedSalary</th></tr><tr class = "subheader headerLastRow"><th class = "rowNumber" style = "font-weight: bold; text-align: right;"></th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "CategoricalArrays.CategoricalValue{Float64, UInt32}" style = "text-align: left;">Cat…</th><th title = "CategoricalArrays.CategoricalValue{Float64, UInt32}" style = "text-align: left;">Cat…</th><th title = "CategoricalArrays.CategoricalValue{Float64, UInt32}" style = "text-align: left;">Cat…</th><th title = "CategoricalArrays.CategoricalValue{Float64, UInt32}" style = "text-align: left;">Cat…</th><th title = "CategoricalArrays.CategoricalValue{Float64, UInt32}" style = "text-align: left;">Cat…</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "CategoricalArrays.CategoricalValue{Int64, UInt32}" style = "text-align: left;">Cat…</th><th title = "CategoricalArrays.CategoricalValue{Int64, UInt32}" style = "text-align: left;">Cat…</th><th title = "Float64" style = "text-align: left;">Float64</th></tr></thead><tbody><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1</td><td style = "text-align: right;">619</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: right;">42</td><td style = "text-align: right;">2</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">1</td><td style = "text-align: left;">1</td><td style = "text-align: left;">1</td><td style = "text-align: right;">1.01349e5</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">2</td><td style = "text-align: right;">608</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: right;">41</td><td style = "text-align: right;">1</td><td style = "text-align: right;">83807.9</td><td style = "text-align: right;">1</td><td style = "text-align: left;">0</td><td style = "text-align: left;">1</td><td style = "text-align: right;">1.12543e5</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">3</td><td style = "text-align: right;">502</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: right;">42</td><td style = "text-align: right;">8</td><td style = "text-align: right;">1.59661e5</td><td style = "text-align: right;">3</td><td style = "text-align: left;">1</td><td style = "text-align: left;">0</td><td style = "text-align: right;">1.13932e5</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">4</td><td style = "text-align: right;">699</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: right;">39</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">2</td><td style = "text-align: left;">0</td><td style = "text-align: left;">0</td><td style = "text-align: right;">93826.6</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">5</td><td style = "text-align: right;">850</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: right;">43</td><td style = "text-align: right;">2</td><td style = "text-align: right;">1.25511e5</td><td style = "text-align: right;">1</td><td style = "text-align: left;">1</td><td style = "text-align: left;">1</td><td style = "text-align: right;">79084.1</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">6</td><td style = "text-align: right;">645</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: right;">44</td><td style = "text-align: right;">8</td><td style = "text-align: right;">1.13756e5</td><td style = "text-align: right;">2</td><td style = "text-align: left;">1</td><td style = "text-align: left;">0</td><td style = "text-align: right;">1.49757e5</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">7</td><td style = "text-align: right;">822</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: right;">50</td><td style = "text-align: right;">7</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">2</td><td style = "text-align: left;">1</td><td style = "text-align: left;">1</td><td style = "text-align: right;">10062.8</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">8</td><td style = "text-align: right;">376</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: right;">29</td><td style = "text-align: right;">4</td><td style = "text-align: right;">1.15047e5</td><td style = "text-align: right;">4</td><td style = "text-align: left;">1</td><td style = "text-align: left;">0</td><td style = "text-align: right;">1.19347e5</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9</td><td style = "text-align: right;">501</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: right;">44</td><td style = "text-align: right;">4</td><td style = "text-align: right;">1.42051e5</td><td style = "text-align: right;">2</td><td style = "text-align: left;">0</td><td style = "text-align: left;">1</td><td style = "text-align: right;">74940.5</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">10</td><td style = "text-align: right;">684</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: right;">27</td><td style = "text-align: right;">2</td><td style = "text-align: right;">1.34604e5</td><td style = "text-align: right;">1</td><td style = "text-align: left;">1</td><td style = "text-align: left;">1</td><td style = "text-align: right;">71725.7</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">11</td><td style = "text-align: right;">528</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: right;">31</td><td style = "text-align: right;">6</td><td style = "text-align: right;">1.02017e5</td><td style = "text-align: right;">2</td><td style = "text-align: left;">0</td><td style = "text-align: left;">0</td><td style = "text-align: right;">80181.1</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">12</td><td style = "text-align: right;">497</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: right;">24</td><td style = "text-align: right;">3</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">2</td><td style = "text-align: left;">1</td><td style = "text-align: left;">0</td><td style = "text-align: right;">76390.0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">13</td><td style = "text-align: right;">476</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: right;">34</td><td style = "text-align: right;">10</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">2</td><td style = "text-align: left;">1</td><td style = "text-align: left;">0</td><td style = "text-align: right;">26261.0</td></tr><tr><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9989</td><td style = "text-align: right;">775</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: right;">30</td><td style = "text-align: right;">4</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">2</td><td style = "text-align: left;">1</td><td style = "text-align: left;">0</td><td style = "text-align: right;">49337.8</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9990</td><td style = "text-align: right;">841</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: right;">28</td><td style = "text-align: right;">4</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">2</td><td style = "text-align: left;">1</td><td style = "text-align: left;">1</td><td style = "text-align: right;">1.79437e5</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9991</td><td style = "text-align: right;">714</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: right;">33</td><td style = "text-align: right;">3</td><td style = "text-align: right;">35016.6</td><td style = "text-align: right;">1</td><td style = "text-align: left;">1</td><td style = "text-align: left;">0</td><td style = "text-align: right;">53667.1</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9992</td><td style = "text-align: right;">597</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: right;">53</td><td style = "text-align: right;">4</td><td style = "text-align: right;">88381.2</td><td style = "text-align: right;">1</td><td style = "text-align: left;">1</td><td style = "text-align: left;">0</td><td style = "text-align: right;">69384.7</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9993</td><td style = "text-align: right;">726</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: right;">36</td><td style = "text-align: right;">2</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">1</td><td style = "text-align: left;">1</td><td style = "text-align: left;">0</td><td style = "text-align: right;">1.95192e5</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9994</td><td style = "text-align: right;">644</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: right;">28</td><td style = "text-align: right;">7</td><td style = "text-align: right;">1.5506e5</td><td style = "text-align: right;">1</td><td style = "text-align: left;">1</td><td style = "text-align: left;">0</td><td style = "text-align: right;">29179.5</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9995</td><td style = "text-align: right;">800</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: right;">29</td><td style = "text-align: right;">2</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">2</td><td style = "text-align: left;">0</td><td style = "text-align: left;">0</td><td style = "text-align: right;">1.67774e5</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9996</td><td style = "text-align: right;">771</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: right;">39</td><td style = "text-align: right;">5</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">2</td><td style = "text-align: left;">1</td><td style = "text-align: left;">0</td><td style = "text-align: right;">96270.6</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9997</td><td style = "text-align: right;">516</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: right;">35</td><td style = "text-align: right;">10</td><td style = "text-align: right;">57369.6</td><td style = "text-align: right;">1</td><td style = "text-align: left;">1</td><td style = "text-align: left;">1</td><td style = "text-align: right;">1.017e5</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9998</td><td style = "text-align: right;">709</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: right;">36</td><td style = "text-align: right;">7</td><td style = "text-align: right;">0.0</td><td style = "text-align: right;">1</td><td style = "text-align: left;">0</td><td style = "text-align: left;">1</td><td style = "text-align: right;">42085.6</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9999</td><td style = "text-align: right;">772</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: right;">42</td><td style = "text-align: right;">3</td><td style = "text-align: right;">75075.3</td><td style = "text-align: right;">2</td><td style = "text-align: left;">1</td><td style = "text-align: left;">0</td><td style = "text-align: right;">92888.5</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">10000</td><td style = "text-align: right;">792</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: right;">28</td><td style = "text-align: right;">4</td><td style = "text-align: right;">1.30143e5</td><td style = "text-align: right;">1</td><td style = "text-align: left;">1</td><td style = "text-align: left;">0</td><td style = "text-align: right;">38190.8</td></tr></tbody></table></div>



Los datos fueron estandarizados para mejorar el desempeño de los modelos.  


```julia
standardizer_model = Standardizer(count=true)
standardizer_machine = machine(standardizer_model, X)
fit!(standardizer_machine)

X = MLJ.transform(standardizer_machine, X)
```

    [36m[1m[ [22m[39m[36m[1mInfo: [22m[39mTraining machine(Standardizer(features = Symbol[], …), …).





<div><div style = "float: left;"><span>10000×13 DataFrame</span></div><div style = "float: right;"><span style = "font-style: italic;">9975 rows omitted</span></div><div style = "clear: both;"></div></div><div class = "data-frame" style = "overflow-x: scroll;"><table class = "data-frame" style = "margin-bottom: 6px;"><thead><tr class = "header"><th class = "rowNumber" style = "font-weight: bold; text-align: right;">Row</th><th style = "text-align: left;">CreditScore</th><th style = "text-align: left;">Geography__France</th><th style = "text-align: left;">Geography__Germany</th><th style = "text-align: left;">Geography__Spain</th><th style = "text-align: left;">Gender__Female</th><th style = "text-align: left;">Gender__Male</th><th style = "text-align: left;">Age</th><th style = "text-align: left;">Tenure</th><th style = "text-align: left;">Balance</th><th style = "text-align: left;">NumOfProducts</th><th style = "text-align: left;">HasCrCard</th><th style = "text-align: left;">IsActiveMember</th><th style = "text-align: left;">EstimatedSalary</th></tr><tr class = "subheader headerLastRow"><th class = "rowNumber" style = "font-weight: bold; text-align: right;"></th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "CategoricalArrays.CategoricalValue{Float64, UInt32}" style = "text-align: left;">Cat…</th><th title = "CategoricalArrays.CategoricalValue{Float64, UInt32}" style = "text-align: left;">Cat…</th><th title = "CategoricalArrays.CategoricalValue{Float64, UInt32}" style = "text-align: left;">Cat…</th><th title = "CategoricalArrays.CategoricalValue{Float64, UInt32}" style = "text-align: left;">Cat…</th><th title = "CategoricalArrays.CategoricalValue{Float64, UInt32}" style = "text-align: left;">Cat…</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "CategoricalArrays.CategoricalValue{Int64, UInt32}" style = "text-align: left;">Cat…</th><th title = "CategoricalArrays.CategoricalValue{Int64, UInt32}" style = "text-align: left;">Cat…</th><th title = "Float64" style = "text-align: left;">Float64</th></tr></thead><tbody><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1</td><td style = "text-align: right;">-0.326205</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: right;">0.293503</td><td style = "text-align: right;">-1.04171</td><td style = "text-align: right;">-1.22579</td><td style = "text-align: right;">-0.911538</td><td style = "text-align: left;">1</td><td style = "text-align: left;">1</td><td style = "text-align: right;">0.0218854</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">2</td><td style = "text-align: right;">-0.440014</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: right;">0.198154</td><td style = "text-align: right;">-1.38747</td><td style = "text-align: right;">0.117344</td><td style = "text-align: right;">-0.911538</td><td style = "text-align: left;">0</td><td style = "text-align: left;">1</td><td style = "text-align: right;">0.216523</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">3</td><td style = "text-align: right;">-1.53672</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: right;">0.293503</td><td style = "text-align: right;">1.03286</td><td style = "text-align: right;">1.33299</td><td style = "text-align: right;">2.52693</td><td style = "text-align: left;">1</td><td style = "text-align: left;">0</td><td style = "text-align: right;">0.240675</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">4</td><td style = "text-align: right;">0.501496</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: right;">0.00745628</td><td style = "text-align: right;">-1.38747</td><td style = "text-align: right;">-1.22579</td><td style = "text-align: right;">0.807696</td><td style = "text-align: left;">0</td><td style = "text-align: left;">0</td><td style = "text-align: right;">-0.108912</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">5</td><td style = "text-align: right;">2.06378</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: right;">0.388852</td><td style = "text-align: right;">-1.04171</td><td style = "text-align: right;">0.785689</td><td style = "text-align: right;">-0.911538</td><td style = "text-align: left;">1</td><td style = "text-align: left;">1</td><td style = "text-align: right;">-0.365258</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">6</td><td style = "text-align: right;">-0.0572024</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: right;">0.4842</td><td style = "text-align: right;">1.03286</td><td style = "text-align: right;">0.597299</td><td style = "text-align: right;">0.807696</td><td style = "text-align: left;">1</td><td style = "text-align: left;">0</td><td style = "text-align: right;">0.863607</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">7</td><td style = "text-align: right;">1.77409</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: right;">1.05629</td><td style = "text-align: right;">0.687096</td><td style = "text-align: right;">-1.22579</td><td style = "text-align: right;">0.807696</td><td style = "text-align: left;">1</td><td style = "text-align: left;">1</td><td style = "text-align: right;">-1.56541</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">8</td><td style = "text-align: right;">-2.84035</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: right;">-0.946032</td><td style = "text-align: right;">-0.350186</td><td style = "text-align: right;">0.617988</td><td style = "text-align: right;">4.24616</td><td style = "text-align: left;">1</td><td style = "text-align: left;">0</td><td style = "text-align: right;">0.334837</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9</td><td style = "text-align: right;">-1.54706</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: right;">0.4842</td><td style = "text-align: right;">-0.350186</td><td style = "text-align: right;">1.05077</td><td style = "text-align: right;">0.807696</td><td style = "text-align: left;">0</td><td style = "text-align: left;">1</td><td style = "text-align: right;">-0.437307</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">10</td><td style = "text-align: right;">0.346302</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: right;">-1.13673</td><td style = "text-align: right;">-1.04171</td><td style = "text-align: right;">0.931417</td><td style = "text-align: right;">-0.911538</td><td style = "text-align: left;">1</td><td style = "text-align: left;">1</td><td style = "text-align: right;">-0.493206</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">11</td><td style = "text-align: right;">-1.26771</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: right;">-0.755334</td><td style = "text-align: right;">0.341335</td><td style = "text-align: right;">0.409165</td><td style = "text-align: right;">0.807696</td><td style = "text-align: left;">0</td><td style = "text-align: left;">0</td><td style = "text-align: right;">-0.346182</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">12</td><td style = "text-align: right;">-1.58845</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: right;">-1.42278</td><td style = "text-align: right;">-0.695947</td><td style = "text-align: right;">-1.22579</td><td style = "text-align: right;">0.807696</td><td style = "text-align: left;">1</td><td style = "text-align: left;">0</td><td style = "text-align: right;">-0.412103</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">13</td><td style = "text-align: right;">-1.80572</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: right;">-0.469288</td><td style = "text-align: right;">1.72438</td><td style = "text-align: right;">-1.22579</td><td style = "text-align: right;">0.807696</td><td style = "text-align: left;">1</td><td style = "text-align: left;">0</td><td style = "text-align: right;">-1.28375</td></tr><tr><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9989</td><td style = "text-align: right;">1.28781</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: right;">-0.850683</td><td style = "text-align: right;">-0.350186</td><td style = "text-align: right;">-1.22579</td><td style = "text-align: right;">0.807696</td><td style = "text-align: left;">1</td><td style = "text-align: left;">0</td><td style = "text-align: right;">-0.882489</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9990</td><td style = "text-align: right;">1.97066</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: right;">-1.04138</td><td style = "text-align: right;">-0.350186</td><td style = "text-align: right;">-1.22579</td><td style = "text-align: right;">0.807696</td><td style = "text-align: left;">1</td><td style = "text-align: left;">1</td><td style = "text-align: right;">1.37968</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9991</td><td style = "text-align: right;">0.656689</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: right;">-0.564637</td><td style = "text-align: right;">-0.695947</td><td style = "text-align: right;">-0.6646</td><td style = "text-align: right;">-0.911538</td><td style = "text-align: left;">1</td><td style = "text-align: left;">0</td><td style = "text-align: right;">-0.807212</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9992</td><td style = "text-align: right;">-0.553823</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: right;">1.34234</td><td style = "text-align: right;">-0.350186</td><td style = "text-align: right;">0.190638</td><td style = "text-align: right;">-0.911538</td><td style = "text-align: left;">1</td><td style = "text-align: left;">0</td><td style = "text-align: right;">-0.533912</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9993</td><td style = "text-align: right;">0.780845</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: right;">-0.27859</td><td style = "text-align: right;">-1.04171</td><td style = "text-align: right;">-1.22579</td><td style = "text-align: right;">-0.911538</td><td style = "text-align: left;">1</td><td style = "text-align: left;">0</td><td style = "text-align: right;">1.65365</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9994</td><td style = "text-align: right;">-0.0675487</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: right;">-1.04138</td><td style = "text-align: right;">0.687096</td><td style = "text-align: right;">1.25926</td><td style = "text-align: right;">-0.911538</td><td style = "text-align: left;">1</td><td style = "text-align: left;">0</td><td style = "text-align: right;">-1.233</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9995</td><td style = "text-align: right;">1.54647</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: right;">-0.946032</td><td style = "text-align: right;">-1.04171</td><td style = "text-align: right;">-1.22579</td><td style = "text-align: right;">0.807696</td><td style = "text-align: left;">0</td><td style = "text-align: left;">0</td><td style = "text-align: right;">1.17689</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9996</td><td style = "text-align: right;">1.24643</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: right;">0.00745628</td><td style = "text-align: right;">-0.00442574</td><td style = "text-align: right;">-1.22579</td><td style = "text-align: right;">0.807696</td><td style = "text-align: left;">1</td><td style = "text-align: left;">0</td><td style = "text-align: right;">-0.0664157</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9997</td><td style = "text-align: right;">-1.39187</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: right;">-0.373939</td><td style = "text-align: right;">1.72438</td><td style = "text-align: right;">-0.306363</td><td style = "text-align: right;">-0.911538</td><td style = "text-align: left;">1</td><td style = "text-align: left;">1</td><td style = "text-align: right;">0.0279867</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9998</td><td style = "text-align: right;">0.604958</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: right;">-0.27859</td><td style = "text-align: right;">0.687096</td><td style = "text-align: right;">-1.22579</td><td style = "text-align: right;">-0.911538</td><td style = "text-align: left;">0</td><td style = "text-align: left;">1</td><td style = "text-align: right;">-1.00859</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9999</td><td style = "text-align: right;">1.25677</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: right;">0.293503</td><td style = "text-align: right;">-0.695947</td><td style = "text-align: right;">-0.0226064</td><td style = "text-align: right;">0.807696</td><td style = "text-align: left;">1</td><td style = "text-align: left;">0</td><td style = "text-align: right;">-0.125224</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">10000</td><td style = "text-align: right;">1.4637</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">0.0</td><td style = "text-align: right;">-1.04138</td><td style = "text-align: right;">-0.350186</td><td style = "text-align: right;">0.859922</td><td style = "text-align: right;">-0.911538</td><td style = "text-align: left;">1</td><td style = "text-align: left;">0</td><td style = "text-align: right;">-1.07632</td></tr></tbody></table></div>



 **División en conjuntos de entrenamiento y prueba:**
   Los datos se dividieron en un 80% para entrenamiento y un 20% para prueba utilizando la función `partition`.


```julia
(X_train, X_test), (y_train, y_test) = partition((X, y), 0.8, rng=43, multi=true)
```




    (([1m8000×13 DataFrame[0m
    [1m  Row [0m│[1m CreditScore [0m[1m Geography__France [0m[1m Geography__Germany [0m[1m Geography__Spain  [0m[1m[0m ⋯
          │[90m Float64     [0m[90m CategoricalValue… [0m[90m CategoricalValue…  [0m[90m CategoricalValue… [0m[90m[0m ⋯
    ──────┼─────────────────────────────────────────────────────────────────────────
        1 │   -0.502092  0.0                1.0                 0.0                ⋯
        2 │    1.4637    1.0                0.0                 0.0
        3 │   -0.181357  0.0                0.0                 1.0
        4 │    1.31885   1.0                0.0                 0.0
        5 │   -0.326205  1.0                0.0                 0.0                ⋯
        6 │    1.96032   0.0                1.0                 0.0
        7 │   -1.60914   1.0                0.0                 0.0
        8 │    0.998116  1.0                0.0                 0.0
        9 │   -0.181357  0.0                0.0                 1.0                ⋯
       10 │   -0.377936  0.0                0.0                 1.0
       11 │   -1.07114   0.0                0.0                 1.0
      ⋮   │      ⋮               ⋮                  ⋮                   ⋮          ⋱
     7991 │    0.563573  0.0                0.0                 1.0
     7992 │   -1.66087   0.0                1.0                 0.0                ⋯
     7993 │    0.729113  1.0                0.0                 0.0
     7994 │    0.139377  0.0                0.0                 1.0
     7995 │   -0.233089  0.0                1.0                 0.0
     7996 │    0.832576  1.0                0.0                 0.0                ⋯
     7997 │   -1.35048   1.0                0.0                 0.0
     7998 │    1.21539   0.0                1.0                 0.0
     7999 │   -1.45395   1.0                0.0                 0.0
     8000 │    2.06378   1.0                0.0                 0.0                ⋯
    [36m                                                 9 columns and 7979 rows omitted[0m, [1m2000×13 DataFrame[0m
    [1m  Row [0m│[1m CreditScore [0m[1m Geography__France [0m[1m Geography__Germany [0m[1m Geography__Spain  [0m[1m[0m ⋯
          │[90m Float64     [0m[90m CategoricalValue… [0m[90m CategoricalValue…  [0m[90m CategoricalValue… [0m[90m[0m ⋯
    ──────┼─────────────────────────────────────────────────────────────────────────
        1 │  -0.357244   1.0                0.0                 0.0                ⋯
        2 │   1.07054    0.0                0.0                 1.0
        3 │   0.429072   0.0                0.0                 1.0
        4 │   1.22573    0.0                1.0                 0.0
        5 │  -1.0401     0.0                0.0                 1.0                ⋯
        6 │  -1.11252    1.0                0.0                 0.0
        7 │   0.563573   1.0                0.0                 0.0
        8 │   0.0462602  1.0                0.0                 0.0
        9 │   0.594612   0.0                1.0                 0.0                ⋯
       10 │  -1.5781     0.0                1.0                 0.0
       11 │   1.70166    0.0                1.0                 0.0
      ⋮   │      ⋮               ⋮                  ⋮                   ⋮          ⋱
     1991 │  -0.11928    0.0                0.0                 1.0
     1992 │  -1.26771    0.0                1.0                 0.0                ⋯
     1993 │  -1.37118    0.0                1.0                 0.0
     1994 │  -0.584862   1.0                0.0                 0.0
     1995 │  -0.274474   0.0                1.0                 0.0
     1996 │   0.0255677  1.0                0.0                 0.0                ⋯
     1997 │  -0.895249   0.0                1.0                 0.0
     1998 │  -0.69867    0.0                1.0                 0.0
     1999 │  -0.108934   1.0                0.0                 0.0
     2000 │  -0.191704   0.0                1.0                 0.0                ⋯
    [36m                                                 9 columns and 1979 rows omitted[0m), ([0, 0, 0, 0, 0, 1, 0, 0, 0, 0  …  0, 0, 0, 0, 0, 0, 0, 1, 0, 1], [1, 0, 0, 1, 0, 0, 0, 0, 1, 0  …  0, 0, 1, 0, 0, 0, 0, 0, 1, 0]))



## Modelos

### 1. Red Neuronal con Flux.jl

La arquitectura de la red fue:
- **Capa de entrada**: 6 neuronas, función de activación ReLU.  
- **Capa oculta**: 6 neuronas, función de activación ReLU.  
- **Capa de salida**: 1 neurona, activación sigmoidal implícita.



```julia
layer1 = Dense(13 => 6, relu)
layer2 = Dense(6 => 6, relu)
output = Dense(6 => 1)

model = Chain(layer1, layer2, output)
```




    Chain(
      Dense(13 => 6, relu),                 [90m# 84 parameters[39m
      Dense(6 => 6, relu),                  [90m# 42 parameters[39m
      Dense(6 => 1),                        [90m# 7 parameters[39m
    ) [90m                  # Total: 6 arrays, [39m133 parameters, 916 bytes.




```julia
loader = Flux.DataLoader((transpose(Matrix(X_train)), y_train), batchsize=32, shuffle=true)
```




    250-element DataLoader(::Tuple{LinearAlgebra.Transpose{Float64, Matrix{Float64}}, Vector{Int64}}, shuffle=true, batchsize=32)
      with first element:
      (13×32 Matrix{Float64}, 32-element Vector{Int64},)




```julia
optimizer = Flux.setup(Flux.Adam(0.01), model)
```




    (layers = ((weight = [32mLeaf(Adam{Float64}(0.01, (0.9, 0.999), 1.0e-8), [39m(Float32[0.0 0.0 … 0.0 0.0; 0.0 0.0 … 0.0 0.0; … ; 0.0 0.0 … 0.0 0.0; 0.0 0.0 … 0.0 0.0], Float32[0.0 0.0 … 0.0 0.0; 0.0 0.0 … 0.0 0.0; … ; 0.0 0.0 … 0.0 0.0; 0.0 0.0 … 0.0 0.0], (0.9, 0.999))[32m)[39m, bias = [32mLeaf(Adam{Float64}(0.01, (0.9, 0.999), 1.0e-8), [39m(Float32[0.0, 0.0, 0.0, 0.0, 0.0, 0.0], Float32[0.0, 0.0, 0.0, 0.0, 0.0, 0.0], (0.9, 0.999))[32m)[39m, σ = ()), (weight = [32mLeaf(Adam{Float64}(0.01, (0.9, 0.999), 1.0e-8), [39m(Float32[0.0 0.0 … 0.0 0.0; 0.0 0.0 … 0.0 0.0; … ; 0.0 0.0 … 0.0 0.0; 0.0 0.0 … 0.0 0.0], Float32[0.0 0.0 … 0.0 0.0; 0.0 0.0 … 0.0 0.0; … ; 0.0 0.0 … 0.0 0.0; 0.0 0.0 … 0.0 0.0], (0.9, 0.999))[32m)[39m, bias = [32mLeaf(Adam{Float64}(0.01, (0.9, 0.999), 1.0e-8), [39m(Float32[0.0, 0.0, 0.0, 0.0, 0.0, 0.0], Float32[0.0, 0.0, 0.0, 0.0, 0.0, 0.0], (0.9, 0.999))[32m)[39m, σ = ()), (weight = [32mLeaf(Adam{Float64}(0.01, (0.9, 0.999), 1.0e-8), [39m(Float32[0.0 0.0 … 0.0 0.0], Float32[0.0 0.0 … 0.0 0.0], (0.9, 0.999))[32m)[39m, bias = [32mLeaf(Adam{Float64}(0.01, (0.9, 0.999), 1.0e-8), [39m(Float32[0.0], Float32[0.0], (0.9, 0.999))[32m)[39m, σ = ())),)




```julia
loss(m, x, y) = Flux.logitbinarycrossentropy(transpose(m(x)), y)
```




    loss (generic function with 1 method)



El modelo fue entrenado durante 10 épocas utilizando el optimizador **Adam** con una tasa de aprendizaje de 0.01.


```julia
number_epochs = 10
@showprogress for epoch in 1:number_epochs
    Flux.train!(loss, model, loader, optimizer)
end
```

    [33m[1m┌ [22m[39m[33m[1mWarning: [22m[39mLayer with Float32 parameters got Float64 input.
    [33m[1m│ [22m[39m  The input will be converted, but any earlier layers may be very slow.
    [33m[1m│ [22m[39m  layer = Dense(13 => 6, relu)  [90m# 84 parameters[39m
    [33m[1m│ [22m[39m  summary(x) = "13×32 Matrix{Float64}"
    [33m[1m└ [22m[39m[90m@ Flux ~/.julia/packages/Flux/n3cOc/src/layers/stateless.jl:60[39m
    [32mProgress: 100%|█████████████████████████████████████████| Time: 0:00:31[39m


**Resultados del modelo con Flux:**
- **Precisión en entrenamiento**: 86.4%.  
- **Precisión en prueba**: 85.8%.  
- **Área bajo la curva (AUC)**: 0.86.  


```julia
output2 = model(transpose(Matrix(X_train)))

mean((output2[1, :] .> 0.5) .== y_train)
```




    0.855875




```julia
test_output = model(transpose(Matrix(X_test)))
```




    1×2000 Matrix{Float32}:
     -2.01054  -1.50879  -2.54158  -0.789179  …  -1.64363  -1.29932  0.397251




```julia
ConfusionMatrix()(test_output[1, :] .> 0.5, y_test)
```




              ┌─────────────┐
              │Ground Truth │
    ┌─────────┼──────┬──────┤
    │Predicted│  0   │  1   │
    ├─────────┼──────┼──────┤
    │    0    │ 1550 │ 291  │
    ├─────────┼──────┼──────┤
    │    1    │  23  │ 136  │
    └─────────┴──────┴──────┘





```julia
mean((test_output[1, :] .> 0.5) .== y_test)
```




    0.843




```julia
MLJ.confusion_matrix(test_output[1, :] .> 0.5, y_test)
```




              ┌─────────────┐
              │Ground Truth │
    ┌─────────┼──────┬──────┤
    │Predicted│  0   │  1   │
    ├─────────┼──────┼──────┤
    │    0    │ 1550 │ 291  │
    ├─────────┼──────┼──────┤
    │    1    │  23  │ 136  │
    └─────────┴──────┴──────┘





```julia
using CategoricalDistributions

# Vector de probabilidades de la clase positiva
prob_predictions = σ.(test_output[1, :])  # Asegúrate de usar las probabilidades correctas

# Etiquetas de las clases
classes = [0, 1]  # Por ejemplo, 0 = clase negativa, 1 = clase positiva

# Convertir a UnivariateFinite
univariate_predictions = [UnivariateFinite(classes, [1-p, p], pool=missing) for p in prob_predictions]

```




    2000-element Vector{UnivariateFinite{Multiclass{2}, Int64, UInt8, Float32}}:
     UnivariateFinite{Multiclass{2}}(0=>0.882, 1=>0.118)
     UnivariateFinite{Multiclass{2}}(0=>0.819, 1=>0.181)
     UnivariateFinite{Multiclass{2}}(0=>0.927, 1=>0.073)
     UnivariateFinite{Multiclass{2}}(0=>0.688, 1=>0.312)
     UnivariateFinite{Multiclass{2}}(0=>0.958, 1=>0.0417)
     UnivariateFinite{Multiclass{2}}(0=>0.945, 1=>0.0545)
     UnivariateFinite{Multiclass{2}}(0=>0.859, 1=>0.141)
     UnivariateFinite{Multiclass{2}}(0=>0.892, 1=>0.108)
     UnivariateFinite{Multiclass{2}}(0=>0.51, 1=>0.49)
     UnivariateFinite{Multiclass{2}}(0=>0.921, 1=>0.0788)
     UnivariateFinite{Multiclass{2}}(0=>0.821, 1=>0.179)
     UnivariateFinite{Multiclass{2}}(0=>0.957, 1=>0.0425)
     UnivariateFinite{Multiclass{2}}(0=>0.927, 1=>0.0728)
     ⋮
     UnivariateFinite{Multiclass{2}}(0=>0.966, 1=>0.0339)
     UnivariateFinite{Multiclass{2}}(0=>0.867, 1=>0.133)
     UnivariateFinite{Multiclass{2}}(0=>0.944, 1=>0.0564)
     UnivariateFinite{Multiclass{2}}(0=>0.966, 1=>0.0338)
     UnivariateFinite{Multiclass{2}}(0=>0.208, 1=>0.792)
     UnivariateFinite{Multiclass{2}}(0=>0.914, 1=>0.086)
     UnivariateFinite{Multiclass{2}}(0=>0.813, 1=>0.187)
     UnivariateFinite{Multiclass{2}}(0=>0.874, 1=>0.126)
     UnivariateFinite{Multiclass{2}}(0=>0.782, 1=>0.218)
     UnivariateFinite{Multiclass{2}}(0=>0.838, 1=>0.162)
     UnivariateFinite{Multiclass{2}}(0=>0.786, 1=>0.214)
     UnivariateFinite{Multiclass{2}}(0=>0.402, 1=>0.598)



### Curva ROC


```julia
rc_test=roc_curve(univariate_predictions, coerce(y_test, Multiclass))
plot(rc_test, legend=false, xlabel="False Positive Rate", ylabel="True Positive Rate", title="ROC Curve")
```

    [33m[1m┌ [22m[39m[33m[1mWarning: [22m[39mLevels not explicitly ordered. Using the order [0, 1]. The "positive" level is 1. 
    [33m[1m└ [22m[39m[90m@ StatisticalMeasures ~/.julia/packages/StatisticalMeasures/UTtxb/src/roc.jl:28[39m





    
![svg](output_36_1.svg)
    




```julia
# Calcular AUC
auc_value = auc(univariate_predictions, coerce(y_test, Multiclass))
println("Área bajo la curva (AUC): ", auc_value)
```

    Área bajo la curva (AUC): 0.8575329290679514


## Regresión Logística con GLM.jl

### Implementación de GLM
Para comparar el desempeño de la red neuronal, se ajustó un modelo lineal generalizado utilizando la función `glm` del paquete `GLM.jl` en Julia.

Se ajustó un modelo de regresión logística utilizando las mismas variables estandarizadas. Se utilizó la función de enlace **Probit**.


```julia
# Crear un DataFrame combinando X y y para GLM
glm_data = hcat(X_train, y_train)
rename!(glm_data, :x1 => :Exited)
println(first(glm_data,5))
```

    [1m5×14 DataFrame[0m
    [1m Row [0m│[1m CreditScore [0m[1m Geography__France [0m[1m Geography__Germany [0m[1m Geography__Spain  [0m[1m Gender__Female    [0m[1m Gender__Male      [0m[1m Age      [0m[1m Tenure    [0m[1m Balance   [0m[1m NumOfProducts [0m[1m HasCrCard [0m[1m IsActiveMember [0m[1m EstimatedSalary [0m[1m Exited [0m
         │[90m Float64     [0m[90m CategoricalValue… [0m[90m CategoricalValue…  [0m[90m CategoricalValue… [0m[90m CategoricalValue… [0m[90m CategoricalValue… [0m[90m Float64  [0m[90m Float64   [0m[90m Float64   [0m[90m Float64       [0m[90m Cat…      [0m[90m Cat…           [0m[90m Float64         [0m[90m Int64  [0m
    ─────┼────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
       1 │   -0.502092  0.0                1.0                 0.0                1.0                0.0                0.293503   0.341335   1.31302       -0.911538  1          1                      0.552877       0
       2 │    1.4637    1.0                0.0                 0.0                1.0                0.0                0.293503  -1.04171   -1.22579        0.807696  1          0                     -0.129127       0
       3 │   -0.181357  0.0                0.0                 1.0                0.0                1.0                1.81908    0.341335   0.349736      -0.911538  1          1                      0.555445       0
       4 │    1.31885   1.0                0.0                 0.0                0.0                1.0                0.4842     1.03286    0.75929       -0.911538  1          0                      0.772115       0
       5 │   -0.326205  1.0                0.0                 0.0                1.0                0.0                0.960945   1.37862    1.1038        -0.911538  1          0                     -1.07638        0



```julia
# Ajustar el modelo de regresión logística usando GLM
glm_model = @formula(Exited ~ Geography__France + Geography__Germany + Geography__Spain + Gender__Female + Gender__Male + CreditScore + Age + Tenure + Balance + NumOfProducts + HasCrCard + IsActiveMember + EstimatedSalary)
logit = glm(glm_model, glm_data, Binomial(), ProbitLink())
```




    StatsModels.TableRegressionModel{GeneralizedLinearModel{GLM.GlmResp{Vector{Float64}, Binomial{Float64}, ProbitLink}, GLM.DensePredChol{Float64, LinearAlgebra.CholeskyPivoted{Float64, Matrix{Float64}, Vector{Int64}}}}, Matrix{Float64}}
    
    Exited ~ 1 + Geography__France + Geography__Germany + Geography__Spain + Gender__Female + Gender__Male + CreditScore + Age + Tenure + Balance + NumOfProducts + HasCrCard + IsActiveMember + EstimatedSalary
    
    Coefficients:
    ─────────────────────────────────────────────────────────────────────────────────────────────
                                  Coef.   Std. Error       z  Pr(>|z|)    Lower 95%     Upper 95%
    ─────────────────────────────────────────────────────────────────────────────────────────────
    (Intercept)              -0.58381      0.0500289  -11.67    <1e-30   -0.681865    -0.485755
    Geography__France: 1.0   -0.0287321    0.0439857   -0.65    0.5136   -0.114943     0.0574783
    Geography__Germany: 1.0   0.442907     0.0503843    8.79    <1e-17    0.344156     0.541658
    Geography__Spain: 1.0     0.0        NaN          NaN       NaN     NaN          NaN
    Gender__Female: 1.0       0.0        NaN          NaN       NaN     NaN          NaN
    Gender__Male: 1.0        -0.294571     0.0344744   -8.54    <1e-16   -0.362139    -0.227002
    CreditScore              -0.0488764    0.0172507   -2.83    0.0046   -0.0826871   -0.0150658
    Age                       0.420182     0.0169896   24.73    <1e-99    0.386883     0.453481
    Tenure                   -0.0295044    0.017147    -1.72    0.0853   -0.0631119    0.00410303
    Balance                   0.0956816    0.020196     4.74    <1e-05    0.0560982    0.135265
    NumOfProducts            -0.0099487    0.0173548   -0.57    0.5665   -0.0439634    0.024066
    HasCrCard: 1             -0.0330246    0.0376894   -0.88    0.3809   -0.106895     0.0408453
    IsActiveMember: 1        -0.577033     0.0355625  -16.23    <1e-58   -0.646734    -0.507332
    EstimatedSalary           0.0129387    0.0172299    0.75    0.4527   -0.0208313    0.0467087
    ─────────────────────────────────────────────────────────────────────────────────────────────



**Resumen del modelo:**


```julia
println("Resumen del modelo GLM:")
println(coeftable(logit))
```

    Resumen del modelo GLM:
    ─────────────────────────────────────────────────────────────────────────────────────────────
                                  Coef.   Std. Error       z  Pr(>|z|)    Lower 95%     Upper 95%
    ─────────────────────────────────────────────────────────────────────────────────────────────
    (Intercept)              -0.58381      0.0500289  -11.67    <1e-30   -0.681865    -0.485755
    Geography__France: 1.0   -0.0287321    0.0439857   -0.65    0.5136   -0.114943     0.0574783
    Geography__Germany: 1.0   0.442907     0.0503843    8.79    <1e-17    0.344156     0.541658
    Geography__Spain: 1.0     0.0        NaN          NaN       NaN     NaN          NaN
    Gender__Female: 1.0       0.0        NaN          NaN       NaN     NaN          NaN
    Gender__Male: 1.0        -0.294571     0.0344744   -8.54    <1e-16   -0.362139    -0.227002
    CreditScore              -0.0488764    0.0172507   -2.83    0.0046   -0.0826871   -0.0150658
    Age                       0.420182     0.0169896   24.73    <1e-99    0.386883     0.453481
    Tenure                   -0.0295044    0.017147    -1.72    0.0853   -0.0631119    0.00410303
    Balance                   0.0956816    0.020196     4.74    <1e-05    0.0560982    0.135265
    NumOfProducts            -0.0099487    0.0173548   -0.57    0.5665   -0.0439634    0.024066
    HasCrCard: 1             -0.0330246    0.0376894   -0.88    0.3809   -0.106895     0.0408453
    IsActiveMember: 1        -0.577033     0.0355625  -16.23    <1e-58   -0.646734    -0.507332
    EstimatedSalary           0.0129387    0.0172299    0.75    0.4527   -0.0208313    0.0467087
    ─────────────────────────────────────────────────────────────────────────────────────────────



```julia
# Predecir en el conjunto de prueba
glm_predictions = GLM.predict(logit, X_test)
glm_binary_predictions = glm_predictions .> 0.5
```




    2000-element BitVector:
     0
     0
     0
     0
     0
     0
     0
     0
     1
     0
     0
     0
     0
     ⋮
     0
     0
     0
     0
     0
     0
     1
     0
     0
     0
     0
     0



**Resultados del modelo con GLM:**
- **Precisión en prueba**: 80.6%.  
- **Área bajo la curva (AUC)**: 0.77


```julia
# Calcular precisión del modelo GLM
glm_accuracy = mean(glm_binary_predictions .== y_test)
println("GLM Test Accuracy: ", glm_accuracy)
```

    GLM Test Accuracy: 0.8065



```julia
# Generar la matriz de confusión para GLM
glm_conf_matrix = ConfusionMatrix()(glm_binary_predictions, y_test)
```




              ┌─────────────┐
              │Ground Truth │
    ┌─────────┼──────┬──────┤
    │Predicted│  0   │  1   │
    ├─────────┼──────┼──────┤
    │    0    │ 1533 │ 347  │
    ├─────────┼──────┼──────┤
    │    1    │  40  │  80  │
    └─────────┴──────┴──────┘





```julia
# Calcular el AUC
auc_glm = auc([UnivariateFinite(classes, [1-p, p], pool=missing) for p in glm_predictions], coerce(y_test, Multiclass))
```




    0.7763458598033859



## Comparación de Modelos



### Curva ROC Comparativa

Se generaron curvas ROC para ambos modelos. La red neuronal mostró un mejor desempeño con un AUC mayor.  



```julia
# Comparar resultados
println("Comparación de AUC entre Flux y GLM:")
println("Flux AUC: ", auc_value)
println("GLM AUC: ", auc_glm)

# Calcular curva ROC para Flux
roc_flux = roc_curve(univariate_predictions, coerce(y_test, Multiclass))

# Calcular curva ROC para GLM
roc_glm = roc_curve([UnivariateFinite(classes, [1-p, p], pool=missing) for p in glm_predictions], coerce(y_test, Multiclass))

# Crear la línea de referencia (clasificador aleatorio)
reference_x = [0, 1]
reference_y = [0, 1]

# Crear la gráfica
plot(roc_flux, label="Flux ROC Curve", xlabel="False Positive Rate", ylabel="True Positive Rate", title="ROC Curves Comparison")
plot!(roc_glm, label="GLM ROC Curve")
plot!(reference_x, reference_y, linestyle=:dash, color=:gray, label="Random Classifier (0.5)")

```

    Comparación de AUC entre Flux y GLM:
    Flux AUC: 0.8575329290679514
    GLM AUC: 0.7763458598033859


    [33m[1m┌ [22m[39m[33m[1mWarning: [22m[39mLevels not explicitly ordered. Using the order [0, 1]. The "positive" level is 1. 
    [33m[1m└ [22m[39m[90m@ StatisticalMeasures ~/.julia/packages/StatisticalMeasures/UTtxb/src/roc.jl:28[39m
    [33m[1m┌ [22m[39m[33m[1mWarning: [22m[39mLevels not explicitly ordered. Using the order [0, 1]. The "positive" level is 1. 
    [33m[1m└ [22m[39m[90m@ StatisticalMeasures ~/.julia/packages/StatisticalMeasures/UTtxb/src/roc.jl:28[39m





    
![svg](output_50_2.svg)
    



## Conclusiones

1. La red neuronal mostró un desempeño superior en comparación con la regresión logística, tanto en precisión como en AUC.
2. Aunque más compleja, la red neuronal capturó mejor las relaciones no lineales presentes en los datos.
3. La regresión logística sigue siendo una opción viable, especialmente por su simplicidad interpretativa.


