using DataFrames
using Flux
using MLJ
using CUDA
using IterTools: ncycle
using ProgressMeter
using Images
using Glob
using MLUtils
using Augmentor
using CUDA: CuIterator
using ImageShow
using Statistics
using CSV
using CategoricalDistributions
using Plots
using GLM


# Cargar el dataset
file_path = "./dat/Churn_Modelling.csv"  # Cambiar a la ruta donde está el archivo
data = CSV.read(file_path, DataFrame)
println(first(data, 10))

println(describe(data))

# Eliminar columnas irrelevantes
data = DataFrames.select(data, Not(["RowNumber", "CustomerId", "Surname"]))

# Dividir datos en características (X) y objetivo (y)
X_features = DataFrames.select(data, Not(:Exited))
y_target = data.Exited

println(MLJ.schema(X_features))

# Codificación de variables categóricas
X_features.Gender = coerce(X_features.Gender, Multiclass)
X_features.Geography = coerce(X_features.Geography, Multiclass)

encoder = OneHotEncoder(features=[:Geography, :Gender])
encoder_model = fit!(machine(encoder, X_features))
X_encoded = MLJ.transform(encoder_model, X_features)
println(MLJ.schema(X_encoded))

# Convertir ciertas columnas en factores ordenados
X_encoded = coerce(X_encoded,
    :Geography__France => OrderedFactor,
    :Geography__Germany => OrderedFactor,
    :Geography__Spain => OrderedFactor,
    :Gender__Female => OrderedFactor,
    :Gender__Male => OrderedFactor,
    :HasCrCard => OrderedFactor,
    :IsActiveMember => OrderedFactor
)

# Estandarizar las características
scaler = Standardizer(count=true)
scaler_model = machine(scaler, X_encoded)
fit!(scaler_model)
X_standardized = MLJ.transform(scaler_model, X_encoded)

# Dividir los datos en conjuntos de entrenamiento y prueba
(X_train, X_test), (y_train, y_test) = partition((X_standardized, y_target), 0.8, rng=43, multi=true)

# ====================================
# Implementación con Flux
# ====================================

# Definir el modelo de red neuronal
input_layer = Dense(size(X_train, 2) => 6, relu)
hidden_layer = Dense(6 => 6, relu)
output_layer = Dense(6 => 1)

nn_model = Chain(input_layer, hidden_layer, output_layer)

# Crear el DataLoader para entrenamiento por lotes
train_loader = Flux.DataLoader((Matrix(X_train)', y_train), batchsize=32, shuffle=true)

# Configurar el optimizador y la función de pérdida
optimizer = Flux.setup(Flux.Adam(0.01), nn_model)
loss_function(model, x, y) = Flux.logitbinarycrossentropy(transpose(model(x)), y)

# Entrenamiento del modelo
num_epochs = 10
@showprogress for epoch in 1:num_epochs
    Flux.train!(loss_function, nn_model, train_loader, optimizer)
end

# Evaluación del modelo en el conjunto de entrenamiento
train_output = nn_model(Matrix(X_train)')
println("Training Accuracy after Training: ", mean((train_output[1, :] .> 0.5) .== y_train))

# Evaluación en el conjunto de prueba
test_output = nn_model(Matrix(X_test)')
println("Test Accuracy: ", mean((test_output[1, :] .> 0.5) .== y_test))

# Generar la matriz de confusión
conf_matrix = ConfusionMatrix()(test_output[1, :] .> 0.5, y_test)
println("Confusion Matrix:\n", conf_matrix)

#output_class=coerce(test_output, Multiclass)
#y_class=coerce(y_test, Multiclass)

# Calcular la curva ROC y el AUC
probabilities = σ.(test_output[1, :])  # Probabilidades predichas
class_labels = [0, 1]
predictions = [UnivariateFinite(class_labels, [1-p, p], pool=missing) for p in probabilities]
roc_curve_data = roc_curve(predictions, coerce(y_test, Multiclass))

# Graficar la curva ROC
p = plot(roc_curve_data, label="ROC Curve", xlabel="False Positive Rate", ylabel="True Positive Rate", title="ROC Curve")
savefig(p, "./fig/roc_curve_flux.png")

# Calcular el AUC
auc_value = auc(predictions, coerce(y_test, Multiclass))
println("Área bajo la curva (AUC): ", auc_value)

# ====================================
# Implementación con GLM
# ====================================

# Crear un DataFrame combinando X y y para GLM
glm_data = hcat(X_train, y_train)
rename!(glm_data, :x1 => :Exited)
println(first(glm_data,5))

# Ajustar el modelo de regresión logística usando GLM
glm_model = @formula(Exited ~ Geography__France + Geography__Germany + Geography__Spain + Gender__Female + Gender__Male + CreditScore + Age + Tenure + Balance + NumOfProducts + HasCrCard + IsActiveMember + EstimatedSalary)
logit = glm(glm_model, glm_data, Binomial(), ProbitLink())
     
println("Resumen del modelo GLM:")
println(coeftable(logit))

# Predecir en el conjunto de prueba
glm_predictions = GLM.predict(logit, X_test)
glm_binary_predictions = glm_predictions .> 0.5

# Calcular precisión del modelo GLM
glm_accuracy = mean(glm_binary_predictions .== y_test)
println("GLM Test Accuracy: ", glm_accuracy)

# Generar la matriz de confusión para GLM
glm_conf_matrix = ConfusionMatrix()(glm_binary_predictions, y_test)
println("GLM Confusion Matrix:\n", glm_conf_matrix)

# Calcular el AUC
auc_glm = auc([UnivariateFinite(class_labels, [1-p, p], pool=missing) for p in glm_predictions], coerce(y_test, Multiclass))
#println("Área bajo la curva GLM (AUC): ", auc_value)

# Comparar resultados
println("Comparación de AUC entre Flux y GLM:")
println("Flux AUC: ", auc_value)
println("GLM AUC: ", auc_glm)

# Calcular curva ROC para Flux
roc_flux = roc_curve([UnivariateFinite(class_labels, [1-p, p], pool=missing) for p in probabilities], coerce(y_test, Multiclass))

# Calcular curva ROC para GLM
roc_glm = roc_curve([UnivariateFinite(class_labels, [1-p, p], pool=missing) for p in glm_predictions], coerce(y_test, Multiclass))

# Crear la línea de referencia (clasificador aleatorio)
reference_x = [0, 1]
reference_y = [0, 1]

# Crear la gráfica
plot(roc_flux, label="Flux ROC Curve", xlabel="False Positive Rate", ylabel="True Positive Rate", title="ROC Curves Comparison")
plot!(roc_glm, label="GLM ROC Curve")
plot!(reference_x, reference_y, linestyle=:dash, color=:gray, label="Random Classifier (0.5)")

savefig("./fig/roc_curve_comparison.png")
