using DataFrames, Random, Flux, Statistics, MLUtils, Plots, StatsPlots, CategoricalArrays
using Flux: onehotbatch, params  # Import onehotbatch and params
using LinearAlgebra
using Optimisers
using CSV

# ------------------------------
# 1. Function to Split DataFrame into Train/Test Sets
# ------------------------------
function train_test_split(df::DataFrame, train_ratio::Real)
    # Ensure the training ratio is between 0 and 1
    if !(0 <= train_ratio <= 1)
        throw(ArgumentError("train_ratio must be between 0 and 1"))
    end

    n = nrow(df)  # Total number of rows
    train_size = floor(Int, n * train_ratio)  # Calculate training set size
    indices = shuffle(1:n)  # Shuffle indices for random splitting
    train_indices = indices[1:train_size]  # Indices for training set
    test_indices = indices[train_size+1:end]  # Indices for testing set

    train_df = df[train_indices, :]  # Training DataFrame
    test_df = df[test_indices, :]  # Testing DataFrame

    # Separate features and target variable for training set
    X_train = select(train_df, Not(:Exited))  # Assumes target column is named "Exited"
    y_train = train_df.Exited  # Target variable for training

    # Separate features and target variable for testing set
    X_test = select(test_df, Not(:Exited))
    y_test = test_df.Exited

    return X_train, y_train, X_test, y_test  # Return split datasets
end

# ------------------------------
# 2. Function to Count Elements per Class in y
# ------------------------------
function count_classes(y)
    counts = Dict()
    for val in y
        if haskey(counts, val)
            counts[val] += 1  # Increment count if key exists
        else
            counts[val] = 1  # Initialize count if key does not exist
        end
    end
    return counts  # Return dictionary of class counts
end

# ------------------------------
# 3. One-Hot Encoding for Categorical Variables
# ------------------------------
function one_hot_encode(df::DataFrame)
    encoded_cols = []  # Initialize array to hold encoded columns
    for col_name in names(df)
        col = df[!, col_name]
        # Check if the column is categorical based on its type
        if eltype(col) <: Union{String, Char, CategoricalArray{String}}
            uniques = unique(col)  # Get unique categories
            encoded = onehotbatch(col, uniques)  # Perform one-hot encoding
            # Create new columns for each unique category
            push!(encoded_cols, DataFrame([Symbol(string(col_name) * "_" * string(uniques[i])) => encoded[i, :] for i in 1:length(uniques)]))
        else
            push!(encoded_cols, DataFrame(Symbol(col_name) => col))  # Retain numerical columns as is
        end
    end
    return reduce(hcat, encoded_cols)  # Combine all encoded columns horizontally
end

# ------------------------------
# 4. Function to Train Logistic Regression Model with Flux
# ------------------------------
function train_logistic_model(X_train, y_train; learning_rate=0.01, epochs=1000)
    # Identify numerical columns
    numeric_cols = names(select(X_train, eltype.(eachcol(X_train)) .<: Number))

    # Convert only numerical columns to matrices
    X_train_matrix = Matrix(select(X_train, numeric_cols))' |> Flux.f32  # Transpose and convert to Float32
    y_train_matrix = reshape(convert(Array{Float32}, y_train), 1, :)  # Reshape target variable

    # Define the logistic regression model
    model = Chain(
        Dense(size(X_train_matrix, 1), 1, σ)  # Single output layer with sigmoid activation
    )
    model = Flux.f32(model)  # Ensure model parameters are Float32

    # Define the loss function using binary cross-entropy
    loss(model, x, y) = Flux.Losses.binarycrossentropy(model(x), y)

    # Initialize optimizer (using Flux's ADAM optimizer directly)
    optimizer = ADAM(learning_rate)
    opt = optimizer
    state = Optimisers.setup(opt, model)  # Setup optimizer state

    # Train the model using Flux's training API
    for epoch in 1:epochs
        Flux.train!(loss, model, [(X_train_matrix, y_train_matrix)], state)  # Perform a training step
        if epoch % 100 == 0
            current_loss = loss(model, X_train_matrix, y_train_matrix)
            println("Epoch $epoch, Loss: $current_loss")  # Log loss every 100 epochs
        end
    end

    return model  # Return the trained model
end

# ------------------------------
# 5. Function to Make Predictions and Binarize Results
# ------------------------------
function predict_and_binarize(model, X_test)
    # Convert testing features to matrix format
    X_test_matrix = Matrix(select(X_test, eltype.(eachcol(X_test)) .<: Number))' |> Flux.f32
    predictions = model(X_test_matrix)  # Get model predictions
    # Binarize predictions based on a threshold of 0.5
    binary_predictions = [p > 0.5 ? 1 : 0 for p in predictions]
    return vec(binary_predictions)  # Return predictions as a vector
end

# ------------------------------
# 6. Function to Calculate Accuracy
# ------------------------------
function calculate_accuracy(y_test, predictions)
    correct_predictions = sum(predictions .== y_test)  # Count correct predictions
    accuracy = correct_predictions / length(y_test)  # Calculate accuracy
    return accuracy  # Return accuracy value
end

# ------------------------------
# 7. Function to Generate Confusion Matrix
# ------------------------------
function confusion_matrix(y_true, y_pred)
    labels = unique(vcat(y_true, y_pred))  # Get unique labels
    k = length(labels)  # Number of classes
    matrix = zeros(Int, k, k)  # Initialize confusion matrix
    label_map = Dict(label => i for (i, label) in enumerate(labels))  # Map labels to indices

    # Populate the confusion matrix
    for (true_val, pred_val) in zip(y_true, y_pred)
        i = label_map[true_val]
        j = label_map[pred_val]
        matrix[i, j] += 1
    end
    return labels, matrix  # Return labels and confusion matrix
end

# Function to Print Confusion Matrix in Readable Format
function print_confusion_matrix(labels, matrix)
    println("Confusion Matrix:")
    print("        ")
    for label in labels
        print(" $label ")
    end
    println()
    for (i, label) in enumerate(labels)
        print("$label     ")
        for j in 1:length(labels)
            print(" $(matrix[i, j]) ")
        end
        println()
    end
end

# ------------------------------
# 8. Function to Calculate ROC Curve
# ------------------------------
function calculate_roc(y_true, y_scores)
    sorted_indices = sortperm(y_scores, rev=true)  # Sort scores in descending order
    y_true_sorted = y_true[sorted_indices]  # Sort true labels accordingly

    tp = cumsum(y_true_sorted)  # Cumulative true positives
    fp = cumsum(1 .- y_true_sorted)  # Cumulative false positives

    P = sum(y_true)  # Total actual positives
    N = length(y_true) - P  # Total actual negatives

    tpr = tp / P  # True Positive Rate
    fpr = fp / N  # False Positive Rate

    # Append starting and ending points for ROC curve
    fpr = [0.0; fpr; 1.0]
    tpr = [0.0; tpr; 1.0]

    return fpr, tpr  # Return False Positive Rates and True Positive Rates
end

# ------------------------------
# 9. Function to Calculate AUC Using Trapezoidal Rule
# ------------------------------
function calculate_auc(fpr, tpr)
    auc = 0.0
    # Iterate through points to calculate area using trapezoidal rule
    for i in 2:length(fpr)
        auc += (fpr[i] - fpr[i-1]) * (tpr[i] + tpr[i-1]) / 2
    end
    return auc  # Return AUC value
end

# ------------------------------
# 10. Function to Plot ROC Curve
# ------------------------------
function plot_roc(y_true, y_scores)
    fpr, tpr = calculate_roc(y_true, y_scores)  # Calculate ROC points
    auc_value = calculate_auc(fpr, tpr)  # Calculate AUC
    # Plot ROC curve with labels and title
    plot(fpr, tpr, 
         xlabel="False Positive Rate (FPR)", 
         ylabel="True Positive Rate (TPR)",
         title="ROC Curve (AUC = $(round(auc_value, digits=3)))",
         legend=false)
    savefig("fig/ROC_Curve.png")  # Save the ROC curve plot
end

# ------------------------------
# Main Execution Flow
# ------------------------------
# Load dataset from CSV file
df = CSV.read("dat/Churn_Modelling.csv", DataFrame)

# Split data into training and testing sets
X_train, y_train, X_test, y_test = train_test_split(df, 0.9)

# Count class instances in the training set
println("Class counts in y_train: $(count_classes(y_train))")

# Perform One-Hot Encoding on categorical variables
X_train_encoded = one_hot_encode(X_train)
X_test_encoded = one_hot_encode(X_test)

# Train the logistic regression model
model = train_logistic_model(X_train_encoded, y_train)

# Make predictions and binarize the results
predictions = predict_and_binarize(model, X_test_encoded)

# Calculate and print accuracy
accuracy_ = calculate_accuracy(y_test, predictions)
println("Accuracy: $(accuracy_)")

# Generate and print confusion matrix
labels, matrix = confusion_matrix(y_test, predictions)
print_confusion_matrix(labels, matrix)

# Plot and save ROC curve (requires probability scores)
X_test_matrix = Matrix(select(X_test_encoded, eltype.(eachcol(X_test_encoded)) .<: Number))' |> Flux.f32
probabilities = model(X_test_matrix)  # Get probability scores from the model
plot_roc(y_test, vec(probabilities))  # Plot ROC curve and save the figure
