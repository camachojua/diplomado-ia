# Logistic Regression with Flux Report

## **Overview**

This report outlines the implementation and evaluation of a logistic regression model using the Flux library in Julia. The objective was to predict customer churn based on the `Churn_Modelling.csv` dataset, following methodologies demonstrated in Flux and GLM (Generalized Linear Models) tutorials. The model's performance was assessed using accuracy metrics, confusion matrices, and Receiver Operating Characteristic (ROC) curves.

## **Data Preprocessing**

### 1. **Data Acquisition**
The `Churn_Modelling.csv` dataset was obtained from the [Selva86 GitHub repository](https://github.com/selva86/datasets/tree/master). This dataset encompasses customer information pertinent to predicting churn, including demographic details, account information, and service usage metrics.

### 2. **Data Splitting**
A custom function `train_test_split` was employed to divide the dataset into training and testing subsets based on a specified training ratio (90% training, 10% testing). This split ensured that the model was trained on a substantial portion of the data while retaining a portion for unbiased evaluation.

### 3. **Handling Missing Data**
- **Missing Value Assessment:** Each column in the dataset was inspected for missing values. Rows containing any missing data were removed to maintain data integrity and ensure accurate model training.
  
- **Categorical Encoding:** Categorical variables were identified and processed using one-hot encoding. The `one_hot_encode` function transformed categorical features into a binary matrix, facilitating their inclusion in the logistic regression model.

### 4. **Feature Selection**
Selected features included both numerical and encoded categorical variables relevant to customer churn. The target variable was `Exited`, indicating whether a customer left the service (`1`) or remained (`0`).

### 5. **Normalization**
Numerical features were normalized to a [0, 1] range to ensure that all features contributed equally to the model training process, preventing dominance by features with larger scales.

## **Modeling with Flux**

### 1. **Model Architecture**
A simple logistic regression model was constructed using Flux's `Chain` and `Dense` layers:
- **Input Layer:** Corresponded to the number of features after encoding.
- **Output Layer:** A single neuron with a sigmoid activation function to output probabilities of churn.

### 2. **Training Procedure**
- **Loss Function:** Binary cross-entropy was used to measure the discrepancy between predicted probabilities and actual labels.
  
- **Optimizer:** The ADAM optimizer was selected for its efficiency and adaptability in updating model weights during training.
  
- **Training Loop:** The model was trained for 1,000 epochs, with loss monitored and printed every 100 epochs to track convergence.

## **Evaluation Metrics**

### 1. **Accuracy**
Calculated as the proportion of correctly predicted instances out of the total instances in the test set. An accuracy score provides a straightforward measure of the model's performance.

### 2. **Confusion Matrix**
A confusion matrix was generated to provide a detailed breakdown of prediction outcomes, including:
- **True Positives (TP):** Correctly predicted churns.
- **True Negatives (TN):** Correctly predicted non-churns.
- **False Positives (FP):** Incorrectly predicted churns.
- **False Negatives (FN):** Incorrectly predicted non-churns.

### 3. **ROC Curve and AUC**
The ROC curve was plotted to illustrate the trade-off between the true positive rate (TPR) and false positive rate (FPR) at various threshold settings. The Area Under the Curve (AUC) was computed to quantify the model's ability to discriminate between classes, with values closer to 1 indicating better performance.

## **Results**

### 1. **Model Training**
The logistic regression model was successfully trained over 1,000 epochs. The loss decreased steadily, indicating effective learning.

### 2. **Performance Metrics**
- **Accuracy:** The model achieved an accuracy of *79.4%* on the test set, demonstrating its ability to correctly predict customer churn if it wasn´t because our model made all of its predictions to one label. The model is overfited and optimizing its parameters would be beneficial for the model.

## **Key Findings**

1. **Effective Feature Encoding:**
   One-hot encoding successfully transformed categorical variables, enabling the logistic regression model to utilize them effectively in predictions.

2. **Model Performance:**
   The high accuracy and AUC scores indicate that the logistic regression model with Flux is proficient in identifying patterns associated with customer churn or that the model is highly overfit in an unbalanced dataset.

## **Conclusion**

The application of Flux for logistic regression on the `Churn_Modelling.csv` dataset proved successful in building a toy model for predicting customer churn. This example is perfect to understand and mitigate overfiting in models. 

Through meticulous data preprocessing, including handling missing values and encoding categorical variables, the model was equipped with high-quality inputs essential for effective learning.
