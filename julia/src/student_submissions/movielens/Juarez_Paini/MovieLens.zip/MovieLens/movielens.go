package main

import (
	"encoding/csv"
	"fmt"
	"log"
	"os"
	"strconv"
	"strings"
	"time"
)

func SplitBigFile(file_name string, number_of_chunks int, directory string) []string {
	// Usa la librería os para abrir el archivo
	file, err := os.Open(directory + file_name + ".csv")
	if err != nil {
		log.Fatalf("Error opening file: %s", err)
	}
	defer file.Close()

	// Para leer el archivo:
	csvReader := csv.NewReader(file)
	data, err := csvReader.ReadAll()
	if err != nil {
		log.Fatalf("Error extracting data from file %v: %s", file_name, err)
	}

	// Define cuantas lineas por archivo nuevo, dividiendo el numero total de lineas entre el numero de archivos
	rowsPerFile := (len(data) - 1) / number_of_chunks
	var filesCreated []string

	for i := 0; i < number_of_chunks; i++ {
		tempName := file_name + "_" + fmt.Sprintf("%02d", i+1)
		WriteCsv(data[i*rowsPerFile:(i+1)*rowsPerFile], tempName, directory) // Escribe el archivo creado
		filesCreated = append(filesCreated, tempName)                        // Agrega el nombre del archivo a la lista de strings
	}

	return filesCreated
}

// Crea el archivo
func WriteCsv(data [][]string, name string, path string) {
	csvFile, err := os.Create(path + "/" + name + ".csv")
	if err != nil {
		log.Fatalf("Error creating new csv file %v: %s", name, err)
	}
	defer csvFile.Close()

	writer := csv.NewWriter(csvFile)
	defer writer.Flush()

	err = writer.WriteAll(data)
	if err != nil {
		log.Fatalf("Error writing new csv file %v: %s", name, err)
	}

	fmt.Printf("Archivo %s ha sido creado con %v filas\n", name, len(data))
}

// Esta función hace las comparaciones necesarias para un solo archivo de ratings haciendo el conteo y comparando con movies.cvs
func Obtaining_Data(directory string, ci chan int, file_name string, raResult chan<- [][]float64, caResult chan<- [][]int, moviesMap map[string][]string) {

	fmt.Printf("Worker empezando a trabajar en el archivo: %s.csv\n", file_name)

	// Leer archivo de ratings
	ratings_file, err := os.Open(directory + file_name + ".csv")
	if err != nil {
		log.Fatalf("Error opening file: %s", err)
	}
	defer ratings_file.Close()
	Reader_ratings := csv.NewReader(ratings_file)
	data_ratings, err := Reader_ratings.ReadAll()
	if err != nil {
		log.Fatalf("Error extracting data from file %v: %s", ratings_file, err)
	}

	// Lista de géneros
	genre_list := []string{"Action", "Adventure", "Animation", "Children", "Comedy", "Crime", "Documentary",
		"Drama", "Fantasy", "Film-Noir", "Horror", "IMAX", "Musical", "Mystery", "Romance",
		"Sci-Fi", "Thriller", "War", "Western", "(no genres listed)"}
	number_genres := len(genre_list)

	// Inicializar ra y ca (listas de conteo para el rating y número de evaluaciones)
	ra := make([][]float64, number_genres)
	ca := make([][]int, number_genres)
	for i := 0; i < number_genres; i++ {
		ra[i] = make([]float64, 1)
		ca[i] = make([]int, 1)
	}

	// Procesar datos de ratings
	// Itera sobre cada fila en data_ratings y obtiene el movieID en la columna [1].
	for i := 0; i < len(data_ratings); i++ {
		movieID := data_ratings[i][1]
		// Busca el movieID en moviesMap (mapa que relaciona cada ID de película con sus géneros).
		if genres, exists := moviesMap[movieID]; exists {
			// Recorre todos los géneros en genre_list.
			for k, genre := range genre_list {
				// Compara cada género de genre_list con los géneros de la película actual movieGenre.
				for _, movieGenre := range genres {
					// Si el género de genre_list coincide con el género de la película, procede a acumular datos.
					if genre == movieGenre {
						//fmt.Println(movieGenre, k)
						// Incrementa el conteo en ca[k][0] cada vez que el género k aparece.
						ca[k][0] += 1
						// Convierte el rating de la película de cadena a float64 y lo acumula en ra[k][0].
						rating, err := strconv.ParseFloat(data_ratings[i][2], 64)
						if err != nil {
							fmt.Println("Error de conversión:", err)
							return
						}
						ra[k][0] += rating
					}
				}
			}
		}
	}

	// Calcular el promedio de los ratings
	for i := 0; i < len(ra); i++ {
		if ca[i][0] > 0 {
			ra[i][0] /= float64(ca[i][0])
		}
	}

	// Enviar resultados a los canales
	raResult <- ra
	caResult <- ca
	ci <- 1
}

func main() {
	start := time.Now()

	// Crea los 10 archivos de ratings
	SplitBigFile("ratings", 10, "/Users/paini/Desktop/DiplomadoAI24-25/ml-25m/")
	ci := make(chan int)

	// Crea canales para resultados
	raResult := make(chan [][]float64, 10)
	caResult := make(chan [][]int, 10)

	// Crea mapa de películas, el crear un mapa implica que se pueden buscar datos sin recorrer todo el archivo
	moviesMap := make(map[string][]string)
	movies_file, err := os.Open("/Users/paini/Desktop/DiplomadoAI24-25/ml-25m/movies.csv")
	if err != nil {
		log.Fatalf("Error opening movies file: %s", err)
	}
	defer movies_file.Close()
	Reader_movies := csv.NewReader(movies_file)
	data_movies, err := Reader_movies.ReadAll()
	if err != nil {
		log.Fatalf("Error reading movies data: %s", err)
	}
	for _, line := range data_movies {
		movieID := line[0]
		genres := strings.Split(line[2], "|")
		moviesMap[movieID] = genres
	}

	// Iniciar 10 workers que ejecuten Obtaining_Data
	nf := 10
	for i := 1; i <= nf; i++ {
		go Obtaining_Data("/Users/paini/Desktop/DiplomadoAI24-25/ml-25m/", ci, "ratings_"+fmt.Sprintf("%02d", i), raResult, caResult, moviesMap)
	}

	// Contador y bucle de espera para goroutines
	iMsg := 0
	go func() {
		for {
			i := <-ci
			iMsg += i
		}
	}()

	// Espera hasta que iMsg sea igual a nf (10)
	for {
		if iMsg == nf {
			break
		}
	}

	// Consolidar resultados
	totalRa := make([]float64, 20)
	totalCa := make([]int, 20)
	for i := 0; i < nf; i++ {
		ra := <-raResult
		ca := <-caResult
		for j := 0; j < len(ra); j++ {
			totalRa[j] += ra[j][0]
			totalCa[j] += ca[j][0]
		}
	}

	// Calcular rating promedio final por género
	for i := 0; i < len(totalRa); i++ {
		if totalCa[i] > 0 {
			totalRa[i] = totalRa[i] / float64(nf)
		}
	}

	// Imprimir resultados finales
	genre_list := []string{"Action", "Adventure", "Animation", "Children", "Comedy", "Crime", "Documentary",
		"Drama", "Fantasy", "Film-Noir", "Horror", "IMAX", "Musical", "Mystery", "Romance",
		"Sci-Fi", "Thriller", "War", "Western", "(no genres listed)"}
	fmt.Println("Rating promedio y conteo por género:")
	for i, genre := range genre_list {
		fmt.Printf("%2d %20s %10d | Rating promedio: %.2f\n", i, genre, totalCa[i], totalRa[i])
	}
	elapsed := time.Since(start) // Calcula el tiempo transcurrido
	fmt.Printf("Tiempo total transcurrido: %s\n", elapsed)
}
