using DataFrames, CSV
using Distributed
using Base.Threads: @threads

archivo = "/Users/paini/Desktop/DiplomadoAI24-25/ml-25m/ratings.csv" 
num_procesos = 10

function contar_lineas(archivo)
    count = 0
    open(archivo, "r") do f
        for _ in eachline(f)
            count += 1
        end
    end
    return count
end

function leer_header(archivo)
    open(archivo, "r") do f
        return readline(f)  # Leer solo la primera línea como encabezado
    end
end

size_of_file = contar_lineas(archivo) - 1  # Excluyendo el encabezado
number_of_chunks = ceil(Int, size_of_file / num_procesos)
header = leer_header(archivo)

function generate_small_file(archivo, i, header, num_procesos, number_of_chunks)
    start_line = (i - 1) * number_of_chunks + 2  # Saltamos el encabezado
    end_line = min(i * number_of_chunks + 1, size_of_file + 1)  # Incluir límites
    output_file = "/Users/paini/Desktop/DiplomadoAI24-25/ml-25m/ratings_$i.csv"
    
    open(archivo, "r") do f
        open(output_file, "w") do out
            println(out, header)  # Escribir el encabezado
            for (line_num, line) in enumerate(eachline(f))
                if line_num >= start_line && line_num <= end_line
                    println(out, line)
                end
            end
        end
    end
end

start_time = time()

@threads for i in 1:num_procesos
    generate_small_file(archivo, i, header, num_procesos, number_of_chunks)
end

end_time = time()

println("Tiempo transcurrido: $(end_time - start_time) segundos")


#Una vez separados los archivos:
movies = DataFrame(CSV.File("/Users/paini/Desktop/DiplomadoAI24-25/ml-25m/movies.csv"))

kg = ["Action", "Adventure", "Animation", "Children", "Comedy", "Crime", "Documentary",
      "Drama", "Fantasy", "Film-Noir", "Horror", "IMAX", "Musical", "Mystery", "Romance",
      "Sci-Fi", "Thriller", "War", "Western", "(no genres listed)"]

ng = length(kg)

# Arrays para almacenar calificaciones y conteos para cada género
ra = zeros(Float64, ng) 
ca = zeros(Int, ng)      

# Función para actualizar los contadores y sumas
function update_genre_stats!(ratings::DataFrame, ca, ra)
    for row in eachrow(ratings)
        genres = split(row.genres, "|")
        rating = row.rating

        for (ig, genre) in enumerate(kg)
            if genre in genres
                ca[ig] += 1              
                ra[ig] += rating         
            end
        end
    end
end


start_time = time()

#Procesamiento de los archivos de ratings
@threads for i in 1:10
    filename = "/Users/paini/Desktop/DiplomadoAI24-25/ml-25m/ratings_$i.csv"
    ratings = DataFrame(CSV.File(filename))

    #Inner join entre películas y calificaciones
    ratings = innerjoin(movies, ratings, on = :movieId)

    select!(ratings, [:genres, :rating])

    #Actualizar contadores y sumas
    lock = Threads.Mutex() 
    lock(lock) do
        update_genre_stats!(ratings, ca, ra) 
    end
end

end_time = time()

#Mostrar los resultados
for ig in 1:ng
    println("$ig    $(kg[ig])   $(ca[ig])")
end

#Promedios
for ig in 1:ng
    if ca[ig] > 0
        avg_rating = ra[ig] / ca[ig]   # Calcular promedio
        println("Promedio de $(kg[ig]): $avg_rating")
    end
end

println("End time: $(end_time - start_time) segundos")

