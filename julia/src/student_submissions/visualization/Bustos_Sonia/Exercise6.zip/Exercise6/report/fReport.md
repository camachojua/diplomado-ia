# Visualización de un Grafo Geométrico Aleatorio

Este código en Julia genera un grafo geométrico aleatorio con un número específico de nodos, conecta los nodos según un radio dado y visualiza el grafo utilizando un esquema de colores basado en la distancia desde un nodo central.

## Carga de Librerías
El código utiliza las siguientes bibliotecas:
- `Graphs`: Para la creación y manipulación de grafos.
- `GraphPlot`: Para la visualización gráfica.
- `Plots`: Generación de gráficos..
- `LinearAlgebra`: Para operaciones matemáticas y cálculo de distancias.
- `Colors`: Para la manipulación de colores en las visualizaciones.

## Función para generar un grafo geométrico aleatorio (`random_geometric_graph`)
```julia
function random_geometric_graph(n, radius)
    pos = [(rand(), rand()) for _ in 1:n]
    G = Graphs.SimpleGraph(n)
    for i in 1:n, j in i+1:n
        if norm(pos[i] .- pos[j]) < radius
            Graphs.add_edge!(G, i, j)
        end
    end
    return G, pos
end
```
1. Genera posiciones aleatorias para `n` nodos en un espacio bidimensional.
2. Crea un grafo simple.
3. Conecta nodos que están dentro del radio especificado.

## Generación del Grafo
```julia
n = 200  # Número de nodos
radius = 0.125  # Radio de conexión
G, pos = random_geometric_graph(n, radius)
```
Se generan $200$ nodos con un radio de conexión de $0.125$.

## Cálculo del Nodo Central
Se determina el nodo más cercano al centro del espacio $(0.5, 0.5)$:
```julia
center = (0.5, 0.5)
dmin = 1.0
ncenter = 0

for i in 1:n
    d = norm(pos[i] .- center)
    if d < dmin
        dmin = d
        ncenter = i
    end
end
```

## Cálculo de Distancias
Se utilizan las distancias desde el nodo central para colorear los nodos:
```julia
distances = Graphs.dijkstra_shortest_paths(G, ncenter).dists
node_colors = map(x -> x == Inf ? 0 : x, distances)
```
Las distancias se normalizan y se convierten en tonalidades de rojo:
```julia
max_dist = maximum(node_colors)
normalized_colors = map(x -> x / max_dist, node_colors)
color_map = cgrad(:gist_heat)
node_colors_tones = [color_map.colors[round(Int, x * (length(color_map.colors) - 1)) + 1] for x in normalized_colors]
```

## Visualización del Grafo
Se crea un gráfico de dispersión que representa los nodos y sus conexiones:
```julia
random_graph = Plots.scatter(
    [p[1] for p in pos], [p[2] for p in pos],
    c=node_colors_tones, ms=5,
    legend=false, markerstrokewidth=0.5,
    axis = false,
    grid = false
)

for edge in Graphs.edges(G)
    i, j = Graphs.src(edge), Graphs.dst(edge)
    Plots.plot!([pos[i][1], pos[j][1]], [pos[i][2], pos[j][2]], lw=0.5, c=:black)
end
```



## Guardado y Visualización
Finalmente, se guarda el gráfico generado en un archivo PNG:
```julia
random_geometric_graph_path = joinpath("..", "fig", "random_geometric_graph.png")
savefig(random_graph, random_geometric_graph_path)

display(random_graph)
```
![random_graph](../fig/random_geometric_graph.png)
`random_graph`