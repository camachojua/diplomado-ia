using Graphs
using GraphPlot
using Plots, LinearAlgebra
using Colors

# Función para generar un grafo geométrico aleatorio
function random_geometric_graph(n, radius)
    # Generar posiciones aleatorias para n nodos
    pos = [(rand(), rand()) for _ in 1:n]
    
    # Crear un grafo simple con n nodos
    G = Graphs.SimpleGraph(n)
    
    # Conectar nodos que están dentro del radio especificado
    for i in 1:n, j in i+1:n
        if norm(pos[i] .- pos[j]) < radius
            Graphs.add_edge!(G, i, j)  # Añadir una arista entre los nodos i y j
        end
    end
    return G, pos  # Retornar el grafo y las posiciones de los nodos
end

# Parámetros para la generación del grafo
n = 200  # Número de nodos
radius = 0.125  # Radio de conexión

# Generar el grafo geométrico aleatorio y obtener las posiciones
G, pos = random_geometric_graph(n, radius)

# G: {200, 848} undirected simple Int64 graph
# pos : 200-element Vector{Tuple{Float64, Float64}}

# Encontrar el nodo más cercano al centro (0.5, 0.5)
center = (0.5, 0.5)  # Coordenadas del centro
dmin = 1.0  # Distancia mínima inicial
ncenter = 0  # Índice del nodo central

# Calcular la distancia de cada nodo al centro
for i in 1:n
    d = norm(pos[i] .- center)  # Calcular la distancia Euclidiana
    if d < dmin  # Si la distancia es menor que la mínima encontrada
        dmin = d  # Actualizar la distancia mínima
        ncenter = i  # Actualizar el índice del nodo central
    end
end

# Calcular las distancias desde el nodo central utilizando el algoritmo de Dijkstra
distances = Graphs.dijkstra_shortest_paths(G, ncenter).dists

# Crear un mapa de colores basado en las distancias
node_colors = map(x -> x == Inf ? 0 : x, distances)  # Asignar 0 a la distancia infinita

# Normalizar las distancias para que estén en el rango [0, 1]
max_dist = maximum(node_colors)  # Obtener la máxima distancia
normalized_colors = map(x -> x / max_dist, node_colors)  # Normalizar las distancias

# Convertir distancias normalizadas a tonalidades de rojo utilizando un gradiente de color
color_map = cgrad(:gist_heat)  
node_colors_tones = [color_map.colors[round(Int, x * (length(color_map.colors) - 1)) + 1] for x in normalized_colors]

# Graficar el grafo con diferentes tonalidades de rojo
random_graph = Plots.scatter(
    [p[1] for p in pos], [p[2] for p in pos],  # Coordenadas x e y de los nodos
    c=node_colors_tones, ms=5,  # Color y tamaño de los marcadores
    legend=false, markerstrokewidth=0.5,  # Sin leyenda y con grosor de borde
    axis = false,  # Quitar los ejes
    grid = false   # Quitar la cuadrícula
)

# Dibujar las aristas del grafo
for edge in Graphs.edges(G)
    i, j = Graphs.src(edge), Graphs.dst(edge)  # Obtener los nodos de origen y destino de la arista
    Plots.plot!([pos[i][1], pos[j][1]], [pos[i][2], pos[j][2]], lw=0.5, c=:black)  # Dibujar la arista
end

# Guardar el gráfico en un archivo PNG
random_geometric_graph_path = joinpath("..", "fig", "random_geometric_graph.png")
savefig(random_graph, random_geometric_graph_path)

# Mostramos gráfica
display(random_graph)