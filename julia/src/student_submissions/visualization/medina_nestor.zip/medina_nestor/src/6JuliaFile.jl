
using Random, Colors, Plots

# Generar el grafo geométrico aleatorio
Random.seed!(1234)  # Para reproducibilidad
n = 150
r = 0.15  # Distancia máxima para conexiones
max_connections = 2  # Mínimo número de conexiones por nodo
margin = 0.05  # Margen para evitar nodos en los bordes
positions = rand(2, n) .* (1 - 2 * margin) .+ margin  # Ajustar posiciones dentro del margen

# Encontrar el nodo más cercano al centro (0.5, 0.5)
center = [0.5, 0.5]
distances = [(positions[1,i] - center[1])^2 + (positions[2,i] - center[2])^2 for i in 1:n]
closest_node = argmin(distances)

# Calcular el gradiente de color basado en la distancia al nodo origen
gradient_colors = [RGBA(1.0 - d / maximum(distances), 0.2, d / maximum(distances), 0.8) for d in distances]

# Crear conexiones respetando la distancia máxima
edges = Dict(i => Set{Int}() for i in 1:n)

for i in 1:n
    neighbors = []
    for j in 1:n
        if i != j && sqrt((positions[1,i] - positions[1,j])^2 + (positions[2,i] - positions[2,j])^2) ≤ r
            push!(neighbors, j)
        end
    end
    # Limitar las conexiones aleatoriamente dentro de los vecinos cercanos
    neighbors = shuffle(neighbors)[1:min(max_connections, length(neighbors))]
    for j in neighbors
        push!(edges[i], j)
        push!(edges[j], i)
    end
end

# Segunda etapa: asegurar al menos `max_connections` por nodo
for i in 1:n
    if length(edges[i]) < max_connections
        # Buscar los nodos más cercanos no conectados
        all_distances = [(j, sqrt((positions[1,i] - positions[1,j])^2 + (positions[2,i] - positions[2,j])^2)) for j in 1:n if j != i && !(j in edges[i])]
        sorted_neighbors = sort(all_distances, by=x->x[2])
        
        # Conectar a los nodos más cercanos adicionales
        for (j, _) in sorted_neighbors[1:max(0, max_connections - length(edges[i]))]
            push!(edges[i], j)
            push!(edges[j], i)
        end
    end
end

# Visualizar el grafo con gradiente de colores y conexiones basadas en la distancia
p = plot(
    legend=false, 
    xlim=(0,1), 
    ylim=(0,1), 
    title="Simulated Neural Network", 
    axis=false,  # Ocultar los ejes
    grid=false   # Ocultar la malla
)

# Agregar las conexiones como líneas
for i in 1:n
    for j in edges[i]
        if i < j  # Evitar duplicar conexiones
            plot!([positions[1,i], positions[1,j]], [positions[2,i], positions[2,j]], lw=0.5, color=:gray, alpha=0.5, legend=false)
        end
    end
end

# Mostrar la gráfica
scatter!(positions[1,:], positions[2,:], color=gradient_colors, markersize=5, legend=false)
savefig("/Users/nmedina/Documents/UNAM/Diplomado_IA/Proyectos/HM_Diciembre/visualization/medina_nestor/fig/random_geometric_graph.png")
display(p)