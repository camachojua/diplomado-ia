# Visualization

## Descripción del Proyecto
En este proyecto, se generó un grafo geométrico aleatorio en Julia y se representó visualmente utilizando nodos y aristas. Los colores de los nodos representan las distancias desde un nodo central seleccionado. Finalmente, la gráfica fue guardada en un archivo dentro del directorio `../fig`.

## Detalles de la Implementación

1. **Generación del Grafo:**
   - Se utilizó un grafo geométrico aleatorio con 100 nodos.
   - Las posiciones de los nodos fueron generadas aleatoriamente en un plano bidimensional.
   - Las aristas se añadieron entre nodos que se encontraban a una distancia menor que `0.2`.

2. **Cálculo de Distancias:**
   - Se calculó la distancia más corta desde un nodo central (nodo 1) a todos los demás nodos utilizando el algoritmo de Dijkstra.

3. **Asignación de Colores:**
   - Los colores de los nodos se normalizaron en función de las distancias calculadas, con una interpolación entre blanco (distancia corta) y rojo (distancia larga).

4. **Visualización:**
   - Se utilizó el paquete **CairoMakie** para generar una gráfica clara y profesional.
   - Los nodos y aristas fueron dibujados de forma proporcional a las posiciones y relaciones calculadas.

5. **Guardado de la Gráfica:**
   - La gráfica fue guardada en el archivo `../fig/random_geometric_graph.png` para su entrega.

## Resultado
La visualización generada representa claramente la estructura del grafo geométrico aleatorio, con colores que indican las distancias relativas desde el nodo central.

## Dependencias
Para ejecutar este proyecto, se deben instalar las siguientes dependencias en Julia:

```julia
using Pkg
Pkg.add("Graphs")
Pkg.add("CairoMakie")
Pkg.add("Colors")
```
