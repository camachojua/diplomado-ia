using Random
using Graphs
using CairoMakie
using Colors

# Crear un grafo geométrico aleatorio
n = 100  # número de nodos
d = 0.2  # distancia máxima para conectar nodos
g = SimpleGraph(n)

# Generar posiciones aleatorias para los nodos
positions = [(rand(), rand()) for _ in 1:n]

# Agregar aristas según la distancia
for i in 1:n
    for j in i+1:n
        if sqrt((positions[i][1] - positions[j][1])^2 + (positions[i][2] - positions[j][2])^2) < d
            add_edge!(g, i, j)
        end
    end
end

# Calcular la distancia desde un nodo central
center = 1
distances = dijkstra_shortest_paths(g, center).dists

# Normalizar distancias para colores
max_dist = maximum(distances)
node_colors = [colorant"red" * (dist / max_dist) + colorant"white" * (1 - dist / max_dist) for dist in distances]

# Crear la figura
f = Figure(resolution = (800, 800))
ax = Axis(f[1, 1], title = "Random Geometric Graph")

# Dibujar nodos
for (i, pos) in enumerate(positions)
    scatter!(ax, [pos[1]], [pos[2]], color=node_colors[i], markersize=8)
end

# Dibujar aristas
for e in edges(g)
    n1, n2 = src(e), dst(e)
    x_coords = [positions[n1][1], positions[n2][1]]
    y_coords = [positions[n1][2], positions[n2][2]]
    lines!(ax, x_coords, y_coords, color=:black, linewidth=0.5)
end

# Guardar la figura
save("../fig/random_geometric_graph.png", f)
