#Autor: Luis Eduardo Sánchez Pérez

using Pkg
Pkg.add(["Graphs", "Plots"])
Pkg.instantiate()
using Graphs
using Plots

#Sección de funciones

# Genera un grafo en 2D de forma aleatoria
function grafoAleatorio2D(n::Int, distancia::Float64)
    # n: Número de nodos
    # distancia: Distancia máxima de conexión entre nodos
	
	#Se obtienen las posiciones de forma aleatoria de todos los n nodos, se guardan en coordenadas 
    coordenadas = Dict(i => (rand(), rand()) for i in 1:n)  
    
	#Se crea un grafo vacío
	g = SimpleGraph(n)  

    # Se evalúan las conexiones entre todos los nodos del grafo.
    for i in 1:n
        for j in i+1:n
			
			#Se obtienen las coordenadas de los nodos que se van a evaluar para ver si cumplen el criterio de distancia
            xi, yi = coordenadas[i]
            xj, yj = coordenadas[j]
			
			#Se calcula la distancia entre los dos nodos
            dist = sqrt((xi - xj)^2 + (yi - yj)^2)
            
			#En caso de que la distancia sea menor que la indicada en la variable distancia, se agrega un vértice.
			if dist ≤ distancia
                add_edge!(g, i, j)
            end
        end
    end
	
	#Se devuelve el grafo y las coordenadas de los nodos
    return g, coordenadas
end


#Código principal:

# Original: 
# G = nx.random_geometric_graph(200, 0.125)
# Esta función crea un grafo de 200 nodos y conecta a los que estén a menos de 0.125 de distancia.
# Esta función no existe explícitamente en Julia, por lo que hay que crearla

# Se define el número de nodos dentro del grafo
nodos = 200 
# Se define la distancia máxima que debe separar a los nodos del grafo.
distancia = 0.125 

#Se genera con el número de nodos y la distancia máxima entre nodos
grafo, coordenadas = grafoAleatorio2D(nodos, distancia)

# Original:
# dmin = 1
# ncenter = 0
# for n in pos:
#    x, y = pos[n]
#    d = (x - 0.5) ** 2 + (y - 0.5) ** 2
#    if d < dmin:
#        ncenter = n
#        dmin = d
# Este código calcula el nodo más cercano al centro (0.5, 0.5)

#Primero se define la menor distancia como 1, luego se irá reemplazando por una más pequeña.
distMin = 1
nodoCentro = 0
for (nodo, (x, y)) in coordenadas
	#Para cada nodo se calcula la distancia
	distanciaAlCentro = (x - 0.5)^2 + (y - 0.5)^2
	if distanciaAlCentro < distMin
		#Si la distancia es menor, se actualiza la distancia más pequeña y se guarda el nodo
		global distMin = distanciaAlCentro
		global nodoCentro = nodo
	end
end

#Original
#p = nx.single_source_shortest_path_length(G, ncenter)
#Esta función calcula la longitud del camino más corto desde el nodoCentro a todos los demás nodos del grafo. El resultado es un diccionario donde las claves son los nodos y los valores son las distancias. Para emular esta función en Julia, se usa el algoritmo de Dijkstra
dijkstra_state = dijkstra_shortest_paths(grafo, nodoCentro)
distancias = Float64.(dijkstra_state.dists)

#Original
# plt.figure(figsize=(8, 8))
# nx.draw_networkx_edges(G, pos, nodelist=[ncenter], alpha=0.4)
# nx.draw_networkx_nodes(
#     G, pos, nodelist=p.keys(), node_size=80, node_color=p.values(),
#     cmap=plt.cm.Reds_r
# )
# plt.xlim(-0.05, 1.05)
# plt.ylim(-0.05, 1.05)
# plt.axis('off')

# Crear el gráfico
# Se obtienen las coordenadas de x
x = [coordenadas[i][1] for i in 1:nv(grafo)]  
#Se obtienen las coordenadas de y 
y = [coordenadas[i][2] for i in 1:nv(grafo)]
# Se definen los colores de los nodos de acuerdo a la distancia al nodo central, se hace la resta para que los nodos más lejanos sean más claros
colores = 1 .- (distancias ./ maximum(distancias))
# Se crea el gráfico
scatter(x, y, marker_z=colores, c=:reds, ms=8, legend=false, grid=false, axis=false)
for edge in edges(grafo)
	i, j = Tuple(edge)
	#Se dibuja cada uno de los vértices del grafo en la imagen
	plot!([coordenadas[i][1], coordenadas[j][1]], [coordenadas[i][2], coordenadas[j][2]], color=:gray, lw=0.5, axis=false)
end

#Se coloca de un color diferente el nodo central para distinguirlo en la imagen
scatter!([coordenadas[nodoCentro][1]], [coordenadas[nodoCentro][2]], color=:red, ms=10, label="", axis=false)

# Original:
# plt.savefig('random_geometric_graph.png')
# Se guarda la imagen generada en el directorio fig, de acuerdo a las guías de las entregas
savefig("../fig/grafosAleatorios.png")









