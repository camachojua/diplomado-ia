using Plots
using Graphs: SimpleGraph, add_edge!, edges, src, dst, dijkstra_shortest_paths
using GraphPlot
using Random
using LinearAlgebra

# Create a random geometric graph
function random_geometric_graph(n::Int, radius::Float64)
    # Generate random positions for nodes
    positions = Dict{Int, Tuple{Float64, Float64}}()
    for i in 1:n
        positions[i] = (rand(), rand())
    end
    
    # Create graph
    g = SimpleGraph(n)
    
    # Add edges based on distance
    for i in 1:n
        for j in (i+1):n
            pos_i = positions[i]
            pos_j = positions[j]
            dist = sqrt((pos_i[1] - pos_j[1])^2 + (pos_i[2] - pos_j[2])^2)
            if dist ≤ radius
                add_edge!(g, i, j)
            end
        end
    end
    
    return g, positions
end

# Find node nearest to center
function find_center_node(positions)
    dmin = 1.0
    ncenter = 1
    for (n, pos) in positions
        x, y = pos
        d = (x - 0.5)^2 + (y - 0.5)^2
        if d < dmin
            ncenter = n
            dmin = d
        end
    end
    return ncenter
end

# Calculate shortest path lengths from center
function path_lengths_from_center(g, center)
    dists = dijkstra_shortest_paths(g, center).dists
    return Dict(i => d for (i, d) in enumerate(dists))
end

# Create the graph
n_nodes = 200
radius = 0.125
g, positions = random_geometric_graph(n_nodes, radius)

# Find center node
center_node = find_center_node(positions)

# Get path lengths
path_lengths = path_lengths_from_center(g, center_node)

# Create plot
p = scatter(
    legend = false,
    xlim = (-0.05, 1.05),
    ylim = (-0.05, 1.05),
    axis = nothing,
    grid = false,
    size = (800, 800)
)

# Draw edges
for e in edges(g)
    s = src(e)
    d = dst(e)
    plot!(
        [positions[s][1], positions[d][1]],
        [positions[s][2], positions[d][2]],
        color = :gray,
        alpha = 0.4
    )
end

# Draw nodes with colors based on path length
max_path = maximum(values(path_lengths))
for (node, length) in path_lengths
    x, y = positions[node]
    color_val = (length / max_path)
    scatter!([x], [y],
        markersize = 8,
        color = RGB(1.0, color_val, color_val),  # Red color scheme
        alpha = 0.8
    )
end

# Save the plot
savefig(p, "fig/random_geometric_graph.png")
