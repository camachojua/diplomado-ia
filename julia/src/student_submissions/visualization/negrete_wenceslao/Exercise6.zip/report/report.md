# Converting Network Visualization from Python to Julia

This report details the process of converting a network visualization program from Python (using networkx and matplotlib) to Julia (using Graphs.jl and Plots.jl).

## Package Equivalents

Python packages and their Julia equivalents used in this conversion:

| Python | Julia | Purpose |
|--------|-------|---------|
| networkx | Graphs.jl | Graph creation and analysis |
| matplotlib | Plots.jl | Visualization |

Additional Julia packages required:
- `GraphPlot`: Additional graph visualization utilities
- `Random`: For random number generation
- `LinearAlgebra`: For mathematical operations

## Graph Creation

### Python (networkx)
```python
G = nx.random_geometric_graph(200, 0.125)
pos = nx.get_node_attributes(G, 'pos')
```

### Julia (Graphs.jl)
```julia
function random_geometric_graph(n::Int, radius::Float64)
    positions = Dict{Int, Tuple{Float64, Float64}}()
    for i in 1:n
        positions[i] = (rand(), rand())
    end
    
    g = SimpleGraph(n)
    
    for i in 1:n
        for j in (i+1):n
            pos_i = positions[i]
            pos_j = positions[j]
            dist = sqrt((pos_i[1] - pos_j[1])^2 + (pos_i[2] - pos_j[2])^2)
            if dist ≤ radius
                add_edge!(g, i, j)
            end
        end
    end
    
    return g, positions
end
```

Key differences:
1. In Python, `networkx` provides a built-in function for random geometric graphs
2. In Julia, we implement the functionality manually:
   - Generate random positions for nodes
   - Create edges based on distance calculations
   - Return both graph and positions separately

## Graph Analysis

### Finding Central Node

Python:
```python
dmin = 1
ncenter = 0
for n in pos:
    x, y = pos[n]
    d = (x-0.5)**2 + (y-0.5)**2
    if d < dmin:
        ncenter = n
        dmin = d
```

Julia:
```julia
function find_center_node(positions)
    dmin = 1.0
    ncenter = 1
    for (n, pos) in positions
        x, y = pos
        d = (x - 0.5)^2 + (y - 0.5)^2
        if d < dmin
            ncenter = n
            dmin = d
        end
    end
    return ncenter
end
```

### Path Length Calculation

Python:
```python
p = nx.single_source_shortest_path_length(G, ncenter)
```

Julia:
```julia
function path_lengths_from_center(g, center)
    dists = dijkstra_shortest_paths(g, center).dists
    return Dict(i => d for (i, d) in enumerate(dists))
end
```

Key differences:
1. Path length calculation uses Dijkstra's algorithm explicitly in Julia
2. Julia returns a dictionary mapping nodes to distances

## Visualization

### Python (matplotlib)
```python
plt.figure(figsize=(8,8))
nx.draw_networkx_edges(G, pos, nodelist=[ncenter], alpha=0.4)
nx.draw_networkx_nodes(G, pos, nodelist=p.keys(), 
                      node_size=80, 
                      node_color=p.values(),
                      cmap=plt.cm.Reds_r)
```

### Julia (Plots.jl)
```julia
p = scatter(
    legend = false,
    xlim = (-0.05, 1.05),
    ylim = (-0.05, 1.05),
    axis = nothing,
    grid = false,
    size = (800, 800)
)

# Draw edges
for e in edges(g)
    s = src(e)
    d = dst(e)
    plot!(
        [positions[s][1], positions[d][1]],
        [positions[s][2], positions[d][2]],
        color = :gray,
        alpha = 0.4
    )
end

# Draw nodes with colors
max_path = maximum(values(path_lengths))
for (node, length) in path_lengths
    x, y = positions[node]
    color_val = (length / max_path)
    scatter!([x], [y],
        markersize = 8,
        color = RGB(1.0, color_val, color_val),
        alpha = 0.8
    )
end
```

Key differences:
1. Julia requires manual edge drawing using `plot!`
2. Node coloring is handled manually in Julia using RGB values
3. Plot customization is more explicit in Julia
