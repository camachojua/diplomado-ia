#using Pkg
#Pkg.add("Cairo")
#Pkg.add("Fontconfig")

using Graphs
using GraphPlot
using Random
using Colors
using Compose
using FileIO
using ImageIO
using Cairo
#using Fontconfig

# Función para generar un grafo geométrico aleatorio
function random_geometric_graph(n_nodes, radius)
    positions = [rand(2) for _ in 1:n_nodes]
    g = Graphs.SimpleGraph(n_nodes)
    for i in 1:n_nodes
        for j in i+1:n_nodes
            dist = sqrt(sum((positions[i] .- positions[j]).^2))
            if dist <= radius
                Graphs.add_edge!(g, i, j)
            end
        end
    end
    return g, positions
end

# Crear un grafo geométrico aleatorio
n_nodes = 200
radius = 0.125
g, positions = random_geometric_graph(n_nodes, radius)

# Encontrar el nodo más cercano al centro (0.5, 0.5)
center = [0.5, 0.5]
dmin, ncenter = Inf, 0
for i in 1:n_nodes
    global dmin, ncenter
    dist = sqrt(sum((positions[i] .- center).^2))
    if dist < dmin
        dmin = dist
        ncenter = i
    end
end

# Calcular las distancias usando Dijkstra
distances = Graphs.dijkstra_shortest_paths(g, ncenter).dists
finite_distances = filter(isfinite, distances)
max_dist = maximum(finite_distances)

# Normalizar distancias e invertir el gradiente
if max_dist == 0
    node_colors = [RGB(1.0, 0.0, 0.0) for _ in distances]
else
    gradient_colors = range(colorant"red", stop=colorant"yellow", length=100)
    normalized_distances = [round(Int, d / max_dist * (length(gradient_colors) - 1)) + 1 for d in distances]
    node_colors = [gradient_colors[idx] for idx in normalized_distances]
end

# Convertir posiciones para gplot
positions_x = [pos[1] for pos in positions]
positions_y = [pos[2] for pos in positions]
node_colors[ncenter] = RGB(0, 0, 1)

# Crear un gráfico con fondo blanco
graph_plot = gplot(
    g,
    positions_x,
    positions_y,
    nodefillc = node_colors,
    edgestrokec = RGB(0, 0, 0),
    nodesize = 2.0
)

# Crear una capa de fondo blanco
width, height = 16cm, 16cm
background = compose(context(), GraphPlot.rectangle(0, 0, width, height), fill("white"))

# Combinar el fondo blanco con el gráfico
final_plot = compose(background, context(), graph_plot)

# Guardar como PNG
png_filename = "./fig/graph_plot.png"
draw(PNG(png_filename, width, height), final_plot)

println("Gráfico guardado como PNG en '$png_filename'")
