# Grafo Geométrico Aleatorio

## Introducción

Este reporte describe la generación y visualización de un grafo geométrico aleatorio utilizando el lenguaje Julia. Los nodos del grafo representan posiciones aleatorias en un plano bidimensional, y las aristas se crean entre nodos que están a una distancia menor o igual a un radio especificado.

El grafo se visualiza con un gradiente de colores que indica la distancia desde un nodo central, resaltado en azul. Este enfoque puede ser útil en el análisis de redes geométricas y en la exploración de propiedades estructurales de grafos espaciales.

---

## Objetivos

1. Generar un grafo geométrico aleatorio.

2. Visualizar el grafo destacando las distancias desde un nodo central.

3. Guardar la visualización en formato PNG.

---

## Metodología

### Librerías Utilizadas

Se usaron las siguientes librerías de Julia:

- Graphs: Para manejar la estructura del grafo y calcular las distancias.

- GraphPlot: Para la visualización del grafo.

- Colors y Compose: Para manejar y aplicar colores.

- Cairo: Para guardar la visualización como imagen PNG.


```julia
using Graphs
using GraphPlot
using Random
using Colors
using Compose
using FileIO
using ImageIO
using Cairo
```

### Generación del Grafo

Se implementó la función **random_geometric_graph(n_nodes, radius)** para crear un grafo geométrico aleatorio:

- Nodos: Posiciones aleatorias en un plano bidimensional.

- Aristas: Se crean entre nodos cuya distancia euclidiana es menor o igual al radio especificado.


```julia
# Función para generar un grafo geométrico aleatorio
function random_geometric_graph(n_nodes, radius)
    positions = [rand(2) for _ in 1:n_nodes]
    g = Graphs.SimpleGraph(n_nodes)
    for i in 1:n_nodes
        for j in i+1:n_nodes
            dist = sqrt(sum((positions[i] .- positions[j]).^2))
            if dist <= radius
                Graphs.add_edge!(g, i, j)
            end
        end
    end
    return g, positions
end
```




    random_geometric_graph (generic function with 1 method)




```julia
# Crear un grafo geométrico aleatorio
n_nodes = 200
radius = 0.125
g, positions = random_geometric_graph(n_nodes, radius)

```




    (SimpleGraph{Int64}(862, [[15, 19], [21, 28, 143], [20, 33, 65, 82, 91, 99, 140, 175, 187, 189, 190], [64, 71, 76, 87, 90, 117, 119, 120, 121, 123, 124, 195, 199], [7, 39, 46, 61, 96, 106, 189, 190], [9, 13, 22, 24, 29, 35, 95, 101, 108, 127, 165, 173, 179, 180, 182], [5, 39, 46, 61, 96, 106, 187, 189, 190], [21, 54, 63, 78, 85, 86, 107], [6, 22, 29, 95, 100, 108, 127, 150, 165, 173, 180, 182], [45, 53, 88, 113, 156, 172]  …  [14, 72, 104, 130], [23, 41, 103, 128, 129, 134, 136, 139, 152, 170, 174, 186], [18, 37, 40, 48, 67, 81, 109, 116, 138, 144, 170, 174], [56, 123, 124, 143, 149, 155, 199], [4, 64, 71, 76, 87, 117, 119, 120, 121, 124], [17, 44, 51, 53, 88, 93, 112, 132, 135, 172], [22, 34, 100, 150, 184, 188], [14, 66, 72, 131, 164], [4, 25, 56, 91, 121, 123, 124, 143, 149, 194], [43, 45, 49, 59, 79, 89, 132, 142, 156, 177, 184]]), [[0.9963277393377219, 0.15251644829569377], [0.6177519920388662, 0.378505460549183], [0.7893472639773778, 0.4825362575324583], [0.5313862013013301, 0.6706859676287701], [0.9756943501309641, 0.5568313404716164], [0.3572948823153391, 0.3131288577852799], [0.9636581232796331, 0.5393901661905944], [0.6542911574505633, 0.21772360251496548], [0.4097030322868752, 0.22664510440536334], [0.05366680559437931, 0.1206257881980658]  …  [0.914692725356127, 0.9294630682518243], [0.07194389694865932, 0.8315933295947223], [0.1445876186514531, 0.6463682218341034], [0.5696796019988728, 0.5151932906347498], [0.5018014052044888, 0.6678025573487135], [0.1247886026160242, 0.2362362729822317], [0.4174520831508707, 0.09630365513110994], [0.7741676550857033, 0.9635528584401811], [0.6056825256149166, 0.5784792831576924], [0.2732544474579345, 0.05805121732920271]])



### Cálculo del Nodo Central

El nodo más cercano al centro del plano  se identificó como el nodo central, utilizando la distancia euclidiana.


```julia
# Encontrar el nodo más cercano al centro (0.5, 0.5)
center = [0.5, 0.5]
dmin, ncenter = Inf, 0
for i in 1:n_nodes
    global dmin, ncenter
    dist = sqrt(sum((positions[i] .- center).^2))
    if dist < dmin
        dmin = dist
        ncenter = i
    end
end
```

### Coloración de Nodos

- Se usó el algoritmo de Dijkstra para calcular las distancias mínimas desde el nodo central a todos los demás nodos.

- Las distancias se normalizaron y se mapearon a un gradiente de colores que va de rojo (cercano) a amarillo (lejano).

- El nodo central se destacó en azul.


```julia
# Calcular las distancias usando Dijkstra
distances = Graphs.dijkstra_shortest_paths(g, ncenter).dists
finite_distances = filter(isfinite, distances)
max_dist = maximum(finite_distances)

# Normalizar distancias e invertir el gradiente
if max_dist == 0
    node_colors = [RGB(1.0, 0.0, 0.0) for _ in distances]
else
    gradient_colors = range(colorant"red", stop=colorant"yellow", length=100)
    normalized_distances = [round(Int, d / max_dist * (length(gradient_colors) - 1)) + 1 for d in distances]
    node_colors = [gradient_colors[idx] for idx in normalized_distances]
end
```




    
![svg](output_11_0.svg)
    




```julia
# Convertir posiciones para gplot
positions_x = [pos[1] for pos in positions]
positions_y = [pos[2] for pos in positions]
node_colors[ncenter] = RGB(0, 0, 1)

```




    
![svg](output_12_0.svg)
    



### Visualización y Guardado

El grafo se visualizó utilizando gplot, combinándolo con un fondo blanco. La imagen final se guardó como un archivo PNG en la carpeta ./fig.


```julia
# Crear un gráfico con fondo blanco
graph_plot = gplot(
    g,
    positions_x,
    positions_y,
    nodefillc = node_colors,
    edgestrokec = RGB(0, 0, 0),
    nodesize = 2.0
)

# Crear una capa de fondo blanco
width, height = 16cm, 16cm
background = compose(context(), GraphPlot.rectangle(0, 0, width, height), fill("white"))

# Combinar el fondo blanco con el gráfico
final_plot = compose(background, context(), graph_plot)

```




<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg"
     xmlns:xlink="http://www.w3.org/1999/xlink"
     version="1.2"
     width="141.42mm" height="100mm" viewBox="0 0 141.42 100"
     stroke="none"
     fill="#000000"
     stroke-width="0.3"
     font-size="3.88"

     id="img-f380a6cc">
<defs>
  <marker id="arrow" markerWidth="15" markerHeight="7" refX="5" refY="3.5" orient="auto" markerUnits="strokeWidth">
    <path d="M0,0 L15,3.5 L0,7 z" stroke="context-stroke" fill="context-stroke"/>
  </marker>
</defs>
<g fill="#FFFFFF" id="img-f380a6cc-1">
  <g transform="translate(80,80)">
    <path d="M-80,-80 L80,-80 80,80 -80,80  z" class="primitive"/>
  </g>
  <g stroke-width="0.21" fill="#000000" fill-opacity="0.000" stroke="#000000" id="img-f380a6cc-2">
    <g transform="translate(128.67,21.55)">
      <path fill="none" d="M0.29,-0.24 L-0.29,0.24 " class="primitive"/>
    </g>
    <g transform="translate(128.3,25.17)">
      <path fill="none" d="M1.12,-3.7 L-1.12,3.7 " class="primitive"/>
    </g>
    <g transform="translate(85.34,37.72)">
      <path fill="none" d="M-0.32,1.23 L0.32,-1.23 " class="primitive"/>
    </g>
    <g transform="translate(81.81,36.73)">
      <path fill="none" d="M2.42,2.36 L-2.42,-2.36 " class="primitive"/>
    </g>
    <g transform="translate(84.29,44.22)">
      <path fill="none" d="M0.46,-3.81 L-0.46,3.81 " class="primitive"/>
    </g>
    <g transform="translate(109.06,46.8)">
      <path fill="none" d="M-3.02,1.23 L3.02,-1.23 " class="primitive"/>
    </g>
    <g transform="translate(104.04,53.54)">
      <path fill="none" d="M0.94,-4.42 L-0.94,4.42 " class="primitive"/>
    </g>
    <g transform="translate(103,46.91)">
      <path fill="none" d="M1.4,0.97 L-1.4,-0.97 " class="primitive"/>
    </g>
    <g transform="translate(110.43,45.59)">
      <path fill="none" d="M-4.45,2.36 L4.45,-2.36 " class="primitive"/>
    </g>
    <g transform="translate(100.01,52.07)">
      <path fill="none" d="M4.4,-3.14 L-4.4,3.14 " class="primitive"/>
    </g>
    <g transform="translate(104.96,52.92)">
      <path fill="none" d="M0.15,-3.79 L-0.15,3.79 " class="primitive"/>
    </g>
    <g transform="translate(107.85,51.44)">
      <path fill="none" d="M-2.16,-2.42 L2.16,2.42 " class="primitive"/>
    </g>
    <g transform="translate(99.67,48.79)">
      <path fill="none" d="M4.44,-0.32 L-4.44,0.32 " class="primitive"/>
    </g>
    <g transform="translate(108.55,49.91)">
      <path fill="none" d="M-2.53,-1.12 L2.53,1.12 " class="primitive"/>
    </g>
    <g transform="translate(109.03,50.83)">
      <path fill="none" d="M-3.11,-1.94 L3.11,1.94 " class="primitive"/>
    </g>
    <g transform="translate(111.31,51.23)">
      <path fill="none" d="M-5.29,-2.43 L5.29,2.43 " class="primitive"/>
    </g>
    <g transform="translate(70.34,67.55)">
      <path fill="none" d="M3.58,-2.84 L-3.58,2.84 " class="primitive"/>
    </g>
    <g transform="translate(69.09,66.5)">
      <path fill="none" d="M4.63,-1.96 L-4.63,1.96 " class="primitive"/>
    </g>
    <g transform="translate(68.91,60.88)">
      <path fill="none" d="M4.9,2.82 L-4.9,-2.82 " class="primitive"/>
    </g>
    <g transform="translate(70.47,68.24)">
      <path fill="none" d="M3.53,-3.48 L-3.53,3.48 " class="primitive"/>
    </g>
    <g transform="translate(79.95,67.77)">
      <path fill="none" d="M-4.58,-3.1 L4.58,3.1 " class="primitive"/>
    </g>
    <g transform="translate(67.99,62.44)">
      <path fill="none" d="M5.65,1.46 L-5.65,-1.46 " class="primitive"/>
    </g>
    <g transform="translate(69.79,66.43)">
      <path fill="none" d="M3.96,-1.86 L-3.96,1.86 " class="primitive"/>
    </g>
    <g transform="translate(74.18,65.05)">
      <path fill="none" d="M0.1,-0.2 L-0.1,0.2 " class="primitive"/>
    </g>
    <g transform="translate(79.36,62.9)">
      <path fill="none" d="M-3.77,1 L3.77,-1 " class="primitive"/>
    </g>
    <g transform="translate(78.28,60.42)">
      <path fill="none" d="M-3.07,3.13 L3.07,-3.13 " class="primitive"/>
    </g>
    <g transform="translate(73.96,59.59)">
      <path fill="none" d="M0.55,3.83 L-0.55,-3.83 " class="primitive"/>
    </g>
    <g transform="translate(72.86,64.04)">
      <path fill="none" d="M0.71,0.05 L-0.71,-0.05 " class="primitive"/>
    </g>
    <g transform="translate(79.01,60.3)">
      <path fill="none" d="M-3.74,3.29 L3.74,-3.29 " class="primitive"/>
    </g>
    <g transform="translate(126.48,53.89)">
      <path fill="none" d="M0.12,0.12 L-0.12,-0.12 " class="primitive"/>
    </g>
    <g transform="translate(127.19,56.21)">
      <path fill="none" d="M-0,-0.86 L0,0.86 " class="primitive"/>
    </g>
    <g transform="translate(128.25,51.48)">
      <path fill="none" d="M-0.81,2.43 L0.81,-2.43 " class="primitive"/>
    </g>
    <g transform="translate(124.22,52.91)">
      <path fill="none" d="M2.17,1.24 L-2.17,-1.24 " class="primitive"/>
    </g>
    <g transform="translate(124.37,53.3)">
      <path fill="none" d="M1.95,0.92 L-1.95,-0.92 " class="primitive"/>
    </g>
    <g transform="translate(124.84,54.23)">
      <path fill="none" d="M1.34,0.22 L-1.34,-0.22 " class="primitive"/>
    </g>
    <g transform="translate(120.05,53.94)">
      <path fill="none" d="M6.11,0.58 L-6.11,-0.58 " class="primitive"/>
    </g>
    <g transform="translate(122.33,54.34)">
      <path fill="none" d="M3.82,0.22 L-3.82,-0.22 " class="primitive"/>
    </g>
    <g transform="translate(57.11,30.58)">
      <path fill="none" d="M-2.56,2.99 L2.56,-2.99 " class="primitive"/>
    </g>
    <g transform="translate(58.3,35.79)">
      <path fill="none" d="M-3.36,-1.24 L3.36,1.24 " class="primitive"/>
    </g>
    <g transform="translate(55.86,29.78)">
      <path fill="none" d="M-1.56,3.72 L1.56,-3.72 " class="primitive"/>
    </g>
    <g transform="translate(53.4,35.46)">
      <path fill="none" d="M0.27,-0.56 L-0.27,0.56 " class="primitive"/>
    </g>
    <g transform="translate(60.83,34.06)">
      <path fill="none" d="M-5.77,0.12 L5.77,-0.12 " class="primitive"/>
    </g>
    <g transform="translate(48.76,34.64)">
      <path fill="none" d="M4.22,-0.35 L-4.22,0.35 " class="primitive"/>
    </g>
    <g transform="translate(58.26,34.47)">
      <path fill="none" d="M-3.21,-0.2 L3.21,0.2 " class="primitive"/>
    </g>
    <g transform="translate(57.74,36.28)">
      <path fill="none" d="M-2.91,-1.62 L2.91,1.62 " class="primitive"/>
    </g>
    <g transform="translate(57.76,32.9)">
      <path fill="none" d="M-2.81,0.98 L2.81,-0.98 " class="primitive"/>
    </g>
    <g transform="translate(55.27,33.6)">
      <path fill="none" d="M-0.4,0.19 L0.4,-0.19 " class="primitive"/>
    </g>
    <g transform="translate(52.33,32.85)">
      <path fill="none" d="M1,0.8 L-1,-0.8 " class="primitive"/>
    </g>
    <g transform="translate(51.4,32.2)">
      <path fill="none" d="M1.9,1.46 L-1.9,-1.46 " class="primitive"/>
    </g>
    <g transform="translate(57.95,37.94)">
      <path fill="none" d="M-3.31,-3.14 L3.31,3.14 " class="primitive"/>
    </g>
    <g transform="translate(49.83,31.17)">
      <path fill="none" d="M3.46,2.51 L-3.46,-2.51 " class="primitive"/>
    </g>
    <g transform="translate(55.47,31.24)">
      <path fill="none" d="M-1.12,2.27 L1.12,-2.27 " class="primitive"/>
    </g>
    <g transform="translate(126.48,55.48)">
      <path fill="none" d="M-0.49,-1.6 L0.49,1.6 " class="primitive"/>
    </g>
    <g transform="translate(127.54,50.75)">
      <path fill="none" d="M-1.29,1.76 L1.29,-1.76 " class="primitive"/>
    </g>
    <g transform="translate(123.5,52.18)">
      <path fill="none" d="M1.38,0.59 L-1.38,-0.59 " class="primitive"/>
    </g>
    <g transform="translate(123.66,52.57)">
      <path fill="none" d="M1.14,0.32 L-1.14,-0.32 " class="primitive"/>
    </g>
    <g transform="translate(124.13,53.5)">
      <path fill="none" d="M0.64,-0.13 L-0.64,0.13 " class="primitive"/>
    </g>
    <g transform="translate(118.87,52.29)">
      <path fill="none" d="M5.88,0.74 L-5.88,-0.74 " class="primitive"/>
    </g>
    <g transform="translate(119.34,53.21)">
      <path fill="none" d="M5.39,-0.04 L-5.39,0.04 " class="primitive"/>
    </g>
    <g transform="translate(121.62,53.61)">
      <path fill="none" d="M3.12,-0.34 L-3.12,0.34 " class="primitive"/>
    </g>
    <g transform="translate(87.5,30.99)">
      <path fill="none" d="M1.41,-4.06 L-1.41,4.06 " class="primitive"/>
    </g>
    <g transform="translate(88.21,22.6)">
      <path fill="none" d="M0.76,2.89 L-0.76,-2.89 " class="primitive"/>
    </g>
    <g transform="translate(92.28,24.62)">
      <path fill="none" d="M-2.28,1.16 L2.28,-1.16 " class="primitive"/>
    </g>
    <g transform="translate(92.23,22.5)">
      <path fill="none" d="M-2.55,3.08 L2.55,-3.08 " class="primitive"/>
    </g>
    <g transform="translate(90.64,23.68)">
      <path fill="none" d="M-1.09,1.86 L1.09,-1.86 " class="primitive"/>
    </g>
    <g transform="translate(94.65,25.24)">
      <path fill="none" d="M-4.48,0.79 L4.48,-0.79 " class="primitive"/>
    </g>
    <g transform="translate(96.17,24.76)">
      <path fill="none" d="M-6.01,1.24 L6.01,-1.24 " class="primitive"/>
    </g>
    <g transform="translate(58.96,26.15)">
      <path fill="none" d="M0.48,0.31 L-0.48,-0.31 " class="primitive"/>
    </g>
    <g transform="translate(63.93,30.44)">
      <path fill="none" d="M-3.09,-2.89 L3.09,2.89 " class="primitive"/>
    </g>
    <g transform="translate(61.36,30.85)">
      <path fill="none" d="M-0.93,-3.16 L0.93,3.16 " class="primitive"/>
    </g>
    <g transform="translate(63.57,23.17)">
      <path fill="none" d="M-2.8,3.16 L2.8,-3.16 " class="primitive"/>
    </g>
    <g transform="translate(60.86,29.28)">
      <path fill="none" d="M-0.44,-1.6 L0.44,1.6 " class="primitive"/>
    </g>
    <g transform="translate(58.37,29.98)">
      <path fill="none" d="M1.43,-2.34 L-1.43,2.34 " class="primitive"/>
    </g>
    <g transform="translate(61.6,24.92)">
      <path fill="none" d="M-0.94,1.38 L0.94,-1.38 " class="primitive"/>
    </g>
    <g transform="translate(55.43,29.23)">
      <path fill="none" d="M3.92,-1.86 L-3.92,1.86 " class="primitive"/>
    </g>
    <g transform="translate(54.51,28.58)">
      <path fill="none" d="M4.74,-1.34 L-4.74,1.34 " class="primitive"/>
    </g>
    <g transform="translate(52.93,27.55)">
      <path fill="none" d="M6.25,-0.5 L-6.25,0.5 " class="primitive"/>
    </g>
    <g transform="translate(58.57,27.62)">
      <path fill="none" d="M0.74,-0.3 L-0.74,0.3 " class="primitive"/>
    </g>
    <g transform="translate(25.08,17.74)">
      <path fill="none" d="M-5.96,0.29 L5.96,-0.29 " class="primitive"/>
    </g>
    <g transform="translate(19.21,18.58)">
      <path fill="none" d="M-0.25,-0.11 L0.25,0.11 " class="primitive"/>
    </g>
    <g transform="translate(15.38,21.15)">
      <path fill="none" d="M2.15,-2.45 L-2.15,2.45 " class="primitive"/>
    </g>
    <g transform="translate(20.97,14.94)">
      <path fill="none" d="M-2.32,2.52 L2.32,-2.52 " class="primitive"/>
    </g>
    <g transform="translate(23.91,15.79)">
      <path fill="none" d="M-4.92,1.93 L4.92,-1.93 " class="primitive"/>
    </g>
    <g transform="translate(17.62,22.07)">
      <path fill="none" d="M0.38,-3.26 L-0.38,3.26 " class="primitive"/>
    </g>
    <g transform="translate(45.53,69.8)">
      <path fill="none" d="M0.58,-2.36 L-0.58,2.36 " class="primitive"/>
    </g>
    <g transform="translate(39.54,67.03)">
      <path fill="none" d="M5.71,-0.26 L-5.71,0.26 " class="primitive"/>
    </g>
    <g transform="translate(47.32,68.99)">
      <path fill="none" d="M-0.71,-1.57 L0.71,1.57 " class="primitive"/>
    </g>
    <g transform="translate(48.71,64.72)">
      <path fill="none" d="M-1.75,1.44 L1.75,-1.44 " class="primitive"/>
    </g>
    <g transform="translate(39.7,68.76)">
      <path fill="none" d="M5.64,-1.75 L-5.64,1.75 " class="primitive"/>
    </g>
    <g transform="translate(51.51,68.26)">
      <path fill="none" d="M-4.26,-1.26 L4.26,1.26 " class="primitive"/>
    </g>
    <g transform="translate(40.06,65.36)">
      <path fill="none" d="M5.23,1.14 L-5.23,-1.14 " class="primitive"/>
    </g>
    <g transform="translate(48.54,64.19)">
      <path fill="none" d="M-1.7,1.9 L1.7,-1.9 " class="primitive"/>
    </g>
    <g transform="translate(45.41,65.17)">
      <path fill="none" d="M0.49,0.86 L-0.49,-0.86 " class="primitive"/>
    </g>
    <g transform="translate(46.56,63.47)">
      <path fill="none" d="M-0.21,2.51 L0.21,-2.51 " class="primitive"/>
    </g>
    <g transform="translate(124.28,34.2)">
      <path fill="none" d="M-2.29,3.94 L2.29,-3.94 " class="primitive"/>
    </g>
    <g transform="translate(117.29,42.01)">
      <path fill="none" d="M3.59,-2.65 L-3.59,2.65 " class="primitive"/>
    </g>
    <g transform="translate(120.51,39.58)">
      <path fill="none" d="M0.34,-0.24 L-0.34,0.24 " class="primitive"/>
    </g>
    <g transform="translate(123.26,37.36)">
      <path fill="none" d="M-1.01,0.89 L1.01,-0.89 " class="primitive"/>
    </g>
    <g transform="translate(118.65,40.8)">
      <path fill="none" d="M2.19,-1.47 L-2.19,1.47 " class="primitive"/>
    </g>
    <g transform="translate(121.1,34.32)">
      <path fill="none" d="M0.41,3.76 L-0.41,-3.76 " class="primitive"/>
    </g>
    <g transform="translate(120.93,34.09)">
      <path fill="none" d="M0.57,3.99 L-0.57,-3.99 " class="primitive"/>
    </g>
    <g transform="translate(125.03,37.34)">
      <path fill="none" d="M-2.54,1.09 L2.54,-1.09 " class="primitive"/>
    </g>
    <g transform="translate(116.45,36.02)">
      <path fill="none" d="M4.32,2.35 L-4.32,-2.35 " class="primitive"/>
    </g>
    <g transform="translate(57.69,37.04)">
      <path fill="none" d="M3.87,0.26 L-3.87,-0.26 " class="primitive"/>
    </g>
    <g transform="translate(65.12,35.64)">
      <path fill="none" d="M-1.78,1.22 L1.78,-1.22 " class="primitive"/>
    </g>
    <g transform="translate(62.55,36.05)">
      <path fill="none" d="M0.02,0.58 L-0.02,-0.58 " class="primitive"/>
    </g>
    <g transform="translate(62.03,37.86)">
      <path fill="none" d="M-0.09,0.08 L0.09,-0.08 " class="primitive"/>
    </g>
    <g transform="translate(62.05,34.48)">
      <path fill="none" d="M0.4,2.15 L-0.4,-2.15 " class="primitive"/>
    </g>
    <g transform="translate(59.56,35.18)">
      <path fill="none" d="M2.3,1.66 L-2.3,-1.66 " class="primitive"/>
    </g>
    <g transform="translate(63.14,41.66)">
      <path fill="none" d="M-0.46,-3.56 L0.46,3.56 " class="primitive"/>
    </g>
    <g transform="translate(56.61,34.43)">
      <path fill="none" d="M5.12,2.51 L-5.12,-2.51 " class="primitive"/>
    </g>
    <g transform="translate(62.24,39.52)">
      <path fill="none" d="M0.23,-1.42 L-0.23,1.42 " class="primitive"/>
    </g>
    <g transform="translate(59.76,32.82)">
      <path fill="none" d="M2.41,3.87 L-2.41,-3.87 " class="primitive"/>
    </g>
    <g transform="translate(105.39,77.84)">
      <path fill="none" d="M1.02,3.49 L-1.02,-3.49 " class="primitive"/>
    </g>
    <g transform="translate(103.91,77.77)">
      <path fill="none" d="M2.28,3.61 L-2.28,-3.61 " class="primitive"/>
    </g>
    <g transform="translate(103.91,85.06)">
      <path fill="none" d="M2.15,-2.39 L-2.15,2.39 " class="primitive"/>
    </g>
    <g transform="translate(101.92,79.74)">
      <path fill="none" d="M3.84,1.89 L-3.84,-1.89 " class="primitive"/>
    </g>
    <g transform="translate(108.33,79.18)">
      <path fill="none" d="M-1.3,2.2 L1.3,-2.2 " class="primitive"/>
    </g>
    <g transform="translate(102.2,84.83)">
      <path fill="none" d="M3.64,-2.29 L-3.64,2.29 " class="primitive"/>
    </g>
    <g transform="translate(113.3,83.94)">
      <path fill="none" d="M-5.71,-1.62 L5.71,1.62 " class="primitive"/>
    </g>
    <g transform="translate(104.98,85.37)">
      <path fill="none" d="M1.29,-2.62 L-1.29,2.62 " class="primitive"/>
    </g>
    <g transform="translate(127.33,25.97)">
      <path fill="none" d="M0.29,-2.88 L-0.29,2.88 " class="primitive"/>
    </g>
    <g transform="translate(122.25,24.56)">
      <path fill="none" d="M4.55,-1.84 L-4.55,1.84 " class="primitive"/>
    </g>
    <g transform="translate(121.52,24.53)">
      <path fill="none" d="M5.24,-1.85 L-5.24,1.85 " class="primitive"/>
    </g>
    <g transform="translate(124.15,26.09)">
      <path fill="none" d="M2.97,-3.12 L-2.97,3.12 " class="primitive"/>
    </g>
    <g transform="translate(123.98,25.86)">
      <path fill="none" d="M3.09,-2.92 L-3.09,2.92 " class="primitive"/>
    </g>
    <g transform="translate(75.95,12.47)">
      <path fill="none" d="M-0.58,-1.68 L0.58,1.68 " class="primitive"/>
    </g>
    <g transform="translate(74.4,11.9)">
      <path fill="none" d="M0.44,-1.12 L-0.44,1.12 " class="primitive"/>
    </g>
    <g transform="translate(77.7,12.32)">
      <path fill="none" d="M-1.92,-1.68 L1.92,1.68 " class="primitive"/>
    </g>
    <g transform="translate(70.88,11.24)">
      <path fill="none" d="M3.27,-0.91 L-3.27,0.91 " class="primitive"/>
    </g>
    <g transform="translate(32.54,30.02)">
      <path fill="none" d="M-3.4,0.16 L3.4,-0.16 " class="primitive"/>
    </g>
    <g transform="translate(30.44,32.21)">
      <path fill="none" d="M-1.67,-1.41 L1.67,1.41 " class="primitive"/>
    </g>
    <g transform="translate(21.66,32.45)">
      <path fill="none" d="M5.5,-1.9 L-5.5,1.9 " class="primitive"/>
    </g>
    <g transform="translate(30.74,34.88)">
      <path fill="none" d="M-2.25,-3.97 L2.25,3.97 " class="primitive"/>
    </g>
    <g transform="translate(27.82,32.55)">
      <path fill="none" d="M0.19,-1.58 L-0.19,1.58 " class="primitive"/>
    </g>
    <g transform="translate(26.84,31.25)">
      <path fill="none" d="M0.57,-0.46 L-0.57,0.46 " class="primitive"/>
    </g>
    <g transform="translate(30.27,34.47)">
      <path fill="none" d="M-1.82,-3.55 L1.82,3.55 " class="primitive"/>
    </g>
    <g transform="translate(31.66,28.54)">
      <path fill="none" d="M-2.7,1.28 L2.7,-1.28 " class="primitive"/>
    </g>
    <g transform="translate(22.63,28.14)">
      <path fill="none" d="M4.55,1.73 L-4.55,-1.73 " class="primitive"/>
    </g>
    <g transform="translate(27.3,29)">
      <path fill="none" d="M0.37,0.56 L-0.37,-0.56 " class="primitive"/>
    </g>
    <g transform="translate(23.92,54.42)">
      <path fill="none" d="M1.54,-0.32 L-1.54,0.32 " class="primitive"/>
    </g>
    <g transform="translate(27.82,49.72)">
      <path fill="none" d="M-1.12,3.45 L1.12,-3.45 " class="primitive"/>
    </g>
    <g transform="translate(19.82,53.84)">
      <path fill="none" d="M5.6,0.05 L-5.6,-0.05 " class="primitive"/>
    </g>
    <g transform="translate(28.57,57.02)">
      <path fill="none" d="M-1.66,-2.47 L1.66,2.47 " class="primitive"/>
    </g>
    <g transform="translate(28.2,52.75)">
      <path fill="none" d="M-0.98,0.64 L0.98,-0.64 " class="primitive"/>
    </g>
    <g transform="translate(28.22,58.08)">
      <path fill="none" d="M-1.46,-3.48 L1.46,3.48 " class="primitive"/>
    </g>
    <g transform="translate(28.16,55.72)">
      <path fill="none" d="M-1.13,-1.21 L1.13,1.21 " class="primitive"/>
    </g>
    <g transform="translate(20.65,55.03)">
      <path fill="none" d="M4.81,-0.94 L-4.81,0.94 " class="primitive"/>
    </g>
    <g transform="translate(29.67,52.29)">
      <path fill="none" d="M-2.36,1.17 L2.36,-1.17 " class="primitive"/>
    </g>
    <g transform="translate(27.65,58.01)">
      <path fill="none" d="M-0.98,-3.39 L0.98,3.39 " class="primitive"/>
    </g>
    <g transform="translate(121.88,28.17)">
      <path fill="none" d="M4.11,1.14 L-4.11,-1.14 " class="primitive"/>
    </g>
    <g transform="translate(125.94,32.74)">
      <path fill="none" d="M0.79,-2.43 L-0.79,2.43 " class="primitive"/>
    </g>
    <g transform="translate(121.15,28.14)">
      <path fill="none" d="M4.82,1.2 L-4.82,-1.2 " class="primitive"/>
    </g>
    <g transform="translate(123.78,29.71)">
      <path fill="none" d="M2.14,-0.08 L-2.14,0.08 " class="primitive"/>
    </g>
    <g transform="translate(123.61,29.48)">
      <path fill="none" d="M2.31,0.07 L-2.31,-0.07 " class="primitive"/>
    </g>
    <g transform="translate(127.71,32.73)">
      <path fill="none" d="M-0.57,-2.41 L0.57,2.41 " class="primitive"/>
    </g>
    <g transform="translate(116.21,42.77)">
      <path fill="none" d="M-2.51,1.89 L2.51,-1.89 " class="primitive"/>
    </g>
    <g transform="translate(117.11,48.2)">
      <path fill="none" d="M-3.4,-2.48 L3.4,2.48 " class="primitive"/>
    </g>
    <g transform="translate(106.92,45.31)">
      <path fill="none" d="M5.02,-0.1 L-5.02,0.1 " class="primitive"/>
    </g>
    <g transform="translate(114.35,43.99)">
      <path fill="none" d="M-0.71,0.63 L0.71,-0.63 " class="primitive"/>
    </g>
    <g transform="translate(117.27,48.59)">
      <path fill="none" d="M-3.59,-2.84 L3.59,2.84 " class="primitive"/>
    </g>
    <g transform="translate(111.77,49.84)">
      <path fill="none" d="M1.02,-3.92 L-1.02,3.92 " class="primitive"/>
    </g>
    <g transform="translate(112.48,48.31)">
      <path fill="none" d="M0.39,-2.38 L-0.39,2.38 " class="primitive"/>
    </g>
    <g transform="translate(112.95,49.23)">
      <path fill="none" d="M0.03,-3.29 L-0.03,3.29 " class="primitive"/>
    </g>
    <g transform="translate(115.23,49.63)">
      <path fill="none" d="M-1.89,-3.74 L1.89,3.74 " class="primitive"/>
    </g>
    <g transform="translate(82.31,34.77)">
      <path fill="none" d="M2.56,0.72 L-2.56,-0.72 " class="primitive"/>
    </g>
    <g transform="translate(50.6,24.18)">
      <path fill="none" d="M6.1,1 L-6.1,-1 " class="primitive"/>
    </g>
    <g transform="translate(60.11,30.04)">
      <path fill="none" d="M-2.04,-4 L2.04,4 " class="primitive"/>
    </g>
    <g transform="translate(62.32,22.37)">
      <path fill="none" d="M-3.84,2.48 L3.84,-2.48 " class="primitive"/>
    </g>
    <g transform="translate(59.61,28.47)">
      <path fill="none" d="M-1.49,-2.45 L1.49,2.45 " class="primitive"/>
    </g>
    <g transform="translate(57.12,29.17)">
      <path fill="none" d="M0.48,-3.09 L-0.48,3.09 " class="primitive"/>
    </g>
    <g transform="translate(60.35,24.11)">
      <path fill="none" d="M-1.77,0.83 L1.77,-0.83 " class="primitive"/>
    </g>
    <g transform="translate(54.18,28.42)">
      <path fill="none" d="M2.88,-2.51 L-2.88,2.51 " class="primitive"/>
    </g>
    <g transform="translate(53.25,27.77)">
      <path fill="none" d="M3.63,-1.98 L-3.63,1.98 " class="primitive"/>
    </g>
    <g transform="translate(51.68,26.74)">
      <path fill="none" d="M5.05,-1.17 L-5.05,1.17 " class="primitive"/>
    </g>
    <g transform="translate(57.32,26.81)">
      <path fill="none" d="M0.2,-0.74 L-0.2,0.74 " class="primitive"/>
    </g>
    <g transform="translate(59.42,20.69)">
      <path fill="none" d="M-1.45,3.94 L1.45,-3.94 " class="primitive"/>
    </g>
    <g transform="translate(32.11,86.3)">
      <path fill="none" d="M-3.17,-0.74 L3.17,0.74 " class="primitive"/>
    </g>
    <g transform="translate(23.84,81.07)">
      <path fill="none" d="M3.52,3.65 L-3.52,-3.65 " class="primitive"/>
    </g>
    <g transform="translate(28.58,84.61)">
      <path fill="none" d="M-0.08,0.1 L0.08,-0.1 " class="primitive"/>
    </g>
    <g transform="translate(22.93,86.65)">
      <path fill="none" d="M4.04,-1.06 L-4.04,1.06 " class="primitive"/>
    </g>
    <g transform="translate(30.28,82.91)">
      <path fill="none" d="M-1.74,1.81 L1.74,-1.81 " class="primitive"/>
    </g>
    <g transform="translate(22.73,88.46)">
      <path fill="none" d="M4.42,-2.65 L-4.42,2.65 " class="primitive"/>
    </g>
    <g transform="translate(30.32,83.23)">
      <path fill="none" d="M-1.72,1.52 L1.72,-1.52 " class="primitive"/>
    </g>
    <g transform="translate(24.1,81.48)">
      <path fill="none" d="M3.25,3.24 L-3.25,-3.24 " class="primitive"/>
    </g>
    <g transform="translate(48.15,35.89)">
      <path fill="none" d="M3.63,0.64 L-3.63,-0.64 " class="primitive"/>
    </g>
    <g transform="translate(57.65,35.72)">
      <path fill="none" d="M-3.86,0.79 L3.86,-0.79 " class="primitive"/>
    </g>
    <g transform="translate(57.13,37.53)">
      <path fill="none" d="M-3.34,-0.63 L3.34,0.63 " class="primitive"/>
    </g>
    <g transform="translate(57.14,34.16)">
      <path fill="none" d="M-3.56,2.08 L3.56,-2.08 " class="primitive"/>
    </g>
    <g transform="translate(54.66,34.85)">
      <path fill="none" d="M-1.27,1.26 L1.27,-1.26 " class="primitive"/>
    </g>
    <g transform="translate(51.71,34.11)">
      <path fill="none" d="M0.78,1.9 L-0.78,-1.9 " class="primitive"/>
    </g>
    <g transform="translate(50.79,33.45)">
      <path fill="none" d="M1.58,2.58 L-1.58,-2.58 " class="primitive"/>
    </g>
    <g transform="translate(57.33,39.19)">
      <path fill="none" d="M-3.73,-2.03 L3.73,2.03 " class="primitive"/>
    </g>
    <g transform="translate(49.21,32.42)">
      <path fill="none" d="M3.04,3.65 L-3.04,-3.65 " class="primitive"/>
    </g>
    <g transform="translate(54.86,32.5)">
      <path fill="none" d="M-1.73,3.52 L1.73,-3.52 " class="primitive"/>
    </g>
    <g transform="translate(98.19,60.28)">
      <path fill="none" d="M-3.81,1.27 L3.81,-1.27 " class="primitive"/>
    </g>
    <g transform="translate(90,58.54)">
      <path fill="none" d="M2.82,2.73 L-2.82,-2.73 " class="primitive"/>
    </g>
    <g transform="translate(94.15,58.8)">
      <path fill="none" d="M-0.55,2.34 L0.55,-2.34 " class="primitive"/>
    </g>
    <g transform="translate(99.11,59.66)">
      <path fill="none" d="M-4.76,1.85 L4.76,-1.85 " class="primitive"/>
    </g>
    <g transform="translate(88.77,61.75)">
      <path fill="none" d="M3.63,0.08 L-3.63,-0.08 " class="primitive"/>
    </g>
    <g transform="translate(87.69,59.27)">
      <path fill="none" d="M4.87,2.19 L-4.87,-2.19 " class="primitive"/>
    </g>
    <g transform="translate(88.42,59.15)">
      <path fill="none" d="M4.19,2.27 L-4.19,-2.27 " class="primitive"/>
    </g>
    <g transform="translate(78.22,89.97)">
      <path fill="none" d="M1.4,0.41 L-1.4,-0.41 " class="primitive"/>
    </g>
    <g transform="translate(87.75,90.27)">
      <path fill="none" d="M-6.13,0.33 L6.13,-0.33 " class="primitive"/>
    </g>
    <g transform="translate(75.87,91.17)">
      <path fill="none" d="M3.68,-0.39 L-3.68,0.39 " class="primitive"/>
    </g>
    <g transform="translate(78.72,79.08)">
      <path fill="none" d="M5.4,-1.37 L-5.4,1.37 " class="primitive"/>
    </g>
    <g transform="translate(84.34,78.43)">
      <path fill="none" d="M0.25,-0.32 L-0.25,0.32 " class="primitive"/>
    </g>
    <g transform="translate(85.19,74.42)">
      <path fill="none" d="M-0.07,2.31 L0.07,-2.31 " class="primitive"/>
    </g>
    <g transform="translate(91.16,77.44)">
      <path fill="none" d="M-5.02,0.02 L5.02,-0.02 " class="primitive"/>
    </g>
    <g transform="translate(79.4,76.31)">
      <path fill="none" d="M4.7,0.95 L-4.7,-0.95 " class="primitive"/>
    </g>
    <g transform="translate(86.28,77.34)">
      <path fill="none" d="M-0.15,0.02 L0.15,-0.02 " class="primitive"/>
    </g>
    <g transform="translate(80.45,76.52)">
      <path fill="none" d="M3.65,0.75 L-3.65,-0.75 " class="primitive"/>
    </g>
    <g transform="translate(88.28,75.72)">
      <path fill="none" d="M-2.36,1.3 L2.36,-1.3 " class="primitive"/>
    </g>
    <g transform="translate(73.21,33.84)">
      <path fill="none" d="M4.53,-0.06 L-4.53,0.06 " class="primitive"/>
    </g>
    <g transform="translate(65.08,34.32)">
      <path fill="none" d="M1.55,-0.25 L-1.55,0.25 " class="primitive"/>
    </g>
    <g transform="translate(64.56,36.13)">
      <path fill="none" d="M2.36,-1.69 L-2.36,1.69 " class="primitive"/>
    </g>
    <g transform="translate(64.58,32.76)">
      <path fill="none" d="M2.15,0.81 L-2.15,-0.81 " class="primitive"/>
    </g>
    <g transform="translate(62.09,33.45)">
      <path fill="none" d="M4.52,0.37 L-4.52,-0.37 " class="primitive"/>
    </g>
    <g transform="translate(64.77,37.79)">
      <path fill="none" d="M2.4,-3.23 L-2.4,3.23 " class="primitive"/>
    </g>
    <g transform="translate(62.29,31.1)">
      <path fill="none" d="M4.52,2.38 L-4.52,-2.38 " class="primitive"/>
    </g>
    <g transform="translate(74.1,84.99)">
      <path fill="none" d="M1.47,3.58 L-1.47,-3.58 " class="primitive"/>
    </g>
    <g transform="translate(69.3,86.94)">
      <path fill="none" d="M5.63,2.01 L-5.63,-2.01 " class="primitive"/>
    </g>
    <g transform="translate(73.51,90.47)">
      <path fill="none" d="M1.5,-0.76 L-1.5,0.76 " class="primitive"/>
    </g>
    <g transform="translate(69.63,89.38)">
      <path fill="none" d="M5.19,-0.09 L-5.19,0.09 " class="primitive"/>
    </g>
    <g transform="translate(75.23,14.3)">
      <path fill="none" d="M0.62,0.23 L-0.62,-0.23 " class="primitive"/>
    </g>
    <g transform="translate(82.02,16.93)">
      <path fill="none" d="M-4.33,-1.7 L4.33,1.7 " class="primitive"/>
    </g>
    <g transform="translate(71.85,17.13)">
      <path fill="none" d="M4.05,-1.86 L-4.05,1.86 " class="primitive"/>
    </g>
    <g transform="translate(83.08,14.11)">
      <path fill="none" d="M-5.27,0.63 L5.27,-0.63 " class="primitive"/>
    </g>
    <g transform="translate(78.53,14.72)">
      <path fill="none" d="M-0.72,0.06 L0.72,-0.06 " class="primitive"/>
    </g>
    <g transform="translate(71.71,13.64)">
      <path fill="none" d="M4.08,0.98 L-4.08,-0.98 " class="primitive"/>
    </g>
    <g transform="translate(54.89,84.75)">
      <path fill="none" d="M2.17,-1.82 L-2.17,1.82 " class="primitive"/>
    </g>
    <g transform="translate(60.23,83.48)">
      <path fill="none" d="M-1.63,-0.72 L1.63,0.72 " class="primitive"/>
    </g>
    <g transform="translate(62.82,80.38)">
      <path fill="none" d="M-4.18,1.63 L4.18,-1.63 " class="primitive"/>
    </g>
    <g transform="translate(60.79,80.96)">
      <path fill="none" d="M-2.19,1.01 L2.19,-1.01 " class="primitive"/>
    </g>
    <g transform="translate(54.61,81.01)">
      <path fill="none" d="M2.23,0.97 L-2.23,-0.97 " class="primitive"/>
    </g>
    <g transform="translate(55.58,80.08)">
      <path fill="none" d="M1.57,1.68 L-1.57,-1.68 " class="primitive"/>
    </g>
    <g transform="translate(60.56,85.93)">
      <path fill="none" d="M-2.33,-2.92 L2.33,2.92 " class="primitive"/>
    </g>
    <g transform="translate(53.44,82.27)">
      <path fill="none" d="M3.24,0.07 L-3.24,-0.07 " class="primitive"/>
    </g>
    <g transform="translate(98.91,57.21)">
      <path fill="none" d="M3.11,1.14 L-3.11,-1.14 " class="primitive"/>
    </g>
    <g transform="translate(103.86,58.07)">
      <path fill="none" d="M-0.16,0.11 L0.16,-0.11 " class="primitive"/>
    </g>
    <g transform="translate(106.75,56.58)">
      <path fill="none" d="M-2.99,1.65 L2.99,-1.65 " class="primitive"/>
    </g>
    <g transform="translate(107.45,55.06)">
      <path fill="none" d="M-3.82,3.08 L3.82,-3.08 " class="primitive"/>
    </g>
    <g transform="translate(107.93,55.97)">
      <path fill="none" d="M-4.16,2.27 L4.16,-2.27 " class="primitive"/>
    </g>
    <g transform="translate(70.3,16.56)">
      <path fill="none" d="M2.71,-2.26 L-2.71,2.26 " class="primitive"/>
    </g>
    <g transform="translate(76.98,14.15)">
      <path fill="none" d="M-2.27,-0.29 L2.27,0.29 " class="primitive"/>
    </g>
    <g transform="translate(70.16,13.08)">
      <path fill="none" d="M2.51,0.47 L-2.51,-0.47 " class="primitive"/>
    </g>
    <g transform="translate(67.4,14.89)">
      <path fill="none" d="M5.26,-0.97 L-5.26,0.97 " class="primitive"/>
    </g>
    <g transform="translate(40.24,32.44)">
      <path fill="none" d="M2.58,2.07 L-2.58,-2.07 " class="primitive"/>
    </g>
    <g transform="translate(38.15,34.62)">
      <path fill="none" d="M4.33,0.36 L-4.33,-0.36 " class="primitive"/>
    </g>
    <g transform="translate(38.45,37.3)">
      <path fill="none" d="M4.18,-1.84 L-4.18,1.84 " class="primitive"/>
    </g>
    <g transform="translate(37.98,36.89)">
      <path fill="none" d="M4.59,-1.51 L-4.59,1.51 " class="primitive"/>
    </g>
    <g transform="translate(50.02,34.03)">
      <path fill="none" d="M-5.5,0.88 L5.5,-0.88 " class="primitive"/>
    </g>
    <g transform="translate(39.37,30.96)">
      <path fill="none" d="M3.54,3.51 L-3.54,-3.51 " class="primitive"/>
    </g>
    <g transform="translate(47.08,33.28)">
      <path fill="none" d="M-2.71,1.36 L2.71,-1.36 " class="primitive"/>
    </g>
    <g transform="translate(46.15,32.63)">
      <path fill="none" d="M-2.01,1.85 L2.01,-1.85 " class="primitive"/>
    </g>
    <g transform="translate(44.58,31.6)">
      <path fill="none" d="M-0.84,2.75 L0.84,-2.75 " class="primitive"/>
    </g>
    <g transform="translate(122.17,38.11)">
      <path fill="none" d="M-2.06,1.67 L2.06,-1.67 " class="primitive"/>
    </g>
    <g transform="translate(117.57,41.56)">
      <path fill="none" d="M1.1,-0.72 L-1.1,0.72 " class="primitive"/>
    </g>
    <g transform="translate(123.94,38.1)">
      <path fill="none" d="M-3.66,1.81 L3.66,-1.81 " class="primitive"/>
    </g>
    <g transform="translate(115.36,36.78)">
      <path fill="none" d="M3.41,2.98 L-3.41,-2.98 " class="primitive"/>
    </g>
    <g transform="translate(26.58,65.87)">
      <path fill="none" d="M1.8,-0.61 L-1.8,0.61 " class="primitive"/>
    </g>
    <g transform="translate(31.06,66.14)">
      <path fill="none" d="M-0.99,-0.69 L0.99,0.69 " class="primitive"/>
    </g>
    <g transform="translate(29.99,62.55)">
      <path fill="none" d="M-0.47,1.67 L0.47,-1.67 " class="primitive"/>
    </g>
    <g transform="translate(29.65,63.6)">
      <path fill="none" d="M-0.15,0.61 L0.15,-0.61 " class="primitive"/>
    </g>
    <g transform="translate(31.21,67.87)">
      <path fill="none" d="M-1.46,-2.27 L1.46,2.27 " class="primitive"/>
    </g>
    <g transform="translate(27.88,69.87)">
      <path fill="none" d="M1.23,-4.21 L-1.23,4.21 " class="primitive"/>
    </g>
    <g transform="translate(29.59,61.24)">
      <path fill="none" d="M-0.22,2.96 L0.22,-2.96 " class="primitive"/>
    </g>
    <g transform="translate(31.58,64.47)">
      <path fill="none" d="M-1.26,0.26 L1.26,-0.26 " class="primitive"/>
    </g>
    <g transform="translate(29.22,68.26)">
      <path fill="none" d="M0.07,-2.59 L-0.07,2.59 " class="primitive"/>
    </g>
    <g transform="translate(26.76,68.09)">
      <path fill="none" d="M2.04,-2.51 L-2.04,2.51 " class="primitive"/>
    </g>
    <g transform="translate(29.08,63.53)">
      <path fill="none" d="M0.11,0.68 L-0.11,-0.68 " class="primitive"/>
    </g>
    <g transform="translate(32.74,85.58)">
      <path fill="none" d="M2.66,1.28 L-2.66,-1.28 " class="primitive"/>
    </g>
    <g transform="translate(34.44,83.89)">
      <path fill="none" d="M1.46,2.7 L-1.46,-2.7 " class="primitive"/>
    </g>
    <g transform="translate(42.71,84.73)">
      <path fill="none" d="M-5.54,2.19 L5.54,-2.19 " class="primitive"/>
    </g>
    <g transform="translate(34.48,84.21)">
      <path fill="none" d="M1.39,2.39 L-1.39,-2.39 " class="primitive"/>
    </g>
    <g transform="translate(128.25,53.07)">
      <path fill="none" d="M-0.89,4.01 L0.89,-4.01 " class="primitive"/>
    </g>
    <g transform="translate(124.22,54.5)">
      <path fill="none" d="M2.42,2.68 L-2.42,-2.68 " class="primitive"/>
    </g>
    <g transform="translate(124.38,54.89)">
      <path fill="none" d="M2.23,2.31 L-2.23,-2.31 " class="primitive"/>
    </g>
    <g transform="translate(124.84,55.82)">
      <path fill="none" d="M1.69,1.42 L-1.69,-1.42 " class="primitive"/>
    </g>
    <g transform="translate(122.33,55.93)">
      <path fill="none" d="M3.95,1.52 L-3.95,-1.52 " class="primitive"/>
    </g>
    <g transform="translate(17.29,54.37)">
      <path fill="none" d="M3.08,0.44 L-3.08,-0.44 " class="primitive"/>
    </g>
    <g transform="translate(26.03,57.56)">
      <path fill="none" d="M-3.83,-2.14 L3.83,2.14 " class="primitive"/>
    </g>
    <g transform="translate(18.43,50.72)">
      <path fill="none" d="M2.49,3.58 L-2.49,-3.58 " class="primitive"/>
    </g>
    <g transform="translate(25.66,53.28)">
      <path fill="none" d="M-3.37,1.32 L3.37,-1.32 " class="primitive"/>
    </g>
    <g transform="translate(25.68,58.61)">
      <path fill="none" d="M-3.63,-3.09 L3.63,3.09 " class="primitive"/>
    </g>
    <g transform="translate(25.62,56.25)">
      <path fill="none" d="M-3.28,-1 L3.28,1 " class="primitive"/>
    </g>
    <g transform="translate(18.11,55.56)">
      <path fill="none" d="M2.27,-0.42 L-2.27,0.42 " class="primitive"/>
    </g>
    <g transform="translate(27.13,52.83)">
      <path fill="none" d="M-4.82,1.79 L4.82,-1.79 " class="primitive"/>
    </g>
    <g transform="translate(25.11,58.54)">
      <path fill="none" d="M-3.11,-2.99 L3.11,2.99 " class="primitive"/>
    </g>
    <g transform="translate(21.28,71.36)">
      <path fill="none" d="M-2.19,3.88 L2.19,-3.88 " class="primitive"/>
    </g>
    <g transform="translate(19.21,76.37)">
      <path fill="none" d="M0.15,0.13 L-0.15,-0.13 " class="primitive"/>
    </g>
    <g transform="translate(16.74,73.73)">
      <path fill="none" d="M1.41,1.58 L-1.41,-1.58 " class="primitive"/>
    </g>
    <g transform="translate(17.73,75.53)">
      <path fill="none" d="M0.07,0.03 L-0.07,-0.03 " class="primitive"/>
    </g>
    <g transform="translate(22.57,75.37)">
      <path fill="none" d="M-2.85,0.42 L2.85,-0.42 " class="primitive"/>
    </g>
    <g transform="translate(23.92,73.76)">
      <path fill="none" d="M-4.32,1.8 L4.32,-1.8 " class="primitive"/>
    </g>
    <g transform="translate(21.45,73.58)">
      <path fill="none" d="M-2.08,1.78 L2.08,-1.78 " class="primitive"/>
    </g>
    <g transform="translate(19.47,76.79)">
      <path fill="none" d="M-0.21,-0.23 L0.21,0.23 " class="primitive"/>
    </g>
    <g transform="translate(38.78,70.11)">
      <path fill="none" d="M5.12,2.37 L-5.12,-2.37 " class="primitive"/>
    </g>
    <g transform="translate(46.56,72.07)">
      <path fill="none" d="M-0.92,0.42 L0.92,-0.42 " class="primitive"/>
    </g>
    <g transform="translate(38.94,71.85)">
      <path fill="none" d="M4.82,0.86 L-4.82,-0.86 " class="primitive"/>
    </g>
    <g transform="translate(50.75,71.35)">
      <path fill="none" d="M-5,1.29 L5,-1.29 " class="primitive"/>
    </g>
    <g transform="translate(48.13,76.27)">
      <path fill="none" d="M-2.76,-2.78 L2.76,2.78 " class="primitive"/>
    </g>
    <g transform="translate(44.65,68.26)">
      <path fill="none" d="M0.1,3.89 L-0.1,-3.89 " class="primitive"/>
    </g>
    <g transform="translate(49.11,75.34)">
      <path fill="none" d="M-3.52,-1.99 L3.52,1.99 " class="primitive"/>
    </g>
    <g transform="translate(46.97,77.53)">
      <path fill="none" d="M-1.86,-3.95 L1.86,3.95 " class="primitive"/>
    </g>
    <g transform="translate(33.71,12.86)">
      <path fill="none" d="M1.37,-3.82 L-1.37,3.82 " class="primitive"/>
    </g>
    <g transform="translate(39.4,9.96)">
      <path fill="none" d="M-3.15,-1.27 L3.15,1.27 " class="primitive"/>
    </g>
    <g transform="translate(38.78,9.49)">
      <path fill="none" d="M-2.49,-0.84 L2.49,0.84 " class="primitive"/>
    </g>
    <g transform="translate(29.6,10.07)">
      <path fill="none" d="M4.79,-1.44 L-4.79,1.44 " class="primitive"/>
    </g>
    <g transform="translate(34.99,9.53)">
      <path fill="none" d="M0.14,-0.48 L-0.14,0.48 " class="primitive"/>
    </g>
    <g transform="translate(32.54,10.92)">
      <path fill="none" d="M2.17,-2 L-2.17,2 " class="primitive"/>
    </g>
    <g transform="translate(34.84,10.42)">
      <path fill="none" d="M0.33,-1.36 L-0.33,1.36 " class="primitive"/>
    </g>
    <g transform="translate(39.71,10.58)">
      <path fill="none" d="M-3.52,-1.82 L3.52,1.82 " class="primitive"/>
    </g>
    <g transform="translate(34.88,32)">
      <path fill="none" d="M1.51,-1.57 L-1.51,1.57 " class="primitive"/>
    </g>
    <g transform="translate(40.23,26.42)">
      <path fill="none" d="M-2.67,2.79 L2.67,-2.79 " class="primitive"/>
    </g>
    <g transform="translate(39.11,25.31)">
      <path fill="none" d="M-1.8,3.81 L1.8,-3.81 " class="primitive"/>
    </g>
    <g transform="translate(35.18,34.68)">
      <path fill="none" d="M1.54,-4.14 L-1.54,4.14 " class="primitive"/>
    </g>
    <g transform="translate(32.26,32.34)">
      <path fill="none" d="M3.89,-2.08 L-3.89,2.08 " class="primitive"/>
    </g>
    <g transform="translate(31.28,31.04)">
      <path fill="none" d="M4.7,-1.01 L-4.7,1.01 " class="primitive"/>
    </g>
    <g transform="translate(34.71,34.27)">
      <path fill="none" d="M1.91,-3.75 L-1.91,3.75 " class="primitive"/>
    </g>
    <g transform="translate(36.48,25.1)">
      <path fill="none" d="M0.42,3.99 L-0.42,-3.99 " class="primitive"/>
    </g>
    <g transform="translate(36.1,28.33)">
      <path fill="none" d="M0.47,0.81 L-0.47,-0.81 " class="primitive"/>
    </g>
    <g transform="translate(43.81,30.66)">
      <path fill="none" d="M-5.8,-0.72 L5.8,0.72 " class="primitive"/>
    </g>
    <g transform="translate(42.89,30.01)">
      <path fill="none" d="M-4.87,-0.15 L4.87,0.15 " class="primitive"/>
    </g>
    <g transform="translate(41.31,28.98)">
      <path fill="none" d="M-3.33,0.65 L3.33,-0.65 " class="primitive"/>
    </g>
    <g transform="translate(31.74,28.79)">
      <path fill="none" d="M4.24,0.83 L-4.24,-0.83 " class="primitive"/>
    </g>
    <g transform="translate(37.77,14.5)">
      <path fill="none" d="M-4.85,2.47 L4.85,-2.47 " class="primitive"/>
    </g>
    <g transform="translate(26.22,18.24)">
      <path fill="none" d="M4.85,-0.69 L-4.85,0.69 " class="primitive"/>
    </g>
    <g transform="translate(37.78,20.21)">
      <path fill="none" d="M-4.84,-2.39 L4.84,2.39 " class="primitive"/>
    </g>
    <g transform="translate(36.66,19.09)">
      <path fill="none" d="M-3.65,-1.36 L3.65,1.36 " class="primitive"/>
    </g>
    <g transform="translate(37.15,14.02)">
      <path fill="none" d="M-4.31,2.87 L4.31,-2.87 " class="primitive"/>
    </g>
    <g transform="translate(27.97,14.6)">
      <path fill="none" d="M3.36,2.29 L-3.36,-2.29 " class="primitive"/>
    </g>
    <g transform="translate(34.03,18.88)">
      <path fill="none" d="M-1.24,-0.95 L1.24,0.95 " class="primitive"/>
    </g>
    <g transform="translate(33.66,22.12)">
      <path fill="none" d="M-1.33,-4.01 L1.33,4.01 " class="primitive"/>
    </g>
    <g transform="translate(33.36,14.06)">
      <path fill="none" d="M-1.01,2.62 L1.01,-2.62 " class="primitive"/>
    </g>
    <g transform="translate(30.91,15.45)">
      <path fill="none" d="M0.76,1.27 L-0.76,-1.27 " class="primitive"/>
    </g>
    <g transform="translate(33.21,14.95)">
      <path fill="none" d="M-0.8,1.75 L0.8,-1.75 " class="primitive"/>
    </g>
    <g transform="translate(38.08,15.12)">
      <path fill="none" d="M-5.07,1.93 L5.07,-1.93 " class="primitive"/>
    </g>
    <g transform="translate(125.27,49.77)">
      <path fill="none" d="M3.1,-1.1 L-3.1,1.1 " class="primitive"/>
    </g>
    <g transform="translate(125.43,50.15)">
      <path fill="none" d="M3.01,-1.41 L-3.01,1.41 " class="primitive"/>
    </g>
    <g transform="translate(125.89,51.08)">
      <path fill="none" d="M2.72,-2.2 L-2.72,2.2 " class="primitive"/>
    </g>
    <g transform="translate(123.39,51.19)">
      <path fill="none" d="M5.06,-2.45 L-5.06,2.45 " class="primitive"/>
    </g>
    <g transform="translate(44.82,50.16)">
      <path fill="none" d="M-2.37,-3.33 L2.37,3.33 " class="primitive"/>
    </g>
    <g transform="translate(35.58,45.86)">
      <path fill="none" d="M5.37,0.26 L-5.37,-0.26 " class="primitive"/>
    </g>
    <g transform="translate(37.68,42.85)">
      <path fill="none" d="M3.6,2.78 L-3.6,-2.78 " class="primitive"/>
    </g>
    <g transform="translate(35.97,48.89)">
      <path fill="none" d="M5.15,-2.32 L-5.15,2.32 " class="primitive"/>
    </g>
    <g transform="translate(37.22,42.44)">
      <path fill="none" d="M4.07,3.18 L-4.07,-3.18 " class="primitive"/>
    </g>
    <g transform="translate(37.43,48.43)">
      <path fill="none" d="M3.7,-1.84 L-3.7,1.84 " class="primitive"/>
    </g>
    <g transform="translate(28.32,67.07)">
      <path fill="none" d="M-3.43,-0.21 L3.43,0.21 " class="primitive"/>
    </g>
    <g transform="translate(27.26,63.48)">
      <path fill="none" d="M-2.8,2.72 L2.8,-2.72 " class="primitive"/>
    </g>
    <g transform="translate(21.79,71.8)">
      <path fill="none" d="M1.77,-4.3 L-1.77,4.3 " class="primitive"/>
    </g>
    <g transform="translate(26.91,64.53)">
      <path fill="none" d="M-2.34,1.73 L2.34,-1.73 " class="primitive"/>
    </g>
    <g transform="translate(28.48,68.8)">
      <path fill="none" d="M-3.74,-1.62 L3.74,1.62 " class="primitive"/>
    </g>
    <g transform="translate(19.31,69.16)">
      <path fill="none" d="M3.7,-1.93 L-3.7,1.93 " class="primitive"/>
    </g>
    <g transform="translate(20.31,70.97)">
      <path fill="none" d="M3.01,-3.54 L-3.01,3.54 " class="primitive"/>
    </g>
    <g transform="translate(25.15,70.8)">
      <path fill="none" d="M-1.06,-3.28 L1.06,3.28 " class="primitive"/>
    </g>
    <g transform="translate(26.85,62.17)">
      <path fill="none" d="M-2.57,3.96 L2.57,-3.96 " class="primitive"/>
    </g>
    <g transform="translate(28.84,65.4)">
      <path fill="none" d="M-4.02,1.12 L4.02,-1.12 " class="primitive"/>
    </g>
    <g transform="translate(26.49,69.19)">
      <path fill="none" d="M-2,-1.82 L2,1.82 " class="primitive"/>
    </g>
    <g transform="translate(24.02,69.02)">
      <path fill="none" d="M-0.12,-1.49 L0.12,1.49 " class="primitive"/>
    </g>
    <g transform="translate(26.35,64.46)">
      <path fill="none" d="M-1.87,1.75 L1.87,-1.75 " class="primitive"/>
    </g>
    <g transform="translate(42.35,16.19)">
      <path fill="none" d="M0.94,-3.87 L-0.94,3.87 " class="primitive"/>
    </g>
    <g transform="translate(42.84,11.12)">
      <path fill="none" d="M-0.09,-0.06 L0.09,0.06 " class="primitive"/>
    </g>
    <g transform="translate(39.72,15.98)">
      <path fill="none" d="M3.21,-3.76 L-3.21,3.76 " class="primitive"/>
    </g>
    <g transform="translate(39.05,11.16)">
      <path fill="none" d="M3.38,0.33 L-3.38,-0.33 " class="primitive"/>
    </g>
    <g transform="translate(36.6,12.55)">
      <path fill="none" d="M5.84,-0.81 L-5.84,0.81 " class="primitive"/>
    </g>
    <g transform="translate(38.9,12.05)">
      <path fill="none" d="M3.53,-0.35 L-3.53,0.35 " class="primitive"/>
    </g>
    <g transform="translate(45.88,14.28)">
      <path fill="none" d="M-1.85,-2.06 L1.85,2.06 " class="primitive"/>
    </g>
    <g transform="translate(43.77,12.22)">
      <path fill="none" d="M0.04,0.08 L-0.04,-0.08 " class="primitive"/>
    </g>
    <g transform="translate(116.07,26.73)">
      <path fill="none" d="M-0.32,-0.01 L0.32,0.01 " class="primitive"/>
    </g>
    <g transform="translate(109.98,25.04)">
      <path fill="none" d="M5.83,1.47 L-5.83,-1.47 " class="primitive"/>
    </g>
    <g transform="translate(118.7,28.29)">
      <path fill="none" d="M-1.22,-0.98 L1.22,0.98 " class="primitive"/>
    </g>
    <g transform="translate(112.04,30.13)">
      <path fill="none" d="M4.02,-2.84 L-4.02,2.84 " class="primitive"/>
    </g>
    <g transform="translate(112.62,24.93)">
      <path fill="none" d="M3.29,1.44 L-3.29,-1.44 " class="primitive"/>
    </g>
    <g transform="translate(113.88,23.23)">
      <path fill="none" d="M2.39,2.89 L-2.39,-2.89 " class="primitive"/>
    </g>
    <g transform="translate(118.53,28.06)">
      <path fill="none" d="M-1.02,-0.77 L1.02,0.77 " class="primitive"/>
    </g>
    <g transform="translate(114.05,29.99)">
      <path fill="none" d="M2.21,-2.6 L-2.21,2.6 " class="primitive"/>
    </g>
    <g transform="translate(33.08,36.86)">
      <path fill="none" d="M-0.22,-1.94 L0.22,1.94 " class="primitive"/>
    </g>
    <g transform="translate(30.16,34.52)">
      <path fill="none" d="M1.6,-0.21 L-1.6,0.21 " class="primitive"/>
    </g>
    <g transform="translate(29.18,33.22)">
      <path fill="none" d="M2.63,0.7 L-2.63,-0.7 " class="primitive"/>
    </g>
    <g transform="translate(32.62,36.45)">
      <path fill="none" d="M0.11,-1.53 L-0.11,1.53 " class="primitive"/>
    </g>
    <g transform="translate(34.01,30.51)">
      <path fill="none" d="M-0.98,2.95 L0.98,-2.95 " class="primitive"/>
    </g>
    <g transform="translate(29.64,30.97)">
      <path fill="none" d="M2.55,2.6 L-2.55,-2.6 " class="primitive"/>
    </g>
    <g transform="translate(102.68,73.56)">
      <path fill="none" d="M0.44,0.02 L-0.44,-0.02 " class="primitive"/>
    </g>
    <g transform="translate(100.69,75.52)">
      <path fill="none" d="M2.65,-1.45 L-2.65,1.45 " class="primitive"/>
    </g>
    <g transform="translate(107.1,74.96)">
      <path fill="none" d="M-2.06,-0.94 L2.06,0.94 " class="primitive"/>
    </g>
    <g transform="translate(97.81,73.8)">
      <path fill="none" d="M5.31,-0.14 L-5.31,0.14 " class="primitive"/>
    </g>
    <g transform="translate(16.51,21.65)">
      <path fill="none" d="M3.08,-2.07 L-3.08,2.07 " class="primitive"/>
    </g>
    <g transform="translate(22.1,15.44)">
      <path fill="none" d="M-1.42,2.94 L1.42,-2.94 " class="primitive"/>
    </g>
    <g transform="translate(25.04,16.29)">
      <path fill="none" d="M-3.9,2.31 L3.9,-2.31 " class="primitive"/>
    </g>
    <g transform="translate(18.75,22.57)">
      <path fill="none" d="M1.27,-2.79 L-1.27,2.79 " class="primitive"/>
    </g>
    <g transform="translate(23.42,23.42)">
      <path fill="none" d="M-2.61,-3.69 L2.61,3.69 " class="primitive"/>
    </g>
    <g transform="translate(91.33,21.01)">
      <path fill="none" d="M-3.22,-1.6 L3.22,1.6 " class="primitive"/>
    </g>
    <g transform="translate(91.29,18.89)">
      <path fill="none" d="M-2.98,0.08 L2.98,-0.08 " class="primitive"/>
    </g>
    <g transform="translate(89.7,20.07)">
      <path fill="none" d="M-1.55,-0.69 L1.55,0.69 " class="primitive"/>
    </g>
    <g transform="translate(88.32,16.17)">
      <path fill="none" d="M-0.79,2.11 L0.79,-2.11 " class="primitive"/>
    </g>
    <g transform="translate(93.16,18.64)">
      <path fill="none" d="M-4.85,0.29 L4.85,-0.29 " class="primitive"/>
    </g>
    <g transform="translate(83.77,16.78)">
      <path fill="none" d="M2.72,1.72 L-2.72,-1.72 " class="primitive"/>
    </g>
    <g transform="translate(124.92,77.94)">
      <path fill="none" d="M0.02,-1.47 L-0.02,1.47 " class="primitive"/>
    </g>
    <g transform="translate(124.61,72.07)">
      <path fill="none" d="M0.27,2.93 L-0.27,-2.93 " class="primitive"/>
    </g>
    <g transform="translate(90.72,55.48)">
      <path fill="none" d="M-3.12,-0.19 L3.12,0.19 " class="primitive"/>
    </g>
    <g transform="translate(85.33,58.43)">
      <path fill="none" d="M0.96,-2.5 L-0.96,2.5 " class="primitive"/>
    </g>
    <g transform="translate(84.25,55.95)">
      <path fill="none" d="M1.36,-0.43 L-1.36,0.43 " class="primitive"/>
    </g>
    <g transform="translate(79.94,55.12)">
      <path fill="none" d="M5.59,0.08 L-5.59,-0.08 " class="primitive"/>
    </g>
    <g transform="translate(85.15,51.99)">
      <path fill="none" d="M1.1,2.52 L-1.1,-2.52 " class="primitive"/>
    </g>
    <g transform="translate(90.38,52.2)">
      <path fill="none" d="M-3.12,2.47 L3.12,-2.47 " class="primitive"/>
    </g>
    <g transform="translate(82.86,53.18)">
      <path fill="none" d="M2.89,1.59 L-2.89,-1.59 " class="primitive"/>
    </g>
    <g transform="translate(84.99,55.83)">
      <path fill="none" d="M0.66,-0.25 L-0.66,0.25 " class="primitive"/>
    </g>
    <g transform="translate(49.4,58.44)">
      <path fill="none" d="M-1.45,-3.58 L1.45,3.58 " class="primitive"/>
    </g>
    <g transform="translate(49.23,57.91)">
      <path fill="none" d="M-1.27,-3.05 L1.27,3.05 " class="primitive"/>
    </g>
    <g transform="translate(46.09,58.89)">
      <path fill="none" d="M1.33,-4.02 L-1.33,4.02 " class="primitive"/>
    </g>
    <g transform="translate(47.25,57.19)">
      <path fill="none" d="M0.31,-2.3 L-0.31,2.3 " class="primitive"/>
    </g>
    <g transform="translate(51.19,54.46)">
      <path fill="none" d="M-2.49,-0.22 L2.49,0.22 " class="primitive"/>
    </g>
    <g transform="translate(99.21,75.46)">
      <path fill="none" d="M1.39,-1.37 L-1.39,1.37 " class="primitive"/>
    </g>
    <g transform="translate(105.62,74.9)">
      <path fill="none" d="M-3.46,-1.1 L3.46,1.1 " class="primitive"/>
    </g>
    <g transform="translate(94.33,75.35)">
      <path fill="none" d="M5.9,-1.59 L-5.9,1.59 " class="primitive"/>
    </g>
    <g transform="translate(96.34,73.73)">
      <path fill="none" d="M3.83,-0.19 L-3.83,0.19 " class="primitive"/>
    </g>
    <g transform="translate(42.36,21.91)">
      <path fill="none" d="M0.52,0.51 L-0.52,-0.51 " class="primitive"/>
    </g>
    <g transform="translate(39.73,21.69)">
      <path fill="none" d="M2.82,1 L-2.82,-1 " class="primitive"/>
    </g>
    <g transform="translate(39.35,24.93)">
      <path fill="none" d="M3.25,-1.51 L-3.25,1.51 " class="primitive"/>
    </g>
    <g transform="translate(47.06,27.26)">
      <path fill="none" d="M-3.05,-3.61 L3.05,3.61 " class="primitive"/>
    </g>
    <g transform="translate(46.14,26.61)">
      <path fill="none" d="M-2.17,-2.94 L2.17,2.94 " class="primitive"/>
    </g>
    <g transform="translate(44.56,25.58)">
      <path fill="none" d="M-0.78,-1.85 L0.78,1.85 " class="primitive"/>
    </g>
    <g transform="translate(45.88,19.99)">
      <path fill="none" d="M-1.9,2.39 L1.9,-2.39 " class="primitive"/>
    </g>
    <g transform="translate(43.77,17.93)">
      <path fill="none" d="M-0.25,4.36 L0.25,-4.36 " class="primitive"/>
    </g>
    <g transform="translate(77.96,80.04)">
      <path fill="none" d="M-4.59,0.54 L4.59,-0.54 " class="primitive"/>
    </g>
    <g transform="translate(69.34,76.51)">
      <path fill="none" d="M2.53,3.54 L-2.53,-3.54 " class="primitive"/>
    </g>
    <g transform="translate(73.02,77.93)">
      <path fill="none" d="M-0.5,2.05 L0.5,-2.05 " class="primitive"/>
    </g>
    <g transform="translate(67.54,82.65)">
      <path fill="none" d="M3.89,-1.58 L-3.89,1.58 " class="primitive"/>
    </g>
    <g transform="translate(70.13,79.54)">
      <path fill="none" d="M1.37,0.72 L-1.37,-0.72 " class="primitive"/>
    </g>
    <g transform="translate(68.1,80.13)">
      <path fill="none" d="M3.22,0.44 L-3.22,-0.44 " class="primitive"/>
    </g>
    <g transform="translate(74.07,78.13)">
      <path fill="none" d="M-1.28,1.9 L1.28,-1.9 " class="primitive"/>
    </g>
    <g transform="translate(118.47,47)">
      <path fill="none" d="M2.33,3.54 L-2.33,-3.54 " class="primitive"/>
    </g>
    <g transform="translate(121.4,51.59)">
      <path fill="none" d="M0.13,0.32 L-0.13,-0.32 " class="primitive"/>
    </g>
    <g transform="translate(121.86,52.52)">
      <path fill="none" d="M-0.29,-0.61 L0.29,0.61 " class="primitive"/>
    </g>
    <g transform="translate(115.9,52.84)">
      <path fill="none" d="M4.38,-1.34 L-4.38,1.34 " class="primitive"/>
    </g>
    <g transform="translate(116.6,51.31)">
      <path fill="none" d="M3.6,-0.08 L-3.6,0.08 " class="primitive"/>
    </g>
    <g transform="translate(117.08,52.23)">
      <path fill="none" d="M3.18,-0.78 L-3.18,0.78 " class="primitive"/>
    </g>
    <g transform="translate(119.36,52.63)">
      <path fill="none" d="M1.17,-0.89 L-1.17,0.89 " class="primitive"/>
    </g>
    <g transform="translate(31.28,42.54)">
      <path fill="none" d="M-1.64,2.35 L1.64,-2.35 " class="primitive"/>
    </g>
    <g transform="translate(22.32,46.02)">
      <path fill="none" d="M5.81,-0.4 L-5.81,0.4 " class="primitive"/>
    </g>
    <g transform="translate(29.56,48.58)">
      <path fill="none" d="M-0.29,-2.29 L0.29,2.29 " class="primitive"/>
    </g>
    <g transform="translate(30.81,42.13)">
      <path fill="none" d="M-1.3,2.72 L1.3,-2.72 " class="primitive"/>
    </g>
    <g transform="translate(31.02,48.12)">
      <path fill="none" d="M-1.38,-1.92 L1.38,1.92 " class="primitive"/>
    </g>
    <g transform="translate(95.36,20.91)">
      <path fill="none" d="M0.03,1.38 L-0.03,-1.38 " class="primitive"/>
    </g>
    <g transform="translate(93.77,22.08)">
      <path fill="none" d="M0.83,0.48 L-0.83,-0.48 " class="primitive"/>
    </g>
    <g transform="translate(97.77,23.65)">
      <path fill="none" d="M-1.39,-0.37 L1.39,0.37 " class="primitive"/>
    </g>
    <g transform="translate(99.29,23.17)">
      <path fill="none" d="M-2.84,-0.11 L2.84,0.11 " class="primitive"/>
    </g>
    <g transform="translate(97.23,20.66)">
      <path fill="none" d="M-1.33,1.72 L1.33,-1.72 " class="primitive"/>
    </g>
    <g transform="translate(101.92,23.07)">
      <path fill="none" d="M-5.48,-0.03 L5.48,0.03 " class="primitive"/>
    </g>
    <g transform="translate(64.82,69.89)">
      <path fill="none" d="M0.58,0.49 L-0.58,-0.49 " class="primitive"/>
    </g>
    <g transform="translate(66.2,71.63)">
      <path fill="none" d="M0.01,0.04 L-0.01,-0.04 " class="primitive"/>
    </g>
    <g transform="translate(69.89,73.05)">
      <path fill="none" d="M-3,-1.65 L3,1.65 " class="primitive"/>
    </g>
    <g transform="translate(65.51,69.82)">
      <path fill="none" d="M0.21,0.43 L-0.21,-0.43 " class="primitive"/>
    </g>
    <g transform="translate(69.91,68.44)">
      <path fill="none" d="M-3.07,2 L3.07,-2 " class="primitive"/>
    </g>
    <g transform="translate(61.4,70.37)">
      <path fill="none" d="M3.65,0.44 L-3.65,-0.44 " class="primitive"/>
    </g>
    <g transform="translate(66.99,74.66)">
      <path fill="none" d="M-0.74,-3 L0.74,3 " class="primitive"/>
    </g>
    <g transform="translate(64.96,75.25)">
      <path fill="none" d="M0.92,-3.58 L-0.92,3.58 " class="primitive"/>
    </g>
    <g transform="translate(70.94,73.25)">
      <path fill="none" d="M-4,-1.9 L4,1.9 " class="primitive"/>
    </g>
    <g transform="translate(68.59,67.43)">
      <path fill="none" d="M-2.05,2.85 L2.05,-2.85 " class="primitive"/>
    </g>
    <g transform="translate(101.43,41.1)">
      <path fill="none" d="M-0.47,3.6 L0.47,-3.6 " class="primitive"/>
    </g>
    <g transform="translate(97.53,47.31)">
      <path fill="none" d="M2.52,-1.42 L-2.52,1.42 " class="primitive"/>
    </g>
    <g transform="translate(106.41,48.43)">
      <path fill="none" d="M-4.72,-2.55 L4.72,2.55 " class="primitive"/>
    </g>
    <g transform="translate(98.06,88.98)">
      <path fill="none" d="M2.17,-0.63 L-2.17,0.63 " class="primitive"/>
    </g>
    <g transform="translate(99.49,87.84)">
      <path fill="none" d="M0.68,0.09 L-0.68,-0.09 " class="primitive"/>
    </g>
    <g transform="translate(102.27,88.38)">
      <path fill="none" d="M-0.11,-0.03 L0.11,0.03 " class="primitive"/>
    </g>
    <g transform="translate(31.73,63.75)">
      <path fill="none" d="M0.85,2.87 L-0.85,-2.87 " class="primitive"/>
    </g>
    <g transform="translate(31.38,64.8)">
      <path fill="none" d="M1.03,1.85 L-1.03,-1.85 " class="primitive"/>
    </g>
    <g transform="translate(32.95,69.07)">
      <path fill="none" d="M-0.09,-1 L0.09,1 " class="primitive"/>
    </g>
    <g transform="translate(29.62,71.07)">
      <path fill="none" d="M2.64,-3.1 L-2.64,3.1 " class="primitive"/>
    </g>
    <g transform="translate(31.33,62.44)">
      <path fill="none" d="M1.25,4.18 L-1.25,-4.18 " class="primitive"/>
    </g>
    <g transform="translate(33.31,65.67)">
      <path fill="none" d="M-0.3,0.94 L0.3,-0.94 " class="primitive"/>
    </g>
    <g transform="translate(38.66,65.48)">
      <path fill="none" d="M-4.92,1.56 L4.92,-1.56 " class="primitive"/>
    </g>
    <g transform="translate(30.96,69.46)">
      <path fill="none" d="M1.29,-1.5 L-1.29,1.5 " class="primitive"/>
    </g>
    <g transform="translate(28.5,69.29)">
      <path fill="none" d="M3.42,-1.55 L-3.42,1.55 " class="primitive"/>
    </g>
    <g transform="translate(30.82,64.73)">
      <path fill="none" d="M1.48,1.96 L-1.48,-1.96 " class="primitive"/>
    </g>
    <g transform="translate(49.75,66.99)">
      <path fill="none" d="M-1.16,3.55 L1.16,-3.55 " class="primitive"/>
    </g>
    <g transform="translate(52.54,70.53)">
      <path fill="none" d="M-3.17,0.55 L3.17,-0.55 " class="primitive"/>
    </g>
    <g transform="translate(49.58,66.46)">
      <path fill="none" d="M-1.04,4.07 L1.04,-4.07 " class="primitive"/>
    </g>
    <g transform="translate(49.92,75.46)">
      <path fill="none" d="M-1.3,-3.48 L1.3,3.48 " class="primitive"/>
    </g>
    <g transform="translate(46.44,67.44)">
      <path fill="none" d="M1.56,3.12 L-1.56,-3.12 " class="primitive"/>
    </g>
    <g transform="translate(50.9,74.52)">
      <path fill="none" d="M-2.04,-2.62 L2.04,2.62 " class="primitive"/>
    </g>
    <g transform="translate(84.43,75.38)">
      <path fill="none" d="M-0.7,3.28 L0.7,-3.28 " class="primitive"/>
    </g>
    <g transform="translate(90.4,78.4)">
      <path fill="none" d="M-5.8,0.83 L5.8,-0.83 " class="primitive"/>
    </g>
    <g transform="translate(78.64,77.27)">
      <path fill="none" d="M4.05,1.73 L-4.05,-1.73 " class="primitive"/>
    </g>
    <g transform="translate(85.52,78.29)">
      <path fill="none" d="M-1.12,0.63 L1.12,-0.63 " class="primitive"/>
    </g>
    <g transform="translate(79.69,77.47)">
      <path fill="none" d="M3.04,1.49 L-3.04,-1.49 " class="primitive"/>
    </g>
    <g transform="translate(87.52,76.68)">
      <path fill="none" d="M-3.19,2.19 L3.19,-2.19 " class="primitive"/>
    </g>
    <g transform="translate(14.33,50.13)">
      <path fill="none" d="M-0.92,2.93 L0.92,-2.93 " class="primitive"/>
    </g>
    <g transform="translate(14.01,54.97)">
      <path fill="none" d="M-0.37,-0.53 L0.37,0.53 " class="primitive"/>
    </g>
    <g transform="translate(64.95,70.58)">
      <path fill="none" d="M-0.87,-1.1 L0.87,1.1 " class="primitive"/>
    </g>
    <g transform="translate(68.64,71.99)">
      <path fill="none" d="M-4.29,-2.67 L4.29,2.67 " class="primitive"/>
    </g>
    <g transform="translate(62.46,64.78)">
      <path fill="none" d="M0.91,3.33 L-0.91,-3.33 " class="primitive"/>
    </g>
    <g transform="translate(64.26,68.77)">
      <path fill="none" d="M0.34,-0.03 L-0.34,0.03 " class="primitive"/>
    </g>
    <g transform="translate(68.66,67.39)">
      <path fill="none" d="M-4.12,1.17 L4.12,-1.17 " class="primitive"/>
    </g>
    <g transform="translate(60.15,69.32)">
      <path fill="none" d="M2.4,-0.34 L-2.4,0.34 " class="primitive"/>
    </g>
    <g transform="translate(65.74,73.61)">
      <path fill="none" d="M-1.85,-4.07 L1.85,4.07 " class="primitive"/>
    </g>
    <g transform="translate(67.34,66.38)">
      <path fill="none" d="M-3.01,1.96 L3.01,-1.96 " class="primitive"/>
    </g>
    <g transform="translate(120.31,91.58)">
      <path fill="none" d="M-3.47,0.05 L3.47,-0.05 " class="primitive"/>
    </g>
    <g transform="translate(117.89,88.74)">
      <path fill="none" d="M-1.62,2.25 L1.62,-2.25 " class="primitive"/>
    </g>
    <g transform="translate(109.57,90.17)">
      <path fill="none" d="M5.24,1.25 L-5.24,-1.25 " class="primitive"/>
    </g>
    <g transform="translate(108.28,10.7)">
      <path fill="none" d="M0.5,-0.13 L-0.5,0.13 " class="primitive"/>
    </g>
    <g transform="translate(110.36,15.01)">
      <path fill="none" d="M-0.51,-3.96 L0.51,3.96 " class="primitive"/>
    </g>
    <g transform="translate(21.39,34.77)">
      <path fill="none" d="M-5.11,-0.08 L5.11,0.08 " class="primitive"/>
    </g>
    <g transform="translate(13.51,34.84)">
      <path fill="none" d="M0.69,-0.07 L-0.69,0.07 " class="primitive"/>
    </g>
    <g transform="translate(20.41,33.47)">
      <path fill="none" d="M-4.19,0.97 L4.19,-0.97 " class="primitive"/>
    </g>
    <g transform="translate(16.2,30.36)">
      <path fill="none" d="M-0.8,3.58 L0.8,-3.58 " class="primitive"/>
    </g>
    <g transform="translate(120.31,39.34)">
      <path fill="none" d="M3.89,-2.91 L-3.89,2.91 " class="primitive"/>
    </g>
    <g transform="translate(122.76,32.86)">
      <path fill="none" d="M1.69,2.37 L-1.69,-2.37 " class="primitive"/>
    </g>
    <g transform="translate(122.59,32.63)">
      <path fill="none" d="M1.86,2.6 L-1.86,-2.6 " class="primitive"/>
    </g>
    <g transform="translate(126.68,35.88)">
      <path fill="none" d="M-0.73,0 L0.73,-0 " class="primitive"/>
    </g>
    <g transform="translate(118.11,34.56)">
      <path fill="none" d="M5.8,1.14 L-5.8,-1.14 " class="primitive"/>
    </g>
    <g transform="translate(57.17,60.16)">
      <path fill="none" d="M5.14,-2.18 L-5.14,2.18 " class="primitive"/>
    </g>
    <g transform="translate(62.28,59.16)">
      <path fill="none" d="M0.52,-0.89 L-0.52,0.89 " class="primitive"/>
    </g>
    <g transform="translate(68.25,56.31)">
      <path fill="none" d="M-4.07,1.04 L4.07,-1.04 " class="primitive"/>
    </g>
    <g transform="translate(57,59.63)">
      <path fill="none" d="M5.26,-1.73 L-5.26,1.73 " class="primitive"/>
    </g>
    <g transform="translate(64.45,54.75)">
      <path fill="none" d="M-0.94,2.14 L0.94,-2.14 " class="primitive"/>
    </g>
    <g transform="translate(58.96,56.19)">
      <path fill="none" d="M3.3,1.1 L-3.3,-1.1 " class="primitive"/>
    </g>
    <g transform="translate(67.16,60.76)">
      <path fill="none" d="M-3.27,-2.61 L3.27,2.61 " class="primitive"/>
    </g>
    <g transform="translate(57.39,85.86)">
      <path fill="none" d="M-4.36,1.03 L4.36,-1.03 " class="primitive"/>
    </g>
    <g transform="translate(51.77,83.39)">
      <path fill="none" d="M0.22,3 L-0.22,-3 " class="primitive"/>
    </g>
    <g transform="translate(52.75,82.46)">
      <path fill="none" d="M-0.59,3.94 L0.59,-3.94 " class="primitive"/>
    </g>
    <g transform="translate(57.72,88.31)">
      <path fill="none" d="M-4.68,-0.97 L4.68,0.97 " class="primitive"/>
    </g>
    <g transform="translate(50.6,84.65)">
      <path fill="none" d="M1.05,1.79 L-1.05,-1.79 " class="primitive"/>
    </g>
    <g transform="translate(93.72,19.96)">
      <path fill="none" d="M0.87,-0.65 L-0.87,0.65 " class="primitive"/>
    </g>
    <g transform="translate(97.73,21.53)">
      <path fill="none" d="M-1.87,-2.12 L1.87,2.12 " class="primitive"/>
    </g>
    <g transform="translate(92.34,16.07)">
      <path fill="none" d="M2.33,2.13 L-2.33,-2.13 " class="primitive"/>
    </g>
    <g transform="translate(99.24,21.05)">
      <path fill="none" d="M-3.12,-1.8 L3.12,1.8 " class="primitive"/>
    </g>
    <g transform="translate(97.18,18.54)">
      <path fill="none" d="M-0.85,0.11 L0.85,-0.11 " class="primitive"/>
    </g>
    <g transform="translate(101.87,20.95)">
      <path fill="none" d="M-5.62,-1.85 L5.62,1.85 " class="primitive"/>
    </g>
    <g transform="translate(41.72,15.72)">
      <path fill="none" d="M-0.42,4.34 L0.42,-4.34 " class="primitive"/>
    </g>
    <g transform="translate(38.61,20.58)">
      <path fill="none" d="M1.59,0.13 L-1.59,-0.13 " class="primitive"/>
    </g>
    <g transform="translate(38.23,23.82)">
      <path fill="none" d="M2.4,-2.42 L-2.4,2.42 " class="primitive"/>
    </g>
    <g transform="translate(37.78,16.65)">
      <path fill="none" d="M2.92,3.51 L-2.92,-3.51 " class="primitive"/>
    </g>
    <g transform="translate(43.44,24.46)">
      <path fill="none" d="M-1.8,-2.99 L1.8,2.99 " class="primitive"/>
    </g>
    <g transform="translate(44.76,18.88)">
      <path fill="none" d="M-2.7,1.47 L2.7,-1.47 " class="primitive"/>
    </g>
    <g transform="translate(42.65,16.82)">
      <path fill="none" d="M-1.16,3.26 L1.16,-3.26 " class="primitive"/>
    </g>
    <g transform="translate(102.93,14.68)">
      <path fill="none" d="M3.25,-3.02 L-3.25,3.02 " class="primitive"/>
    </g>
    <g transform="translate(108.88,15.39)">
      <path fill="none" d="M-1.74,-3.62 L1.74,3.62 " class="primitive"/>
    </g>
    <g transform="translate(30.31,55.88)">
      <path fill="none" d="M0.3,3.54 L-0.3,-3.54 " class="primitive"/>
    </g>
    <g transform="translate(30.32,61.21)">
      <path fill="none" d="M0.11,-0.34 L-0.11,0.34 " class="primitive"/>
    </g>
    <g transform="translate(30.26,58.85)">
      <path fill="none" d="M0.18,0.59 L-0.18,-0.59 " class="primitive"/>
    </g>
    <g transform="translate(32.25,62.08)">
      <path fill="none" d="M-1.06,-1.29 L1.06,1.29 " class="primitive"/>
    </g>
    <g transform="translate(31.77,55.43)">
      <path fill="none" d="M-0.93,4 L0.93,-4 " class="primitive"/>
    </g>
    <g transform="translate(37.6,61.89)">
      <path fill="none" d="M-5.95,-1.49 L5.95,1.49 " class="primitive"/>
    </g>
    <g transform="translate(29.76,61.14)">
      <path fill="none" d="M0.34,-0.37 L-0.34,0.37 " class="primitive"/>
    </g>
    <g transform="translate(118.63,47.38)">
      <path fill="none" d="M-2.5,-3.92 L2.5,3.92 " class="primitive"/>
    </g>
    <g transform="translate(113.5,38)">
      <path fill="none" d="M1.88,4.08 L-1.88,-4.08 " class="primitive"/>
    </g>
    <g transform="translate(113.84,47.1)">
      <path fill="none" d="M1.57,-3.61 L-1.57,3.61 " class="primitive"/>
    </g>
    <g transform="translate(109.26,25.01)">
      <path fill="none" d="M5.12,1.43 L-5.12,-1.43 " class="primitive"/>
    </g>
    <g transform="translate(117.98,28.27)">
      <path fill="none" d="M-1.83,-1.09 L1.83,1.09 " class="primitive"/>
    </g>
    <g transform="translate(111.31,30.1)">
      <path fill="none" d="M3.36,-2.83 L-3.36,2.83 " class="primitive"/>
    </g>
    <g transform="translate(111.89,24.91)">
      <path fill="none" d="M2.62,1.36 L-2.62,-1.36 " class="primitive"/>
    </g>
    <g transform="translate(113.15,23.2)">
      <path fill="none" d="M1.77,2.83 L-1.77,-2.83 " class="primitive"/>
    </g>
    <g transform="translate(117.8,28.04)">
      <path fill="none" d="M-1.63,-0.88 L1.63,0.88 " class="primitive"/>
    </g>
    <g transform="translate(113.32,29.96)">
      <path fill="none" d="M1.6,-2.58 L-1.6,2.58 " class="primitive"/>
    </g>
    <g transform="translate(30.46,37.2)">
      <path fill="none" d="M2.23,1.78 L-2.23,-1.78 " class="primitive"/>
    </g>
    <g transform="translate(29.48,35.9)">
      <path fill="none" d="M3.27,3.05 L-3.27,-3.05 " class="primitive"/>
    </g>
    <g transform="translate(32.91,39.12)">
      <path fill="none" d="M-0.19,-0.16 L0.19,0.16 " class="primitive"/>
    </g>
    <g transform="translate(96.14,22.71)">
      <path fill="none" d="M-3.1,-1.21 L3.1,1.21 " class="primitive"/>
    </g>
    <g transform="translate(90.75,17.25)">
      <path fill="none" d="M1.12,3.18 L-1.12,-3.18 " class="primitive"/>
    </g>
    <g transform="translate(97.65,22.23)">
      <path fill="none" d="M-4.52,-0.89 L4.52,0.89 " class="primitive"/>
    </g>
    <g transform="translate(95.59,19.72)">
      <path fill="none" d="M-2.56,1.05 L2.56,-1.05 " class="primitive"/>
    </g>
    <g transform="translate(101.66,23.8)">
      <path fill="none" d="M-0.56,0.18 L0.56,-0.18 " class="primitive"/>
    </g>
    <g transform="translate(99.6,21.28)">
      <path fill="none" d="M0.41,2.26 L-0.41,-2.26 " class="primitive"/>
    </g>
    <g transform="translate(104.29,23.69)">
      <path fill="none" d="M-3.13,0.44 L3.13,-0.44 " class="primitive"/>
    </g>
    <g transform="translate(105.55,21.99)">
      <path fill="none" d="M-4.51,1.91 L4.51,-1.91 " class="primitive"/>
    </g>
    <g transform="translate(70.02,73.73)">
      <path fill="none" d="M-2.77,-1.07 L2.77,1.07 " class="primitive"/>
    </g>
    <g transform="translate(65.64,70.5)">
      <path fill="none" d="M0.42,1.1 L-0.42,-1.1 " class="primitive"/>
    </g>
    <g transform="translate(70.04,69.13)">
      <path fill="none" d="M-3.05,2.61 L3.05,-2.61 " class="primitive"/>
    </g>
    <g transform="translate(61.53,71.06)">
      <path fill="none" d="M3.83,1 L-3.83,-1 " class="primitive"/>
    </g>
    <g transform="translate(67.12,75.35)">
      <path fill="none" d="M-0.6,-2.31 L0.6,2.31 " class="primitive"/>
    </g>
    <g transform="translate(65.09,75.93)">
      <path fill="none" d="M0.99,-2.9 L-0.99,2.9 " class="primitive"/>
    </g>
    <g transform="translate(71.07,73.94)">
      <path fill="none" d="M-3.8,-1.3 L3.8,1.3 " class="primitive"/>
    </g>
    <g transform="translate(68.72,68.12)">
      <path fill="none" d="M-2,3.52 L2,-3.52 " class="primitive"/>
    </g>
    <g transform="translate(14.92,25.14)">
      <path fill="none" d="M-1.34,-0.55 L1.34,0.55 " class="primitive"/>
    </g>
    <g transform="translate(19.59,25.99)">
      <path fill="none" d="M-5.93,-1.52 L5.93,1.52 " class="primitive"/>
    </g>
    <g transform="translate(38.43,10.69)">
      <path fill="none" d="M2.74,-0.03 L-2.74,0.03 " class="primitive"/>
    </g>
    <g transform="translate(35.98,12.07)">
      <path fill="none" d="M5.24,-1.2 L-5.24,1.2 " class="primitive"/>
    </g>
    <g transform="translate(38.27,11.58)">
      <path fill="none" d="M2.95,-0.69 L-2.95,0.69 " class="primitive"/>
    </g>
    <g transform="translate(45.25,13.8)">
      <path fill="none" d="M-2.45,-2.55 L2.45,2.55 " class="primitive"/>
    </g>
    <g transform="translate(43.14,11.74)">
      <path fill="none" d="M-0.39,-0.46 L0.39,0.46 " class="primitive"/>
    </g>
    <g transform="translate(91.25,74.4)">
      <path fill="none" d="M-5.12,-2.59 L5.12,2.59 " class="primitive"/>
    </g>
    <g transform="translate(79.5,73.26)">
      <path fill="none" d="M4.85,-1.58 L-4.85,1.58 " class="primitive"/>
    </g>
    <g transform="translate(79.52,68.66)">
      <path fill="none" d="M4.9,2.3 L-4.9,-2.3 " class="primitive"/>
    </g>
    <g transform="translate(84.69,66.51)">
      <path fill="none" d="M0.5,4.13 L-0.5,-4.13 " class="primitive"/>
    </g>
    <g transform="translate(86.37,74.29)">
      <path fill="none" d="M-0.82,-2.2 L0.82,2.2 " class="primitive"/>
    </g>
    <g transform="translate(80.54,73.47)">
      <path fill="none" d="M3.86,-1.71 L-3.86,1.71 " class="primitive"/>
    </g>
    <g transform="translate(88.37,72.67)">
      <path fill="none" d="M-2.19,-0.92 L2.19,0.92 " class="primitive"/>
    </g>
    <g transform="translate(99.83,56.59)">
      <path fill="none" d="M-3.94,-0.68 L3.94,0.68 " class="primitive"/>
    </g>
    <g transform="translate(89.49,58.69)">
      <path fill="none" d="M4.57,-2.51 L-4.57,2.51 " class="primitive"/>
    </g>
    <g transform="translate(88.41,56.21)">
      <path fill="none" d="M5.43,-0.4 L-5.43,0.4 " class="primitive"/>
    </g>
    <g transform="translate(94.53,52.46)">
      <path fill="none" d="M0.26,2.54 L-0.26,-2.54 " class="primitive"/>
    </g>
    <g transform="translate(89.14,56.08)">
      <path fill="none" d="M4.7,-0.29 L-4.7,0.29 " class="primitive"/>
    </g>
    <g transform="translate(103.63,76.86)">
      <path fill="none" d="M-5.37,0.47 L5.37,-0.47 " class="primitive"/>
    </g>
    <g transform="translate(92.34,77.31)">
      <path fill="none" d="M3.84,0.09 L-3.84,-0.09 " class="primitive"/>
    </g>
    <g transform="translate(97.5,82.51)">
      <path fill="none" d="M-0.24,-4.36 L0.24,4.36 " class="primitive"/>
    </g>
    <g transform="translate(94.34,75.7)">
      <path fill="none" d="M2.08,1.25 L-2.08,-1.25 " class="primitive"/>
    </g>
    <g transform="translate(26.56,33.57)">
      <path fill="none" d="M0.49,0.65 L-0.49,-0.65 " class="primitive"/>
    </g>
    <g transform="translate(29.99,36.79)">
      <path fill="none" d="M-1.76,-1.38 L1.76,1.38 " class="primitive"/>
    </g>
    <g transform="translate(31.38,30.86)">
      <path fill="none" d="M-3.26,3.4 L3.26,-3.4 " class="primitive"/>
    </g>
    <g transform="translate(27.02,31.31)">
      <path fill="none" d="M0.41,2.82 L-0.41,-2.82 " class="primitive"/>
    </g>
    <g transform="translate(18.68,33.64)">
      <path fill="none" d="M-5.9,1.18 L5.9,-1.18 " class="primitive"/>
    </g>
    <g transform="translate(14.47,30.54)">
      <path fill="none" d="M-2.28,3.8 L2.28,-3.8 " class="primitive"/>
    </g>
    <g transform="translate(61.99,36.54)">
      <path fill="none" d="M0.31,-1.09 L-0.31,1.09 " class="primitive"/>
    </g>
    <g transform="translate(62.01,33.17)">
      <path fill="none" d="M0.27,0.85 L-0.27,-0.85 " class="primitive"/>
    </g>
    <g transform="translate(59.52,33.86)">
      <path fill="none" d="M2.02,0.59 L-2.02,-0.59 " class="primitive"/>
    </g>
    <g transform="translate(56.57,33.12)">
      <path fill="none" d="M4.96,1.35 L-4.96,-1.35 " class="primitive"/>
    </g>
    <g transform="translate(62.2,38.2)">
      <path fill="none" d="M0.25,-2.74 L-0.25,2.74 " class="primitive"/>
    </g>
    <g transform="translate(59.72,31.51)">
      <path fill="none" d="M2.24,2.6 L-2.24,-2.6 " class="primitive"/>
    </g>
    <g transform="translate(122.02,52.9)">
      <path fill="none" d="M-0.12,-0.23 L0.12,0.23 " class="primitive"/>
    </g>
    <g transform="translate(116.06,53.23)">
      <path fill="none" d="M4.5,-1.03 L-4.5,1.03 " class="primitive"/>
    </g>
    <g transform="translate(116.76,51.7)">
      <path fill="none" d="M3.76,0.22 L-3.76,-0.22 " class="primitive"/>
    </g>
    <g transform="translate(117.23,52.62)">
      <path fill="none" d="M3.3,-0.49 L-3.3,0.49 " class="primitive"/>
    </g>
    <g transform="translate(119.51,53.02)">
      <path fill="none" d="M1.2,-0.61 L-1.2,0.61 " class="primitive"/>
    </g>
    <g transform="translate(15.15,51.33)">
      <path fill="none" d="M0.27,-4.11 L-0.27,4.11 " class="primitive"/>
    </g>
    <g transform="translate(107.67,55.97)">
      <path fill="none" d="M-2.05,1.05 L2.05,-1.05 " class="primitive"/>
    </g>
    <g transform="translate(108.37,54.44)">
      <path fill="none" d="M-2.92,2.45 L2.92,-2.45 " class="primitive"/>
    </g>
    <g transform="translate(108.85,55.35)">
      <path fill="none" d="M-3.23,1.66 L3.23,-1.66 " class="primitive"/>
    </g>
    <g transform="translate(111.12,55.75)">
      <path fill="none" d="M-5.37,1.44 L5.37,-1.44 " class="primitive"/>
    </g>
    <g transform="translate(64.96,21.13)">
      <path fill="none" d="M1.32,-1.17 L-1.32,1.17 " class="primitive"/>
    </g>
    <g transform="translate(66.78,15.9)">
      <path fill="none" d="M0.11,2.75 L-0.11,-2.75 " class="primitive"/>
    </g>
    <g transform="translate(64.03,17.71)">
      <path fill="none" d="M2.09,1.21 L-2.09,-1.21 " class="primitive"/>
    </g>
    <g transform="translate(61.49,34.98)">
      <path fill="none" d="M-0.01,2.64 L0.01,-2.64 " class="primitive"/>
    </g>
    <g transform="translate(59,35.67)">
      <path fill="none" d="M1.9,2.06 L-1.9,-2.06 " class="primitive"/>
    </g>
    <g transform="translate(62.58,42.15)">
      <path fill="none" d="M-0.9,-3.08 L0.9,3.08 " class="primitive"/>
    </g>
    <g transform="translate(56.06,34.93)">
      <path fill="none" d="M4.64,2.93 L-4.64,-2.93 " class="primitive"/>
    </g>
    <g transform="translate(61.68,40.01)">
      <path fill="none" d="M-0.12,-0.93 L0.12,0.93 " class="primitive"/>
    </g>
    <g transform="translate(94.21,15.82)">
      <path fill="none" d="M-3.99,-2.04 L3.99,2.04 " class="primitive"/>
    </g>
    <g transform="translate(84.83,13.96)">
      <path fill="none" d="M3.53,-0.47 L-3.53,0.47 " class="primitive"/>
    </g>
    <g transform="translate(17.25,74.17)">
      <path fill="none" d="M1.9,2.02 L-1.9,-2.02 " class="primitive"/>
    </g>
    <g transform="translate(18.25,75.97)">
      <path fill="none" d="M0.67,0.38 L-0.67,-0.38 " class="primitive"/>
    </g>
    <g transform="translate(23.09,75.8)">
      <path fill="none" d="M-2.4,0.72 L2.4,-0.72 " class="primitive"/>
    </g>
    <g transform="translate(24.47,80.35)">
      <path fill="none" d="M-4.03,-3.01 L4.03,3.01 " class="primitive"/>
    </g>
    <g transform="translate(26.17,78.65)">
      <path fill="none" d="M-5.47,-1.57 L5.47,1.57 " class="primitive"/>
    </g>
    <g transform="translate(24.43,74.2)">
      <path fill="none" d="M-3.88,2.15 L3.88,-2.15 " class="primitive"/>
    </g>
    <g transform="translate(21.96,74.02)">
      <path fill="none" d="M-1.72,2.14 L1.72,-2.14 " class="primitive"/>
    </g>
    <g transform="translate(26.21,78.97)">
      <path fill="none" d="M-5.54,-1.85 L5.54,1.85 " class="primitive"/>
    </g>
    <g transform="translate(19.99,77.22)">
      <path fill="none" d="M0.16,0.26 L-0.16,-0.26 " class="primitive"/>
    </g>
    <g transform="translate(122.43,82.99)">
      <path fill="none" d="M1.91,-2.22 L-1.91,2.22 " class="primitive"/>
    </g>
    <g transform="translate(29.9,54.57)">
      <path fill="none" d="M0.03,-2.23 L-0.03,2.23 " class="primitive"/>
    </g>
    <g transform="translate(31.41,51.15)">
      <path fill="none" d="M-0.51,0.16 L0.51,-0.16 " class="primitive"/>
    </g>
    <g transform="translate(116.53,54.15)">
      <path fill="none" d="M4.92,-0.27 L-4.92,0.27 " class="primitive"/>
    </g>
    <g transform="translate(117.23,52.63)">
      <path fill="none" d="M4.27,0.98 L-4.27,-0.98 " class="primitive"/>
    </g>
    <g transform="translate(117.7,53.54)">
      <path fill="none" d="M3.75,0.23 L-3.75,-0.23 " class="primitive"/>
    </g>
    <g transform="translate(119.98,53.94)">
      <path fill="none" d="M1.47,-0.07 L-1.47,0.07 " class="primitive"/>
    </g>
    <g transform="translate(101.11,20.8)">
      <path fill="none" d="M1.54,1.87 L-1.54,-1.87 " class="primitive"/>
    </g>
    <g transform="translate(105.8,23.21)">
      <path fill="none" d="M-1.59,0.06 L1.59,-0.06 " class="primitive"/>
    </g>
    <g transform="translate(107.07,21.51)">
      <path fill="none" d="M-3.02,1.4 L3.02,-1.4 " class="primitive"/>
    </g>
    <g transform="translate(59.02,32.3)">
      <path fill="none" d="M1.52,-0.42 L-1.52,0.42 " class="primitive"/>
    </g>
    <g transform="translate(62.25,27.24)">
      <path fill="none" d="M-0.62,3.63 L0.62,-3.63 " class="primitive"/>
    </g>
    <g transform="translate(56.07,31.55)">
      <path fill="none" d="M4.39,0.04 L-4.39,-0.04 " class="primitive"/>
    </g>
    <g transform="translate(55.15,30.9)">
      <path fill="none" d="M5.33,0.59 L-5.33,-0.59 " class="primitive"/>
    </g>
    <g transform="translate(61.7,36.64)">
      <path fill="none" d="M-0.16,-4.3 L0.16,4.3 " class="primitive"/>
    </g>
    <g transform="translate(59.22,29.94)">
      <path fill="none" d="M1.56,1.13 L-1.56,-1.13 " class="primitive"/>
    </g>
    <g transform="translate(31.54,66.54)">
      <path fill="none" d="M-1.3,-3.56 L1.3,3.56 " class="primitive"/>
    </g>
    <g transform="translate(29.92,59.91)">
      <path fill="none" d="M0.04,1.63 L-0.04,-1.63 " class="primitive"/>
    </g>
    <g transform="translate(31.9,63.14)">
      <path fill="none" d="M-1.05,-0.47 L1.05,0.47 " class="primitive"/>
    </g>
    <g transform="translate(37.25,62.95)">
      <path fill="none" d="M-6.25,-0.58 L6.25,0.58 " class="primitive"/>
    </g>
    <g transform="translate(29.55,66.93)">
      <path fill="none" d="M0.35,-3.92 L-0.35,3.92 " class="primitive"/>
    </g>
    <g transform="translate(27.09,66.75)">
      <path fill="none" d="M2.46,-3.81 L-2.46,3.81 " class="primitive"/>
    </g>
    <g transform="translate(29.41,62.2)">
      <path fill="none" d="M-0.46,-0.06 L0.46,0.06 " class="primitive"/>
    </g>
    <g transform="translate(103.74,20.7)">
      <path fill="none" d="M-3.85,-1.98 L3.85,1.98 " class="primitive"/>
    </g>
    <g transform="translate(105.01,19)">
      <path fill="none" d="M-4.93,-0.58 L4.93,0.58 " class="primitive"/>
    </g>
    <g transform="translate(113.94,31.66)">
      <path fill="none" d="M5.69,-1.57 L-5.69,1.57 " class="primitive"/>
    </g>
    <g transform="translate(120.43,29.6)">
      <path fill="none" d="M-0.32,-0.42 L0.32,0.42 " class="primitive"/>
    </g>
    <g transform="translate(124.53,32.85)">
      <path fill="none" d="M-3.22,-2.48 L3.22,2.48 " class="primitive"/>
    </g>
    <g transform="translate(115.95,31.52)">
      <path fill="none" d="M3.73,-1.36 L-3.73,1.36 " class="primitive"/>
    </g>
    <g transform="translate(29.02,35.49)">
      <path fill="none" d="M-2.81,-2.63 L2.81,2.63 " class="primitive"/>
    </g>
    <g transform="translate(30.41,29.56)">
      <path fill="none" d="M-4.01,2.25 L4.01,-2.25 " class="primitive"/>
    </g>
    <g transform="translate(21.37,29.16)">
      <path fill="none" d="M3.49,2.57 L-3.49,-2.57 " class="primitive"/>
    </g>
    <g transform="translate(26.04,30.02)">
      <path fill="none" d="M-0.31,1.52 L0.31,-1.52 " class="primitive"/>
    </g>
    <g transform="translate(29.25,11.26)">
      <path fill="none" d="M-4.36,0.43 L4.36,-0.43 " class="primitive"/>
    </g>
    <g transform="translate(26.8,12.65)">
      <path fill="none" d="M-1.98,-0.57 L1.98,0.57 " class="primitive"/>
    </g>
    <g transform="translate(29.09,12.15)">
      <path fill="none" d="M-4.2,-0.28 L4.2,0.28 " class="primitive"/>
    </g>
    <g transform="translate(69.33,71.92)">
      <path fill="none" d="M3.65,2.7 L-3.65,-2.7 " class="primitive"/>
    </g>
    <g transform="translate(73.73,70.55)">
      <path fill="none" d="M-0.02,3.86 L0.02,-3.86 " class="primitive"/>
    </g>
    <g transform="translate(80.58,76.18)">
      <path fill="none" d="M-5.86,-0.87 L5.86,0.87 " class="primitive"/>
    </g>
    <g transform="translate(70.81,76.77)">
      <path fill="none" d="M2.08,-1.16 L-2.08,1.16 " class="primitive"/>
    </g>
    <g transform="translate(68.78,77.35)">
      <path fill="none" d="M4.04,-1.81 L-4.04,1.81 " class="primitive"/>
    </g>
    <g transform="translate(74.75,75.36)">
      <path fill="none" d="M-0.04,-0.01 L0.04,0.01 " class="primitive"/>
    </g>
    <g transform="translate(56.25,61.72)">
      <path fill="none" d="M-4.11,0.8 L4.11,-0.8 " class="primitive"/>
    </g>
    <g transform="translate(53.93,66.26)">
      <path fill="none" d="M-2.29,-2.9 L2.29,2.9 " class="primitive"/>
    </g>
    <g transform="translate(50.97,62.19)">
      <path fill="none" d="M-0.06,-0.19 L0.06,0.19 " class="primitive"/>
    </g>
    <g transform="translate(47.83,63.17)">
      <path fill="none" d="M2.28,-0.31 L-2.28,0.31 " class="primitive"/>
    </g>
    <g transform="translate(48.98,61.47)">
      <path fill="none" d="M1.35,0.78 L-1.35,-0.78 " class="primitive"/>
    </g>
    <g transform="translate(52.93,58.75)">
      <path fill="none" d="M-1.47,3.27 L1.47,-3.27 " class="primitive"/>
    </g>
    <g transform="translate(29.77,72.8)">
      <path fill="none" d="M2.53,-1.52 L-2.53,1.52 " class="primitive"/>
    </g>
    <g transform="translate(33.47,67.41)">
      <path fill="none" d="M-0.29,2.66 L0.29,-2.66 " class="primitive"/>
    </g>
    <g transform="translate(32.86,75.65)">
      <path fill="none" d="M0.21,-4.11 L-0.21,4.11 " class="primitive"/>
    </g>
    <g transform="translate(31.12,71.2)">
      <path fill="none" d="M0.98,-0.19 L-0.98,0.19 " class="primitive"/>
    </g>
    <g transform="translate(28.65,71.02)">
      <path fill="none" d="M3.41,-0.16 L-3.41,0.16 " class="primitive"/>
    </g>
    <g transform="translate(32.9,75.97)">
      <path fill="none" d="M0.18,-4.43 L-0.18,4.43 " class="primitive"/>
    </g>
    <g transform="translate(30.97,66.46)">
      <path fill="none" d="M1.79,3.65 L-1.79,-3.65 " class="primitive"/>
    </g>
    <g transform="translate(63.16,64.71)">
      <path fill="none" d="M-1.48,-3.28 L1.48,3.28 " class="primitive"/>
    </g>
    <g transform="translate(67.55,63.34)">
      <path fill="none" d="M-5.3,-2.23 L5.3,2.23 " class="primitive"/>
    </g>
    <g transform="translate(59.04,65.27)">
      <path fill="none" d="M1.96,-3.85 L-1.96,3.85 " class="primitive"/>
    </g>
    <g transform="translate(67.33,57.88)">
      <path fill="none" d="M-5.11,2.44 L5.11,-2.44 " class="primitive"/>
    </g>
    <g transform="translate(56.08,61.2)">
      <path fill="none" d="M4.25,-0.38 L-4.25,0.38 " class="primitive"/>
    </g>
    <g transform="translate(63.53,56.32)">
      <path fill="none" d="M-1.83,3.72 L1.83,-3.72 " class="primitive"/>
    </g>
    <g transform="translate(54.1,60.48)">
      <path fill="none" d="M6.22,0.22 L-6.22,-0.22 " class="primitive"/>
    </g>
    <g transform="translate(58.04,57.75)">
      <path fill="none" d="M2.68,2.4 L-2.68,-2.4 " class="primitive"/>
    </g>
    <g transform="translate(66.24,62.32)">
      <path fill="none" d="M-3.93,-1.28 L3.93,1.28 " class="primitive"/>
    </g>
    <g transform="translate(69.35,67.32)">
      <path fill="none" d="M-3.44,1.07 L3.44,-1.07 " class="primitive"/>
    </g>
    <g transform="translate(60.84,69.25)">
      <path fill="none" d="M3.09,-0.42 L-3.09,0.42 " class="primitive"/>
    </g>
    <g transform="translate(66.44,73.54)">
      <path fill="none" d="M-1.26,-4.13 L1.26,4.13 " class="primitive"/>
    </g>
    <g transform="translate(70.38,72.13)">
      <path fill="none" d="M-4.65,-2.94 L4.65,2.94 " class="primitive"/>
    </g>
    <g transform="translate(68.04,66.31)">
      <path fill="none" d="M-2.38,1.84 L2.38,-1.84 " class="primitive"/>
    </g>
    <g transform="translate(78.92,63.8)">
      <path fill="none" d="M-4.28,1.78 L4.28,-1.78 " class="primitive"/>
    </g>
    <g transform="translate(74.77,70.76)">
      <path fill="none" d="M-0.87,-4.08 L0.87,4.08 " class="primitive"/>
    </g>
    <g transform="translate(72.43,64.93)">
      <path fill="none" d="M0.61,0.47 L-0.61,-0.47 " class="primitive"/>
    </g>
    <g transform="translate(83.02,59.16)">
      <path fill="none" d="M0.77,1.78 L-0.77,-1.78 " class="primitive"/>
    </g>
    <g transform="translate(78.7,58.34)">
      <path fill="none" d="M4.61,2.83 L-4.61,-2.83 " class="primitive"/>
    </g>
    <g transform="translate(77.61,62.78)">
      <path fill="none" d="M5.48,-0.96 L-5.48,0.96 " class="primitive"/>
    </g>
    <g transform="translate(83.75,59.04)">
      <path fill="none" d="M0.25,1.87 L-0.25,-1.87 " class="primitive"/>
    </g>
    <g transform="translate(53.76,65.74)">
      <path fill="none" d="M2.49,3.41 L-2.49,-3.41 " class="primitive"/>
    </g>
    <g transform="translate(55.08,73.8)">
      <path fill="none" d="M1.35,-3.28 L-1.35,3.28 " class="primitive"/>
    </g>
    <g transform="translate(77.63,55.85)">
      <path fill="none" d="M3.31,0.64 L-3.31,-0.64 " class="primitive"/>
    </g>
    <g transform="translate(82.84,52.72)">
      <path fill="none" d="M-0.73,3.23 L0.73,-3.23 " class="primitive"/>
    </g>
    <g transform="translate(78.27,52.57)">
      <path fill="none" d="M3.11,3.48 L-3.11,-3.48 " class="primitive"/>
    </g>
    <g transform="translate(80.55,53.91)">
      <path fill="none" d="M1.05,2.08 L-1.05,-2.08 " class="primitive"/>
    </g>
    <g transform="translate(82.68,56.56)">
      <path fill="none" d="M0.28,-0.05 L-0.28,0.05 " class="primitive"/>
    </g>
    <g transform="translate(78.52,51.9)">
      <path fill="none" d="M-4.42,2.65 L4.42,-2.65 " class="primitive"/>
    </g>
    <g transform="translate(73.96,51.74)">
      <path fill="none" d="M-0.5,2.55 L0.5,-2.55 " class="primitive"/>
    </g>
    <g transform="translate(69.5,53.46)">
      <path fill="none" d="M2.91,1.19 L-2.91,-1.19 " class="primitive"/>
    </g>
    <g transform="translate(76.23,53.08)">
      <path fill="none" d="M-2.16,1.44 L2.16,-1.44 " class="primitive"/>
    </g>
    <g transform="translate(72.21,59.47)">
      <path fill="none" d="M0.92,-3.72 L-0.92,3.72 " class="primitive"/>
    </g>
    <g transform="translate(78.36,55.73)">
      <path fill="none" d="M-4.03,-0.56 L4.03,0.56 " class="primitive"/>
    </g>
    <g transform="translate(66.95,88.13)">
      <path fill="none" d="M-3.54,-2.97 L3.54,2.97 " class="primitive"/>
    </g>
    <g transform="translate(65.33,81.49)">
      <path fill="none" d="M-2.06,2.47 L2.06,-2.47 " class="primitive"/>
    </g>
    <g transform="translate(63.3,82.07)">
      <path fill="none" d="M-0.4,1.79 L0.4,-1.79 " class="primitive"/>
    </g>
    <g transform="translate(57.11,82.12)">
      <path fill="none" d="M4.74,2.08 L-4.74,-2.08 " class="primitive"/>
    </g>
    <g transform="translate(58.09,81.19)">
      <path fill="none" d="M3.93,2.87 L-3.93,-2.87 " class="primitive"/>
    </g>
    <g transform="translate(63.07,87.04)">
      <path fill="none" d="M-0.23,-1.71 L0.23,1.71 " class="primitive"/>
    </g>
    <g transform="translate(55.95,83.39)">
      <path fill="none" d="M5.78,1.03 L-5.78,-1.03 " class="primitive"/>
    </g>
    <g transform="translate(81.63,76.38)">
      <path fill="none" d="M4.81,0.68 L-4.81,-0.68 " class="primitive"/>
    </g>
    <g transform="translate(89.46,75.59)">
      <path fill="none" d="M-1.32,1.06 L1.32,-1.06 " class="primitive"/>
    </g>
    <g transform="translate(53.59,32.25)">
      <path fill="none" d="M1.97,0.5 L-1.97,-0.5 " class="primitive"/>
    </g>
    <g transform="translate(52.66,31.59)">
      <path fill="none" d="M2.94,1.06 L-2.94,-1.06 " class="primitive"/>
    </g>
    <g transform="translate(59.21,37.33)">
      <path fill="none" d="M-2.26,-3.67 L2.26,3.67 " class="primitive"/>
    </g>
    <g transform="translate(51.09,30.56)">
      <path fill="none" d="M4.57,2.04 L-4.57,-2.04 " class="primitive"/>
    </g>
    <g transform="translate(56.73,30.64)">
      <path fill="none" d="M-0.14,1.62 L0.14,-1.62 " class="primitive"/>
    </g>
    <g transform="translate(15.77,73.33)">
      <path fill="none" d="M-0.62,-1.12 L0.62,1.12 " class="primitive"/>
    </g>
    <g transform="translate(20.61,73.17)">
      <path fill="none" d="M-4.87,-1.36 L4.87,1.36 " class="primitive"/>
    </g>
    <g transform="translate(21.95,71.56)">
      <path fill="none" d="M-6.14,-0.02 L6.14,0.02 " class="primitive"/>
    </g>
    <g transform="translate(19.49,71.38)">
      <path fill="none" d="M-3.67,0.11 L3.67,-0.11 " class="primitive"/>
    </g>
    <g transform="translate(17.51,74.58)">
      <path fill="none" d="M-2.18,-2.43 L2.18,2.43 " class="primitive"/>
    </g>
    <g transform="translate(21.61,74.97)">
      <path fill="none" d="M-3.8,0.13 L3.8,-0.13 " class="primitive"/>
    </g>
    <g transform="translate(22.95,73.36)">
      <path fill="none" d="M-5.22,1.5 L5.22,-1.5 " class="primitive"/>
    </g>
    <g transform="translate(20.48,73.19)">
      <path fill="none" d="M-2.88,1.51 L2.88,-1.51 " class="primitive"/>
    </g>
    <g transform="translate(18.51,76.39)">
      <path fill="none" d="M-1.01,-0.73 L1.01,0.73 " class="primitive"/>
    </g>
    <g transform="translate(122.4,88.67)">
      <path fill="none" d="M1.89,2.21 L-1.89,-2.21 " class="primitive"/>
    </g>
    <g transform="translate(96.35,88.75)">
      <path fill="none" d="M-0.74,0.59 L0.74,-0.59 " class="primitive"/>
    </g>
    <g transform="translate(99.13,89.29)">
      <path fill="none" d="M-3.19,0.45 L3.19,-0.45 " class="primitive"/>
    </g>
    <g transform="translate(35.6,23.61)">
      <path fill="none" d="M0.29,-2.5 L-0.29,2.5 " class="primitive"/>
    </g>
    <g transform="translate(35.31,15.55)">
      <path fill="none" d="M0.57,4.09 L-0.57,-4.09 " class="primitive"/>
    </g>
    <g transform="translate(32.86,16.93)">
      <path fill="none" d="M2.56,2.82 L-2.56,-2.82 " class="primitive"/>
    </g>
    <g transform="translate(35.16,16.44)">
      <path fill="none" d="M0.67,3.2 L-0.67,-3.2 " class="primitive"/>
    </g>
    <g transform="translate(40.81,24.25)">
      <path fill="none" d="M-4.14,-3.33 L4.14,3.33 " class="primitive"/>
    </g>
    <g transform="translate(42.13,18.66)">
      <path fill="none" d="M-5.19,1.44 L5.19,-1.44 " class="primitive"/>
    </g>
    <g transform="translate(31.24,24.07)">
      <path fill="none" d="M4.04,-3.15 L-4.04,3.15 " class="primitive"/>
    </g>
    <g transform="translate(40.02,16.6)">
      <path fill="none" d="M-3.42,3.18 L3.42,-3.18 " class="primitive"/>
    </g>
    <g transform="translate(67.28,90.58)">
      <path fill="none" d="M2.91,0.82 L-2.91,-0.82 " class="primitive"/>
    </g>
    <g transform="translate(27.83,79.34)">
      <path fill="none" d="M-1.17,-3.82 L1.17,3.82 " class="primitive"/>
    </g>
    <g transform="translate(29.53,77.65)">
      <path fill="none" d="M-2.45,-2.26 L2.45,2.26 " class="primitive"/>
    </g>
    <g transform="translate(27.79,73.19)">
      <path fill="none" d="M-0.81,0.97 L0.81,-0.97 " class="primitive"/>
    </g>
    <g transform="translate(25.32,73.02)">
      <path fill="none" d="M0.7,1.11 L-0.7,-1.11 " class="primitive"/>
    </g>
    <g transform="translate(29.57,77.97)">
      <path fill="none" d="M-2.52,-2.56 L2.52,2.56 " class="primitive"/>
    </g>
    <g transform="translate(23.35,76.22)">
      <path fill="none" d="M2.23,-1.02 L-2.23,1.02 " class="primitive"/>
    </g>
    <g transform="translate(42.01,28.52)">
      <path fill="none" d="M-5.8,-1.43 L5.8,1.43 " class="primitive"/>
    </g>
    <g transform="translate(40.43,27.49)">
      <path fill="none" d="M-4.18,-0.52 L4.18,0.52 " class="primitive"/>
    </g>
    <g transform="translate(30.86,27.31)">
      <path fill="none" d="M3.33,-0.35 L-3.33,0.35 " class="primitive"/>
    </g>
    <g transform="translate(23.56,85.93)">
      <path fill="none" d="M4.73,-1.71 L-4.73,1.71 " class="primitive"/>
    </g>
    <g transform="translate(30.91,82.19)">
      <path fill="none" d="M-1.09,1.09 L1.09,-1.09 " class="primitive"/>
    </g>
    <g transform="translate(30.95,82.51)">
      <path fill="none" d="M-1.04,0.83 L1.04,-0.83 " class="primitive"/>
    </g>
    <g transform="translate(24.73,80.76)">
      <path fill="none" d="M3.74,2.61 L-3.74,-2.61 " class="primitive"/>
    </g>
    <g transform="translate(104.64,35.13)">
      <path fill="none" d="M1.86,-1.15 L-1.86,1.15 " class="primitive"/>
    </g>
    <g transform="translate(107.86,28.3)">
      <path fill="none" d="M-0.5,4.46 L0.5,-4.46 " class="primitive"/>
    </g>
    <g transform="translate(113.77,31.43)">
      <path fill="none" d="M-5.54,1.76 L5.54,-1.76 " class="primitive"/>
    </g>
    <g transform="translate(109.29,33.36)">
      <path fill="none" d="M-0.97,0.06 L0.97,-0.06 " class="primitive"/>
    </g>
    <g transform="translate(31.85,60.78)">
      <path fill="none" d="M-1.57,-2.56 L1.57,2.56 " class="primitive"/>
    </g>
    <g transform="translate(31.37,54.12)">
      <path fill="none" d="M-1.2,2.72 L1.2,-2.72 " class="primitive"/>
    </g>
    <g transform="translate(29.35,59.83)">
      <path fill="none" d="M0.35,-1.56 L-0.35,1.56 " class="primitive"/>
    </g>
    <g transform="translate(14.88,87.38)">
      <path fill="none" d="M2.03,0.4 L-2.03,-0.4 " class="primitive"/>
    </g>
    <g transform="translate(17.72,89.78)">
      <path fill="none" d="M0.12,-1.07 L-0.12,1.07 " class="primitive"/>
    </g>
    <g transform="translate(19.08,82.81)">
      <path fill="none" d="M-1,4.44 L1,-4.44 " class="primitive"/>
    </g>
    <g transform="translate(111.26,52.95)">
      <path fill="none" d="M-0.38,0.83 L0.38,-0.83 " class="primitive"/>
    </g>
    <g transform="translate(111.74,53.87)">
      <path fill="none" d="M-0.34,0.18 L0.34,-0.18 " class="primitive"/>
    </g>
    <g transform="translate(114.02,54.27)">
      <path fill="none" d="M-2.42,0.15 L2.42,-0.15 " class="primitive"/>
    </g>
    <g transform="translate(69.15,47.21)">
      <path fill="none" d="M-4.47,-1.03 L4.47,1.03 " class="primitive"/>
    </g>
    <g transform="translate(64.69,48.93)">
      <path fill="none" d="M-0.76,-2.26 L0.76,2.26 " class="primitive"/>
    </g>
    <g transform="translate(62.79,43.82)">
      <path fill="none" d="M0.6,1.44 L-0.6,-1.44 " class="primitive"/>
    </g>
    <g transform="translate(32.19,12.11)">
      <path fill="none" d="M1.64,-0.92 L-1.64,0.92 " class="primitive"/>
    </g>
    <g transform="translate(34.49,11.62)">
      <path fill="none" d="M0.03,-0.16 L-0.03,0.16 " class="primitive"/>
    </g>
    <g transform="translate(39.36,11.78)">
      <path fill="none" d="M-3.72,-0.83 L3.72,0.83 " class="primitive"/>
    </g>
    <g transform="translate(79.17,48.62)">
      <path fill="none" d="M3.53,0.12 L-3.53,-0.12 " class="primitive"/>
    </g>
    <g transform="translate(88.97,48.98)">
      <path fill="none" d="M-4.19,-0.17 L4.19,0.17 " class="primitive"/>
    </g>
    <g transform="translate(81.44,49.95)">
      <path fill="none" d="M1.45,-0.75 L-1.45,0.75 " class="primitive"/>
    </g>
    <g transform="translate(83.57,52.6)">
      <path fill="none" d="M0.13,-3.1 L-0.13,3.1 " class="primitive"/>
    </g>
    <g transform="translate(39.18,63.82)">
      <path fill="none" d="M-4.31,0.15 L4.31,-0.15 " class="primitive"/>
    </g>
    <g transform="translate(40.33,62.12)">
      <path fill="none" d="M-5.54,1.61 L5.54,-1.61 " class="primitive"/>
    </g>
    <g transform="translate(31.48,67.8)">
      <path fill="none" d="M1.93,-3.12 L-1.93,3.12 " class="primitive"/>
    </g>
    <g transform="translate(29.02,67.62)">
      <path fill="none" d="M4.1,-3.08 L-4.1,3.08 " class="primitive"/>
    </g>
    <g transform="translate(31.34,63.07)">
      <path fill="none" d="M1.58,0.6 L-1.58,-0.6 " class="primitive"/>
    </g>
    <g transform="translate(47.66,62.65)">
      <path fill="none" d="M2.18,-0.68 L-2.18,0.68 " class="primitive"/>
    </g>
    <g transform="translate(48.82,60.95)">
      <path fill="none" d="M1.06,0.38 L-1.06,-0.38 " class="primitive"/>
    </g>
    <g transform="translate(52.76,58.22)">
      <path fill="none" d="M-1.57,2.76 L1.57,-2.76 " class="primitive"/>
    </g>
    <g transform="translate(65.88,78.97)">
      <path fill="none" d="M1.06,-0.31 L-1.06,0.31 " class="primitive"/>
    </g>
    <g transform="translate(71.86,76.98)">
      <path fill="none" d="M-3.01,1.08 L3.01,-1.08 " class="primitive"/>
    </g>
    <g transform="translate(60.68,78.09)">
      <path fill="none" d="M6.19,0.26 L-6.19,-0.26 " class="primitive"/>
    </g>
    <g transform="translate(70.15,50.19)">
      <path fill="none" d="M3.54,-1.37 L-3.54,1.37 " class="primitive"/>
    </g>
    <g transform="translate(76.87,49.8)">
      <path fill="none" d="M-1.47,-0.86 L1.47,0.86 " class="primitive"/>
    </g>
    <g transform="translate(79.01,52.45)">
      <path fill="none" d="M-3.76,-3.4 L3.76,3.4 " class="primitive"/>
    </g>
    <g transform="translate(59.96,25.58)">
      <path fill="none" d="M2.38,-2.12 L-2.38,2.12 " class="primitive"/>
    </g>
    <g transform="translate(62.06,19.46)">
      <path fill="none" d="M0.73,2.7 L-0.73,-2.7 " class="primitive"/>
    </g>
    <g transform="translate(57.67,79.6)">
      <path fill="none" d="M5.14,-0.04 L-5.14,0.04 " class="primitive"/>
    </g>
    <g transform="translate(69.83,77.56)">
      <path fill="none" d="M-5.03,1.68 L5.03,-1.68 " class="primitive"/>
    </g>
    <g transform="translate(58.65,78.67)">
      <path fill="none" d="M4.19,0.71 L-4.19,-0.71 " class="primitive"/>
    </g>
    <g transform="translate(63.63,84.52)">
      <path fill="none" d="M0.19,-4.23 L-0.19,4.23 " class="primitive"/>
    </g>
    <g transform="translate(30.87,76.04)">
      <path fill="none" d="M1.46,3.75 L-1.46,-3.75 " class="primitive"/>
    </g>
    <g transform="translate(32.65,80.82)">
      <path fill="none" d="M0.05,0.42 L-0.05,-0.42 " class="primitive"/>
    </g>
    <g transform="translate(26.43,79.07)">
      <path fill="none" d="M5.19,1.2 L-5.19,-1.2 " class="primitive"/>
    </g>
    <g transform="translate(52.47,78.72)">
      <path fill="none" d="M-0.36,0.34 L0.36,-0.34 " class="primitive"/>
    </g>
    <g transform="translate(50.32,80.91)">
      <path fill="none" d="M0.6,-0.65 L-0.6,0.65 " class="primitive"/>
    </g>
    <g transform="translate(60.2,53.34)">
      <path fill="none" d="M4.51,-1.18 L-4.51,1.18 " class="primitive"/>
    </g>
    <g transform="translate(72.42,51.52)">
      <path fill="none" d="M-5.69,0.33 L5.69,-0.33 " class="primitive"/>
    </g>
    <g transform="translate(32.04,13)">
      <path fill="none" d="M-1.3,0.28 L1.3,-0.28 " class="primitive"/>
    </g>
    <g transform="translate(36.91,13.17)">
      <path fill="none" d="M-6.12,0.28 L6.12,-0.28 " class="primitive"/>
    </g>
    <g transform="translate(45.68,61.93)">
      <path fill="none" d="M-0.7,1.03 L0.7,-1.03 " class="primitive"/>
    </g>
    <g transform="translate(106.65,34.99)">
      <path fill="none" d="M-3.73,1.42 L3.73,-1.42 " class="primitive"/>
    </g>
    <g transform="translate(109.7,21.41)">
      <path fill="none" d="M-0.78,1.05 L0.78,-1.05 " class="primitive"/>
    </g>
    <g transform="translate(114.35,26.24)">
      <path fill="none" d="M-5.08,-2.69 L5.08,2.69 " class="primitive"/>
    </g>
    <g transform="translate(109.87,28.17)">
      <path fill="none" d="M-1.23,-4.33 L1.23,4.33 " class="primitive"/>
    </g>
    <g transform="translate(14.69,89.19)">
      <path fill="none" d="M-2.17,-1.84 L2.17,1.84 " class="primitive"/>
    </g>
    <g transform="translate(50.77,57.5)">
      <path fill="none" d="M-3.2,2.21 L3.2,-2.21 " class="primitive"/>
    </g>
    <g transform="translate(100.56,88.15)">
      <path fill="none" d="M-1.78,-0.35 L1.78,0.35 " class="primitive"/>
    </g>
    <g transform="translate(49.72,30.85)">
      <path fill="none" d="M0.19,0.13 L-0.19,-0.13 " class="primitive"/>
    </g>
    <g transform="translate(48.14,29.82)">
      <path fill="none" d="M1.75,1.18 L-1.75,-1.18 " class="primitive"/>
    </g>
    <g transform="translate(53.79,29.89)">
      <path fill="none" d="M-2.3,1.18 L2.3,-1.18 " class="primitive"/>
    </g>
    <g transform="translate(51.3,79.98)">
      <path fill="none" d="M1.55,-1.59 L-1.55,1.59 " class="primitive"/>
    </g>
    <g transform="translate(124.36,32.62)">
      <path fill="none" d="M-3.4,-2.7 L3.4,2.7 " class="primitive"/>
    </g>
    <g transform="translate(115.78,31.3)">
      <path fill="none" d="M3.59,-1.54 L-3.59,1.54 " class="primitive"/>
    </g>
    <g transform="translate(26.66,71.41)">
      <path fill="none" d="M1.43,0.1 L-1.43,-0.1 " class="primitive"/>
    </g>
    <g transform="translate(30.91,76.36)">
      <path fill="none" d="M-1.51,-4.06 L1.51,4.06 " class="primitive"/>
    </g>
    <g transform="translate(24.69,74.61)">
      <path fill="none" d="M3.69,-2.51 L-3.69,2.51 " class="primitive"/>
    </g>
    <g transform="translate(28.99,66.86)">
      <path fill="none" d="M0.12,4 L-0.12,-4 " class="primitive"/>
    </g>
    <g transform="translate(73.46,13.5)">
      <path fill="none" d="M5.8,0.91 L-5.8,-0.91 " class="primitive"/>
    </g>
    <g transform="translate(21.83,26.91)">
      <path fill="none" d="M-3.66,-0.67 L3.66,0.67 " class="primitive"/>
    </g>
    <g transform="translate(47.22,29.17)">
      <path fill="none" d="M0.81,0.53 L-0.81,-0.53 " class="primitive"/>
    </g>
    <g transform="translate(52.86,29.24)">
      <path fill="none" d="M-3.08,0.73 L3.08,-0.73 " class="primitive"/>
    </g>
    <g transform="translate(22.22,74.44)">
      <path fill="none" d="M1.56,-2.53 L-1.56,2.53 " class="primitive"/>
    </g>
    <g transform="translate(26.52,66.68)">
      <path fill="none" d="M-1.97,3.86 L1.97,-3.86 " class="primitive"/>
    </g>
    <g transform="translate(39.2,12.67)">
      <path fill="none" d="M-3.83,-0.13 L3.83,0.13 " class="primitive"/>
    </g>
    <g transform="translate(51.29,28.21)">
      <path fill="none" d="M-4.61,-0.06 L4.61,0.06 " class="primitive"/>
    </g>
    <g transform="translate(54.71,16.5)">
      <path fill="none" d="M-5.38,0.39 L5.38,-0.39 " class="primitive"/>
    </g>
    <g transform="translate(46.18,14.9)">
      <path fill="none" d="M1.5,1.46 L-1.5,-1.46 " class="primitive"/>
    </g>
    <g transform="translate(26.47,79.39)">
      <path fill="none" d="M5.25,1.48 L-5.25,-1.48 " class="primitive"/>
    </g>
    <g transform="translate(112.44,52.34)">
      <path fill="none" d="M-0.12,-0.22 L0.12,0.22 " class="primitive"/>
    </g>
    <g transform="translate(114.72,52.74)">
      <path fill="none" d="M-1.89,-0.9 L1.89,0.9 " class="primitive"/>
    </g>
    <g transform="translate(63.89,14.23)">
      <path fill="none" d="M1.99,-1.31 L-1.99,1.31 " class="primitive"/>
    </g>
    <g transform="translate(115.19,53.66)">
      <path fill="none" d="M-1.27,-0.22 L1.27,0.22 " class="primitive"/>
    </g>
    <g transform="translate(81.28,53.78)">
      <path fill="none" d="M-1.62,-2.01 L1.62,2.01 " class="primitive"/>
    </g>
  </g>
  <g stroke-width="0.21" stroke="#000000" id="img-f380a6cc-3">
  </g>
  <g font-size="4" stroke="#000000" stroke-opacity="0.000" fill="#000000" id="img-f380a6cc-4">
  </g>
  <g stroke-width="0" stroke="#000000" stroke-opacity="0.000" id="img-f380a6cc-5">
    <g transform="translate(129.64,20.75)" fill="#FFC600">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(84.84,39.68)" fill="#FF3900">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(105.14,48.4)" fill="#FF5500">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(74.62,64.16)" fill="#FF3900">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(127.19,54.62)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(54.01,34.21)" fill="#FF5500">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(125.77,53.16)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(89.16,26.21)" fill="#FF7100">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(60.22,26.96)" fill="#FF7100">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(18.08,18.08)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(46.29,66.71)" fill="#FF7100">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(121.6,38.82)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(62.59,37.37)" fill="#FF3900">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(106.62,82.05)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(127.7,22.35)" fill="#FFC600">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(75.12,10.07)" fill="#FFC600">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(28.1,30.23)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(26.46,53.89)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(126.96,29.58)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(112.99,45.2)" fill="#FF7100">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(85.84,35.76)" fill="#FF5500">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(57.71,25.35)" fill="#FF7100">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(27.95,85.33)" fill="#FFC600">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(52.78,36.71)" fill="#FF5500">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(93.43,61.86)" fill="#FF3900">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(80.58,90.66)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(85.1,77.47)" fill="#FF7100">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(78.78,33.77)" fill="#FF5500">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(67.64,33.91)" fill="#FF5500">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(75.85,89.28)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(76.78,14.87)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(57.72,82.37)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(102.94,58.69)" fill="#FF5500">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(73.68,13.74)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(43.51,35.07)" fill="#FF7100">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(119.43,40.34)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(29.32,64.94)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(36.27,87.28)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(127.2,57.8)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(21.38,54.96)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(18.7,75.93)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(44.77,72.89)" fill="#FF7100">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(35.34,8.33)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(36.98,29.82)" fill="#FF7100">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(32.09,17.4)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(129.3,48.33)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(41.99,46.17)" fill="#FF7100">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(23.85,66.8)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(43.46,11.59)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(116.79,26.76)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(32.79,34.18)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(104.16,73.63)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(20.35,19.07)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(87.27,18.99)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(124.95,75.73)" fill="#FFE300">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(86.56,55.22)" fill="#FF3900">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(47.66,54.15)" fill="#FF5500">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(101.21,73.49)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(43.48,23.02)" fill="#FF7100">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(72.34,80.7)" fill="#FF7100">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(121.24,51.2)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(29.17,45.55)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(95.4,23.03)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(66.07,70.94)" fill="#FF5500">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(100.86,45.43)" fill="#FF5500">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(101.2,88.07)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(32.79,67.34)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(48.36,71.26)" fill="#FF7100">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(83.58,79.38)" fill="#FF7100">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(13.19,53.78)" fill="#FFC600">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(63.57,68.84)" fill="#FF5500">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(115.8,91.65)" fill="#FFC600">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(109.76,10.32)" fill="#FFC600">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(15.23,34.67)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(124.91,35.89)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(63.2,57.6)" fill="#FF3900">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(52.05,87.13)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(95.31,18.79)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(41.23,20.79)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(106.81,11.08)" fill="#FFC600">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(30.67,60.16)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(115.71,42.79)" fill="#FF7100">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(115.35,26.71)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(33.38,39.53)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(92.13,21.14)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(100.14,24.27)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(66.33,72.31)" fill="#FF5500">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(12.68,24.23)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(42.21,10.65)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(85.29,71.37)" fill="#FF5500">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(94.87,55.73)" fill="#FF3900">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(97.22,77.42)" fill="#FF7100">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(27.54,34.86)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(11.79,35.02)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(62.51,34.73)" fill="#FF5500">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(121.55,51.98)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(15.47,46.48)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(110.03,76.3)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(104.78,57.45)" fill="#FF5500">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(66.92,19.38)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(61.47,38.35)" fill="#FF3900">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(89.38,13.35)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(19.73,76.81)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(124.89,80.15)" fill="#FFC600">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(29.94,51.6)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(122.49,53.83)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(103.17,23.32)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(61.51,31.6)" fill="#FF5500">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(29.97,62.27)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(99.05,18.29)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(120.61,29.83)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(25.58,32.27)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(23.86,11.8)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(73.7,75.15)" fill="#FF7100">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(51.14,62.72)" fill="#FF5500">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(33.1,70.81)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(61.36,60.73)" fill="#FF3900">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(32.45,38.71)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(64.96,68.69)" fill="#FF5500">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(73.75,65.95)" fill="#FF5500">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(84.1,61.65)" fill="#FF3900">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(56.72,69.81)" fill="#FF5500">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(81.94,56.68)" fill="#FF1C00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(73.31,55.02)" fill="#FF1C00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(62.74,84.59)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(87.46,77.2)" fill="#FF7100">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(56.53,32.99)" fill="#FF5500">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(14.78,71.53)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(16.77,75.14)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(124.83,91.51)" fill="#FFC600">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(94.92,89.88)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(35.98,20.37)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(71.16,91.67)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(26.45,74.8)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(35.23,26.85)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(29.22,83.89)" fill="#FFC600">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(107.28,33.49)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(29.86,57.54)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(17.91,87.97)" fill="#FFC600">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(110.56,54.48)" fill="#FF7100">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(63.69,45.96)" fill="#FF1C00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(34.64,10.73)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(83.74,48.77)" fill="#FF1C00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(33.83,64.01)" fill="#FF7100">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(50.8,61.67)" fill="#FF5500">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(124.28,68.4)" fill="#FFFF00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(14.83,56.17)" fill="#FFC600">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(67.91,78.39)" fill="#FF7100">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(74.6,48.47)" fill="#0000FF">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(62.99,22.88)" fill="#FF7100">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(63.85,79.55)" fill="#FF7100">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(32.61,80.5)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(32.88,50.7)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(51.49,79.65)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(65.69,51.9)" fill="#FF1C00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(29.74,13.5)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(44.53,63.62)" fill="#FF7100">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(102,36.77)" fill="#FF7100">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(108.44,23.11)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(75.8,75.56)" fill="#FF7100">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(110.96,19.7)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(11.85,86.78)" fill="#FFE300">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(46.83,60.23)" fill="#FF5500">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(97.78,87.61)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(50.64,31.5)" fill="#FF5500">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(53.44,77.78)" fill="#FF7100">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(120.26,29.37)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(63.4,89.48)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(128.45,35.87)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(29.13,71.59)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(80.28,14.57)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(17.16,26.06)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(48.79,30.2)" fill="#FF7100">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(24.2,71.24)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(94.19,49.18)" fill="#FF3900">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(111.3,33.22)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(34.33,12.5)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(17.52,91.59)" fill="#FFE300">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(61.89,41.67)" fill="#FF3900">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(45.64,28.14)" fill="#FF7100">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(54.72,54.78)" fill="#FF3900">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(56.93,28.28)" fill="#FF5500">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(91.46,73.97)" fill="#FF7100">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(48.29,16.96)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(49.16,82.18)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(32.69,81.13)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(111.97,51.42)" fill="#FF7100">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(66.65,12.42)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(112.91,53.25)" fill="#FF7100">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(117.47,54.06)" fill="#FF7100">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(119.98,85.84)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(20.25,77.64)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(28.84,62.12)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(79.15,51.13)" fill="#FF1C00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(71.11,63.92)" fill="#FF3900">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(26.5,27.76)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(61.13,16.04)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(103.35,88.69)" fill="#FFAA00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(83.41,56.43)" fill="#FF1C00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
    <g transform="translate(44.07,12.84)" fill="#FF8E00">
      <circle cx="0" cy="0" r="1" class="primitive"/>
    </g>
  </g>
  <g font-size="4" stroke="#000000" stroke-opacity="0.000" fill="#000000" id="img-f380a6cc-6">
  </g>
</g>
<script> <![CDATA[
(function(N){var k=/[\.\/]/,L=/\s*,\s*/,C=function(a,d){return a-d},a,v,y={n:{}},M=function(){for(var a=0,d=this.length;a<d;a++)if("undefined"!=typeof this[a])return this[a]},A=function(){for(var a=this.length;--a;)if("undefined"!=typeof this[a])return this[a]},w=function(k,d){k=String(k);var f=v,n=Array.prototype.slice.call(arguments,2),u=w.listeners(k),p=0,b,q=[],e={},l=[],r=a;l.firstDefined=M;l.lastDefined=A;a=k;for(var s=v=0,x=u.length;s<x;s++)"zIndex"in u[s]&&(q.push(u[s].zIndex),0>u[s].zIndex&&
(e[u[s].zIndex]=u[s]));for(q.sort(C);0>q[p];)if(b=e[q[p++] ],l.push(b.apply(d,n)),v)return v=f,l;for(s=0;s<x;s++)if(b=u[s],"zIndex"in b)if(b.zIndex==q[p]){l.push(b.apply(d,n));if(v)break;do if(p++,(b=e[q[p] ])&&l.push(b.apply(d,n)),v)break;while(b)}else e[b.zIndex]=b;else if(l.push(b.apply(d,n)),v)break;v=f;a=r;return l};w._events=y;w.listeners=function(a){a=a.split(k);var d=y,f,n,u,p,b,q,e,l=[d],r=[];u=0;for(p=a.length;u<p;u++){e=[];b=0;for(q=l.length;b<q;b++)for(d=l[b].n,f=[d[a[u] ],d["*"] ],n=2;n--;)if(d=
f[n])e.push(d),r=r.concat(d.f||[]);l=e}return r};w.on=function(a,d){a=String(a);if("function"!=typeof d)return function(){};for(var f=a.split(L),n=0,u=f.length;n<u;n++)(function(a){a=a.split(k);for(var b=y,f,e=0,l=a.length;e<l;e++)b=b.n,b=b.hasOwnProperty(a[e])&&b[a[e] ]||(b[a[e] ]={n:{}});b.f=b.f||[];e=0;for(l=b.f.length;e<l;e++)if(b.f[e]==d){f=!0;break}!f&&b.f.push(d)})(f[n]);return function(a){+a==+a&&(d.zIndex=+a)}};w.f=function(a){var d=[].slice.call(arguments,1);return function(){w.apply(null,
[a,null].concat(d).concat([].slice.call(arguments,0)))}};w.stop=function(){v=1};w.nt=function(k){return k?(new RegExp("(?:\\.|\\/|^)"+k+"(?:\\.|\\/|$)")).test(a):a};w.nts=function(){return a.split(k)};w.off=w.unbind=function(a,d){if(a){var f=a.split(L);if(1<f.length)for(var n=0,u=f.length;n<u;n++)w.off(f[n],d);else{for(var f=a.split(k),p,b,q,e,l=[y],n=0,u=f.length;n<u;n++)for(e=0;e<l.length;e+=q.length-2){q=[e,1];p=l[e].n;if("*"!=f[n])p[f[n] ]&&q.push(p[f[n] ]);else for(b in p)p.hasOwnProperty(b)&&
q.push(p[b]);l.splice.apply(l,q)}n=0;for(u=l.length;n<u;n++)for(p=l[n];p.n;){if(d){if(p.f){e=0;for(f=p.f.length;e<f;e++)if(p.f[e]==d){p.f.splice(e,1);break}!p.f.length&&delete p.f}for(b in p.n)if(p.n.hasOwnProperty(b)&&p.n[b].f){q=p.n[b].f;e=0;for(f=q.length;e<f;e++)if(q[e]==d){q.splice(e,1);break}!q.length&&delete p.n[b].f}}else for(b in delete p.f,p.n)p.n.hasOwnProperty(b)&&p.n[b].f&&delete p.n[b].f;p=p.n}}}else w._events=y={n:{}}};w.once=function(a,d){var f=function(){w.unbind(a,f);return d.apply(this,
arguments)};return w.on(a,f)};w.version="0.4.2";w.toString=function(){return"You are running Eve 0.4.2"};"undefined"!=typeof module&&module.exports?module.exports=w:"function"===typeof define&&define.amd?define("eve",[],function(){return w}):N.eve=w})(this);
(function(N,k){"function"===typeof define&&define.amd?define("Snap.svg",["eve"],function(L){return k(N,L)}):k(N,N.eve)})(this,function(N,k){var L=function(a){var k={},y=N.requestAnimationFrame||N.webkitRequestAnimationFrame||N.mozRequestAnimationFrame||N.oRequestAnimationFrame||N.msRequestAnimationFrame||function(a){setTimeout(a,16)},M=Array.isArray||function(a){return a instanceof Array||"[object Array]"==Object.prototype.toString.call(a)},A=0,w="M"+(+new Date).toString(36),z=function(a){if(null==
a)return this.s;var b=this.s-a;this.b+=this.dur*b;this.B+=this.dur*b;this.s=a},d=function(a){if(null==a)return this.spd;this.spd=a},f=function(a){if(null==a)return this.dur;this.s=this.s*a/this.dur;this.dur=a},n=function(){delete k[this.id];this.update();a("mina.stop."+this.id,this)},u=function(){this.pdif||(delete k[this.id],this.update(),this.pdif=this.get()-this.b)},p=function(){this.pdif&&(this.b=this.get()-this.pdif,delete this.pdif,k[this.id]=this)},b=function(){var a;if(M(this.start)){a=[];
for(var b=0,e=this.start.length;b<e;b++)a[b]=+this.start[b]+(this.end[b]-this.start[b])*this.easing(this.s)}else a=+this.start+(this.end-this.start)*this.easing(this.s);this.set(a)},q=function(){var l=0,b;for(b in k)if(k.hasOwnProperty(b)){var e=k[b],f=e.get();l++;e.s=(f-e.b)/(e.dur/e.spd);1<=e.s&&(delete k[b],e.s=1,l--,function(b){setTimeout(function(){a("mina.finish."+b.id,b)})}(e));e.update()}l&&y(q)},e=function(a,r,s,x,G,h,J){a={id:w+(A++).toString(36),start:a,end:r,b:s,s:0,dur:x-s,spd:1,get:G,
set:h,easing:J||e.linear,status:z,speed:d,duration:f,stop:n,pause:u,resume:p,update:b};k[a.id]=a;r=0;for(var K in k)if(k.hasOwnProperty(K)&&(r++,2==r))break;1==r&&y(q);return a};e.time=Date.now||function(){return+new Date};e.getById=function(a){return k[a]||null};e.linear=function(a){return a};e.easeout=function(a){return Math.pow(a,1.7)};e.easein=function(a){return Math.pow(a,0.48)};e.easeinout=function(a){if(1==a)return 1;if(0==a)return 0;var b=0.48-a/1.04,e=Math.sqrt(0.1734+b*b);a=e-b;a=Math.pow(Math.abs(a),
1/3)*(0>a?-1:1);b=-e-b;b=Math.pow(Math.abs(b),1/3)*(0>b?-1:1);a=a+b+0.5;return 3*(1-a)*a*a+a*a*a};e.backin=function(a){return 1==a?1:a*a*(2.70158*a-1.70158)};e.backout=function(a){if(0==a)return 0;a-=1;return a*a*(2.70158*a+1.70158)+1};e.elastic=function(a){return a==!!a?a:Math.pow(2,-10*a)*Math.sin(2*(a-0.075)*Math.PI/0.3)+1};e.bounce=function(a){a<1/2.75?a*=7.5625*a:a<2/2.75?(a-=1.5/2.75,a=7.5625*a*a+0.75):a<2.5/2.75?(a-=2.25/2.75,a=7.5625*a*a+0.9375):(a-=2.625/2.75,a=7.5625*a*a+0.984375);return a};
return N.mina=e}("undefined"==typeof k?function(){}:k),C=function(){function a(c,t){if(c){if(c.tagName)return x(c);if(y(c,"array")&&a.set)return a.set.apply(a,c);if(c instanceof e)return c;if(null==t)return c=G.doc.querySelector(c),x(c)}return new s(null==c?"100%":c,null==t?"100%":t)}function v(c,a){if(a){"#text"==c&&(c=G.doc.createTextNode(a.text||""));"string"==typeof c&&(c=v(c));if("string"==typeof a)return"xlink:"==a.substring(0,6)?c.getAttributeNS(m,a.substring(6)):"xml:"==a.substring(0,4)?c.getAttributeNS(la,
a.substring(4)):c.getAttribute(a);for(var da in a)if(a[h](da)){var b=J(a[da]);b?"xlink:"==da.substring(0,6)?c.setAttributeNS(m,da.substring(6),b):"xml:"==da.substring(0,4)?c.setAttributeNS(la,da.substring(4),b):c.setAttribute(da,b):c.removeAttribute(da)}}else c=G.doc.createElementNS(la,c);return c}function y(c,a){a=J.prototype.toLowerCase.call(a);return"finite"==a?isFinite(c):"array"==a&&(c instanceof Array||Array.isArray&&Array.isArray(c))?!0:"null"==a&&null===c||a==typeof c&&null!==c||"object"==
a&&c===Object(c)||$.call(c).slice(8,-1).toLowerCase()==a}function M(c){if("function"==typeof c||Object(c)!==c)return c;var a=new c.constructor,b;for(b in c)c[h](b)&&(a[b]=M(c[b]));return a}function A(c,a,b){function m(){var e=Array.prototype.slice.call(arguments,0),f=e.join("\u2400"),d=m.cache=m.cache||{},l=m.count=m.count||[];if(d[h](f)){a:for(var e=l,l=f,B=0,H=e.length;B<H;B++)if(e[B]===l){e.push(e.splice(B,1)[0]);break a}return b?b(d[f]):d[f]}1E3<=l.length&&delete d[l.shift()];l.push(f);d[f]=c.apply(a,
e);return b?b(d[f]):d[f]}return m}function w(c,a,b,m,e,f){return null==e?(c-=b,a-=m,c||a?(180*I.atan2(-a,-c)/C+540)%360:0):w(c,a,e,f)-w(b,m,e,f)}function z(c){return c%360*C/180}function d(c){var a=[];c=c.replace(/(?:^|\s)(\w+)\(([^)]+)\)/g,function(c,b,m){m=m.split(/\s*,\s*|\s+/);"rotate"==b&&1==m.length&&m.push(0,0);"scale"==b&&(2<m.length?m=m.slice(0,2):2==m.length&&m.push(0,0),1==m.length&&m.push(m[0],0,0));"skewX"==b?a.push(["m",1,0,I.tan(z(m[0])),1,0,0]):"skewY"==b?a.push(["m",1,I.tan(z(m[0])),
0,1,0,0]):a.push([b.charAt(0)].concat(m));return c});return a}function f(c,t){var b=O(c),m=new a.Matrix;if(b)for(var e=0,f=b.length;e<f;e++){var h=b[e],d=h.length,B=J(h[0]).toLowerCase(),H=h[0]!=B,l=H?m.invert():0,E;"t"==B&&2==d?m.translate(h[1],0):"t"==B&&3==d?H?(d=l.x(0,0),B=l.y(0,0),H=l.x(h[1],h[2]),l=l.y(h[1],h[2]),m.translate(H-d,l-B)):m.translate(h[1],h[2]):"r"==B?2==d?(E=E||t,m.rotate(h[1],E.x+E.width/2,E.y+E.height/2)):4==d&&(H?(H=l.x(h[2],h[3]),l=l.y(h[2],h[3]),m.rotate(h[1],H,l)):m.rotate(h[1],
h[2],h[3])):"s"==B?2==d||3==d?(E=E||t,m.scale(h[1],h[d-1],E.x+E.width/2,E.y+E.height/2)):4==d?H?(H=l.x(h[2],h[3]),l=l.y(h[2],h[3]),m.scale(h[1],h[1],H,l)):m.scale(h[1],h[1],h[2],h[3]):5==d&&(H?(H=l.x(h[3],h[4]),l=l.y(h[3],h[4]),m.scale(h[1],h[2],H,l)):m.scale(h[1],h[2],h[3],h[4])):"m"==B&&7==d&&m.add(h[1],h[2],h[3],h[4],h[5],h[6])}return m}function n(c,t){if(null==t){var m=!0;t="linearGradient"==c.type||"radialGradient"==c.type?c.node.getAttribute("gradientTransform"):"pattern"==c.type?c.node.getAttribute("patternTransform"):
c.node.getAttribute("transform");if(!t)return new a.Matrix;t=d(t)}else t=a._.rgTransform.test(t)?J(t).replace(/\.{3}|\u2026/g,c._.transform||aa):d(t),y(t,"array")&&(t=a.path?a.path.toString.call(t):J(t)),c._.transform=t;var b=f(t,c.getBBox(1));if(m)return b;c.matrix=b}function u(c){c=c.node.ownerSVGElement&&x(c.node.ownerSVGElement)||c.node.parentNode&&x(c.node.parentNode)||a.select("svg")||a(0,0);var t=c.select("defs"),t=null==t?!1:t.node;t||(t=r("defs",c.node).node);return t}function p(c){return c.node.ownerSVGElement&&
x(c.node.ownerSVGElement)||a.select("svg")}function b(c,a,m){function b(c){if(null==c)return aa;if(c==+c)return c;v(B,{width:c});try{return B.getBBox().width}catch(a){return 0}}function h(c){if(null==c)return aa;if(c==+c)return c;v(B,{height:c});try{return B.getBBox().height}catch(a){return 0}}function e(b,B){null==a?d[b]=B(c.attr(b)||0):b==a&&(d=B(null==m?c.attr(b)||0:m))}var f=p(c).node,d={},B=f.querySelector(".svg---mgr");B||(B=v("rect"),v(B,{x:-9E9,y:-9E9,width:10,height:10,"class":"svg---mgr",
fill:"none"}),f.appendChild(B));switch(c.type){case "rect":e("rx",b),e("ry",h);case "image":e("width",b),e("height",h);case "text":e("x",b);e("y",h);break;case "circle":e("cx",b);e("cy",h);e("r",b);break;case "ellipse":e("cx",b);e("cy",h);e("rx",b);e("ry",h);break;case "line":e("x1",b);e("x2",b);e("y1",h);e("y2",h);break;case "marker":e("refX",b);e("markerWidth",b);e("refY",h);e("markerHeight",h);break;case "radialGradient":e("fx",b);e("fy",h);break;case "tspan":e("dx",b);e("dy",h);break;default:e(a,
b)}f.removeChild(B);return d}function q(c){y(c,"array")||(c=Array.prototype.slice.call(arguments,0));for(var a=0,b=0,m=this.node;this[a];)delete this[a++];for(a=0;a<c.length;a++)"set"==c[a].type?c[a].forEach(function(c){m.appendChild(c.node)}):m.appendChild(c[a].node);for(var h=m.childNodes,a=0;a<h.length;a++)this[b++]=x(h[a]);return this}function e(c){if(c.snap in E)return E[c.snap];var a=this.id=V(),b;try{b=c.ownerSVGElement}catch(m){}this.node=c;b&&(this.paper=new s(b));this.type=c.tagName;this.anims=
{};this._={transform:[]};c.snap=a;E[a]=this;"g"==this.type&&(this.add=q);if(this.type in{g:1,mask:1,pattern:1})for(var e in s.prototype)s.prototype[h](e)&&(this[e]=s.prototype[e])}function l(c){this.node=c}function r(c,a){var b=v(c);a.appendChild(b);return x(b)}function s(c,a){var b,m,f,d=s.prototype;if(c&&"svg"==c.tagName){if(c.snap in E)return E[c.snap];var l=c.ownerDocument;b=new e(c);m=c.getElementsByTagName("desc")[0];f=c.getElementsByTagName("defs")[0];m||(m=v("desc"),m.appendChild(l.createTextNode("Created with Snap")),
b.node.appendChild(m));f||(f=v("defs"),b.node.appendChild(f));b.defs=f;for(var ca in d)d[h](ca)&&(b[ca]=d[ca]);b.paper=b.root=b}else b=r("svg",G.doc.body),v(b.node,{height:a,version:1.1,width:c,xmlns:la});return b}function x(c){return!c||c instanceof e||c instanceof l?c:c.tagName&&"svg"==c.tagName.toLowerCase()?new s(c):c.tagName&&"object"==c.tagName.toLowerCase()&&"image/svg+xml"==c.type?new s(c.contentDocument.getElementsByTagName("svg")[0]):new e(c)}a.version="0.3.0";a.toString=function(){return"Snap v"+
this.version};a._={};var G={win:N,doc:N.document};a._.glob=G;var h="hasOwnProperty",J=String,K=parseFloat,U=parseInt,I=Math,P=I.max,Q=I.min,Y=I.abs,C=I.PI,aa="",$=Object.prototype.toString,F=/^\s*((#[a-f\d]{6})|(#[a-f\d]{3})|rgba?\(\s*([\d\.]+%?\s*,\s*[\d\.]+%?\s*,\s*[\d\.]+%?(?:\s*,\s*[\d\.]+%?)?)\s*\)|hsba?\(\s*([\d\.]+(?:deg|\xb0|%)?\s*,\s*[\d\.]+%?\s*,\s*[\d\.]+(?:%?\s*,\s*[\d\.]+)?%?)\s*\)|hsla?\(\s*([\d\.]+(?:deg|\xb0|%)?\s*,\s*[\d\.]+%?\s*,\s*[\d\.]+(?:%?\s*,\s*[\d\.]+)?%?)\s*\))\s*$/i;a._.separator=
RegExp("[,\t\n\x0B\f\r \u00a0\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000\u2028\u2029]+");var S=RegExp("[\t\n\x0B\f\r \u00a0\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000\u2028\u2029]*,[\t\n\x0B\f\r \u00a0\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000\u2028\u2029]*"),X={hs:1,rg:1},W=RegExp("([a-z])[\t\n\x0B\f\r \u00a0\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000\u2028\u2029,]*((-?\\d*\\.?\\d*(?:e[\\-+]?\\d+)?[\t\n\x0B\f\r \u00a0\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000\u2028\u2029]*,?[\t\n\x0B\f\r \u00a0\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000\u2028\u2029]*)+)",
"ig"),ma=RegExp("([rstm])[\t\n\x0B\f\r \u00a0\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000\u2028\u2029,]*((-?\\d*\\.?\\d*(?:e[\\-+]?\\d+)?[\t\n\x0B\f\r \u00a0\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000\u2028\u2029]*,?[\t\n\x0B\f\r \u00a0\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000\u2028\u2029]*)+)","ig"),Z=RegExp("(-?\\d*\\.?\\d*(?:e[\\-+]?\\d+)?)[\t\n\x0B\f\r \u00a0\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000\u2028\u2029]*,?[\t\n\x0B\f\r \u00a0\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000\u2028\u2029]*",
"ig"),na=0,ba="S"+(+new Date).toString(36),V=function(){return ba+(na++).toString(36)},m="http://www.w3.org/1999/xlink",la="http://www.w3.org/2000/svg",E={},ca=a.url=function(c){return"url('#"+c+"')"};a._.$=v;a._.id=V;a.format=function(){var c=/\{([^\}]+)\}/g,a=/(?:(?:^|\.)(.+?)(?=\[|\.|$|\()|\[('|")(.+?)\2\])(\(\))?/g,b=function(c,b,m){var h=m;b.replace(a,function(c,a,b,m,t){a=a||m;h&&(a in h&&(h=h[a]),"function"==typeof h&&t&&(h=h()))});return h=(null==h||h==m?c:h)+""};return function(a,m){return J(a).replace(c,
function(c,a){return b(c,a,m)})}}();a._.clone=M;a._.cacher=A;a.rad=z;a.deg=function(c){return 180*c/C%360};a.angle=w;a.is=y;a.snapTo=function(c,a,b){b=y(b,"finite")?b:10;if(y(c,"array"))for(var m=c.length;m--;){if(Y(c[m]-a)<=b)return c[m]}else{c=+c;m=a%c;if(m<b)return a-m;if(m>c-b)return a-m+c}return a};a.getRGB=A(function(c){if(!c||(c=J(c)).indexOf("-")+1)return{r:-1,g:-1,b:-1,hex:"none",error:1,toString:ka};if("none"==c)return{r:-1,g:-1,b:-1,hex:"none",toString:ka};!X[h](c.toLowerCase().substring(0,
2))&&"#"!=c.charAt()&&(c=T(c));if(!c)return{r:-1,g:-1,b:-1,hex:"none",error:1,toString:ka};var b,m,e,f,d;if(c=c.match(F)){c[2]&&(e=U(c[2].substring(5),16),m=U(c[2].substring(3,5),16),b=U(c[2].substring(1,3),16));c[3]&&(e=U((d=c[3].charAt(3))+d,16),m=U((d=c[3].charAt(2))+d,16),b=U((d=c[3].charAt(1))+d,16));c[4]&&(d=c[4].split(S),b=K(d[0]),"%"==d[0].slice(-1)&&(b*=2.55),m=K(d[1]),"%"==d[1].slice(-1)&&(m*=2.55),e=K(d[2]),"%"==d[2].slice(-1)&&(e*=2.55),"rgba"==c[1].toLowerCase().slice(0,4)&&(f=K(d[3])),
d[3]&&"%"==d[3].slice(-1)&&(f/=100));if(c[5])return d=c[5].split(S),b=K(d[0]),"%"==d[0].slice(-1)&&(b/=100),m=K(d[1]),"%"==d[1].slice(-1)&&(m/=100),e=K(d[2]),"%"==d[2].slice(-1)&&(e/=100),"deg"!=d[0].slice(-3)&&"\u00b0"!=d[0].slice(-1)||(b/=360),"hsba"==c[1].toLowerCase().slice(0,4)&&(f=K(d[3])),d[3]&&"%"==d[3].slice(-1)&&(f/=100),a.hsb2rgb(b,m,e,f);if(c[6])return d=c[6].split(S),b=K(d[0]),"%"==d[0].slice(-1)&&(b/=100),m=K(d[1]),"%"==d[1].slice(-1)&&(m/=100),e=K(d[2]),"%"==d[2].slice(-1)&&(e/=100),
"deg"!=d[0].slice(-3)&&"\u00b0"!=d[0].slice(-1)||(b/=360),"hsla"==c[1].toLowerCase().slice(0,4)&&(f=K(d[3])),d[3]&&"%"==d[3].slice(-1)&&(f/=100),a.hsl2rgb(b,m,e,f);b=Q(I.round(b),255);m=Q(I.round(m),255);e=Q(I.round(e),255);f=Q(P(f,0),1);c={r:b,g:m,b:e,toString:ka};c.hex="#"+(16777216|e|m<<8|b<<16).toString(16).slice(1);c.opacity=y(f,"finite")?f:1;return c}return{r:-1,g:-1,b:-1,hex:"none",error:1,toString:ka}},a);a.hsb=A(function(c,b,m){return a.hsb2rgb(c,b,m).hex});a.hsl=A(function(c,b,m){return a.hsl2rgb(c,
b,m).hex});a.rgb=A(function(c,a,b,m){if(y(m,"finite")){var e=I.round;return"rgba("+[e(c),e(a),e(b),+m.toFixed(2)]+")"}return"#"+(16777216|b|a<<8|c<<16).toString(16).slice(1)});var T=function(c){var a=G.doc.getElementsByTagName("head")[0]||G.doc.getElementsByTagName("svg")[0];T=A(function(c){if("red"==c.toLowerCase())return"rgb(255, 0, 0)";a.style.color="rgb(255, 0, 0)";a.style.color=c;c=G.doc.defaultView.getComputedStyle(a,aa).getPropertyValue("color");return"rgb(255, 0, 0)"==c?null:c});return T(c)},
qa=function(){return"hsb("+[this.h,this.s,this.b]+")"},ra=function(){return"hsl("+[this.h,this.s,this.l]+")"},ka=function(){return 1==this.opacity||null==this.opacity?this.hex:"rgba("+[this.r,this.g,this.b,this.opacity]+")"},D=function(c,b,m){null==b&&y(c,"object")&&"r"in c&&"g"in c&&"b"in c&&(m=c.b,b=c.g,c=c.r);null==b&&y(c,string)&&(m=a.getRGB(c),c=m.r,b=m.g,m=m.b);if(1<c||1<b||1<m)c/=255,b/=255,m/=255;return[c,b,m]},oa=function(c,b,m,e){c=I.round(255*c);b=I.round(255*b);m=I.round(255*m);c={r:c,
g:b,b:m,opacity:y(e,"finite")?e:1,hex:a.rgb(c,b,m),toString:ka};y(e,"finite")&&(c.opacity=e);return c};a.color=function(c){var b;y(c,"object")&&"h"in c&&"s"in c&&"b"in c?(b=a.hsb2rgb(c),c.r=b.r,c.g=b.g,c.b=b.b,c.opacity=1,c.hex=b.hex):y(c,"object")&&"h"in c&&"s"in c&&"l"in c?(b=a.hsl2rgb(c),c.r=b.r,c.g=b.g,c.b=b.b,c.opacity=1,c.hex=b.hex):(y(c,"string")&&(c=a.getRGB(c)),y(c,"object")&&"r"in c&&"g"in c&&"b"in c&&!("error"in c)?(b=a.rgb2hsl(c),c.h=b.h,c.s=b.s,c.l=b.l,b=a.rgb2hsb(c),c.v=b.b):(c={hex:"none"},
c.r=c.g=c.b=c.h=c.s=c.v=c.l=-1,c.error=1));c.toString=ka;return c};a.hsb2rgb=function(c,a,b,m){y(c,"object")&&"h"in c&&"s"in c&&"b"in c&&(b=c.b,a=c.s,c=c.h,m=c.o);var e,h,d;c=360*c%360/60;d=b*a;a=d*(1-Y(c%2-1));b=e=h=b-d;c=~~c;b+=[d,a,0,0,a,d][c];e+=[a,d,d,a,0,0][c];h+=[0,0,a,d,d,a][c];return oa(b,e,h,m)};a.hsl2rgb=function(c,a,b,m){y(c,"object")&&"h"in c&&"s"in c&&"l"in c&&(b=c.l,a=c.s,c=c.h);if(1<c||1<a||1<b)c/=360,a/=100,b/=100;var e,h,d;c=360*c%360/60;d=2*a*(0.5>b?b:1-b);a=d*(1-Y(c%2-1));b=e=
h=b-d/2;c=~~c;b+=[d,a,0,0,a,d][c];e+=[a,d,d,a,0,0][c];h+=[0,0,a,d,d,a][c];return oa(b,e,h,m)};a.rgb2hsb=function(c,a,b){b=D(c,a,b);c=b[0];a=b[1];b=b[2];var m,e;m=P(c,a,b);e=m-Q(c,a,b);c=((0==e?0:m==c?(a-b)/e:m==a?(b-c)/e+2:(c-a)/e+4)+360)%6*60/360;return{h:c,s:0==e?0:e/m,b:m,toString:qa}};a.rgb2hsl=function(c,a,b){b=D(c,a,b);c=b[0];a=b[1];b=b[2];var m,e,h;m=P(c,a,b);e=Q(c,a,b);h=m-e;c=((0==h?0:m==c?(a-b)/h:m==a?(b-c)/h+2:(c-a)/h+4)+360)%6*60/360;m=(m+e)/2;return{h:c,s:0==h?0:0.5>m?h/(2*m):h/(2-2*
m),l:m,toString:ra}};a.parsePathString=function(c){if(!c)return null;var b=a.path(c);if(b.arr)return a.path.clone(b.arr);var m={a:7,c:6,o:2,h:1,l:2,m:2,r:4,q:4,s:4,t:2,v:1,u:3,z:0},e=[];y(c,"array")&&y(c[0],"array")&&(e=a.path.clone(c));e.length||J(c).replace(W,function(c,a,b){var h=[];c=a.toLowerCase();b.replace(Z,function(c,a){a&&h.push(+a)});"m"==c&&2<h.length&&(e.push([a].concat(h.splice(0,2))),c="l",a="m"==a?"l":"L");"o"==c&&1==h.length&&e.push([a,h[0] ]);if("r"==c)e.push([a].concat(h));else for(;h.length>=
m[c]&&(e.push([a].concat(h.splice(0,m[c]))),m[c]););});e.toString=a.path.toString;b.arr=a.path.clone(e);return e};var O=a.parseTransformString=function(c){if(!c)return null;var b=[];y(c,"array")&&y(c[0],"array")&&(b=a.path.clone(c));b.length||J(c).replace(ma,function(c,a,m){var e=[];a.toLowerCase();m.replace(Z,function(c,a){a&&e.push(+a)});b.push([a].concat(e))});b.toString=a.path.toString;return b};a._.svgTransform2string=d;a._.rgTransform=RegExp("^[a-z][\t\n\x0B\f\r \u00a0\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000\u2028\u2029]*-?\\.?\\d",
"i");a._.transform2matrix=f;a._unit2px=b;a._.getSomeDefs=u;a._.getSomeSVG=p;a.select=function(c){return x(G.doc.querySelector(c))};a.selectAll=function(c){c=G.doc.querySelectorAll(c);for(var b=(a.set||Array)(),m=0;m<c.length;m++)b.push(x(c[m]));return b};setInterval(function(){for(var c in E)if(E[h](c)){var a=E[c],b=a.node;("svg"!=a.type&&!b.ownerSVGElement||"svg"==a.type&&(!b.parentNode||"ownerSVGElement"in b.parentNode&&!b.ownerSVGElement))&&delete E[c]}},1E4);(function(c){function m(c){function a(c,
b){var m=v(c.node,b);(m=(m=m&&m.match(d))&&m[2])&&"#"==m.charAt()&&(m=m.substring(1))&&(f[m]=(f[m]||[]).concat(function(a){var m={};m[b]=ca(a);v(c.node,m)}))}function b(c){var a=v(c.node,"xlink:href");a&&"#"==a.charAt()&&(a=a.substring(1))&&(f[a]=(f[a]||[]).concat(function(a){c.attr("xlink:href","#"+a)}))}var e=c.selectAll("*"),h,d=/^\s*url\(("|'|)(.*)\1\)\s*$/;c=[];for(var f={},l=0,E=e.length;l<E;l++){h=e[l];a(h,"fill");a(h,"stroke");a(h,"filter");a(h,"mask");a(h,"clip-path");b(h);var t=v(h.node,
"id");t&&(v(h.node,{id:h.id}),c.push({old:t,id:h.id}))}l=0;for(E=c.length;l<E;l++)if(e=f[c[l].old])for(h=0,t=e.length;h<t;h++)e[h](c[l].id)}function e(c,a,b){return function(m){m=m.slice(c,a);1==m.length&&(m=m[0]);return b?b(m):m}}function d(c){return function(){var a=c?"<"+this.type:"",b=this.node.attributes,m=this.node.childNodes;if(c)for(var e=0,h=b.length;e<h;e++)a+=" "+b[e].name+'="'+b[e].value.replace(/"/g,'\\"')+'"';if(m.length){c&&(a+=">");e=0;for(h=m.length;e<h;e++)3==m[e].nodeType?a+=m[e].nodeValue:
1==m[e].nodeType&&(a+=x(m[e]).toString());c&&(a+="</"+this.type+">")}else c&&(a+="/>");return a}}c.attr=function(c,a){if(!c)return this;if(y(c,"string"))if(1<arguments.length){var b={};b[c]=a;c=b}else return k("snap.util.getattr."+c,this).firstDefined();for(var m in c)c[h](m)&&k("snap.util.attr."+m,this,c[m]);return this};c.getBBox=function(c){if(!a.Matrix||!a.path)return this.node.getBBox();var b=this,m=new a.Matrix;if(b.removed)return a._.box();for(;"use"==b.type;)if(c||(m=m.add(b.transform().localMatrix.translate(b.attr("x")||
0,b.attr("y")||0))),b.original)b=b.original;else var e=b.attr("xlink:href"),b=b.original=b.node.ownerDocument.getElementById(e.substring(e.indexOf("#")+1));var e=b._,h=a.path.get[b.type]||a.path.get.deflt;try{if(c)return e.bboxwt=h?a.path.getBBox(b.realPath=h(b)):a._.box(b.node.getBBox()),a._.box(e.bboxwt);b.realPath=h(b);b.matrix=b.transform().localMatrix;e.bbox=a.path.getBBox(a.path.map(b.realPath,m.add(b.matrix)));return a._.box(e.bbox)}catch(d){return a._.box()}};var f=function(){return this.string};
c.transform=function(c){var b=this._;if(null==c){var m=this;c=new a.Matrix(this.node.getCTM());for(var e=n(this),h=[e],d=new a.Matrix,l=e.toTransformString(),b=J(e)==J(this.matrix)?J(b.transform):l;"svg"!=m.type&&(m=m.parent());)h.push(n(m));for(m=h.length;m--;)d.add(h[m]);return{string:b,globalMatrix:c,totalMatrix:d,localMatrix:e,diffMatrix:c.clone().add(e.invert()),global:c.toTransformString(),total:d.toTransformString(),local:l,toString:f}}c instanceof a.Matrix?this.matrix=c:n(this,c);this.node&&
("linearGradient"==this.type||"radialGradient"==this.type?v(this.node,{gradientTransform:this.matrix}):"pattern"==this.type?v(this.node,{patternTransform:this.matrix}):v(this.node,{transform:this.matrix}));return this};c.parent=function(){return x(this.node.parentNode)};c.append=c.add=function(c){if(c){if("set"==c.type){var a=this;c.forEach(function(c){a.add(c)});return this}c=x(c);this.node.appendChild(c.node);c.paper=this.paper}return this};c.appendTo=function(c){c&&(c=x(c),c.append(this));return this};
c.prepend=function(c){if(c){if("set"==c.type){var a=this,b;c.forEach(function(c){b?b.after(c):a.prepend(c);b=c});return this}c=x(c);var m=c.parent();this.node.insertBefore(c.node,this.node.firstChild);this.add&&this.add();c.paper=this.paper;this.parent()&&this.parent().add();m&&m.add()}return this};c.prependTo=function(c){c=x(c);c.prepend(this);return this};c.before=function(c){if("set"==c.type){var a=this;c.forEach(function(c){var b=c.parent();a.node.parentNode.insertBefore(c.node,a.node);b&&b.add()});
this.parent().add();return this}c=x(c);var b=c.parent();this.node.parentNode.insertBefore(c.node,this.node);this.parent()&&this.parent().add();b&&b.add();c.paper=this.paper;return this};c.after=function(c){c=x(c);var a=c.parent();this.node.nextSibling?this.node.parentNode.insertBefore(c.node,this.node.nextSibling):this.node.parentNode.appendChild(c.node);this.parent()&&this.parent().add();a&&a.add();c.paper=this.paper;return this};c.insertBefore=function(c){c=x(c);var a=this.parent();c.node.parentNode.insertBefore(this.node,
c.node);this.paper=c.paper;a&&a.add();c.parent()&&c.parent().add();return this};c.insertAfter=function(c){c=x(c);var a=this.parent();c.node.parentNode.insertBefore(this.node,c.node.nextSibling);this.paper=c.paper;a&&a.add();c.parent()&&c.parent().add();return this};c.remove=function(){var c=this.parent();this.node.parentNode&&this.node.parentNode.removeChild(this.node);delete this.paper;this.removed=!0;c&&c.add();return this};c.select=function(c){return x(this.node.querySelector(c))};c.selectAll=
function(c){c=this.node.querySelectorAll(c);for(var b=(a.set||Array)(),m=0;m<c.length;m++)b.push(x(c[m]));return b};c.asPX=function(c,a){null==a&&(a=this.attr(c));return+b(this,c,a)};c.use=function(){var c,a=this.node.id;a||(a=this.id,v(this.node,{id:a}));c="linearGradient"==this.type||"radialGradient"==this.type||"pattern"==this.type?r(this.type,this.node.parentNode):r("use",this.node.parentNode);v(c.node,{"xlink:href":"#"+a});c.original=this;return c};var l=/\S+/g;c.addClass=function(c){var a=(c||
"").match(l)||[];c=this.node;var b=c.className.baseVal,m=b.match(l)||[],e,h,d;if(a.length){for(e=0;d=a[e++];)h=m.indexOf(d),~h||m.push(d);a=m.join(" ");b!=a&&(c.className.baseVal=a)}return this};c.removeClass=function(c){var a=(c||"").match(l)||[];c=this.node;var b=c.className.baseVal,m=b.match(l)||[],e,h;if(m.length){for(e=0;h=a[e++];)h=m.indexOf(h),~h&&m.splice(h,1);a=m.join(" ");b!=a&&(c.className.baseVal=a)}return this};c.hasClass=function(c){return!!~(this.node.className.baseVal.match(l)||[]).indexOf(c)};
c.toggleClass=function(c,a){if(null!=a)return a?this.addClass(c):this.removeClass(c);var b=(c||"").match(l)||[],m=this.node,e=m.className.baseVal,h=e.match(l)||[],d,f,E;for(d=0;E=b[d++];)f=h.indexOf(E),~f?h.splice(f,1):h.push(E);b=h.join(" ");e!=b&&(m.className.baseVal=b);return this};c.clone=function(){var c=x(this.node.cloneNode(!0));v(c.node,"id")&&v(c.node,{id:c.id});m(c);c.insertAfter(this);return c};c.toDefs=function(){u(this).appendChild(this.node);return this};c.pattern=c.toPattern=function(c,
a,b,m){var e=r("pattern",u(this));null==c&&(c=this.getBBox());y(c,"object")&&"x"in c&&(a=c.y,b=c.width,m=c.height,c=c.x);v(e.node,{x:c,y:a,width:b,height:m,patternUnits:"userSpaceOnUse",id:e.id,viewBox:[c,a,b,m].join(" ")});e.node.appendChild(this.node);return e};c.marker=function(c,a,b,m,e,h){var d=r("marker",u(this));null==c&&(c=this.getBBox());y(c,"object")&&"x"in c&&(a=c.y,b=c.width,m=c.height,e=c.refX||c.cx,h=c.refY||c.cy,c=c.x);v(d.node,{viewBox:[c,a,b,m].join(" "),markerWidth:b,markerHeight:m,
orient:"auto",refX:e||0,refY:h||0,id:d.id});d.node.appendChild(this.node);return d};var E=function(c,a,b,m){"function"!=typeof b||b.length||(m=b,b=L.linear);this.attr=c;this.dur=a;b&&(this.easing=b);m&&(this.callback=m)};a._.Animation=E;a.animation=function(c,a,b,m){return new E(c,a,b,m)};c.inAnim=function(){var c=[],a;for(a in this.anims)this.anims[h](a)&&function(a){c.push({anim:new E(a._attrs,a.dur,a.easing,a._callback),mina:a,curStatus:a.status(),status:function(c){return a.status(c)},stop:function(){a.stop()}})}(this.anims[a]);
return c};a.animate=function(c,a,b,m,e,h){"function"!=typeof e||e.length||(h=e,e=L.linear);var d=L.time();c=L(c,a,d,d+m,L.time,b,e);h&&k.once("mina.finish."+c.id,h);return c};c.stop=function(){for(var c=this.inAnim(),a=0,b=c.length;a<b;a++)c[a].stop();return this};c.animate=function(c,a,b,m){"function"!=typeof b||b.length||(m=b,b=L.linear);c instanceof E&&(m=c.callback,b=c.easing,a=b.dur,c=c.attr);var d=[],f=[],l={},t,ca,n,T=this,q;for(q in c)if(c[h](q)){T.equal?(n=T.equal(q,J(c[q])),t=n.from,ca=
n.to,n=n.f):(t=+T.attr(q),ca=+c[q]);var la=y(t,"array")?t.length:1;l[q]=e(d.length,d.length+la,n);d=d.concat(t);f=f.concat(ca)}t=L.time();var p=L(d,f,t,t+a,L.time,function(c){var a={},b;for(b in l)l[h](b)&&(a[b]=l[b](c));T.attr(a)},b);T.anims[p.id]=p;p._attrs=c;p._callback=m;k("snap.animcreated."+T.id,p);k.once("mina.finish."+p.id,function(){delete T.anims[p.id];m&&m.call(T)});k.once("mina.stop."+p.id,function(){delete T.anims[p.id]});return T};var T={};c.data=function(c,b){var m=T[this.id]=T[this.id]||
{};if(0==arguments.length)return k("snap.data.get."+this.id,this,m,null),m;if(1==arguments.length){if(a.is(c,"object")){for(var e in c)c[h](e)&&this.data(e,c[e]);return this}k("snap.data.get."+this.id,this,m[c],c);return m[c]}m[c]=b;k("snap.data.set."+this.id,this,b,c);return this};c.removeData=function(c){null==c?T[this.id]={}:T[this.id]&&delete T[this.id][c];return this};c.outerSVG=c.toString=d(1);c.innerSVG=d()})(e.prototype);a.parse=function(c){var a=G.doc.createDocumentFragment(),b=!0,m=G.doc.createElement("div");
c=J(c);c.match(/^\s*<\s*svg(?:\s|>)/)||(c="<svg>"+c+"</svg>",b=!1);m.innerHTML=c;if(c=m.getElementsByTagName("svg")[0])if(b)a=c;else for(;c.firstChild;)a.appendChild(c.firstChild);m.innerHTML=aa;return new l(a)};l.prototype.select=e.prototype.select;l.prototype.selectAll=e.prototype.selectAll;a.fragment=function(){for(var c=Array.prototype.slice.call(arguments,0),b=G.doc.createDocumentFragment(),m=0,e=c.length;m<e;m++){var h=c[m];h.node&&h.node.nodeType&&b.appendChild(h.node);h.nodeType&&b.appendChild(h);
"string"==typeof h&&b.appendChild(a.parse(h).node)}return new l(b)};a._.make=r;a._.wrap=x;s.prototype.el=function(c,a){var b=r(c,this.node);a&&b.attr(a);return b};k.on("snap.util.getattr",function(){var c=k.nt(),c=c.substring(c.lastIndexOf(".")+1),a=c.replace(/[A-Z]/g,function(c){return"-"+c.toLowerCase()});return pa[h](a)?this.node.ownerDocument.defaultView.getComputedStyle(this.node,null).getPropertyValue(a):v(this.node,c)});var pa={"alignment-baseline":0,"baseline-shift":0,clip:0,"clip-path":0,
"clip-rule":0,color:0,"color-interpolation":0,"color-interpolation-filters":0,"color-profile":0,"color-rendering":0,cursor:0,direction:0,display:0,"dominant-baseline":0,"enable-background":0,fill:0,"fill-opacity":0,"fill-rule":0,filter:0,"flood-color":0,"flood-opacity":0,font:0,"font-family":0,"font-size":0,"font-size-adjust":0,"font-stretch":0,"font-style":0,"font-variant":0,"font-weight":0,"glyph-orientation-horizontal":0,"glyph-orientation-vertical":0,"image-rendering":0,kerning:0,"letter-spacing":0,
"lighting-color":0,marker:0,"marker-end":0,"marker-mid":0,"marker-start":0,mask:0,opacity:0,overflow:0,"pointer-events":0,"shape-rendering":0,"stop-color":0,"stop-opacity":0,stroke:0,"stroke-dasharray":0,"stroke-dashoffset":0,"stroke-linecap":0,"stroke-linejoin":0,"stroke-miterlimit":0,"stroke-opacity":0,"stroke-width":0,"text-anchor":0,"text-decoration":0,"text-rendering":0,"unicode-bidi":0,visibility:0,"word-spacing":0,"writing-mode":0};k.on("snap.util.attr",function(c){var a=k.nt(),b={},a=a.substring(a.lastIndexOf(".")+
1);b[a]=c;var m=a.replace(/-(\w)/gi,function(c,a){return a.toUpperCase()}),a=a.replace(/[A-Z]/g,function(c){return"-"+c.toLowerCase()});pa[h](a)?this.node.style[m]=null==c?aa:c:v(this.node,b)});a.ajax=function(c,a,b,m){var e=new XMLHttpRequest,h=V();if(e){if(y(a,"function"))m=b,b=a,a=null;else if(y(a,"object")){var d=[],f;for(f in a)a.hasOwnProperty(f)&&d.push(encodeURIComponent(f)+"="+encodeURIComponent(a[f]));a=d.join("&")}e.open(a?"POST":"GET",c,!0);a&&(e.setRequestHeader("X-Requested-With","XMLHttpRequest"),
e.setRequestHeader("Content-type","application/x-www-form-urlencoded"));b&&(k.once("snap.ajax."+h+".0",b),k.once("snap.ajax."+h+".200",b),k.once("snap.ajax."+h+".304",b));e.onreadystatechange=function(){4==e.readyState&&k("snap.ajax."+h+"."+e.status,m,e)};if(4==e.readyState)return e;e.send(a);return e}};a.load=function(c,b,m){a.ajax(c,function(c){c=a.parse(c.responseText);m?b.call(m,c):b(c)})};a.getElementByPoint=function(c,a){var b,m,e=G.doc.elementFromPoint(c,a);if(G.win.opera&&"svg"==e.tagName){b=
e;m=b.getBoundingClientRect();b=b.ownerDocument;var h=b.body,d=b.documentElement;b=m.top+(g.win.pageYOffset||d.scrollTop||h.scrollTop)-(d.clientTop||h.clientTop||0);m=m.left+(g.win.pageXOffset||d.scrollLeft||h.scrollLeft)-(d.clientLeft||h.clientLeft||0);h=e.createSVGRect();h.x=c-m;h.y=a-b;h.width=h.height=1;b=e.getIntersectionList(h,null);b.length&&(e=b[b.length-1])}return e?x(e):null};a.plugin=function(c){c(a,e,s,G,l)};return G.win.Snap=a}();C.plugin(function(a,k,y,M,A){function w(a,d,f,b,q,e){null==
d&&"[object SVGMatrix]"==z.call(a)?(this.a=a.a,this.b=a.b,this.c=a.c,this.d=a.d,this.e=a.e,this.f=a.f):null!=a?(this.a=+a,this.b=+d,this.c=+f,this.d=+b,this.e=+q,this.f=+e):(this.a=1,this.c=this.b=0,this.d=1,this.f=this.e=0)}var z=Object.prototype.toString,d=String,f=Math;(function(n){function k(a){return a[0]*a[0]+a[1]*a[1]}function p(a){var d=f.sqrt(k(a));a[0]&&(a[0]/=d);a[1]&&(a[1]/=d)}n.add=function(a,d,e,f,n,p){var k=[[],[],[] ],u=[[this.a,this.c,this.e],[this.b,this.d,this.f],[0,0,1] ];d=[[a,
e,n],[d,f,p],[0,0,1] ];a&&a instanceof w&&(d=[[a.a,a.c,a.e],[a.b,a.d,a.f],[0,0,1] ]);for(a=0;3>a;a++)for(e=0;3>e;e++){for(f=n=0;3>f;f++)n+=u[a][f]*d[f][e];k[a][e]=n}this.a=k[0][0];this.b=k[1][0];this.c=k[0][1];this.d=k[1][1];this.e=k[0][2];this.f=k[1][2];return this};n.invert=function(){var a=this.a*this.d-this.b*this.c;return new w(this.d/a,-this.b/a,-this.c/a,this.a/a,(this.c*this.f-this.d*this.e)/a,(this.b*this.e-this.a*this.f)/a)};n.clone=function(){return new w(this.a,this.b,this.c,this.d,this.e,
this.f)};n.translate=function(a,d){return this.add(1,0,0,1,a,d)};n.scale=function(a,d,e,f){null==d&&(d=a);(e||f)&&this.add(1,0,0,1,e,f);this.add(a,0,0,d,0,0);(e||f)&&this.add(1,0,0,1,-e,-f);return this};n.rotate=function(b,d,e){b=a.rad(b);d=d||0;e=e||0;var l=+f.cos(b).toFixed(9);b=+f.sin(b).toFixed(9);this.add(l,b,-b,l,d,e);return this.add(1,0,0,1,-d,-e)};n.x=function(a,d){return a*this.a+d*this.c+this.e};n.y=function(a,d){return a*this.b+d*this.d+this.f};n.get=function(a){return+this[d.fromCharCode(97+
a)].toFixed(4)};n.toString=function(){return"matrix("+[this.get(0),this.get(1),this.get(2),this.get(3),this.get(4),this.get(5)].join()+")"};n.offset=function(){return[this.e.toFixed(4),this.f.toFixed(4)]};n.determinant=function(){return this.a*this.d-this.b*this.c};n.split=function(){var b={};b.dx=this.e;b.dy=this.f;var d=[[this.a,this.c],[this.b,this.d] ];b.scalex=f.sqrt(k(d[0]));p(d[0]);b.shear=d[0][0]*d[1][0]+d[0][1]*d[1][1];d[1]=[d[1][0]-d[0][0]*b.shear,d[1][1]-d[0][1]*b.shear];b.scaley=f.sqrt(k(d[1]));
p(d[1]);b.shear/=b.scaley;0>this.determinant()&&(b.scalex=-b.scalex);var e=-d[0][1],d=d[1][1];0>d?(b.rotate=a.deg(f.acos(d)),0>e&&(b.rotate=360-b.rotate)):b.rotate=a.deg(f.asin(e));b.isSimple=!+b.shear.toFixed(9)&&(b.scalex.toFixed(9)==b.scaley.toFixed(9)||!b.rotate);b.isSuperSimple=!+b.shear.toFixed(9)&&b.scalex.toFixed(9)==b.scaley.toFixed(9)&&!b.rotate;b.noRotation=!+b.shear.toFixed(9)&&!b.rotate;return b};n.toTransformString=function(a){a=a||this.split();if(+a.shear.toFixed(9))return"m"+[this.get(0),
this.get(1),this.get(2),this.get(3),this.get(4),this.get(5)];a.scalex=+a.scalex.toFixed(4);a.scaley=+a.scaley.toFixed(4);a.rotate=+a.rotate.toFixed(4);return(a.dx||a.dy?"t"+[+a.dx.toFixed(4),+a.dy.toFixed(4)]:"")+(1!=a.scalex||1!=a.scaley?"s"+[a.scalex,a.scaley,0,0]:"")+(a.rotate?"r"+[+a.rotate.toFixed(4),0,0]:"")}})(w.prototype);a.Matrix=w;a.matrix=function(a,d,f,b,k,e){return new w(a,d,f,b,k,e)}});C.plugin(function(a,v,y,M,A){function w(h){return function(d){k.stop();d instanceof A&&1==d.node.childNodes.length&&
("radialGradient"==d.node.firstChild.tagName||"linearGradient"==d.node.firstChild.tagName||"pattern"==d.node.firstChild.tagName)&&(d=d.node.firstChild,b(this).appendChild(d),d=u(d));if(d instanceof v)if("radialGradient"==d.type||"linearGradient"==d.type||"pattern"==d.type){d.node.id||e(d.node,{id:d.id});var f=l(d.node.id)}else f=d.attr(h);else f=a.color(d),f.error?(f=a(b(this).ownerSVGElement).gradient(d))?(f.node.id||e(f.node,{id:f.id}),f=l(f.node.id)):f=d:f=r(f);d={};d[h]=f;e(this.node,d);this.node.style[h]=
x}}function z(a){k.stop();a==+a&&(a+="px");this.node.style.fontSize=a}function d(a){var b=[];a=a.childNodes;for(var e=0,f=a.length;e<f;e++){var l=a[e];3==l.nodeType&&b.push(l.nodeValue);"tspan"==l.tagName&&(1==l.childNodes.length&&3==l.firstChild.nodeType?b.push(l.firstChild.nodeValue):b.push(d(l)))}return b}function f(){k.stop();return this.node.style.fontSize}var n=a._.make,u=a._.wrap,p=a.is,b=a._.getSomeDefs,q=/^url\(#?([^)]+)\)$/,e=a._.$,l=a.url,r=String,s=a._.separator,x="";k.on("snap.util.attr.mask",
function(a){if(a instanceof v||a instanceof A){k.stop();a instanceof A&&1==a.node.childNodes.length&&(a=a.node.firstChild,b(this).appendChild(a),a=u(a));if("mask"==a.type)var d=a;else d=n("mask",b(this)),d.node.appendChild(a.node);!d.node.id&&e(d.node,{id:d.id});e(this.node,{mask:l(d.id)})}});(function(a){k.on("snap.util.attr.clip",a);k.on("snap.util.attr.clip-path",a);k.on("snap.util.attr.clipPath",a)})(function(a){if(a instanceof v||a instanceof A){k.stop();if("clipPath"==a.type)var d=a;else d=
n("clipPath",b(this)),d.node.appendChild(a.node),!d.node.id&&e(d.node,{id:d.id});e(this.node,{"clip-path":l(d.id)})}});k.on("snap.util.attr.fill",w("fill"));k.on("snap.util.attr.stroke",w("stroke"));var G=/^([lr])(?:\(([^)]*)\))?(.*)$/i;k.on("snap.util.grad.parse",function(a){a=r(a);var b=a.match(G);if(!b)return null;a=b[1];var e=b[2],b=b[3],e=e.split(/\s*,\s*/).map(function(a){return+a==a?+a:a});1==e.length&&0==e[0]&&(e=[]);b=b.split("-");b=b.map(function(a){a=a.split(":");var b={color:a[0]};a[1]&&
(b.offset=parseFloat(a[1]));return b});return{type:a,params:e,stops:b}});k.on("snap.util.attr.d",function(b){k.stop();p(b,"array")&&p(b[0],"array")&&(b=a.path.toString.call(b));b=r(b);b.match(/[ruo]/i)&&(b=a.path.toAbsolute(b));e(this.node,{d:b})})(-1);k.on("snap.util.attr.#text",function(a){k.stop();a=r(a);for(a=M.doc.createTextNode(a);this.node.firstChild;)this.node.removeChild(this.node.firstChild);this.node.appendChild(a)})(-1);k.on("snap.util.attr.path",function(a){k.stop();this.attr({d:a})})(-1);
k.on("snap.util.attr.class",function(a){k.stop();this.node.className.baseVal=a})(-1);k.on("snap.util.attr.viewBox",function(a){a=p(a,"object")&&"x"in a?[a.x,a.y,a.width,a.height].join(" "):p(a,"array")?a.join(" "):a;e(this.node,{viewBox:a});k.stop()})(-1);k.on("snap.util.attr.transform",function(a){this.transform(a);k.stop()})(-1);k.on("snap.util.attr.r",function(a){"rect"==this.type&&(k.stop(),e(this.node,{rx:a,ry:a}))})(-1);k.on("snap.util.attr.textpath",function(a){k.stop();if("text"==this.type){var d,
f;if(!a&&this.textPath){for(a=this.textPath;a.node.firstChild;)this.node.appendChild(a.node.firstChild);a.remove();delete this.textPath}else if(p(a,"string")?(d=b(this),a=u(d.parentNode).path(a),d.appendChild(a.node),d=a.id,a.attr({id:d})):(a=u(a),a instanceof v&&(d=a.attr("id"),d||(d=a.id,a.attr({id:d})))),d)if(a=this.textPath,f=this.node,a)a.attr({"xlink:href":"#"+d});else{for(a=e("textPath",{"xlink:href":"#"+d});f.firstChild;)a.appendChild(f.firstChild);f.appendChild(a);this.textPath=u(a)}}})(-1);
k.on("snap.util.attr.text",function(a){if("text"==this.type){for(var b=this.node,d=function(a){var b=e("tspan");if(p(a,"array"))for(var f=0;f<a.length;f++)b.appendChild(d(a[f]));else b.appendChild(M.doc.createTextNode(a));b.normalize&&b.normalize();return b};b.firstChild;)b.removeChild(b.firstChild);for(a=d(a);a.firstChild;)b.appendChild(a.firstChild)}k.stop()})(-1);k.on("snap.util.attr.fontSize",z)(-1);k.on("snap.util.attr.font-size",z)(-1);k.on("snap.util.getattr.transform",function(){k.stop();
return this.transform()})(-1);k.on("snap.util.getattr.textpath",function(){k.stop();return this.textPath})(-1);(function(){function b(d){return function(){k.stop();var b=M.doc.defaultView.getComputedStyle(this.node,null).getPropertyValue("marker-"+d);return"none"==b?b:a(M.doc.getElementById(b.match(q)[1]))}}function d(a){return function(b){k.stop();var d="marker"+a.charAt(0).toUpperCase()+a.substring(1);if(""==b||!b)this.node.style[d]="none";else if("marker"==b.type){var f=b.node.id;f||e(b.node,{id:b.id});
this.node.style[d]=l(f)}}}k.on("snap.util.getattr.marker-end",b("end"))(-1);k.on("snap.util.getattr.markerEnd",b("end"))(-1);k.on("snap.util.getattr.marker-start",b("start"))(-1);k.on("snap.util.getattr.markerStart",b("start"))(-1);k.on("snap.util.getattr.marker-mid",b("mid"))(-1);k.on("snap.util.getattr.markerMid",b("mid"))(-1);k.on("snap.util.attr.marker-end",d("end"))(-1);k.on("snap.util.attr.markerEnd",d("end"))(-1);k.on("snap.util.attr.marker-start",d("start"))(-1);k.on("snap.util.attr.markerStart",
d("start"))(-1);k.on("snap.util.attr.marker-mid",d("mid"))(-1);k.on("snap.util.attr.markerMid",d("mid"))(-1)})();k.on("snap.util.getattr.r",function(){if("rect"==this.type&&e(this.node,"rx")==e(this.node,"ry"))return k.stop(),e(this.node,"rx")})(-1);k.on("snap.util.getattr.text",function(){if("text"==this.type||"tspan"==this.type){k.stop();var a=d(this.node);return 1==a.length?a[0]:a}})(-1);k.on("snap.util.getattr.#text",function(){return this.node.textContent})(-1);k.on("snap.util.getattr.viewBox",
function(){k.stop();var b=e(this.node,"viewBox");if(b)return b=b.split(s),a._.box(+b[0],+b[1],+b[2],+b[3])})(-1);k.on("snap.util.getattr.points",function(){var a=e(this.node,"points");k.stop();if(a)return a.split(s)})(-1);k.on("snap.util.getattr.path",function(){var a=e(this.node,"d");k.stop();return a})(-1);k.on("snap.util.getattr.class",function(){return this.node.className.baseVal})(-1);k.on("snap.util.getattr.fontSize",f)(-1);k.on("snap.util.getattr.font-size",f)(-1)});C.plugin(function(a,v,y,
M,A){function w(a){return a}function z(a){return function(b){return+b.toFixed(3)+a}}var d={"+":function(a,b){return a+b},"-":function(a,b){return a-b},"/":function(a,b){return a/b},"*":function(a,b){return a*b}},f=String,n=/[a-z]+$/i,u=/^\s*([+\-\/*])\s*=\s*([\d.eE+\-]+)\s*([^\d\s]+)?\s*$/;k.on("snap.util.attr",function(a){if(a=f(a).match(u)){var b=k.nt(),b=b.substring(b.lastIndexOf(".")+1),q=this.attr(b),e={};k.stop();var l=a[3]||"",r=q.match(n),s=d[a[1] ];r&&r==l?a=s(parseFloat(q),+a[2]):(q=this.asPX(b),
a=s(this.asPX(b),this.asPX(b,a[2]+l)));isNaN(q)||isNaN(a)||(e[b]=a,this.attr(e))}})(-10);k.on("snap.util.equal",function(a,b){var q=f(this.attr(a)||""),e=f(b).match(u);if(e){k.stop();var l=e[3]||"",r=q.match(n),s=d[e[1] ];if(r&&r==l)return{from:parseFloat(q),to:s(parseFloat(q),+e[2]),f:z(r)};q=this.asPX(a);return{from:q,to:s(q,this.asPX(a,e[2]+l)),f:w}}})(-10)});C.plugin(function(a,v,y,M,A){var w=y.prototype,z=a.is;w.rect=function(a,d,k,p,b,q){var e;null==q&&(q=b);z(a,"object")&&"[object Object]"==
a?e=a:null!=a&&(e={x:a,y:d,width:k,height:p},null!=b&&(e.rx=b,e.ry=q));return this.el("rect",e)};w.circle=function(a,d,k){var p;z(a,"object")&&"[object Object]"==a?p=a:null!=a&&(p={cx:a,cy:d,r:k});return this.el("circle",p)};var d=function(){function a(){this.parentNode.removeChild(this)}return function(d,k){var p=M.doc.createElement("img"),b=M.doc.body;p.style.cssText="position:absolute;left:-9999em;top:-9999em";p.onload=function(){k.call(p);p.onload=p.onerror=null;b.removeChild(p)};p.onerror=a;
b.appendChild(p);p.src=d}}();w.image=function(f,n,k,p,b){var q=this.el("image");if(z(f,"object")&&"src"in f)q.attr(f);else if(null!=f){var e={"xlink:href":f,preserveAspectRatio:"none"};null!=n&&null!=k&&(e.x=n,e.y=k);null!=p&&null!=b?(e.width=p,e.height=b):d(f,function(){a._.$(q.node,{width:this.offsetWidth,height:this.offsetHeight})});a._.$(q.node,e)}return q};w.ellipse=function(a,d,k,p){var b;z(a,"object")&&"[object Object]"==a?b=a:null!=a&&(b={cx:a,cy:d,rx:k,ry:p});return this.el("ellipse",b)};
w.path=function(a){var d;z(a,"object")&&!z(a,"array")?d=a:a&&(d={d:a});return this.el("path",d)};w.group=w.g=function(a){var d=this.el("g");1==arguments.length&&a&&!a.type?d.attr(a):arguments.length&&d.add(Array.prototype.slice.call(arguments,0));return d};w.svg=function(a,d,k,p,b,q,e,l){var r={};z(a,"object")&&null==d?r=a:(null!=a&&(r.x=a),null!=d&&(r.y=d),null!=k&&(r.width=k),null!=p&&(r.height=p),null!=b&&null!=q&&null!=e&&null!=l&&(r.viewBox=[b,q,e,l]));return this.el("svg",r)};w.mask=function(a){var d=
this.el("mask");1==arguments.length&&a&&!a.type?d.attr(a):arguments.length&&d.add(Array.prototype.slice.call(arguments,0));return d};w.ptrn=function(a,d,k,p,b,q,e,l){if(z(a,"object"))var r=a;else arguments.length?(r={},null!=a&&(r.x=a),null!=d&&(r.y=d),null!=k&&(r.width=k),null!=p&&(r.height=p),null!=b&&null!=q&&null!=e&&null!=l&&(r.viewBox=[b,q,e,l])):r={patternUnits:"userSpaceOnUse"};return this.el("pattern",r)};w.use=function(a){return null!=a?(make("use",this.node),a instanceof v&&(a.attr("id")||
a.attr({id:ID()}),a=a.attr("id")),this.el("use",{"xlink:href":a})):v.prototype.use.call(this)};w.text=function(a,d,k){var p={};z(a,"object")?p=a:null!=a&&(p={x:a,y:d,text:k||""});return this.el("text",p)};w.line=function(a,d,k,p){var b={};z(a,"object")?b=a:null!=a&&(b={x1:a,x2:k,y1:d,y2:p});return this.el("line",b)};w.polyline=function(a){1<arguments.length&&(a=Array.prototype.slice.call(arguments,0));var d={};z(a,"object")&&!z(a,"array")?d=a:null!=a&&(d={points:a});return this.el("polyline",d)};
w.polygon=function(a){1<arguments.length&&(a=Array.prototype.slice.call(arguments,0));var d={};z(a,"object")&&!z(a,"array")?d=a:null!=a&&(d={points:a});return this.el("polygon",d)};(function(){function d(){return this.selectAll("stop")}function n(b,d){var f=e("stop"),k={offset:+d+"%"};b=a.color(b);k["stop-color"]=b.hex;1>b.opacity&&(k["stop-opacity"]=b.opacity);e(f,k);this.node.appendChild(f);return this}function u(){if("linearGradient"==this.type){var b=e(this.node,"x1")||0,d=e(this.node,"x2")||
1,f=e(this.node,"y1")||0,k=e(this.node,"y2")||0;return a._.box(b,f,math.abs(d-b),math.abs(k-f))}b=this.node.r||0;return a._.box((this.node.cx||0.5)-b,(this.node.cy||0.5)-b,2*b,2*b)}function p(a,d){function f(a,b){for(var d=(b-u)/(a-w),e=w;e<a;e++)h[e].offset=+(+u+d*(e-w)).toFixed(2);w=a;u=b}var n=k("snap.util.grad.parse",null,d).firstDefined(),p;if(!n)return null;n.params.unshift(a);p="l"==n.type.toLowerCase()?b.apply(0,n.params):q.apply(0,n.params);n.type!=n.type.toLowerCase()&&e(p.node,{gradientUnits:"userSpaceOnUse"});
var h=n.stops,n=h.length,u=0,w=0;n--;for(var v=0;v<n;v++)"offset"in h[v]&&f(v,h[v].offset);h[n].offset=h[n].offset||100;f(n,h[n].offset);for(v=0;v<=n;v++){var y=h[v];p.addStop(y.color,y.offset)}return p}function b(b,k,p,q,w){b=a._.make("linearGradient",b);b.stops=d;b.addStop=n;b.getBBox=u;null!=k&&e(b.node,{x1:k,y1:p,x2:q,y2:w});return b}function q(b,k,p,q,w,h){b=a._.make("radialGradient",b);b.stops=d;b.addStop=n;b.getBBox=u;null!=k&&e(b.node,{cx:k,cy:p,r:q});null!=w&&null!=h&&e(b.node,{fx:w,fy:h});
return b}var e=a._.$;w.gradient=function(a){return p(this.defs,a)};w.gradientLinear=function(a,d,e,f){return b(this.defs,a,d,e,f)};w.gradientRadial=function(a,b,d,e,f){return q(this.defs,a,b,d,e,f)};w.toString=function(){var b=this.node.ownerDocument,d=b.createDocumentFragment(),b=b.createElement("div"),e=this.node.cloneNode(!0);d.appendChild(b);b.appendChild(e);a._.$(e,{xmlns:"http://www.w3.org/2000/svg"});b=b.innerHTML;d.removeChild(d.firstChild);return b};w.clear=function(){for(var a=this.node.firstChild,
b;a;)b=a.nextSibling,"defs"!=a.tagName?a.parentNode.removeChild(a):w.clear.call({node:a}),a=b}})()});C.plugin(function(a,k,y,M){function A(a){var b=A.ps=A.ps||{};b[a]?b[a].sleep=100:b[a]={sleep:100};setTimeout(function(){for(var d in b)b[L](d)&&d!=a&&(b[d].sleep--,!b[d].sleep&&delete b[d])});return b[a]}function w(a,b,d,e){null==a&&(a=b=d=e=0);null==b&&(b=a.y,d=a.width,e=a.height,a=a.x);return{x:a,y:b,width:d,w:d,height:e,h:e,x2:a+d,y2:b+e,cx:a+d/2,cy:b+e/2,r1:F.min(d,e)/2,r2:F.max(d,e)/2,r0:F.sqrt(d*
d+e*e)/2,path:s(a,b,d,e),vb:[a,b,d,e].join(" ")}}function z(){return this.join(",").replace(N,"$1")}function d(a){a=C(a);a.toString=z;return a}function f(a,b,d,h,f,k,l,n,p){if(null==p)return e(a,b,d,h,f,k,l,n);if(0>p||e(a,b,d,h,f,k,l,n)<p)p=void 0;else{var q=0.5,O=1-q,s;for(s=e(a,b,d,h,f,k,l,n,O);0.01<Z(s-p);)q/=2,O+=(s<p?1:-1)*q,s=e(a,b,d,h,f,k,l,n,O);p=O}return u(a,b,d,h,f,k,l,n,p)}function n(b,d){function e(a){return+(+a).toFixed(3)}return a._.cacher(function(a,h,l){a instanceof k&&(a=a.attr("d"));
a=I(a);for(var n,p,D,q,O="",s={},c=0,t=0,r=a.length;t<r;t++){D=a[t];if("M"==D[0])n=+D[1],p=+D[2];else{q=f(n,p,D[1],D[2],D[3],D[4],D[5],D[6]);if(c+q>h){if(d&&!s.start){n=f(n,p,D[1],D[2],D[3],D[4],D[5],D[6],h-c);O+=["C"+e(n.start.x),e(n.start.y),e(n.m.x),e(n.m.y),e(n.x),e(n.y)];if(l)return O;s.start=O;O=["M"+e(n.x),e(n.y)+"C"+e(n.n.x),e(n.n.y),e(n.end.x),e(n.end.y),e(D[5]),e(D[6])].join();c+=q;n=+D[5];p=+D[6];continue}if(!b&&!d)return n=f(n,p,D[1],D[2],D[3],D[4],D[5],D[6],h-c)}c+=q;n=+D[5];p=+D[6]}O+=
D.shift()+D}s.end=O;return n=b?c:d?s:u(n,p,D[0],D[1],D[2],D[3],D[4],D[5],1)},null,a._.clone)}function u(a,b,d,e,h,f,k,l,n){var p=1-n,q=ma(p,3),s=ma(p,2),c=n*n,t=c*n,r=q*a+3*s*n*d+3*p*n*n*h+t*k,q=q*b+3*s*n*e+3*p*n*n*f+t*l,s=a+2*n*(d-a)+c*(h-2*d+a),t=b+2*n*(e-b)+c*(f-2*e+b),x=d+2*n*(h-d)+c*(k-2*h+d),c=e+2*n*(f-e)+c*(l-2*f+e);a=p*a+n*d;b=p*b+n*e;h=p*h+n*k;f=p*f+n*l;l=90-180*F.atan2(s-x,t-c)/S;return{x:r,y:q,m:{x:s,y:t},n:{x:x,y:c},start:{x:a,y:b},end:{x:h,y:f},alpha:l}}function p(b,d,e,h,f,n,k,l){a.is(b,
"array")||(b=[b,d,e,h,f,n,k,l]);b=U.apply(null,b);return w(b.min.x,b.min.y,b.max.x-b.min.x,b.max.y-b.min.y)}function b(a,b,d){return b>=a.x&&b<=a.x+a.width&&d>=a.y&&d<=a.y+a.height}function q(a,d){a=w(a);d=w(d);return b(d,a.x,a.y)||b(d,a.x2,a.y)||b(d,a.x,a.y2)||b(d,a.x2,a.y2)||b(a,d.x,d.y)||b(a,d.x2,d.y)||b(a,d.x,d.y2)||b(a,d.x2,d.y2)||(a.x<d.x2&&a.x>d.x||d.x<a.x2&&d.x>a.x)&&(a.y<d.y2&&a.y>d.y||d.y<a.y2&&d.y>a.y)}function e(a,b,d,e,h,f,n,k,l){null==l&&(l=1);l=(1<l?1:0>l?0:l)/2;for(var p=[-0.1252,
0.1252,-0.3678,0.3678,-0.5873,0.5873,-0.7699,0.7699,-0.9041,0.9041,-0.9816,0.9816],q=[0.2491,0.2491,0.2335,0.2335,0.2032,0.2032,0.1601,0.1601,0.1069,0.1069,0.0472,0.0472],s=0,c=0;12>c;c++)var t=l*p[c]+l,r=t*(t*(-3*a+9*d-9*h+3*n)+6*a-12*d+6*h)-3*a+3*d,t=t*(t*(-3*b+9*e-9*f+3*k)+6*b-12*e+6*f)-3*b+3*e,s=s+q[c]*F.sqrt(r*r+t*t);return l*s}function l(a,b,d){a=I(a);b=I(b);for(var h,f,l,n,k,s,r,O,x,c,t=d?0:[],w=0,v=a.length;w<v;w++)if(x=a[w],"M"==x[0])h=k=x[1],f=s=x[2];else{"C"==x[0]?(x=[h,f].concat(x.slice(1)),
h=x[6],f=x[7]):(x=[h,f,h,f,k,s,k,s],h=k,f=s);for(var G=0,y=b.length;G<y;G++)if(c=b[G],"M"==c[0])l=r=c[1],n=O=c[2];else{"C"==c[0]?(c=[l,n].concat(c.slice(1)),l=c[6],n=c[7]):(c=[l,n,l,n,r,O,r,O],l=r,n=O);var z;var K=x,B=c;z=d;var H=p(K),J=p(B);if(q(H,J)){for(var H=e.apply(0,K),J=e.apply(0,B),H=~~(H/8),J=~~(J/8),U=[],A=[],F={},M=z?0:[],P=0;P<H+1;P++){var C=u.apply(0,K.concat(P/H));U.push({x:C.x,y:C.y,t:P/H})}for(P=0;P<J+1;P++)C=u.apply(0,B.concat(P/J)),A.push({x:C.x,y:C.y,t:P/J});for(P=0;P<H;P++)for(K=
0;K<J;K++){var Q=U[P],L=U[P+1],B=A[K],C=A[K+1],N=0.001>Z(L.x-Q.x)?"y":"x",S=0.001>Z(C.x-B.x)?"y":"x",R;R=Q.x;var Y=Q.y,V=L.x,ea=L.y,fa=B.x,ga=B.y,ha=C.x,ia=C.y;if(W(R,V)<X(fa,ha)||X(R,V)>W(fa,ha)||W(Y,ea)<X(ga,ia)||X(Y,ea)>W(ga,ia))R=void 0;else{var $=(R*ea-Y*V)*(fa-ha)-(R-V)*(fa*ia-ga*ha),aa=(R*ea-Y*V)*(ga-ia)-(Y-ea)*(fa*ia-ga*ha),ja=(R-V)*(ga-ia)-(Y-ea)*(fa-ha);if(ja){var $=$/ja,aa=aa/ja,ja=+$.toFixed(2),ba=+aa.toFixed(2);R=ja<+X(R,V).toFixed(2)||ja>+W(R,V).toFixed(2)||ja<+X(fa,ha).toFixed(2)||
ja>+W(fa,ha).toFixed(2)||ba<+X(Y,ea).toFixed(2)||ba>+W(Y,ea).toFixed(2)||ba<+X(ga,ia).toFixed(2)||ba>+W(ga,ia).toFixed(2)?void 0:{x:$,y:aa}}else R=void 0}R&&F[R.x.toFixed(4)]!=R.y.toFixed(4)&&(F[R.x.toFixed(4)]=R.y.toFixed(4),Q=Q.t+Z((R[N]-Q[N])/(L[N]-Q[N]))*(L.t-Q.t),B=B.t+Z((R[S]-B[S])/(C[S]-B[S]))*(C.t-B.t),0<=Q&&1>=Q&&0<=B&&1>=B&&(z?M++:M.push({x:R.x,y:R.y,t1:Q,t2:B})))}z=M}else z=z?0:[];if(d)t+=z;else{H=0;for(J=z.length;H<J;H++)z[H].segment1=w,z[H].segment2=G,z[H].bez1=x,z[H].bez2=c;t=t.concat(z)}}}return t}
function r(a){var b=A(a);if(b.bbox)return C(b.bbox);if(!a)return w();a=I(a);for(var d=0,e=0,h=[],f=[],l,n=0,k=a.length;n<k;n++)l=a[n],"M"==l[0]?(d=l[1],e=l[2],h.push(d),f.push(e)):(d=U(d,e,l[1],l[2],l[3],l[4],l[5],l[6]),h=h.concat(d.min.x,d.max.x),f=f.concat(d.min.y,d.max.y),d=l[5],e=l[6]);a=X.apply(0,h);l=X.apply(0,f);h=W.apply(0,h);f=W.apply(0,f);f=w(a,l,h-a,f-l);b.bbox=C(f);return f}function s(a,b,d,e,h){if(h)return[["M",+a+ +h,b],["l",d-2*h,0],["a",h,h,0,0,1,h,h],["l",0,e-2*h],["a",h,h,0,0,1,
-h,h],["l",2*h-d,0],["a",h,h,0,0,1,-h,-h],["l",0,2*h-e],["a",h,h,0,0,1,h,-h],["z"] ];a=[["M",a,b],["l",d,0],["l",0,e],["l",-d,0],["z"] ];a.toString=z;return a}function x(a,b,d,e,h){null==h&&null==e&&(e=d);a=+a;b=+b;d=+d;e=+e;if(null!=h){var f=Math.PI/180,l=a+d*Math.cos(-e*f);a+=d*Math.cos(-h*f);var n=b+d*Math.sin(-e*f);b+=d*Math.sin(-h*f);d=[["M",l,n],["A",d,d,0,+(180<h-e),0,a,b] ]}else d=[["M",a,b],["m",0,-e],["a",d,e,0,1,1,0,2*e],["a",d,e,0,1,1,0,-2*e],["z"] ];d.toString=z;return d}function G(b){var e=
A(b);if(e.abs)return d(e.abs);Q(b,"array")&&Q(b&&b[0],"array")||(b=a.parsePathString(b));if(!b||!b.length)return[["M",0,0] ];var h=[],f=0,l=0,n=0,k=0,p=0;"M"==b[0][0]&&(f=+b[0][1],l=+b[0][2],n=f,k=l,p++,h[0]=["M",f,l]);for(var q=3==b.length&&"M"==b[0][0]&&"R"==b[1][0].toUpperCase()&&"Z"==b[2][0].toUpperCase(),s,r,w=p,c=b.length;w<c;w++){h.push(s=[]);r=b[w];p=r[0];if(p!=p.toUpperCase())switch(s[0]=p.toUpperCase(),s[0]){case "A":s[1]=r[1];s[2]=r[2];s[3]=r[3];s[4]=r[4];s[5]=r[5];s[6]=+r[6]+f;s[7]=+r[7]+
l;break;case "V":s[1]=+r[1]+l;break;case "H":s[1]=+r[1]+f;break;case "R":for(var t=[f,l].concat(r.slice(1)),u=2,v=t.length;u<v;u++)t[u]=+t[u]+f,t[++u]=+t[u]+l;h.pop();h=h.concat(P(t,q));break;case "O":h.pop();t=x(f,l,r[1],r[2]);t.push(t[0]);h=h.concat(t);break;case "U":h.pop();h=h.concat(x(f,l,r[1],r[2],r[3]));s=["U"].concat(h[h.length-1].slice(-2));break;case "M":n=+r[1]+f,k=+r[2]+l;default:for(u=1,v=r.length;u<v;u++)s[u]=+r[u]+(u%2?f:l)}else if("R"==p)t=[f,l].concat(r.slice(1)),h.pop(),h=h.concat(P(t,
q)),s=["R"].concat(r.slice(-2));else if("O"==p)h.pop(),t=x(f,l,r[1],r[2]),t.push(t[0]),h=h.concat(t);else if("U"==p)h.pop(),h=h.concat(x(f,l,r[1],r[2],r[3])),s=["U"].concat(h[h.length-1].slice(-2));else for(t=0,u=r.length;t<u;t++)s[t]=r[t];p=p.toUpperCase();if("O"!=p)switch(s[0]){case "Z":f=+n;l=+k;break;case "H":f=s[1];break;case "V":l=s[1];break;case "M":n=s[s.length-2],k=s[s.length-1];default:f=s[s.length-2],l=s[s.length-1]}}h.toString=z;e.abs=d(h);return h}function h(a,b,d,e){return[a,b,d,e,d,
e]}function J(a,b,d,e,h,f){var l=1/3,n=2/3;return[l*a+n*d,l*b+n*e,l*h+n*d,l*f+n*e,h,f]}function K(b,d,e,h,f,l,n,k,p,s){var r=120*S/180,q=S/180*(+f||0),c=[],t,x=a._.cacher(function(a,b,c){var d=a*F.cos(c)-b*F.sin(c);a=a*F.sin(c)+b*F.cos(c);return{x:d,y:a}});if(s)v=s[0],t=s[1],l=s[2],u=s[3];else{t=x(b,d,-q);b=t.x;d=t.y;t=x(k,p,-q);k=t.x;p=t.y;F.cos(S/180*f);F.sin(S/180*f);t=(b-k)/2;v=(d-p)/2;u=t*t/(e*e)+v*v/(h*h);1<u&&(u=F.sqrt(u),e*=u,h*=u);var u=e*e,w=h*h,u=(l==n?-1:1)*F.sqrt(Z((u*w-u*v*v-w*t*t)/
(u*v*v+w*t*t)));l=u*e*v/h+(b+k)/2;var u=u*-h*t/e+(d+p)/2,v=F.asin(((d-u)/h).toFixed(9));t=F.asin(((p-u)/h).toFixed(9));v=b<l?S-v:v;t=k<l?S-t:t;0>v&&(v=2*S+v);0>t&&(t=2*S+t);n&&v>t&&(v-=2*S);!n&&t>v&&(t-=2*S)}if(Z(t-v)>r){var c=t,w=k,G=p;t=v+r*(n&&t>v?1:-1);k=l+e*F.cos(t);p=u+h*F.sin(t);c=K(k,p,e,h,f,0,n,w,G,[t,c,l,u])}l=t-v;f=F.cos(v);r=F.sin(v);n=F.cos(t);t=F.sin(t);l=F.tan(l/4);e=4/3*e*l;l*=4/3*h;h=[b,d];b=[b+e*r,d-l*f];d=[k+e*t,p-l*n];k=[k,p];b[0]=2*h[0]-b[0];b[1]=2*h[1]-b[1];if(s)return[b,d,k].concat(c);
c=[b,d,k].concat(c).join().split(",");s=[];k=0;for(p=c.length;k<p;k++)s[k]=k%2?x(c[k-1],c[k],q).y:x(c[k],c[k+1],q).x;return s}function U(a,b,d,e,h,f,l,k){for(var n=[],p=[[],[] ],s,r,c,t,q=0;2>q;++q)0==q?(r=6*a-12*d+6*h,s=-3*a+9*d-9*h+3*l,c=3*d-3*a):(r=6*b-12*e+6*f,s=-3*b+9*e-9*f+3*k,c=3*e-3*b),1E-12>Z(s)?1E-12>Z(r)||(s=-c/r,0<s&&1>s&&n.push(s)):(t=r*r-4*c*s,c=F.sqrt(t),0>t||(t=(-r+c)/(2*s),0<t&&1>t&&n.push(t),s=(-r-c)/(2*s),0<s&&1>s&&n.push(s)));for(r=q=n.length;q--;)s=n[q],c=1-s,p[0][q]=c*c*c*a+3*
c*c*s*d+3*c*s*s*h+s*s*s*l,p[1][q]=c*c*c*b+3*c*c*s*e+3*c*s*s*f+s*s*s*k;p[0][r]=a;p[1][r]=b;p[0][r+1]=l;p[1][r+1]=k;p[0].length=p[1].length=r+2;return{min:{x:X.apply(0,p[0]),y:X.apply(0,p[1])},max:{x:W.apply(0,p[0]),y:W.apply(0,p[1])}}}function I(a,b){var e=!b&&A(a);if(!b&&e.curve)return d(e.curve);var f=G(a),l=b&&G(b),n={x:0,y:0,bx:0,by:0,X:0,Y:0,qx:null,qy:null},k={x:0,y:0,bx:0,by:0,X:0,Y:0,qx:null,qy:null},p=function(a,b,c){if(!a)return["C",b.x,b.y,b.x,b.y,b.x,b.y];a[0]in{T:1,Q:1}||(b.qx=b.qy=null);
switch(a[0]){case "M":b.X=a[1];b.Y=a[2];break;case "A":a=["C"].concat(K.apply(0,[b.x,b.y].concat(a.slice(1))));break;case "S":"C"==c||"S"==c?(c=2*b.x-b.bx,b=2*b.y-b.by):(c=b.x,b=b.y);a=["C",c,b].concat(a.slice(1));break;case "T":"Q"==c||"T"==c?(b.qx=2*b.x-b.qx,b.qy=2*b.y-b.qy):(b.qx=b.x,b.qy=b.y);a=["C"].concat(J(b.x,b.y,b.qx,b.qy,a[1],a[2]));break;case "Q":b.qx=a[1];b.qy=a[2];a=["C"].concat(J(b.x,b.y,a[1],a[2],a[3],a[4]));break;case "L":a=["C"].concat(h(b.x,b.y,a[1],a[2]));break;case "H":a=["C"].concat(h(b.x,
b.y,a[1],b.y));break;case "V":a=["C"].concat(h(b.x,b.y,b.x,a[1]));break;case "Z":a=["C"].concat(h(b.x,b.y,b.X,b.Y))}return a},s=function(a,b){if(7<a[b].length){a[b].shift();for(var c=a[b];c.length;)q[b]="A",l&&(u[b]="A"),a.splice(b++,0,["C"].concat(c.splice(0,6)));a.splice(b,1);v=W(f.length,l&&l.length||0)}},r=function(a,b,c,d,e){a&&b&&"M"==a[e][0]&&"M"!=b[e][0]&&(b.splice(e,0,["M",d.x,d.y]),c.bx=0,c.by=0,c.x=a[e][1],c.y=a[e][2],v=W(f.length,l&&l.length||0))},q=[],u=[],c="",t="",x=0,v=W(f.length,
l&&l.length||0);for(;x<v;x++){f[x]&&(c=f[x][0]);"C"!=c&&(q[x]=c,x&&(t=q[x-1]));f[x]=p(f[x],n,t);"A"!=q[x]&&"C"==c&&(q[x]="C");s(f,x);l&&(l[x]&&(c=l[x][0]),"C"!=c&&(u[x]=c,x&&(t=u[x-1])),l[x]=p(l[x],k,t),"A"!=u[x]&&"C"==c&&(u[x]="C"),s(l,x));r(f,l,n,k,x);r(l,f,k,n,x);var w=f[x],z=l&&l[x],y=w.length,U=l&&z.length;n.x=w[y-2];n.y=w[y-1];n.bx=$(w[y-4])||n.x;n.by=$(w[y-3])||n.y;k.bx=l&&($(z[U-4])||k.x);k.by=l&&($(z[U-3])||k.y);k.x=l&&z[U-2];k.y=l&&z[U-1]}l||(e.curve=d(f));return l?[f,l]:f}function P(a,
b){for(var d=[],e=0,h=a.length;h-2*!b>e;e+=2){var f=[{x:+a[e-2],y:+a[e-1]},{x:+a[e],y:+a[e+1]},{x:+a[e+2],y:+a[e+3]},{x:+a[e+4],y:+a[e+5]}];b?e?h-4==e?f[3]={x:+a[0],y:+a[1]}:h-2==e&&(f[2]={x:+a[0],y:+a[1]},f[3]={x:+a[2],y:+a[3]}):f[0]={x:+a[h-2],y:+a[h-1]}:h-4==e?f[3]=f[2]:e||(f[0]={x:+a[e],y:+a[e+1]});d.push(["C",(-f[0].x+6*f[1].x+f[2].x)/6,(-f[0].y+6*f[1].y+f[2].y)/6,(f[1].x+6*f[2].x-f[3].x)/6,(f[1].y+6*f[2].y-f[3].y)/6,f[2].x,f[2].y])}return d}y=k.prototype;var Q=a.is,C=a._.clone,L="hasOwnProperty",
N=/,?([a-z]),?/gi,$=parseFloat,F=Math,S=F.PI,X=F.min,W=F.max,ma=F.pow,Z=F.abs;M=n(1);var na=n(),ba=n(0,1),V=a._unit2px;a.path=A;a.path.getTotalLength=M;a.path.getPointAtLength=na;a.path.getSubpath=function(a,b,d){if(1E-6>this.getTotalLength(a)-d)return ba(a,b).end;a=ba(a,d,1);return b?ba(a,b).end:a};y.getTotalLength=function(){if(this.node.getTotalLength)return this.node.getTotalLength()};y.getPointAtLength=function(a){return na(this.attr("d"),a)};y.getSubpath=function(b,d){return a.path.getSubpath(this.attr("d"),
b,d)};a._.box=w;a.path.findDotsAtSegment=u;a.path.bezierBBox=p;a.path.isPointInsideBBox=b;a.path.isBBoxIntersect=q;a.path.intersection=function(a,b){return l(a,b)};a.path.intersectionNumber=function(a,b){return l(a,b,1)};a.path.isPointInside=function(a,d,e){var h=r(a);return b(h,d,e)&&1==l(a,[["M",d,e],["H",h.x2+10] ],1)%2};a.path.getBBox=r;a.path.get={path:function(a){return a.attr("path")},circle:function(a){a=V(a);return x(a.cx,a.cy,a.r)},ellipse:function(a){a=V(a);return x(a.cx||0,a.cy||0,a.rx,
a.ry)},rect:function(a){a=V(a);return s(a.x||0,a.y||0,a.width,a.height,a.rx,a.ry)},image:function(a){a=V(a);return s(a.x||0,a.y||0,a.width,a.height)},line:function(a){return"M"+[a.attr("x1")||0,a.attr("y1")||0,a.attr("x2"),a.attr("y2")]},polyline:function(a){return"M"+a.attr("points")},polygon:function(a){return"M"+a.attr("points")+"z"},deflt:function(a){a=a.node.getBBox();return s(a.x,a.y,a.width,a.height)}};a.path.toRelative=function(b){var e=A(b),h=String.prototype.toLowerCase;if(e.rel)return d(e.rel);
a.is(b,"array")&&a.is(b&&b[0],"array")||(b=a.parsePathString(b));var f=[],l=0,n=0,k=0,p=0,s=0;"M"==b[0][0]&&(l=b[0][1],n=b[0][2],k=l,p=n,s++,f.push(["M",l,n]));for(var r=b.length;s<r;s++){var q=f[s]=[],x=b[s];if(x[0]!=h.call(x[0]))switch(q[0]=h.call(x[0]),q[0]){case "a":q[1]=x[1];q[2]=x[2];q[3]=x[3];q[4]=x[4];q[5]=x[5];q[6]=+(x[6]-l).toFixed(3);q[7]=+(x[7]-n).toFixed(3);break;case "v":q[1]=+(x[1]-n).toFixed(3);break;case "m":k=x[1],p=x[2];default:for(var c=1,t=x.length;c<t;c++)q[c]=+(x[c]-(c%2?l:
n)).toFixed(3)}else for(f[s]=[],"m"==x[0]&&(k=x[1]+l,p=x[2]+n),q=0,c=x.length;q<c;q++)f[s][q]=x[q];x=f[s].length;switch(f[s][0]){case "z":l=k;n=p;break;case "h":l+=+f[s][x-1];break;case "v":n+=+f[s][x-1];break;default:l+=+f[s][x-2],n+=+f[s][x-1]}}f.toString=z;e.rel=d(f);return f};a.path.toAbsolute=G;a.path.toCubic=I;a.path.map=function(a,b){if(!b)return a;var d,e,h,f,l,n,k;a=I(a);h=0;for(l=a.length;h<l;h++)for(k=a[h],f=1,n=k.length;f<n;f+=2)d=b.x(k[f],k[f+1]),e=b.y(k[f],k[f+1]),k[f]=d,k[f+1]=e;return a};
a.path.toString=z;a.path.clone=d});C.plugin(function(a,v,y,C){var A=Math.max,w=Math.min,z=function(a){this.items=[];this.bindings={};this.length=0;this.type="set";if(a)for(var f=0,n=a.length;f<n;f++)a[f]&&(this[this.items.length]=this.items[this.items.length]=a[f],this.length++)};v=z.prototype;v.push=function(){for(var a,f,n=0,k=arguments.length;n<k;n++)if(a=arguments[n])f=this.items.length,this[f]=this.items[f]=a,this.length++;return this};v.pop=function(){this.length&&delete this[this.length--];
return this.items.pop()};v.forEach=function(a,f){for(var n=0,k=this.items.length;n<k&&!1!==a.call(f,this.items[n],n);n++);return this};v.animate=function(d,f,n,u){"function"!=typeof n||n.length||(u=n,n=L.linear);d instanceof a._.Animation&&(u=d.callback,n=d.easing,f=n.dur,d=d.attr);var p=arguments;if(a.is(d,"array")&&a.is(p[p.length-1],"array"))var b=!0;var q,e=function(){q?this.b=q:q=this.b},l=0,r=u&&function(){l++==this.length&&u.call(this)};return this.forEach(function(a,l){k.once("snap.animcreated."+
a.id,e);b?p[l]&&a.animate.apply(a,p[l]):a.animate(d,f,n,r)})};v.remove=function(){for(;this.length;)this.pop().remove();return this};v.bind=function(a,f,k){var u={};if("function"==typeof f)this.bindings[a]=f;else{var p=k||a;this.bindings[a]=function(a){u[p]=a;f.attr(u)}}return this};v.attr=function(a){var f={},k;for(k in a)if(this.bindings[k])this.bindings[k](a[k]);else f[k]=a[k];a=0;for(k=this.items.length;a<k;a++)this.items[a].attr(f);return this};v.clear=function(){for(;this.length;)this.pop()};
v.splice=function(a,f,k){a=0>a?A(this.length+a,0):a;f=A(0,w(this.length-a,f));var u=[],p=[],b=[],q;for(q=2;q<arguments.length;q++)b.push(arguments[q]);for(q=0;q<f;q++)p.push(this[a+q]);for(;q<this.length-a;q++)u.push(this[a+q]);var e=b.length;for(q=0;q<e+u.length;q++)this.items[a+q]=this[a+q]=q<e?b[q]:u[q-e];for(q=this.items.length=this.length-=f-e;this[q];)delete this[q++];return new z(p)};v.exclude=function(a){for(var f=0,k=this.length;f<k;f++)if(this[f]==a)return this.splice(f,1),!0;return!1};
v.insertAfter=function(a){for(var f=this.items.length;f--;)this.items[f].insertAfter(a);return this};v.getBBox=function(){for(var a=[],f=[],k=[],u=[],p=this.items.length;p--;)if(!this.items[p].removed){var b=this.items[p].getBBox();a.push(b.x);f.push(b.y);k.push(b.x+b.width);u.push(b.y+b.height)}a=w.apply(0,a);f=w.apply(0,f);k=A.apply(0,k);u=A.apply(0,u);return{x:a,y:f,x2:k,y2:u,width:k-a,height:u-f,cx:a+(k-a)/2,cy:f+(u-f)/2}};v.clone=function(a){a=new z;for(var f=0,k=this.items.length;f<k;f++)a.push(this.items[f].clone());
return a};v.toString=function(){return"Snap\u2018s set"};v.type="set";a.set=function(){var a=new z;arguments.length&&a.push.apply(a,Array.prototype.slice.call(arguments,0));return a}});C.plugin(function(a,v,y,C){function A(a){var b=a[0];switch(b.toLowerCase()){case "t":return[b,0,0];case "m":return[b,1,0,0,1,0,0];case "r":return 4==a.length?[b,0,a[2],a[3] ]:[b,0];case "s":return 5==a.length?[b,1,1,a[3],a[4] ]:3==a.length?[b,1,1]:[b,1]}}function w(b,d,f){d=q(d).replace(/\.{3}|\u2026/g,b);b=a.parseTransformString(b)||
[];d=a.parseTransformString(d)||[];for(var k=Math.max(b.length,d.length),p=[],v=[],h=0,w,z,y,I;h<k;h++){y=b[h]||A(d[h]);I=d[h]||A(y);if(y[0]!=I[0]||"r"==y[0].toLowerCase()&&(y[2]!=I[2]||y[3]!=I[3])||"s"==y[0].toLowerCase()&&(y[3]!=I[3]||y[4]!=I[4])){b=a._.transform2matrix(b,f());d=a._.transform2matrix(d,f());p=[["m",b.a,b.b,b.c,b.d,b.e,b.f] ];v=[["m",d.a,d.b,d.c,d.d,d.e,d.f] ];break}p[h]=[];v[h]=[];w=0;for(z=Math.max(y.length,I.length);w<z;w++)w in y&&(p[h][w]=y[w]),w in I&&(v[h][w]=I[w])}return{from:u(p),
to:u(v),f:n(p)}}function z(a){return a}function d(a){return function(b){return+b.toFixed(3)+a}}function f(b){return a.rgb(b[0],b[1],b[2])}function n(a){var b=0,d,f,k,n,h,p,q=[];d=0;for(f=a.length;d<f;d++){h="[";p=['"'+a[d][0]+'"'];k=1;for(n=a[d].length;k<n;k++)p[k]="val["+b++ +"]";h+=p+"]";q[d]=h}return Function("val","return Snap.path.toString.call(["+q+"])")}function u(a){for(var b=[],d=0,f=a.length;d<f;d++)for(var k=1,n=a[d].length;k<n;k++)b.push(a[d][k]);return b}var p={},b=/[a-z]+$/i,q=String;
p.stroke=p.fill="colour";v.prototype.equal=function(a,b){return k("snap.util.equal",this,a,b).firstDefined()};k.on("snap.util.equal",function(e,k){var r,s;r=q(this.attr(e)||"");var x=this;if(r==+r&&k==+k)return{from:+r,to:+k,f:z};if("colour"==p[e])return r=a.color(r),s=a.color(k),{from:[r.r,r.g,r.b,r.opacity],to:[s.r,s.g,s.b,s.opacity],f:f};if("transform"==e||"gradientTransform"==e||"patternTransform"==e)return k instanceof a.Matrix&&(k=k.toTransformString()),a._.rgTransform.test(k)||(k=a._.svgTransform2string(k)),
w(r,k,function(){return x.getBBox(1)});if("d"==e||"path"==e)return r=a.path.toCubic(r,k),{from:u(r[0]),to:u(r[1]),f:n(r[0])};if("points"==e)return r=q(r).split(a._.separator),s=q(k).split(a._.separator),{from:r,to:s,f:function(a){return a}};aUnit=r.match(b);s=q(k).match(b);return aUnit&&aUnit==s?{from:parseFloat(r),to:parseFloat(k),f:d(aUnit)}:{from:this.asPX(e),to:this.asPX(e,k),f:z}})});C.plugin(function(a,v,y,C){var A=v.prototype,w="createTouch"in C.doc;v="click dblclick mousedown mousemove mouseout mouseover mouseup touchstart touchmove touchend touchcancel".split(" ");
var z={mousedown:"touchstart",mousemove:"touchmove",mouseup:"touchend"},d=function(a,b){var d="y"==a?"scrollTop":"scrollLeft",e=b&&b.node?b.node.ownerDocument:C.doc;return e[d in e.documentElement?"documentElement":"body"][d]},f=function(){this.returnValue=!1},n=function(){return this.originalEvent.preventDefault()},u=function(){this.cancelBubble=!0},p=function(){return this.originalEvent.stopPropagation()},b=function(){if(C.doc.addEventListener)return function(a,b,e,f){var k=w&&z[b]?z[b]:b,l=function(k){var l=
d("y",f),q=d("x",f);if(w&&z.hasOwnProperty(b))for(var r=0,u=k.targetTouches&&k.targetTouches.length;r<u;r++)if(k.targetTouches[r].target==a||a.contains(k.targetTouches[r].target)){u=k;k=k.targetTouches[r];k.originalEvent=u;k.preventDefault=n;k.stopPropagation=p;break}return e.call(f,k,k.clientX+q,k.clientY+l)};b!==k&&a.addEventListener(b,l,!1);a.addEventListener(k,l,!1);return function(){b!==k&&a.removeEventListener(b,l,!1);a.removeEventListener(k,l,!1);return!0}};if(C.doc.attachEvent)return function(a,
b,e,h){var k=function(a){a=a||h.node.ownerDocument.window.event;var b=d("y",h),k=d("x",h),k=a.clientX+k,b=a.clientY+b;a.preventDefault=a.preventDefault||f;a.stopPropagation=a.stopPropagation||u;return e.call(h,a,k,b)};a.attachEvent("on"+b,k);return function(){a.detachEvent("on"+b,k);return!0}}}(),q=[],e=function(a){for(var b=a.clientX,e=a.clientY,f=d("y"),l=d("x"),n,p=q.length;p--;){n=q[p];if(w)for(var r=a.touches&&a.touches.length,u;r--;){if(u=a.touches[r],u.identifier==n.el._drag.id||n.el.node.contains(u.target)){b=
u.clientX;e=u.clientY;(a.originalEvent?a.originalEvent:a).preventDefault();break}}else a.preventDefault();b+=l;e+=f;k("snap.drag.move."+n.el.id,n.move_scope||n.el,b-n.el._drag.x,e-n.el._drag.y,b,e,a)}},l=function(b){a.unmousemove(e).unmouseup(l);for(var d=q.length,f;d--;)f=q[d],f.el._drag={},k("snap.drag.end."+f.el.id,f.end_scope||f.start_scope||f.move_scope||f.el,b);q=[]};for(y=v.length;y--;)(function(d){a[d]=A[d]=function(e,f){a.is(e,"function")&&(this.events=this.events||[],this.events.push({name:d,
f:e,unbind:b(this.node||document,d,e,f||this)}));return this};a["un"+d]=A["un"+d]=function(a){for(var b=this.events||[],e=b.length;e--;)if(b[e].name==d&&(b[e].f==a||!a)){b[e].unbind();b.splice(e,1);!b.length&&delete this.events;break}return this}})(v[y]);A.hover=function(a,b,d,e){return this.mouseover(a,d).mouseout(b,e||d)};A.unhover=function(a,b){return this.unmouseover(a).unmouseout(b)};var r=[];A.drag=function(b,d,f,h,n,p){function u(r,v,w){(r.originalEvent||r).preventDefault();this._drag.x=v;
this._drag.y=w;this._drag.id=r.identifier;!q.length&&a.mousemove(e).mouseup(l);q.push({el:this,move_scope:h,start_scope:n,end_scope:p});d&&k.on("snap.drag.start."+this.id,d);b&&k.on("snap.drag.move."+this.id,b);f&&k.on("snap.drag.end."+this.id,f);k("snap.drag.start."+this.id,n||h||this,v,w,r)}if(!arguments.length){var v;return this.drag(function(a,b){this.attr({transform:v+(v?"T":"t")+[a,b]})},function(){v=this.transform().local})}this._drag={};r.push({el:this,start:u});this.mousedown(u);return this};
A.undrag=function(){for(var b=r.length;b--;)r[b].el==this&&(this.unmousedown(r[b].start),r.splice(b,1),k.unbind("snap.drag.*."+this.id));!r.length&&a.unmousemove(e).unmouseup(l);return this}});C.plugin(function(a,v,y,C){y=y.prototype;var A=/^\s*url\((.+)\)/,w=String,z=a._.$;a.filter={};y.filter=function(d){var f=this;"svg"!=f.type&&(f=f.paper);d=a.parse(w(d));var k=a._.id(),u=z("filter");z(u,{id:k,filterUnits:"userSpaceOnUse"});u.appendChild(d.node);f.defs.appendChild(u);return new v(u)};k.on("snap.util.getattr.filter",
function(){k.stop();var d=z(this.node,"filter");if(d)return(d=w(d).match(A))&&a.select(d[1])});k.on("snap.util.attr.filter",function(d){if(d instanceof v&&"filter"==d.type){k.stop();var f=d.node.id;f||(z(d.node,{id:d.id}),f=d.id);z(this.node,{filter:a.url(f)})}d&&"none"!=d||(k.stop(),this.node.removeAttribute("filter"))});a.filter.blur=function(d,f){null==d&&(d=2);return a.format('<feGaussianBlur stdDeviation="{def}"/>',{def:null==f?d:[d,f]})};a.filter.blur.toString=function(){return this()};a.filter.shadow=
function(d,f,k,u,p){"string"==typeof k&&(p=u=k,k=4);"string"!=typeof u&&(p=u,u="#000");null==k&&(k=4);null==p&&(p=1);null==d&&(d=0,f=2);null==f&&(f=d);u=a.color(u||"#000");return a.format('<feGaussianBlur in="SourceAlpha" stdDeviation="{blur}"/><feOffset dx="{dx}" dy="{dy}" result="offsetblur"/><feFlood flood-color="{color}"/><feComposite in2="offsetblur" operator="in"/><feComponentTransfer><feFuncA type="linear" slope="{opacity}"/></feComponentTransfer><feMerge><feMergeNode/><feMergeNode in="SourceGraphic"/></feMerge>',
{color:u,dx:d,dy:f,blur:k,opacity:p})};a.filter.shadow.toString=function(){return this()};a.filter.grayscale=function(d){null==d&&(d=1);return a.format('<feColorMatrix type="matrix" values="{a} {b} {c} 0 0 {d} {e} {f} 0 0 {g} {b} {h} 0 0 0 0 0 1 0"/>',{a:0.2126+0.7874*(1-d),b:0.7152-0.7152*(1-d),c:0.0722-0.0722*(1-d),d:0.2126-0.2126*(1-d),e:0.7152+0.2848*(1-d),f:0.0722-0.0722*(1-d),g:0.2126-0.2126*(1-d),h:0.0722+0.9278*(1-d)})};a.filter.grayscale.toString=function(){return this()};a.filter.sepia=
function(d){null==d&&(d=1);return a.format('<feColorMatrix type="matrix" values="{a} {b} {c} 0 0 {d} {e} {f} 0 0 {g} {h} {i} 0 0 0 0 0 1 0"/>',{a:0.393+0.607*(1-d),b:0.769-0.769*(1-d),c:0.189-0.189*(1-d),d:0.349-0.349*(1-d),e:0.686+0.314*(1-d),f:0.168-0.168*(1-d),g:0.272-0.272*(1-d),h:0.534-0.534*(1-d),i:0.131+0.869*(1-d)})};a.filter.sepia.toString=function(){return this()};a.filter.saturate=function(d){null==d&&(d=1);return a.format('<feColorMatrix type="saturate" values="{amount}"/>',{amount:1-
d})};a.filter.saturate.toString=function(){return this()};a.filter.hueRotate=function(d){return a.format('<feColorMatrix type="hueRotate" values="{angle}"/>',{angle:d||0})};a.filter.hueRotate.toString=function(){return this()};a.filter.invert=function(d){null==d&&(d=1);return a.format('<feComponentTransfer><feFuncR type="table" tableValues="{amount} {amount2}"/><feFuncG type="table" tableValues="{amount} {amount2}"/><feFuncB type="table" tableValues="{amount} {amount2}"/></feComponentTransfer>',{amount:d,
amount2:1-d})};a.filter.invert.toString=function(){return this()};a.filter.brightness=function(d){null==d&&(d=1);return a.format('<feComponentTransfer><feFuncR type="linear" slope="{amount}"/><feFuncG type="linear" slope="{amount}"/><feFuncB type="linear" slope="{amount}"/></feComponentTransfer>',{amount:d})};a.filter.brightness.toString=function(){return this()};a.filter.contrast=function(d){null==d&&(d=1);return a.format('<feComponentTransfer><feFuncR type="linear" slope="{amount}" intercept="{amount2}"/><feFuncG type="linear" slope="{amount}" intercept="{amount2}"/><feFuncB type="linear" slope="{amount}" intercept="{amount2}"/></feComponentTransfer>',
{amount:d,amount2:0.5-d/2})};a.filter.contrast.toString=function(){return this()}});return C});

]]> </script>
</svg>




## Resultados

### Especificaciones del Grafo

- Número de Nodos: 200

- Radio de Conexión: 0.125

### Nodo Central

- Posición del Nodo Central: Aproximadamente 

- Distancia Mínima al Centro: Calculada en la implementación.

### Colores

- Gradiente utilizado: De rojo a amarillo.

- Nodo central resaltado en azul.

### Imagen Generada

La imagen del grafo se guardó como **graph_plot.png** en la carpeta ./fig.
