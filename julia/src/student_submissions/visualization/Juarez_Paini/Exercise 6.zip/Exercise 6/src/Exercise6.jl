using Graphs, GraphMakie, CairoMakie, Random

function encontrarNodoCentro(puntos)
    distanciaActual = Inf
    nodoCentro = 0
    for (indice, punto) in enumerate(eachcol(puntos))
        # Calculando la distancia euclidiana entre nodos
        distancia = (punto[1] - 0.5)^2 + (punto[2] - 0.5)^2 
        if distancia < distanciaActual
            distanciaActual = distancia
            nodoCentro = indice
        end
    end
    nodoCentro
end


function dibujarGrafoGeometricoAleatorio(puntos::Matrix{Float32})
    grafo, = euclidean_graph(puntos; cutoff=0.125)  # Crear grafo geométrico

    nodoCentral = encontrarNodoCentro(puntos)  # Nodo más cercano al centro
    
    colorNodo = dijkstra_shortest_paths(grafo, nodoCentral).dists  # Colores basados en distancia

    # Tamaño de nodos
    tamañoNodo = fill(10, nv(grafo))
    tamañoNodo[nodoCentral] = 30
   
    # Etiquetas de nodos
    etiquetasNodos = 1:nv(grafo) 
    tamañoFuente = fill(0, nv(grafo))
    tamañoFuente[nodoCentral] = 8

    # Crear gráfico
    figura, ejes, p = graphplot(grafo;
        node_size=tamañoNodo,
        node_color=colorNodo,
        ilabels_fontsize=tamañoFuente,
        ilabels=etiquetasNodos,
        ilabels_color=:white,
    )

    save("GrafoGeometricoAleatorio.png", figura)
    figura  # Devolver figura
end


# Generar una matriz de 2x300 con números aleatorios entre 0 y 1, distribuidos uniformemente, y cada número tiene tipo Float32
puntos = rand(Xoshiro(2), Float32, (2, 300))   
# Dibuja el grafo
dibujarGrafoGeometricoAleatorio(puntos)               
