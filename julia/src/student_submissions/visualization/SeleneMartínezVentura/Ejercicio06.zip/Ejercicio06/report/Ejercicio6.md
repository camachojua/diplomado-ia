Produce the plot shown below in Julia. You may use the Plots or the Makie Package.
1. Submit your project following the submission guidelines
2. Be sure that you include the code and the figure(s)


```julia
#import Pkg
#Pkg.add(["Graphs", "GraphPlot"])
using Graphs
using GraphPlot
using Random
using GLMakie
#Pkg.add("GraphMakie")
using GraphMakie
using GraphMakie.NetworkLayout

n = 200# Nodes number 
radius = 0.125
# Generación de un grafo geométrico aleatorio (posición de nodos basada en coordenadas aleatorias)
positions = [(rand(), rand()) for _ in 1:n];

# Construir el grafo basado en distancias
G = SimpleGraph(n)
# Agrego aristas cuando se tienen nodos cuya distancia euclidea es menor al radio umbral definido.
# Con esto se cumple la condición de Random Geometric Graph
for i in 1:n
    for j in i+1:n
        d = sqrt((positions[i][1] - positions[j][1])^2 + (positions[i][2] - positions[j][2])^2)
        if d < radius
            add_edge!(G, i, j)
        end
    end
end
# A continuación se realiza la busqueda del nodo más cercano al centro (0.5, 0.5)
dmin = 1
ncenter = 0
for n in 1:n
    x, y = positions[n]
    d = (x - 0.5)^2 + (y - 0.5)^2
    if d < dmin
        ncenter = n
        dmin = d
    end
end

println(ncenter)

# Calcular las distancias más cortas desde el nodo cercano al centro
# Distancia en términos de grafos como la longitud del camino más corto entre dos nodos.
dist_values = dijkstra_shortest_paths(G, ncenter).dists;
# Extraer las distancias de los nodos

# Crear el gráfico
fig = Figure(size = (800, 800))

# Usamos GraphMakie para dibujar el grafo
ax = Axis(fig[1, 1])
graphplot!(ax, G, layout = positions, 
       nodefill =  [dist_values[i] for i in 1:n], 
       nodecolor = :reds, 
       nodewidth = 2.0, 
       nodealpha = 0.9, 
       edgestroke = 0.9, 
       edgealpha = 0.7,
       edgecolor = :lightgray)

# Personalizar la visualización (ajustar límites)
xlims!(ax, -0.05, 1.05)
ylims!(ax, -0.05, 1.05)

# Guardar la visualización
save("../fig/random_geometric_graph.png", fig)

# Mostrar la visualización
display(fig)
```

    78



    GLMakie.Screen(...)


##### Crear un grafo geométrico aleatorio con n nodos, donde la probabilidad de que haya una arista entre dos nodos depende de la distancia entre ellos.
##### Si la distancia euclidiana entre dos nodos es menor que 0.125, entonces se conecta una arista entre ellos.


```julia
# Graficar con Makie
#fig = Figure(size = (800, 800))
#gplot(G)
```
