#import Pkg
#Pkg.add(["Graphs", "GraphPlot"])
using Graphs
using GraphPlot
using Random
using GLMakie
n = 200 # Nodes number 
radius = 0.125

# Generación de un grafo geométrico aleatorio (posición de nodos basada en coordenadas aleatorias)
positions = [(rand(), rand()) for _ in 1:n]

# Construir el grafo basado en distancias
G = SimpleGraph(n)
for i in 1:n
    for j in i+1:n
        d = sqrt((positions[i][1] - positions[j][1])^2 + (positions[i][2] - positions[j][2])^2)
        if d < radius
            add_edge!(G, i, j)
        end
    end
end

# Buscar el nodo más cercano al centro (0.5, 0.5)
dmin = Inf
local_ncenter = 0
for n in 1:n
    x, y = positions[n]
    d = (x - 0.5)^2 + (y - 0.5)^2
    if d < dmin
        local_ncenter = n
        dmin = d
    end
end
# Calcular las distancias más cortas desde el nodo cercano al centro
dist_values = dijkstra_shortest_paths(G, ncenter)

# Extraer las posiciones para los nodos
x_coords = [positions[i][1] for i in 1:n]
y_coords = [positions[i][2] for i in 1:n]
# Graficar con Makie
fig = Figure(size = (800, 800))

# Dibujar los nodos y aristas
ax = Axis(fig[1, 1], title = "Random Geometric Graph", xlabel = "X", ylabel = "Y")
# Extraer las distancias de los nodos
path_lengths = dist_values.dists
# Normalizar las distancias (opcional, para mejor visualización)
min_dist = minimum(filter(!isinf, values(path_lengths)))
max_dist = maximum(values(path_lengths))
normalized_distances = [ 
    (get(path_lengths, i, Inf) - min_dist) / (max_dist - min_dist) for i in 1:n 
]
# Dibujar los nodos, coloreados por la distancia más corta
scatter!(ax, x_coords, y_coords, color = path_lengths, colormap = :reds, markersize = 5)

# Resaltar el nodo más cercano al centro
scatter!(ax, x_coords[ncenter], y_coords[ncenter], color = :black, markersize = 10)
# Dibujar las aristas (opcional)
for e in edges(G)
    i, j = src(e), dst(e) #Accedemos a los nodos de la arista usando src() y dst()
    x1, y1 = positions[i]
    x2, y2 = positions[j]
    plot!(ax, [x1, x2], [y1, y2], color = :gray, strokewidth = 0.5)
end
# Mostrar la figura
display(fig)