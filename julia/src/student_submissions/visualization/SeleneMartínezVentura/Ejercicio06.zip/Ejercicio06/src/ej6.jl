using Graphs
using Random
using GLMakie
using GraphMakie

# 1. Función para generar el grafo geométrico aleatorio
function generar_grafo_geometrico(n, radius)
    # Generación de posiciones aleatorias para los nodos
    positions = [(rand(), rand()) for _ in 1:n]

    # Construcción del grafo geométrico aleatorio
    G = SimpleGraph(n)
    for i in 1:n
        for j in i+1:n
            d = sqrt((positions[i][1] - positions[j][1])^2 + (positions[i][2] - positions[j][2])^2)
            if d < radius
                add_edge!(G, i, j)
            end
        end
    end
    return G, positions
end

# 2. Función para buscar el nodo más cercano al centro (0.5, 0.5)
function buscar_nodo_central(positions)
    dmin = 1
    ncenter = 0
    for n in 1:length(positions)
        x, y = positions[n]
        d = (x - 0.5)^2 + (y - 0.5)^2
        if d < dmin
            ncenter = n
            dmin = d
        end
    end
    return ncenter
end

# 3. Función para calcular las distancias más cortas desde el nodo central
function calcular_distancias(G, ncenter)
    dist_values = dijkstra_shortest_paths(G, ncenter).dists
    return dist_values
end

# 4. Función para visualizar el grafo con el nodo central resaltado
function visualizar_grafo(positions, G, dist_values, ncenter)
    # Crear la figura para la visualización
    fig = Figure(size = (800, 800))

    # Usar GraphMakie para crear el grafo
    ax = Axis(fig[1, 1])

    # Usar un gradiente de colores para los nodos basado en las distancias
    max_dist = maximum(dist_values)  # Obtener la distancia máxima
    node_colors = [dist / max_dist for dist in dist_values]  # Normalizar las distancias a un rango de 0 a 1

    # Graficar el grafo
    graphplot!(ax, G, layout = positions, 
        nodefill = node_colors,  # Colores normalizados
        nodecolor = :RdYlBu,  # Usar un mapa de colores (puedes cambiarlo)
        nodewidth = 4.0,  # Mayor tamaño de nodos
        nodealpha = 0.8,  # Algo de transparencia
        edgestroke = 0.8,  # Grosor de las aristas
        edgealpha = 0.6,   # Transparencia de las aristas
        edgecolor = :lightgray)

    # Destacar el nodo central con un color y tamaño especial
    highlight_radius = 0.05  # Aumentar tamaño del nodo central
    highlight_color = :red

    # Asegurarse de pasar `ax` a `scatter!` para resaltar el nodo central
    scatter!(ax, [positions[ncenter][1]], [positions[ncenter][2]], 
             markersize = highlight_radius * 100, color = highlight_color)

    # Personalizar límites
    xlims!(ax, -0.05, 1.05)
    ylims!(ax, -0.05, 1.05)

    # Mostrar la visualización
    display(fig)

    # Guardar la visualización como archivo
    save("../fig/random_geometric_graph_with_gradient.png", fig)
end

# Configuración de parámetros
n = 200  # Número de nodos
radius = 0.125  # Radio para la creación de aristas

# Ejecutar las funciones
G, positions = generar_grafo_geometrico(n, radius)
ncenter = buscar_nodo_central(positions)
dist_values = calcular_distancias(G, ncenter)
visualizar_grafo(positions, G, dist_values, ncenter)
