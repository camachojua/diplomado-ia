# Ejercicio 5: Regresión Logistica
_Felipe Andres Castillo_

# Introducción

El algoritmo de regresión logística, también conocido como clasificador de máxima entropía, se encuadra dentro de los conocidos como modelos lineales generalizados. El objetivo de este es, en un escenario de clasificación binaria, aproximar la probabilidad de que una muestra pertenezca a una cierta clase a partir de una combinación lineal de las características predictiva, es decir, a partir de la siguiente expresión: 
$$p = a_1x_1 + a_2x_2 + ... + a_nx_n $$
expresión en la que $x_1$, $x_2$, …, $x_n$ son las características predictivas y $a_1$, $a_2$ …, $a_n$ son los coeficientes de la combinación lineal. 

Sin embargo, si el objetivo es predecir la probabilidad ($p$) de un cierto evento, la relación entre las variables independientes mencionadas y la etiqueta (la probabilidad) no puede ser de ese tipo, entre otras cosas porque la probabilidad $p$ va a tomar un valor en el rango $[0, 1]$, mientras que la combinación línea va a devolver valores potencialmente en el rango $(-\infty, +\infty)$.

Para solucionar este problema no se considera la probabilidad $p$, sino la función _logit_ que, aun involucrando la probabilidad $p$, tiene como rango $(-\infty, +\infty)$. Esta función está definida de la siguiente forma:
$$logit(p) = \ln\left(\frac{p}{1-p}\right)$$
Es decir, nuestro modelo vendrá definido por la expresión
$$\ln\left(\frac{p}{1-p}\right) = a_1x_1 + a_2x_2 + ... + a_nx_n $$
$$\Rightarrow \frac{p}{1-p} = e^{a_1x_1 + a_2x_2 + ... + a_nx_n}$$
$$\Rightarrow p = (1-p) \cdot e^{a_1x_1 + a_2x_2 + ... + a_nx_n}$$
$$\Rightarrow p + p \cdot e^{a_1x_1 + a_2x_2 + ... + a_nx_n} = e^{a_1x_1 + a_2x_2 + ... + a_nx_n}$$
$$\Rightarrow p(1 + e^{a_1x_1 + a_2x_2 + ... + a_nx_n}) = e^{a_1x_1 + a_2x_2 + ... + a_nx_n}$$
$$\Rightarrow p = \frac{e^{a_1x_1 + a_2x_2 + ... + a_nx_n}}{1 + e^{a_1x_1 + a_2x_2 + ... + a_nx_n}} $$
$$\Rightarrow p = \frac{1}{1 + e^{-(a_1x_1 + a_2x_2 + ... + a_nx_n)}}$$
$$\therefore p = \frac{1}{1 + e^{-z}}$$
Esta es la llamada función **sigmoide**. 

![image.png](92d0f0a4-189f-4ea9-be3e-4137e621a80d.png)

La regresión logística calcula una suma ponderada de las características predictivas, pero en lugar de devolver dicho resultado, lo pasa por la función sigmoide para devolver un valor en el rango (0, 1) que se interpreta como una probabilidad.


```julia
using Pkg
#Pkg.add("Flux")

using CSV
using DataFrames
using Flux
using Statistics
using Random

#Se utilizan algunas funciones definidas en el ejercicio 1
include("./../src/exercise1_code.jl")
```




    displayCorrelation (generic function with 1 method)



## Datos

### Descripción de las variables

El dataset **Churn Modelling** contiene detalles de los clientes de un banco y la variable objetivo es una variable binaria que refleja el hecho de si el cliente dejó el banco (cerró su cuenta) o si continúa siendo un cliente.


```julia
CM_data = CSV.read("./../dat/Churn_Modelling.csv", DataFrame)
rows, cols = dataShape(CM_data)
println("El DataFrame consta de $(cols) columnas y $(rows) registros")
describe(CM_data)
```

    El DataFrame consta de 14 columnas y 10000 registros
    




<div><div style = "float: left;"><span>14×7 DataFrame</span></div><div style = "clear: both;"></div></div><div class = "data-frame" style = "overflow-x: scroll;"><table class = "data-frame" style = "margin-bottom: 6px;"><thead><tr class = "header"><th class = "rowNumber" style = "font-weight: bold; text-align: right;">Row</th><th style = "text-align: left;">variable</th><th style = "text-align: left;">mean</th><th style = "text-align: left;">min</th><th style = "text-align: left;">median</th><th style = "text-align: left;">max</th><th style = "text-align: left;">nmissing</th><th style = "text-align: left;">eltype</th></tr><tr class = "subheader headerLastRow"><th class = "rowNumber" style = "font-weight: bold; text-align: right;"></th><th title = "Symbol" style = "text-align: left;">Symbol</th><th title = "Union{Nothing, Float64}" style = "text-align: left;">Union…</th><th title = "Any" style = "text-align: left;">Any</th><th title = "Union{Nothing, Float64}" style = "text-align: left;">Union…</th><th title = "Any" style = "text-align: left;">Any</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "DataType" style = "text-align: left;">DataType</th></tr></thead><tbody><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1</td><td style = "text-align: left;">RowNumber</td><td style = "text-align: left;">5000.5</td><td style = "text-align: left;">1</td><td style = "text-align: left;">5000.5</td><td style = "text-align: left;">10000</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Int64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">2</td><td style = "text-align: left;">CustomerId</td><td style = "text-align: left;">1.56909e7</td><td style = "text-align: left;">15565701</td><td style = "text-align: left;">1.56907e7</td><td style = "text-align: left;">15815690</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Int64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">3</td><td style = "text-align: left;">Surname</td><td style = "font-style: italic; text-align: left;"></td><td style = "text-align: left;">Abazu</td><td style = "font-style: italic; text-align: left;"></td><td style = "text-align: left;">Zuyeva</td><td style = "text-align: right;">0</td><td style = "text-align: left;">String31</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">4</td><td style = "text-align: left;">CreditScore</td><td style = "text-align: left;">650.529</td><td style = "text-align: left;">350</td><td style = "text-align: left;">652.0</td><td style = "text-align: left;">850</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Int64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">5</td><td style = "text-align: left;">Geography</td><td style = "font-style: italic; text-align: left;"></td><td style = "text-align: left;">France</td><td style = "font-style: italic; text-align: left;"></td><td style = "text-align: left;">Spain</td><td style = "text-align: right;">0</td><td style = "text-align: left;">String7</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">6</td><td style = "text-align: left;">Gender</td><td style = "font-style: italic; text-align: left;"></td><td style = "text-align: left;">Female</td><td style = "font-style: italic; text-align: left;"></td><td style = "text-align: left;">Male</td><td style = "text-align: right;">0</td><td style = "text-align: left;">String7</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">7</td><td style = "text-align: left;">Age</td><td style = "text-align: left;">38.9218</td><td style = "text-align: left;">18</td><td style = "text-align: left;">37.0</td><td style = "text-align: left;">92</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Int64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">8</td><td style = "text-align: left;">Tenure</td><td style = "text-align: left;">5.0128</td><td style = "text-align: left;">0</td><td style = "text-align: left;">5.0</td><td style = "text-align: left;">10</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Int64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9</td><td style = "text-align: left;">Balance</td><td style = "text-align: left;">76485.9</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">97198.5</td><td style = "text-align: left;">2.50898e5</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Float64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">10</td><td style = "text-align: left;">NumOfProducts</td><td style = "text-align: left;">1.5302</td><td style = "text-align: left;">1</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">4</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Int64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">11</td><td style = "text-align: left;">HasCrCard</td><td style = "text-align: left;">0.7055</td><td style = "text-align: left;">0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">1</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Int64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">12</td><td style = "text-align: left;">IsActiveMember</td><td style = "text-align: left;">0.5151</td><td style = "text-align: left;">0</td><td style = "text-align: left;">1.0</td><td style = "text-align: left;">1</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Int64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">13</td><td style = "text-align: left;">EstimatedSalary</td><td style = "text-align: left;">1.0009e5</td><td style = "text-align: left;">11.58</td><td style = "text-align: left;">1.00194e5</td><td style = "text-align: left;">1.99992e5</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Float64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">14</td><td style = "text-align: left;">Exited</td><td style = "text-align: left;">0.2037</td><td style = "text-align: left;">0</td><td style = "text-align: left;">0.0</td><td style = "text-align: left;">1</td><td style = "text-align: right;">0</td><td style = "text-align: left;">Int64</td></tr></tbody></table></div>



1. **RowNumber**: numera cada uno de los 10000 registros
2. **CustomerId**: número de identificación de cada cliente
3. **Surname**: apellido del cliente
4. **CreditScore**: el rango de puntaje crediticio, que va de 350 a 850
5. **Geography**: país de residencia de los clientes (Francia, Alemania y España)
6. **Gender**: género del cliente
7. **Age**: edad (rango de 18 a 92 años)
8. **Tenure**: años que el cliente ha permanecido en el banco
9. **Balance**: la cantidad de dinero disponible para retirar
10. **NumOfProducts**: número de productos que los clientes utilizan en el banco
11. **HasCrCard**: indica si el cliente tiene tarjeta de crédito (1) o no (0)
12. **IsActiveMember**: indica si el cliente está activo (1) o no (0)
13. **EstimatedSalary**: el salario anual informado por el cliente
14. **Exited**: si el cliente ha abandonado (cerrado la cuenta bancaria), 1 indica abandono

### Missing values y outliers

Según el cuadro descriptivo, ninguna de las variables contiene **registros faltantes**. Además, la mayoría de las variables son categóricas. En el caso de las variables numéricas, se verifica que los valores mínimos y máximos se encuentran dentro de lo esperado, descartando números negativos, valores extremadamente grandes o resultados diferentes de 0 y 1 cuando no corresponde.

Por último, para las variables cuantitativas, no se identifican **valores atípicos**, lo que sugiere que los datos están dentro de un rango razonable para su análisis:


```julia
quantitative_var = filter(:Column => c -> c ∈ ["Balance", "EstimatedSalary"], dataType(CM_data))
for col_name in quantitative_var.Column
    removeOutliersIQR(col_name, CM_data)
end
```

    Se removieron 0 outliers de la columna Balance
    Se removieron 0 outliers de la columna EstimatedSalary
    

### One Hot Encoding y normalización

Algunas de las variables categoricas ya están codificadas (**One Hot Encoding**), pero hay otras que es necesario convertir sus valores a números.


```julia
function OneHotEncoding(column)
    variables = unique(column)
    n = 0
    for var in variables
        replace!(column, var => "$(n)")
        n+=1
    end
    column = parse.(Int, column)
    return column
end             
```




    OneHotEncoding (generic function with 1 method)




```julia
CM_data.Gender = OneHotEncoding(CM_data.Gender)
CM_data.Geography = OneHotEncoding(CM_data.Geography);
```

Para la variables cuantitativas, se **normalizarán** sus valores.


```julia
CM_data.Balance = Flux.normalise(CM_data.Balance)
CM_data.EstimatedSalary = Flux.normalise(CM_data.EstimatedSalary);
```

### Datos de entrenamiento y de prueba  

Dado que nos interesa predecir si un cliente dejará o permanecerá en el banco, las variables RowNumber, CustomerId y Surname, no son relevantes.


```julia
data = select(CM_data, Not(["RowNumber", "CustomerId", "Surname"]))
first(data, 5)
```




<div><div style = "float: left;"><span>5×11 DataFrame</span></div><div style = "clear: both;"></div></div><div class = "data-frame" style = "overflow-x: scroll;"><table class = "data-frame" style = "margin-bottom: 6px;"><thead><tr class = "header"><th class = "rowNumber" style = "font-weight: bold; text-align: right;">Row</th><th style = "text-align: left;">CreditScore</th><th style = "text-align: left;">Geography</th><th style = "text-align: left;">Gender</th><th style = "text-align: left;">Age</th><th style = "text-align: left;">Tenure</th><th style = "text-align: left;">Balance</th><th style = "text-align: left;">NumOfProducts</th><th style = "text-align: left;">HasCrCard</th><th style = "text-align: left;">IsActiveMember</th><th style = "text-align: left;">EstimatedSalary</th><th style = "text-align: left;">Exited</th></tr><tr class = "subheader headerLastRow"><th class = "rowNumber" style = "font-weight: bold; text-align: right;"></th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Int64" style = "text-align: left;">Int64</th></tr></thead><tbody><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1</td><td style = "text-align: right;">619</td><td style = "text-align: right;">0</td><td style = "text-align: right;">0</td><td style = "text-align: right;">42</td><td style = "text-align: right;">2</td><td style = "text-align: right;">-1.22585</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0.0218865</td><td style = "text-align: right;">1</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">2</td><td style = "text-align: right;">608</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0</td><td style = "text-align: right;">41</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0.11735</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0.216534</td><td style = "text-align: right;">0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">3</td><td style = "text-align: right;">502</td><td style = "text-align: right;">0</td><td style = "text-align: right;">0</td><td style = "text-align: right;">42</td><td style = "text-align: right;">8</td><td style = "text-align: right;">1.33305</td><td style = "text-align: right;">3</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0</td><td style = "text-align: right;">0.240687</td><td style = "text-align: right;">1</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">4</td><td style = "text-align: right;">699</td><td style = "text-align: right;">0</td><td style = "text-align: right;">0</td><td style = "text-align: right;">39</td><td style = "text-align: right;">1</td><td style = "text-align: right;">-1.22585</td><td style = "text-align: right;">2</td><td style = "text-align: right;">0</td><td style = "text-align: right;">0</td><td style = "text-align: right;">-0.108918</td><td style = "text-align: right;">0</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">5</td><td style = "text-align: right;">850</td><td style = "text-align: right;">1</td><td style = "text-align: right;">0</td><td style = "text-align: right;">43</td><td style = "text-align: right;">2</td><td style = "text-align: right;">0.785728</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">1</td><td style = "text-align: right;">-0.365276</td><td style = "text-align: right;">0</td></tr></tbody></table></div>




```julia
#Variables predictoras y variable objetivo
X = select(data, Not(:Exited))
y = data.Exited;
```

Lo siguiente es dividir nuestro conjunto de datos en dos subconjuntos: el de entrenamiento (70%) y el de prueba (30%).


```julia
Random.seed!(18)

# rows es el número total de registros
# Muestra aleatoria de indices para los datos de entrenamiento (70% de los datos)
idx_train = sample(1:rows, Int(round(0.7*rows)), replace = false)
# Indices restantes para los datos de prueba
idx_test = Not(idx_train)

# Datos entrenamiento
X_train = Float32.(Matrix(X[idx_train,:])')
y_train = Float32.(y[idx_train])

# Datos prueba
X_test = Float32.(Matrix(X[idx_test,:])')
y_test = Float32.(y[idx_test]);

# Nota: se usa la transpuesta de la matriz para X_train, X_test para obtener una matriz de 10 filas y n columnas. Este formato es necesario.
# también se convierten los valores Float64 a Float32, pues así lo sugiere la documentación para tener un mejor rendimiento
```

## Regresión Logistica con Flux

### Definición del modelo y entrenamiento


```julia
# Definir modelo: una sola salida con sigmoide
model = Chain(Dense(10 => 1, σ))
function loss(model, X, y)
    ŷ = model(X)[1,:]  # Nos da una matriz de 1x7000, pero "y" es un vector
    Flux.logitbinarycrossentropy(ŷ, y)
end

# Métrica de precisión
accuracy(model, X, y) = mean((model(X)[:, 1] .> 0.5) .== y)

# Optimizador
optimizer = Flux.setup(Adam(0.1), model)

# Entrenamiento
data = [(X_train, y_train)]
for epoch in 1:5
    Flux.train!(loss, model, data, optimizer)
    println("Epoch $epoch - Accuracy_train: $(accuracy(model, X_train, y_train)) - Accuracy_test: $(accuracy(model, X_test, y_test))")
end
```

    Epoch 1 - Accuracy_train: 0.7952857142857143 - Accuracy_test: 0.7986666666666666
    Epoch 2 - Accuracy_train: 0.7952857142857143 - Accuracy_test: 0.7986666666666666
    Epoch 3 - Accuracy_train: 0.7952857142857143 - Accuracy_test: 0.7986666666666666
    Epoch 4 - Accuracy_train: 0.7952857142857143 - Accuracy_test: 0.7986666666666666
    Epoch 5 - Accuracy_train: 0.7952857142857143 - Accuracy_test: 0.7986666666666666
    

Por alguna razón que no pude encontrar, el modelo hace que todos los valores predichos sean 0. Cambie la función de activación, la función de perdida, el optimizador, el learning rate, modifiqué la capa a una de 10 => 2, pero de cualquier forma se otiene el mismo resultado. 


```julia
countmap(model(X_train)[1,:])
```




    Dict{Float32, Int64} with 6 entries:
      0.0         => 6995
      2.29864f-33 => 1
      4.2274f-34  => 1
      4.101f-32   => 1
      6.3918f-34  => 1
      2.99723f-35 => 1



Pensé que podría ser por un problema de desbalanceo de las clases, siendo que hay más datos para 0, que para 1. Pero tampoco fue ese el problema. 


```julia
Random.seed!(18)

# rows es el número total de registros
# Muestra aleatoria de indices para los datos de entrenamiento (70% de los datos)
idx_train = sample(1:rows, Int(round(0.7*rows)), replace = false)
# Indices restantes para los datos de prueba
idx_test = Not(idx_train)

# Datos entrenamiento
X_train = Float32.(Matrix(X[idx_train,:])')
y_train = y[idx_train]

class0_idx = findall(y_train .== 0.0)
class1_idx = findall(y_train .== 1.0)
println("Clase 0: ", length(class0_idx))
println("Clase 1: ", length(class1_idx))

# Aumentar el número de registros asociados a la clase 1
oversampled_idx = vcat(class0_idx, sample(class1_idx, length(class0_idx), replace=true))
X_train =X_train[:,oversampled_idx]
y_train = y_train[oversampled_idx]

class0_idx = findall(y_train .== 0.0)
class1_idx = findall(y_train .== 1.0)
println("Clase 0 final: ", length(class0_idx))
println("Clase 1 final: ", length(class1_idx))

# Datos prueba
X_test = Float32.(Matrix(X[idx_test,:])')
y_test = y[idx_test];
```

    Clase 0: 5567
    Clase 1: 1433
    Clase 0 final: 5567
    Clase 1 final: 5567
    


```julia
# Definir modelo: una sola salida con sigmoide
model = Chain(Dense(10 => 1, σ))
function loss(model, X, y)
    ŷ = model(X)[1,:]  # Nos da una matriz de 1x7000, pero "y" es un vector
    Flux.logitbinarycrossentropy(ŷ, y)
end

# Métrica de precisión
accuracy(model, X, y) = mean((model(X)[:, 1] .> 0.5) .== y)

# Optimizador
optimizer = Flux.setup(Adam(0.1), model)

# Entrenamiento
data = [(X_train, y_train)]
for epoch in 1:5
    Flux.train!(loss, model, data, optimizer)
    println("Epoch $epoch - Accuracy_train: $(accuracy(model, X_train, y_train)) - Accuracy_test: $(accuracy(model, X_test, y_test))")
end
```

    Epoch 1 - Accuracy_train: 0.5 - Accuracy_test: 0.7986666666666666
    Epoch 2 - Accuracy_train: 0.5 - Accuracy_test: 0.7986666666666666
    Epoch 3 - Accuracy_train: 0.5 - Accuracy_test: 0.7986666666666666
    Epoch 4 - Accuracy_train: 0.5 - Accuracy_test: 0.7986666666666666
    Epoch 5 - Accuracy_train: 0.5 - Accuracy_test: 0.7986666666666666
    
