using Plots
using Colors

# Select the GR backend for better compatibility
gr()

# Parameters
num_nodes = 200                   # Number of nodes in the graph
connection_radius = 0.125         # Radius within which nodes are connected
connection_radius_sq = connection_radius^2  # Square of the connection radius for distance comparison

# Generate random positions for the nodes within the [0, 1] x [0, 1] space
positions = rand(num_nodes, 2)

# Initialize an adjacency list to represent the graph
adjacency_list = Vector{Vector{Int}}(undef, num_nodes)
for i in 1:num_nodes
    adjacency_list[i] = Int[]  # Start with an empty list for each node
end

# Build the graph by connecting nodes that are within the specified radius
for i in 1:num_nodes
    for j in (i+1):num_nodes
        dx = positions[i, 1] - positions[j, 1]
        dy = positions[i, 2] - positions[j, 2]
        if dx^2 + dy^2 <= connection_radius_sq
            push!(adjacency_list[i], j)
            push!(adjacency_list[j], i)
        end
    end
end

# Function to identify the node closest to the center point (0.5, 0.5)
function find_central_node(positions)
    minimum_distance = Inf
    central_node = 1
    for i in 1:size(positions, 1)
        x, y = positions[i, :]
        distance = (x - 0.5)^2 + (y - 0.5)^2
        if distance < minimum_distance
            minimum_distance = distance
            central_node = i
        end
    end
    return central_node
end

central_node = find_central_node(positions)
println("Central node: ", central_node)

# Function to compute the shortest path lengths from the central node using BFS
function compute_shortest_paths(adjacency_list, source)
    num_nodes = length(adjacency_list)
    distances = fill(Inf, num_nodes)  # Initialize all distances as infinite
    distances[source] = 0
    queue = Int[]  # Queue for BFS
    push!(queue, source)
    
    while !isempty(queue)
        current_node = popfirst!(queue)
        for neighbor in adjacency_list[current_node]
            if distances[neighbor] == Inf
                distances[neighbor] = distances[current_node] + 1
                push!(queue, neighbor)
            end
        end
    end
    return distances
end

path_lengths = compute_shortest_paths(adjacency_list, central_node)

# Prepare node colors based on the shortest path lengths
max_distance = maximum(path_lengths[.!isinf.(path_lengths)])
node_colors = Float64[]  # Initialize as a vector of Float64

for i in 1:num_nodes
    if isfinite(path_lengths[i])
        push!(node_colors, path_lengths[i])
    else
        push!(node_colors, max_distance)
    end
end

# Debugging checks to ensure node_colors is correctly formed
println("Type of node_colors: ", typeof(node_colors))
println("Length of node_colors: ", length(node_colors))
println("Are all values finite? ", all(isfinite, node_colors))

# Assertions to validate the integrity of node_colors
@assert typeof(node_colors) <: AbstractVector{Float64} "node_colors must be a Vector{Float64}"
@assert length(node_colors) == num_nodes "Length of node_colors must be equal to the number of nodes"
@assert all(isfinite, node_colors) "node_colors contains non-finite values"

# Function to manually interpolate between two colors based on a normalized value
function manual_color_interpolation(x, start_color, end_color)
    # x should be in the range [0, 1]
    r = red(start_color) + x * (red(end_color) - red(start_color))
    g = green(start_color) + x * (green(end_color) - green(start_color))
    b = blue(start_color) + x * (blue(end_color) - blue(start_color))
    return RGB(r, g, b)
end

# Define the start and end colors for interpolation
start_color = RGB(1.0, 0.0, 0.0)    # Red for nodes close to the center
end_color = RGB(1.0, 1.0, 1.0)      # White for nodes far from the center

# Normalize node_colors to the range [0, 1] for interpolation
min_color_value = minimum(node_colors)
max_color_value = maximum(node_colors)
normalized_node_colors = (node_colors .- min_color_value) ./ (max_color_value - min_color_value)

# Map the normalized values to RGB colors manually
mapped_colors = [manual_color_interpolation(x, start_color, end_color) for x in normalized_node_colors]

# Identify edges connected to the central node for highlighting
central_edges = [(central_node, neighbor) for neighbor in adjacency_list[central_node]]

# Compile a list of all unique edges in the graph
all_edges = Vector{Tuple{Int, Int}}()
for i in 1:num_nodes
    for j in adjacency_list[i]
        if i < j  # Ensure each edge is only added once
            push!(all_edges, (i, j))
        end
    end
end

# Create coordinate lists for plotting edges
edge_x_coords = Vector{Vector{Float64}}()  # List of x-coordinates for each edge
edge_y_coords = Vector{Vector{Float64}}()  # List of y-coordinates for each edge
for (i, j) in all_edges
    push!(edge_x_coords, [positions[i, 1], positions[j, 1]])
    push!(edge_y_coords, [positions[i, 2], positions[j, 2]])
end

# Initialize the main plot with specified size and aesthetics
main_plot = plot(
    size = (800, 800),
    xlims = (-0.05, 1.05),
    ylims = (-0.05, 1.05),
    legend = false,
    background_color = :white,
    aspect_ratio = 1
)

# Plot all edges in light gray for a subtle background
for k in 1:length(all_edges)
    plot!(
        main_plot,
        edge_x_coords[k],
        edge_y_coords[k],
        color = :lightgray,
        alpha = 0.4,
        linewidth = 1
    )
end

# Highlight edges connected to the central node in black with increased opacity
for (i, j) in central_edges
    plot!(
        main_plot,
        [positions[i, 1], positions[j, 1]],
        [positions[i, 2], positions[j, 2]],
        color = :black,
        alpha = 0.6,
        linewidth = 1.5
    )
end

# Plot nodes with colors mapped based on their shortest path length from the central node
scatter!(
    main_plot,
    positions[:, 1],
    positions[:, 2],
    color = mapped_colors,          # Assign colors manually
    markersize = 10,
    alpha = 0.8,
    label = false
)

# Save and display the final plot
savefig(main_plot, "fig/RandomScatter.png")
display(main_plot)
