# Visualization Report

## **Overview**

The primary objective was to visualize a network of nodes by reducing its dimensionality and highlighting key structural elements. Utilizing Julia's `Plots` and related packages, the exercise involved generating a graph of interconnected nodes, identifying the central node, computing shortest paths, and visualizing the network with color-coded nodes based on their proximity to the center.

## **Methodology**

### 1. **Graph Generation**

- **Node Initialization:**
  - **Number of Nodes:** 200
  - **Connection Radius:** 0.125 (determines the proximity within which nodes are connected)
  - **Positioning:** Nodes were randomly positioned within a [0, 1] x [0, 1] 2D space to simulate a uniform distribution.

- **Adjacency List Construction:**
  - Nodes were connected if the Euclidean distance between them was less than or equal to the specified connection radius.
  - An adjacency list was created to represent the graph's structure, where each node maintains a list of its immediate neighbors.

### 2. **Central Node Identification**

- **Definition:** The central node is the node closest to the geometric center point (0.5, 0.5) of the graph.
- **Identification Process:**
  - Calculated the squared distance of each node from the center.
  - Selected the node with the minimum distance as the central node.

### 3. **Shortest Path Calculation**

- **Objective:** Determine the shortest path lengths from the central node to all other nodes in the graph.
- **Algorithm Used:** Breadth-First Search (BFS)
- **Outcome:** Computed the shortest number of edges required to reach each node from the central node, resulting in a distance metric for visualization.

### 4. **Color Mapping Based on Proximity**

- **Normalization:**
  - Shortest path lengths were normalized to a [0, 1] range to facilitate color interpolation.
  
- **Color Interpolation:**
  - **Start Color:** Red (`RGB(1.0, 0.0, 0.0)`) for nodes closest to the center.
  - **End Color:** White (`RGB(1.0, 1.0, 1.0)`) for nodes farthest from the center.
  - Applied a linear interpolation to assign colors to nodes based on their normalized shortest path lengths.

### 5. **Visualization**

- **Edge Plotting:**
  - All edges were plotted in light gray to provide a subtle background structure.
  - Edges connected to the central node were highlighted in black with increased opacity to emphasize the central hub.

- **Node Plotting:**
  - Nodes were plotted as scatter points with sizes and colors corresponding to their proximity to the central node.
  
- **Final Output:**
  - The comprehensive plot was saved as `fig/RandomScatter.png` and displayed for analysis.

## **Results**

### 1. **Central Node Identification**
- **Central Node:** Identified correctly.
  
### 2. **Shortest Path Distribution**
- **Node Colors:** Successfully mapped based on their shortest path lengths, with a gradient from red (closest) to white (farthest).
  
- **Saved Plot:**
  - The final visualization was saved as `fig/RandomScatter.png`.

## **Key Findings**

1. **Centrality Impact:**
   - The central node serves as a hub, with numerous connections, facilitating shorter paths to other nodes within the network.
   
2. **Proximity Visualization:**
   - The color gradient effectively illustrates the distribution of nodes based on their proximity to the central node, enhancing interpretability of the network structure.
   
3. **Network Density:**
   - The chosen connection radius resulted in a moderately dense network, balancing connectivity with visual clarity.
   
## **Conclusion**

By identifying the central node and mapping nodes based on their shortest path lengths, the visualization provided clear insights into the network's hierarchy and connectivity. The color-coded approach facilitated an intuitive understanding of node proximities, while the highlighting of central connections emphasized the role of the central hub within the network.

This methodology can be extended to more complex and larger networks, offering a scalable solution for visualizing and analyzing network structures in various domains such as social networks, biological systems, and communication networks. Future enhancements may include interactive visualizations using packages like Makie for more dynamic exploration of network properties.
