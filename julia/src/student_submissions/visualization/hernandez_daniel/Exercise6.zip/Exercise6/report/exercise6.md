# Reporte de ejercicio 6
Hernández Vela Daniel

```julia
n = 200
r = 0.125
G = SimpleGraph(n)
positions = Dict(i => (rand(), rand()) for i in 1:n)

for i in 1:n
    for j in i+1:n
        if sqrt((positions[i][1] - positions[j][1])^2 + (positions[i][2] - positions[j][2])^2) < r
            add_edge!(G, i, j)
        end
    end
end

dmin = 1.0
ncenter = 1
for (n, (x, y)) in positions
    d = (x - 0.5)^2 + (y - 0.5)^2
    if d < dmin
        ncenter = n
        dmin = d
    end
end

p = dijkstra_shortest_paths(G, ncenter).dists
if maximum(p) == minimum(p)
    p_norm = [0.5 for i in 1:n]
else
    p_max = maximum(p)
    p_min = minimum(p)
    p_norm = [1 - (p[i] - p_min) / (p_max - p_min) for i in 1:n]
    p_norm = [0.1 + 0.9 * p_norm[i] for i in 1:n]
end

scatter([positions[i][1] for i in 1:n], [positions[i][2] for i in 1:n], 
        markersize=5, 
        c=[RGBA(1.0, 0.0, 0.0, p_norm[i]) for i in 1:n],
        alpha=[RGBA(1.0, 0.0, 0.0, p_norm[i]) for i in 1:n],
        legend=false, size=(500,500))

for e in edges(G)
    plot!([positions[src(e)][1], positions[dst(e)][1]], 
          [positions[src(e)][2], positions[dst(e)][2]], 
          linecolor=:black, linealpha=0.4, legend=false)
end

xlims!(-0.05, 1.05)
ylims!(-0.05, 1.05)
plot!(legend=false, axis=false)
```

En este ejercicio no disponemos de datos con los que trabajar, por lo que se describirá el proceso para generar el grafo.

1. Se define n como 200, que es el número de nodos del grafo, y r como 0.125, que es el radio de conexión. Se crea un grafo simple G con n nodos y se inicializa un diccionario que asigna a cada nodo una posición aleatoria en el plano 2D.

2. Se itera sobre todos los pares de nodos (i, j). Para cada par, se calcula la distancia euclidiana entre sus posiciones. Si la distancia es menor que r, se añade una arista entre los nodos i y j en el grafo G.

3. Se inicializa dmin como 1.0 y ncenter como 1. Luego, se itera sobre todas las posiciones de los nodos para encontrar el nodo más cercano al centro del plano (0.5, 0.5). Este nodo se almacena en ncenter.

4. Se usa el algoritmo de Dijkstra para calcular las distancias más cortas desde el nodo central a todos los demás nodos. Estas distancias se almacenan en p.

5. Normalización de distancias: Si todas las distancias son iguales, se asigna un valor de 0.5 a todas las posiciones normalizadas p_norm. Si no, se normalizan las distancias para que estén en el rango [0.1, 1.0] (esto con el objetivo de poder colorear los nodos usando los valores dentro del rango).

6. Se crea un scatter donde cada nodo se dibuja en su posición correspondiente. La transparencia de cada nodo depende de su distancia normalizada p_norm. Luego se dibujan las aristas.