using Images
using LinearAlgebra
using Statistics
using Plots

function svd_reduction(img::AbstractArray, k::Int)
    img_gray = Gray.(img)
    img_data = Float64.(reshape(img_gray, :, size(img_gray, 1)))'

    mean_img = mean(img_data, dims=1)
    img_data_centered = img_data .- mean_img

    U, Σ, V = svd(img_data_centered)

    # Seleccionamos las componentes principales
    U_reduced = U[:, 1:k]
    Σ_reduced = Diagonal(Σ[1:k])  
    V_reduced = V[:, 1:k]

    # Proyectamos los datos sobre las componentes principales
    reduced_data = U_reduced * Σ_reduced

    # Reconstruimos la imagen
    reconstructed_data = reduced_data * V_reduced' .+ mean_img
    reconstructed_img = reshape(reconstructed_data', size(img_gray))

    # Dimensionalidades
    dim_before = size(img_data)
    dim_after = size(reduced_data)

    return reconstructed_img, dim_before, dim_after
end

function pca_reduction(img::AbstractArray, k::Int)
    img_gray = Gray.(img)
    img_data = Float64.(reshape(img_gray, :, size(img_gray, 1)))'

    mean_img = mean(img_data, dims=1)
    img_data_centered = img_data .- mean_img

    cov_matrix = cov(img_data_centered)

    eigvals, eigvecs = eigen(cov_matrix)

    # Seleccionamos las componentes principales
    principal_components = eigvecs[:, 1:k]

    # Proyectamos los datos sobre las componentes principales
    reduced_data = img_data_centered * principal_components

    # Reconstruimos la imagen
    reconstructed_data = reduced_data * transpose(principal_components) .+ mean_img
    reconstructed_img = reshape(reconstructed_data', size(img_gray))

    # Dimensionalidades
    dim_before = size(img_data)
    dim_after = size(reduced_data)

    return reconstructed_img, dim_before, dim_after
end

imgagen = Images.load("C:/Users/PC/Downloads/image1.jpeg")

componentes = 50 

# SVD
reconstructed_svd, dim_before_svd, dim_after_svd = svd_reduction(imgagen, componentes)
println("Dimensionalidad antes de SVD: ", dim_before_svd)
println("Dimensionalidad después de SVD: ", dim_after_svd)

# PCA
reconstructed_pca, dim_before_pca, dim_after_pca = pca_reduction(imgagen, componentes)
println("Dimensionalidad antes de PCA: ", dim_before_pca)
println("Dimensionalidad después de PCA: ", dim_after_pca)

# Imagenes
plot(heatmap(reconstructed_svd), title="Imagen Reconstruida con SVD")
plot(heatmap(reconstructed_pca), title="Imagen Reconstruida con PCA")
