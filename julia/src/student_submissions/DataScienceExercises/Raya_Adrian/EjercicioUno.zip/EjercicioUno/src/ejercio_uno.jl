using DataFrames
using Statistics
using Plots
using StatsPlots

struct DataCleaner
    df::DataFrame
end

function dataShape(cleaner::DataCleaner)
    return size(cleaner.df)
end

function dataType(cleaner::DataCleaner)
    return eltypes(cleaner.df)
end

function count_missing(cleaner::DataCleaner, col::Symbol)
    return count(ismissing, cleaner.df[!, col])
end

function dataMissingPercentage(cleaner::DataCleaner)
    return map(col -> mean(ismissing.(cleaner.df[!, col])) * 100, names(cleaner.df))
end

function deleteColumns!(cleaner::DataCleaner, threshold::Float64)
    missing_percent = dataMissingPercentage(cleaner)
    cols_to_drop = [name for (i, name) in enumerate(names(cleaner.df)) if missing_percent[i] >= threshold]
    select!(cleaner.df, Not(cols_to_drop))
end

function calculateCorrelation(cleaner::DataCleaner)
    numeric_cols = names(cleaner.df, Number)
    return cor(Matrix(cleaner.df[:, numeric_cols]))
end

function displayCorrelation(cleaner::DataCleaner)
    numeric_cols = names(cleaner.df, Number)
    correlation_matrix = calculateCorrelation(cleaner)
    heatmap(correlation_matrix, xticks=(1:length(numeric_cols), string.(numeric_cols)),
            yticks=(1:length(numeric_cols), string.(numeric_cols)), color=:coolwarm)
end

function removeOutliersIQR!(cleaner::DataCleaner)
    numeric_cols = names(cleaner.df, Number)
    for col in numeric_cols
        Q1 = quantile(cleaner.df[!, col], 0.25)
        Q3 = quantile(cleaner.df[!, col], 0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        filter!(row -> (row[col] >= lower_bound && row[col] <= upper_bound) || ismissing(row[col]), cleaner.df)
    end
end

function deleteRow!(cleaner::DataCleaner, column::Symbol)
    filter!(row -> !ismissing(row[column]), cleaner.df)
end

function filterColumnsByCorrelation!(cleaner::DataCleaner, target::Symbol, threshold::Float64, relation::String="positive")
    correlation_matrix = calculateCorrelation(cleaner)
    numeric_cols = names(cleaner.df, Number)
    target_index = findfirst(x -> x == target, numeric_cols)

    if relation == "positive"
        cols_to_remove = [numeric_cols[i] for i in 1:length(numeric_cols) if correlation_matrix[i, target_index] < threshold]
    elseif relation == "negative"
        cols_to_remove = [numeric_cols[i] for i in 1:length(numeric_cols) if correlation_matrix[i, target_index] > -threshold]
    else
        error("Invalid relation argument: use 'positive' or 'negative'")
    end

    select!(cleaner.df, Not(cols_to_remove))
end

function cleanData!(cleaner::DataCleaner, threshold::Float64)
    deleteColumns!(cleaner, threshold)
    removeOutliersIQR!(cleaner)
end

# Function to clean a DataFrame
function clean_dataframe(df::DataFrame, threshold::Float64)
    cleaner = DataCleaner(df)
    cleanData!(cleaner, threshold)
    return cleaner.df
end

df = CSV.read("C:/Users/PC/Desktop/DiplomadoIA/Julia/Data/bottle.csv", DataFrame)


cleaner = DataCleaner(df)

# Limpiar el conjunto de datos
threshold = 50.0  # Porcentaje de valores faltantes aceptable
cleaned_df = clean_dataframe(df, threshold)

println("DataFrame después de limpiar:")
println(first(cleaned_df, 5))

# Mostrar las correlaciones
println("Correlaciones entre variables:")
displayCorrelation(cleaner)
