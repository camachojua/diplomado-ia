using DataFrames, Random, Flux, Statistics, MLUtils, Plots, StatsPlots, CategoricalArrays
using Flux: onehotbatch, params 
using LinearAlgebra
using Optimisers
using CSV

function train_test_split(df::DataFrame, train_ratio::Real)
    if !(0 <= train_ratio <= 1)
        throw(ArgumentError("train_ratio debe estar entre 0 y 1"))
    end

    n = nrow(df)
    train_size = floor(Int, n * train_ratio)
    indices = shuffle(1:n)
    train_indices = indices[1:train_size]
    test_indices = indices[train_size+1:end]

    train_df = df[train_indices, :]
    test_df = df[test_indices, :]

    X_train = select(train_df, Not(:Exited)) 
    y_train = train_df.Exited

    X_test = select(test_df, Not(:Exited))
    y_test = test_df.Exited
    
    return X_train, y_train, X_test, y_test
end

function count_classes(y)
    counts = Dict()
    for val in y
        if haskey(counts, val)
            counts[val] += 1
        else
            counts[val] = 1
        end
    end
    return counts
end

function one_hot_encode(X_train::DataFrame)
    encoded_cols = []
    for col_name in names(X_train)
        col = X_train[!, col_name]
        if eltype(col) <: Union{String, Char, CategoricalArray{String}}
               uniques = unique(col)
               encoded = onehotbatch(col, uniques)
                push!(encoded_cols, DataFrame( [Symbol(string(col_name)*"_"*string(uniques[i])) => encoded[i,:] for i in 1:length(uniques)] ))
        else
            push!(encoded_cols, DataFrame(Symbol(col_name)=>col))
        end
    end
    return reduce(hcat,encoded_cols)
end

function train_logistic_model(X_train, y_train; learning_rate=0.01, epochs=1000)
    numeric_cols = names(select(X_train, eltype.(eachcol(X_train)) .<: Number))
    
    X_train_matrix = Matrix(select(X_train, numeric_cols))' |> Flux.f32
    y_train_matrix = reshape(convert(Array{Float32}, y_train), 1, :)
    
    model = Chain(
        Dense(size(X_train_matrix, 1), 1, σ)  
    )
    model = Flux.f32(model)

    loss(model, x, y) = Flux.Losses.binarycrossentropy(model(x), y)
    
    optimizer = ADAM(learning_rate)
    opt = optimizer
    state = Optimisers.setup(opt,model)

    for epoch in 1:epochs
        Flux.train!(loss, model, [(X_train_matrix, y_train_matrix)], state)
    end

    return model
end

function predict_and_binarize(model, X_test)
    X_test_matrix = Matrix(select(X_test, eltype.(eachcol(X_test)) .<: Number))' |> Flux.f32
    predictions = model(X_test_matrix)
    binary_predictions = [p > 0.5 ? 1 : 0 for p in predictions]
    return vec(binary_predictions)
end

function calculate_accuracy(y_test, predictions)
    correct_predictions = sum(predictions .== y_test)
    accuracy = correct_predictions / length(y_test)
    return accuracy
end

function confusion_matrix(y_true, y_pred)
    labels = unique(vcat(y_true, y_pred))
    k = length(labels)
    matrix = zeros(Int, k, k)
    label_map = Dict(label => i for (i, label) in enumerate(labels))

    for (true_val, pred_val) in zip(y_true, y_pred)
        i = label_map[true_val]
        j = label_map[pred_val]
        matrix[i, j] += 1
    end
    return labels, matrix
end

function print_confusion_matrix(labels, matrix)
    println("Matriz de confusión:")
    print("        ")
    for label in labels
        print(" $label ")
    end
    println()
    for (i, label) in enumerate(labels)
        print("$label     ")
        for j in 1:length(labels)
            print(" $(matrix[i, j]) ")
        end
        println()
    end
end

function calcular_roc(y_true, y_scores)
    orden = sortperm(y_scores, rev=true)
    y_true_ordenado = y_true[orden]
    
    tp = cumsum(y_true_ordenado)
    fp = cumsum(1 .- y_true_ordenado)
    
    P = sum(y_true)
    N = length(y_true) - P
    
    tpr = tp / P
    fpr = fp / N
    
    fpr = [0.0; fpr; 1.0]
    tpr = [0.0; tpr; 1.0]
    
    return fpr, tpr
end


function plot_roc(y_true, y_score)
    fpr, tpr = calcular_roc(y_true, y_score)
    auc_value = calcular_auc(fpr, tpr)
    plot(fpr, tpr, 
         xlabel="Tasa de Falsos Positivos (FPR)", 
         ylabel="Tasa de Verdaderos Positivos (TPR)",
         title="Curva ROC (AUC = $(round(auc_value, digits=3)))",
         legend=false)
end

df = CSV.read("C:/Users/PC/Desktop/DiplomadoIA/Julia/Data/Churn_Modelling.csv", DataFrame)

X_train, y_train, X_test, y_test = train_test_split(df, 0.8)

println("Conteo de clases en y_train: $(count_classes(y_train))")

X_train_encoded = one_hot_encode(X_train)
X_test_encoded = one_hot_encode(X_test)

model = train_logistic_model(X_train_encoded, y_train)

predictions = predict_and_binarize(model, X_test_encoded)

accuracy = calculate_accuracy(y_test, predictions)
println("Accuracy: $(accuracy)")

labels, matrix = confusion_matrix(y_test, predictions)
print_confusion_matrix(labels, matrix)

X_test_matrix = Matrix(select(X_test_encoded, eltype.(eachcol(X_test_encoded)) .<: Number))' |> Flux.f32
probabilities =  model(X_test_matrix)
plot_roc(y_test, vec(probabilities))
