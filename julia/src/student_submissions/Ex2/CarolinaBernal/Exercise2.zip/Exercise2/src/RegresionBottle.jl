### Exercise 2. Regression 
## Carolina Bernal Rodríguez 

# Source: https://www.kaggle.com/datasets/sohier/calcofi
#=
Use the bottle.csv data from the CalCofi dataset to determine the most important factors of T_degC 

1. Use the EDA you already have done in Julia
2. Use Julia to do linear regressions combining different sets of independent variables until you find the combination that gives you better predictions
3. Submit your project following the submissions guidelines 

=#

using Pkg
#Pkg.add(["CSV","DataFrames","Printf","Statistics","NamedArrays", "PlotlyJS", "Random", "GLM", "StatsBase"])

using CSV
using DataFrames
using Statistics
using Printf
using PlotlyJS
using NamedArrays
using Random
using GLM
using StatsBase
using MLJBase
using MLUtils



## Here we're goint to use the clean dataset we got in Exercise1
cd("/Users/carolinabernal/Documents/DiplomadoExercises")
bottle_file = "Exercise1/dat/bottle_clean.csv"

bottle = CSV.File(bottle_file) |> DataFrame
describe(bottle)

originalBottle = copy(bottle) # Save the original if we need it latter


## filterRowbyIndx() to filter the desired row of the dataframe, retrieve the DataFrameRow filtered 
## as a DataFrame and the row index we decide to filter 
function filterRowbyIndx(df::DataFrame, selectIndx::Integer)

    ncolm = ncol(df)
    int = 0  # Initialize the indx at 0
    dfFilter= DataFrame(zeros(1, ncolm), :auto)

    for i in 1:selectIndx
        dfFilter = df[i,:] 
        dfFilter = DataFrame(dfFilter)
        int = i
    end

    return dfFilter, int
end

bottleRow, rowIndx = filterRowbyIndx(bottle,5)
bottleRow
rowIndx


## splitData() function to 

function splitData(data::DataFrame, trainRatio::Float64 = 0.8, seed::Int = 34)
   
    n = nrow(data) # num of rows
    indices = shuffle(MersenneTwister(seed), 1:n) ## Suffle with a fixed seed
    split_idx = floor(Int, trainRatio * n) # Get the index to split
    
    # Create test and train data index and dataframes
    trainIndx = indices[1:split_idx]
    testIndx = indices[split_idx+1:end]
    
    trainData = data[trainIndx, :]
    testData = data[testIndx, :]
    
    return trainData, testData
end


trainData, testData = splitData(bottle)
nRowTrain = nrow(trainData)
nRowTest  = nrow(testData)

## Validate the size of the dataframe is the same post splitting
nRowTrain + nRowTest == size(bottle)[1]

## Linear Regression Model - LRM
LRM = lm(@formula(T_degC ~ STheta), trainData)

#RSQR coefficient
rSQR = StatsModels.r2(LRM)
@show rSQR

prediction = StatsModels.predict(LRM, testData);

accuracyTestData = DataFrame(yTarget = testData[!,:T_degC], yPredicted = prediction)

accyTarget = accuracyTestData.yTarget
accPredicted = accuracyTestData.yPredicted

accTestDataError = accyTarget - accPredicted
meanAbsErr = mean(abs.(accTestDataError))

println("Mean absolute error (test data): ", meanAbsErr)
println("r2 value: ", rSQR)

function termnsSymbol(DataFrame, target::Symbol)
    
    # Obtener los nombres de las columnas
    selected_columns = names(DataFrame)
    
    # Filtrar el target (columna a excluir)
    selected_columns = filter(x -> x != target, selected_columns)
    
    # Aplicar la función Term y sumar los resultados
    return sum(Term.(Symbol.(selected_columns)))

end

terms = termnsSymbol(trainData, :T_degC)

LRM = lm(Term(:T_degC) ~ termnsSymbol(trainData, :T_degC), trainData)

rSQR = StatsModels.r2(LRM)

prediction = StatsModels.predict(LRM, testData);

accuracyTestData = DataFrame(yTarget = testData[!,:T_degC], yPredicted = prediction)

accyTarget = accuracyTestData.yTarget
accPredicted = accuracyTestData.yPredicted

accTestDataError = accyTarget - accPredicted
meanAbsErrTest = mean(abs.(accTestDataError))

println("Mean absolute error (test data): ", meanAbsErrTest)
println("r2 value: ", rSQR)

LRM = lm(Term(:T_degC) ~ sum(Term.(Symbol.(["Depthm", "Salnty", "STheta", "O2Sat", "Oxy_µmol/Kg", 
                                        "R_SALINITY", "R_SIGMA", "R_DYNHT", "R_O2", "R_PRES", "R_O2Sat"]))), trainData)

rsqr = StatsModels.r2(LRM)
prediction = StatsModels.predict(LRM, testData);
accuracyTestDF = DataFrame(yTarget = testData[!,:T_degC], yPredicted = prediction)



#ploting the first values if the model is ok we should expect to see a linear relationship 
p = plot(
        last(accuracyTestDF, 1000), 
        x = :yTarget, 
        y = :yPredicted,
        mode = "markers",
        marker = attr(
                color = "rgba(255, 87, 34, 0.8)",  
                size = 8,  
                line = attr(color = "rgba(255, 22, 34, 1)", width = 2) 
            ),
         Layout(
                title = "Predicted vs Actual" 

        )

            )
        
        
        # Mostrar la gráfica
p
        


savefig(p, "Exercise2/fig/Bottle_AccvsPred.png")
## and that's what we see

accyTarget = accuracyTestData.yTarget
accPredicted = accuracyTestData.yPredicted

accTestErrFinal = accyTarget - accPredicted

meanAbsErrTestFinal = mean(abs.(accTestErrFinal))

println("Mean absolute error (test data): ", meanAbsErrTestFinal)
println("r2 value: ", rSQR)

meanAbsErrTest - meanAbsErrTestFinal ## evaluate if the prediction improved

###saving the prediction output on a file
accuracyTestDF
CSV.write("Exercise2/dat/BottlePrediction.csv", accuracyTestDF)
