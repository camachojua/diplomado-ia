# Ejercicio 4 Dimensionality Reduction

using Pkg
Pkg.add("Images")
Pkg.add("ColorTypes")

using Images
using LinearAlgebra
using Colors
using ColorTypes
using Plots


 # Se tomaron como base las funciones proporciondas en clase que se encuentran en la
 # presentación Diemsionality Reduction: PCA, SVD, T-SNE
 # Las funciones FindApproxImg y PlotNormalizedSumgsOfApproxImgs, se parametrizaron 
 # para la generación de los archivos.

function FindSVD( M::Matrix )
    F = svd( M )
    return F
 end

 function PrintSVDInfo( F::SVD )
    println("PrintSVDInfo")
    println("F.U  Info: Type = ", typeof(F.U),  "  size=", size(F.U))
    println("F.S  Info: Type = ", typeof(F.S),  "  size=", size(F.S))
    println("F.V  Info: Type = ", typeof(F.V),  "  size=", size(F.V))
    println("F.Vt Info: Type = ", typeof(F.Vt), "  size=", size(F.Vt))
 end

  
  
 function FindApproxImg(F::SVD, file_prefix::String; k_values::Vector{Int})
   for k in k_values
       M = F.U[:, 1:k] * Diagonal(F.S[1:k]) * F.V[:, 1:k]'
       M = abs.(M .* 0.99)
       println("M Info: Type = ", typeof(M), "  size=", size(M))
       
       # Construir el nombre del archivo con el prefijo y el valor de k
       file_name = "$file_prefix$k.jpg"
       save(file_name, M)
   end
end

function PlotNormalizedSumgsOfApproxImgs(file_prefix::String; k_values::Vector{Int} = [5, 50, 100])
   for k in k_values
       # Construir dinámicamente los nombres de los archivos
       input_file = "../dat/$file_prefix$k.jpg"
       output_file = "../dat/$file_prefix$k"*"Norm.png"
       
       # Cargar la imagen de entrada
       xImg = load(input_file)
       println("Tamaño del archivo de salida K=$k Imagen=", size(xImg))
       
       # Calcular SVD y realizar la operación
       F = FindSVD(xImg)
       sv = convert(Vector{Float32}, F.S)
       
       # Generar la gráfica normalizada y guardarla
       PlotNormalizedSum(sv, output_file, k)
   end
end

function PlotNormalizedSum(sv, output_file, k)
    norm_sum = cumsum(sv) ./ sum(sv)  # Suma acumulada normalizada
    plot(norm_sum, label="Suma Normalizada", xlabel="Indice", ylabel="Suma Acumulada", title="Suma Normalizada de Valores Singulares")
    savefig(output_file)
end

# Proceso General 

bFile="../dat/Señora.jpg"
img0=load(bFile)
img1=Gray.(img0)
img2=convert(Matrix{Float64}, img1)
F=svd(img2)

PrintSVDInfo(F)
FindApproxImg(F,"../dat/Señora",k_values=[5,50,100])
#PlotNormalizedSumgsOfAppoxImgs()
PlotNormalizedSumgsOfApproxImgs("../dat/Señora"; k_values=[5, 50, 100])

