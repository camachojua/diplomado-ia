#=
Use the Stock Market data from Chap 4 of the ISL Book to do classification, using the following algorithms:

    LASSO
    Ridge
    Elastic Net
    Decision Tree
    Random Forest
    Nearest Neighbors
    Support Vector Machines (SVM)

You will need to do the following

    1. Get the data
    2. Clean it
    3. Use Go or Julia to write/use the classification algos. 
    4. Evaluate the accuracy of each prediction, using a confusion matrix and a ROC curve.
    5. Submit your project following the submission guidelines

=#

#= The Stock Market Data

    `Smarket` data, which is part of the `ISLP`
    library. This data set consists of percentage returns for the S&P 500
    stock index over 1,250 days, from the beginning of 2001 until the end
    of 2005. For each date, we have recorded the percentage returns for
    each of the five previous trading days,  `Lag1`  through
    `Lag5`. We have also recorded  `Volume`  (the number of
    shares traded on the previous day, in billions),  `Today`  (the
    percentage return on the date in question) and  `Direction`
    (whether the market was  `Up`  or  `Down`  on this date).

=#
using  Pkg
#Pkg.add(["CSV","DataFrames","GLMNet","Statistics"])
# using  RCall
using CSV
using DataFrames
using GLMNet
using LinearAlgebra
using LIBSVM
using Distances
using DataStructures
using Random
using DecisionTree
using MLBase
using NearestNeighbors
using NamedArrays
using EvalMetrics
using ROCAnalysis
using Plots
using  DataFrames
#using ROC

# Use the correct directory 
cd("/Users/carolinabernal/Documents/DiplomadoExercises")

#########
# Step 1 - Get the data from R using RCall. 
# NOTE: Python Dataset was downloaded from Google colab: pip install ISLP ;  from ISLP import load_data; Smarket = load_data('Smarket');
# df = pd.DataFrame(Smarket) ;  df.to_csv("Smarket_python.csv", index=False)

#R"install.packages('ISLR')"
#R"pkg.build('RCall')" when Pkg.add() failed , for M1,2, ...  Mac, to use RCall download R Intel version 
# otherwise this won't work 

# R"library(ISLR)"
# R"data(Smarket)"
# R"names(Smarket)"


# R"Smarket_r_df <- as.data.frame(Smarket)"

# R"""
# write.csv(Smarket_r_df , "Exercise3/dat/Smarket_r.csv", row.names = FALSE)
# """

Smarket_r_file = "Exercise3/dat/Smarket_r.csv"
Smarket_r_df = CSV.File(Smarket_r_file) |> DataFrame

size(Smarket_r_df)

Smarket_info = describe(Smarket_r_df)

########
# Step 2 - Clean the data, search for missings and set correct, numeric data on columns to use the models

# To clean the data we are going to ensure there are no missing values in any of the columns
Smarket_info.nmissing
# Smarket_info[!,6] # Get the column with the missing column row cnt

### Replace the elements of type string that contain "Up" or "Down" in 
### column Direction with a number [0,1] to compute LogReg on the data.
Smarket_df = copy(Smarket_r_df)
replace!(Smarket_df.Direction, "Up" => "1")
replace!(Smarket_df.Direction, "Down" => "0")
Smarket_df
describe(Smarket_df)
# Values 1 and 0 on Direction are strings , we need to convert to Int, "Up" => 1, is not possible since we need to asign the same value type.

# use parse to convert to Int 
Smarket_df[!, :Direction] = parse.(Int64,Smarket_df[!, :Direction])
describe(Smarket_df)
size(Smarket_df)


#### Step 3 - Classification algorithms

## This code is based on JuliaAcademy DataScience
## The original code for this classification algorithms can be found here: https://github.com/JuliaAcademy/DataScience/blob/main/06.%20Classification.ipynb


## GLMNET (generalized models) Pkg in Julia referenced on the slide 45 of Data Science in Julia https://bit.ly/482MfIt
## https://docs.google.com/presentation/d/1nrcj_vZ52r16klTf3uOLr_xF52WPxg3vx7r28KKguZI/edit#slide=id.g2d47ee807fc_6_0 

#= 
GLMNet.jl
    the package in Julia provides a way to use the glmnet library, originally from R.
    glmnet is known for its efficient fitting of regularized generalized linear models,
    primarily focusing on Lasso and Elastic-Net regularization
=#


## cv - cross-validation
#path = glmnet(X[trainids,:], y[trainids])
#cv = glmnetcv(X[trainids,:], y[trainids])

#  predict Direction using  Lag1 through  Lag5 Volume and Today
#  we want to use some of the data to fit a model (training data), and the rest of the data to validate (testing data)

Smarket_df.Direction
## Direction data from Stock Market Up and Down 
Smarket_r_dct = Smarket_df.Direction

function perclass_splits(y,at)
    uids = unique(y)
    keepids = []
    for ui in uids
        curids = findall(y.==ui)
        rowids = randsubseq(curids, at) 
        push!(keepids,rowids...)
    end
    return keepids
end


# Map with numbers 1,2 the values Up [1] and Down [2]
Smarket_dct_map = MLBase.labelmap(Smarket_r_dct)
y2 = labelencode(Smarket_dct_map, Smarket_r_dct)

# Use columns Lag1 to Lag 5, Volume and today to predict Direction

X = Matrix(DataFrames.select(Smarket_df, Not([:Direction, :Today, :Year])))

#X = Matrix(Smarket_p_df[:,2:8])
#y2 = Smarket_dfp_dct_y

trainids2 = perclass_splits(y2,0.7)
testids = setdiff(1:length(y2),trainids2)

# We will need one more function, and that is the function that will assign classes based on the predicted values when the predicted values are continuous.
assign_class(predictedvalue) = argmin(abs.(predictedvalue .- [1,2]))


###--------- Method 1 :  LASSO (Least Absolute Shrinkage Selection Operator)-------###
# choose the best lambda to predict with.
path = glmnet(X[trainids2,:], y2[trainids2])
cv = glmnetcv(X[trainids2,:], y2[trainids2])
mylambda = path.lambda[argmin(cv.meanloss)]

path = glmnet(X[trainids2,:], y2[trainids2],lambda=[mylambda]);

q = X[testids,:];
predictions_lasso = GLMNet.predict(path,q)

predictions_lasso = assign_class.(predictions_lasso)

findaccuracy(predictedvals,groundtruthvals) = sum(predictedvals.==groundtruthvals)/length(groundtruthvals)


acc_lasso = findaccuracy(predictions_lasso,y2[testids])
println("Model Lasso accuracy :  ",acc_lasso )


###--------- Mehod 2:  Ridge  --------- #####
path = glmnet(X[trainids2,:], y2[trainids2],alpha=0);
cv = glmnetcv(X[trainids2,:], y2[trainids2],alpha=0)
mylambda = path.lambda[argmin(cv.meanloss)]
path = glmnet(X[trainids2,:], y2[trainids2],alpha=0,lambda=[mylambda]);
q = X[testids,:];
predictions_ridge = GLMNet.predict(path,q)
predictions_ridge = assign_class.(predictions_ridge)
acc_ridge = findaccuracy(predictions_ridge,y2[testids])
println("Model Ridge accuracy :  ",acc_ridge )

###---------  Method 3: Elastic Net  --------- #####
# We will use the same function but set alpha to 0.5 (it's the combination of lasso and ridge). choose the best lambda to predict with.
path = glmnet(X[trainids2,:], y2[trainids2],alpha=0.5);
cv = glmnetcv(X[trainids2,:], y2[trainids2],alpha=0.5)
mylambda = path.lambda[argmin(cv.meanloss)]
path = glmnet(X[trainids2,:], y2[trainids2],alpha=0.5,lambda=[mylambda]);
q = X[testids,:];
predictions_EN = GLMNet.predict(path,q)
predictions_EN = assign_class.(predictions_EN)
acc_eln = findaccuracy(predictions_EN,y2[testids])
println("Model Elastic Net accuracy :  ",acc_eln )

###---------  Method 4:  Decision Tree  --------- #####

model = DecisionTreeClassifier(max_depth=3)
DecisionTree.fit!(model, X[trainids2,:], y2[trainids2])


q = X[testids,:];
predictions_DT = DecisionTree.predict(model, q)
acc_dt = findaccuracy(predictions_DT,y2[testids])
println("Model Decision Tree accuracy :  ",acc_dt )

###---------  Method 5:  Random Forests  --------- #####
model = RandomForestClassifier(n_trees=20)
DecisionTree.fit!(model, X[trainids2,:], y2[trainids2])


q = X[testids,:];
predictions_RF = DecisionTree.predict(model, q)
acc_rmf = findaccuracy(predictions_RF,y2[testids])
println("Model Random Forests accuracy :  ",acc_rmf )

###---------  Method 6:  Using a Nearest Neighbor method  --------- #####

Xtrain = X[trainids2,:]

ytrain = y2[trainids2]
kdtree = KDTree(Xtrain')

queries = X[testids,:]
idxs, dists = knn(kdtree, queries', 5, true)


c = ytrain[hcat(idxs...)]
possible_labels = map(i->counter(c[:,i]),1:size(c,2))
predictions_NN = map(i->parse(Int,string(string(argmax(possible_labels[i])))),1:size(c,2))
acc_nn = findaccuracy(predictions_NN,y2[testids])
println("Model Nearest Neighbor accuracy :  ",acc_nn )


###---------  Method 7: Support Vector Machines   --------- #####
# We will use the LIBSVM package here.

Xtrain = X[trainids2,:]
ytrain = y2[trainids2]

model = svmtrain(Xtrain', ytrain)


predictions_SVM, decision_values = svmpredict(model, X[testids,:]')
acc_svm = findaccuracy(predictions_SVM,y2[testids])
println("Model Support Vector Machines accuracy :  ",acc_svm )

##### ----- Accurracy -------- #####

overall_accuracies = zeros(7)
methods = ["LASSO","Ridge","Elastic Net", "Desicion Tree", "Random Forest","kNN", "SVM"]
ytest = y2[testids]
overall_accuracies[1] = findaccuracy(predictions_lasso,ytest)
overall_accuracies[2] = findaccuracy(predictions_ridge,ytest)
overall_accuracies[3] = findaccuracy(predictions_EN,ytest)
overall_accuracies[4] = findaccuracy(predictions_DT,ytest)
overall_accuracies[5] = findaccuracy(predictions_RF,ytest)
overall_accuracies[6] = findaccuracy(predictions_NN,ytest)
overall_accuracies[7] = findaccuracy(predictions_SVM,ytest)

acc_matrix = hcat(methods, overall_accuracies)
print(acc_matrix)
@show acc_matrix

##### ----- Confusion Matrix -------- #####

function ConfMatrixModel(targets, predicts_mdl)
    
    predicts_model = predicts_mdl[:,1]

    # Set the correct labeling, change 2 for 0 since Up [1] and Down [2], for conf matrix we need 0 and 1
    targets[targets .== 2] .= 0 
    predicts_model[predicts_model .== 2] .= 0

    cm_model = ConfusionMatrix(targets, predicts_model)

    n_cm_model = NamedArray(getproperty.(Ref(cm_model), [:tn :fn ; :fp :tp]), 
               (["f", "t"], ["f", "t"]), 
               ("pred", "true"))

    return cm_model , n_cm_model
    
end

targets = y2[testids]


cm_lasso , n_cm_lasso =  ConfMatrixModel(targets, predictions_lasso)
@show cm_lasso            
@show n_cm_lasso


cm_ridge , n_cm_ridge = ConfMatrixModel(targets, predictions_ridge)
@show cm_ridge
@show n_cm_ridge

cm_EN , n_cm_EN =  ConfMatrixModel(targets, predictions_EN)
@show cm_EN           
@show n_cm_EN

cm_DT , n_cm_DT =  ConfMatrixModel(targets, predictions_DT)
@show cm_DT          
@show n_cm_DT

cm_RF , n_cm_RF =  ConfMatrixModel(targets, predictions_RF)
@show cm_RF          
@show n_cm_RF

cm_NN , n_cm_NN =  ConfMatrixModel(targets, predictions_NN)
@show cm_NN          
@show n_cm_NN

cm_SVM , n_cm_SVM =  ConfMatrixModel(targets, predictions_SVM)
@show cm_SVM       
@show n_cm_SVM


##### -------- ROC -------- #####
targets = y2[testids]
pred_NN = predictions_NN[:,1]
targets == pred_NN

function RoC(y_observable, y_calc)

    #re-mapping in case is needed, this is super particular for this use case:
    y_observable[y_observable .== 2] .= 0 
    y_calc[y_calc .== 2] .= 0

    #sorting probabilities and indexes
    sorted_indices = sortperm(vec(y_calc), rev=true)
    y_obs_sort= vec(y_observable[sorted_indices])
    n_pos = sum(y_observable)
    n_neg = length(y_observable) - n_pos
    
    #calculating ROC curve
    tp, fp = 0, 0
    tpr = Float64[]
    fpr = Float64[]
    
    y_l = length(y_obs_sort)
    
    for i in 1:y_l
        if y_obs_sort[i] == 1
            tp += 1
        else
            fp += 1
        end
        push!(tpr, tp/n_pos)
        push!(fpr, fp/n_neg)
    end
    
    #defining the DF

    df = DataFrame(FPR = fpr, TPR = tpr)
    fpr = df.FPR = Float64.(df.FPR)
    tpr = df.TPR = Float64.(df.TPR)
    return fpr, tpr
end

graph_path = "Exercise3/fig/graph.png"
fpr, tpr = RoC(targets, predictions_lasso)
p = plot(fpr, tpr, Layout(
    title = "ROC: predictions_lasso"

)
)
savefig(p, graph_path)

fpr, tpr = RoC(targets, predictions_ridge)
p = plot(fpr, tpr,  Layout(title="ROC: predictions_ridge"))
savefig(p, "Exercise3/fig/ROC: predictions_ridge.png")
fpr, tpr = RoC(targets, predictions_EN)
p = plot(fpr, tpr,  Layout(title="ROC: predictions_EN"))
savefig(p, "Exercise3/fig/ROC: predictions_EN.png")
fpr, tpr = RoC(targets, predictions_DT)
p = plot(fpr, tpr,  Layout(title="ROC: predictions_DT"))
savefig(p, "Exercise3/fig/ROC: predictions_DT.png")
fpr, tpr = RoC(targets, predictions_RF)
p = plot(fpr, tpr,  Layout(title="ROC: predictions_RF"))
savefig(p, "Exercise3/fig/ROC: predictions_RF.png")
fpr, tpr = RoC(targets, predictions_NN)
p = plot(fpr, tpr, Layout(title="ROC: predictions_NN"))
savefig(p, "Exercise3/fig/ROC: predictions_NN.png")
fpr, tpr = RoC(targets, predictions_SVM)
p = plot(fpr, tpr,  Layout(title="ROC: predictions_SVM"))
savefig(p, "Exercise3/fig/ROC: predictions_SVM.png")