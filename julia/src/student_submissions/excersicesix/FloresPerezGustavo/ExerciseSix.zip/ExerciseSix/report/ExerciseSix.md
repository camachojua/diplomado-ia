```julia
using Plots
import Pkg; Pkg.add("Graphs")
using Random
using Graphs
using LinearAlgebra
```

    [32m[1m   Resolving[22m[39m package versions...
    [32m[1m    Updating[22m[39m `C:\Users\Gustavo\.julia\environments\v1.11\Project.toml`
      [90m[86223c79] [39m[92m+ Graphs v1.12.0[39m
    [32m[1m    Updating[22m[39m `C:\Users\Gustavo\.julia\environments\v1.11\Manifest.toml`
      [90m[ec485272] [39m[92m+ ArnoldiMethod v0.4.0[39m
      [90m[86223c79] [39m[92m+ Graphs v1.12.0[39m
      [90m[d25df0c9] [39m[92m+ Inflate v0.1.5[39m
    [92m[1mPrecompiling[22m[39m project...
       1243.0 ms[32m  ✓ [39m[90mInflate[39m
       1582.2 ms[32m  ✓ [39m[90mArnoldiMethod[39m
       5197.5 ms[32m  ✓ [39mGraphs
      3 dependencies successfully precompiled in 9 seconds. 443 already precompiled.
    


```julia
function grafo_geometrico_plots(num_nodos = 200, radio = 0.125)
    # Generar puntos aleatorios en un cuadrado unitario
    posiciones = rand(2, num_nodos)

    # Crear el grafo
    grafo = SimpleGraph(num_nodos)
    for i in 1:num_nodos, j in (i+1):num_nodos
        if norm(posiciones[:, i] - posiciones[:, j]) <= radio
            add_edge!(grafo, i, j)
        end
    end

    # Encontrar el nodo central
    centro = [0.5, 0.5]
    # Repetir centro para que tenga las mismas dimensiones que cada columna de posiciones
    centro_repetido = repeat(centro, 1, num_nodos) 
    distancias_al_centro = norm.(posiciones .- centro_repetido)
    ncenter = argmin(distancias_al_centro)

    # Convertir ncenter a entero
    ncenter_int = Tuple(ncenter)[1]

    # Calcular las distancias desde el nodo central
    distancias = gdistances(grafo, ncenter_int)

    # Visualizar el grafo
    plt = plot(
        layout = (1, 1),
        legend = false,
        axis = false,
        xlims = (-0.05, 1.05),
        ylims = (-0.05, 1.05),
        aspect_ratio = 1,
    )

    for edge in edges(grafo)
        # Usar Graphs.src(edge) y Graphs.dst(edge)
        src_node = Graphs.src(edge) 
        dst_node = Graphs.dst(edge) 
        plot!(
            plt,
            [posiciones[1, src_node], posiciones[1, dst_node]],
            [posiciones[2, src_node], posiciones[2, dst_node]],
            color = :gray,
            alpha = 0.4,
        )
    end

    scatter!(
        plt,
        posiciones[1, :],
        posiciones[2, :],
        markersize = 5,
        markercolor = distancias,
        c = :reds,
    )

    return plt
end

# Generar y mostrar el gráfico
grafo_geometrico_plots()
```




<?xml version="1.0" encoding="utf-8"?>
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="600" height="400" viewBox="0 0 2400 1600">
<defs>
  <clipPath id="clip740">
    <rect x="0" y="0" width="2400" height="1600"/>
  </clipPath>
</defs>
<path clip-path="url(#clip740)" d="M0 1600 L2400 1600 L2400 0 L0 0  Z" fill="#ffffff" fill-rule="evenodd" fill-opacity="1"/>
<defs>
  <clipPath id="clip741">
    <rect x="480" y="0" width="1681" height="1600"/>
  </clipPath>
</defs>
<path clip-path="url(#clip740)" d="M549.913 1486.45 L1989.12 1486.45 L1989.12 47.2441 L549.913 47.2441  Z" fill="#ffffff" fill-rule="evenodd" fill-opacity="1"/>
<defs>
  <clipPath id="clip742">
    <rect x="549" y="47" width="1440" height="1440"/>
  </clipPath>
</defs>
<polyline clip-path="url(#clip742)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:2; stroke-opacity:0.1; fill:none" points="615.331,1486.45 615.331,47.2441 "/>
<polyline clip-path="url(#clip742)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:2; stroke-opacity:0.1; fill:none" points="942.423,1486.45 942.423,47.2441 "/>
<polyline clip-path="url(#clip742)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:2; stroke-opacity:0.1; fill:none" points="1269.51,1486.45 1269.51,47.2441 "/>
<polyline clip-path="url(#clip742)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:2; stroke-opacity:0.1; fill:none" points="1596.61,1486.45 1596.61,47.2441 "/>
<polyline clip-path="url(#clip742)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:2; stroke-opacity:0.1; fill:none" points="1923.7,1486.45 1923.7,47.2441 "/>
<polyline clip-path="url(#clip742)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:2; stroke-opacity:0.1; fill:none" points="549.913,1421.03 1989.12,1421.03 "/>
<polyline clip-path="url(#clip742)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:2; stroke-opacity:0.1; fill:none" points="549.913,1093.94 1989.12,1093.94 "/>
<polyline clip-path="url(#clip742)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:2; stroke-opacity:0.1; fill:none" points="549.913,766.846 1989.12,766.846 "/>
<polyline clip-path="url(#clip742)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:2; stroke-opacity:0.1; fill:none" points="549.913,439.754 1989.12,439.754 "/>
<polyline clip-path="url(#clip742)" style="stroke:#000000; stroke-linecap:round; stroke-linejoin:round; stroke-width:2; stroke-opacity:0.1; fill:none" points="549.913,112.662 1989.12,112.662 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1417.16,451.056 1410.21,376.625 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1417.16,451.056 1492.02,318.88 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1417.16,451.056 1486.99,397.629 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1417.16,451.056 1442.11,541.959 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1417.16,451.056 1455.36,452.296 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1417.16,451.056 1398.97,594.793 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="791.637,568.175 769.406,634.153 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="791.637,568.175 814.732,652.033 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="791.637,568.175 937.144,552.433 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="791.637,568.175 772.628,583.151 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="791.637,568.175 704.229,460.25 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="791.637,568.175 831.69,709.673 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="791.637,568.175 902.058,533.174 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="791.637,568.175 723.281,539.905 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="791.637,568.175 660.083,606.633 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="791.637,568.175 744.524,577.068 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="791.637,568.175 814.958,495.066 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1107.74,293.733 1067.85,298.664 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1107.74,293.733 1051.73,175.744 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1107.74,293.733 1076.15,249.713 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1107.74,293.733 1077.93,399.032 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1107.74,293.733 992.901,246.941 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1212.88,1068.81 1326.28,1110.96 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1212.88,1068.81 1295.13,1087.44 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1212.88,1068.81 1149.38,1182.41 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1212.88,1068.81 1310.36,1031.89 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1212.88,1068.81 1119.78,991.659 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1212.88,1068.81 1253.25,1218.33 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1212.88,1068.81 1209.48,1175.26 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1212.88,1068.81 1141.51,950.168 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1212.88,1068.81 1161.98,992.257 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1212.88,1068.81 1208.98,968.883 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="658.401,972.437 744.715,1013.21 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="658.401,972.437 732.051,1036.95 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="658.401,972.437 653.658,1076.62 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="658.401,972.437 699.749,877.716 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1336.49,1316.15 1413.05,1321.03 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1336.49,1316.15 1280.49,1316.75 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1336.49,1316.15 1358.02,1312.65 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1336.49,1316.15 1253.25,1218.33 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1336.49,1316.15 1220.93,1415.85 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1336.49,1316.15 1187.61,1380 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1336.49,1316.15 1329.99,1298.51 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1336.49,1316.15 1354.65,1183.44 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1336.49,1316.15 1438.06,1350.33 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1913.94,1003.43 1869.69,1148.62 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1913.94,1003.43 1857.57,916.675 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1913.94,1003.43 1770.09,926.74 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1798.97,430.447 1857.13,368.615 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1798.97,430.447 1657.49,357.488 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1798.97,430.447 1822.06,281.577 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1798.97,430.447 1724.14,547.408 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1798.97,430.447 1767.22,375.57 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1798.97,430.447 1659.71,484.598 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1798.97,430.447 1784.76,366.428 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1798.97,430.447 1669,510.764 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1798.97,430.447 1833.29,459.766 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1798.97,430.447 1765.88,476.23 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="869.21,360.079 821.658,406.573 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="869.21,360.079 884.188,365.667 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="869.21,360.079 960.434,383.949 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="869.21,360.079 814.958,495.066 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1410.21,376.625 1492.02,318.88 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1410.21,376.625 1486.99,397.629 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1410.21,376.625 1455.36,452.296 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1410.21,376.625 1357.49,242.337 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1410.21,376.625 1325.57,284.807 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="717.983,1300.2 658.265,1411.34 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="717.983,1300.2 821.39,1400.29 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="717.983,1300.2 698.25,1238.58 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="717.983,1300.2 802.437,1287.4 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="717.983,1300.2 749.111,1264.31 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="717.983,1300.2 840.398,1321.59 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1730.78,652.236 1780.13,763.749 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1730.78,652.236 1828.62,695.053 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1730.78,652.236 1724.14,547.408 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1730.78,652.236 1630.42,770.141 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1730.78,652.236 1669,510.764 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1730.78,652.236 1683.32,706.632 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1730.78,652.236 1745.81,626.024 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1730.78,652.236 1659.87,686.32 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1730.78,652.236 1696.71,642.681 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1730.78,652.236 1841.35,687.149 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1160.59,743.112 1103.28,794.582 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1160.59,743.112 1096.83,822.995 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1160.59,743.112 1064.61,777.473 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1160.59,743.112 1070.34,744.599 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1160.59,743.112 1166.44,840.56 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1160.59,743.112 1179.16,629.458 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1160.59,743.112 1316.19,726.7 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1160.59,743.112 1292.89,668.564 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1160.59,743.112 1064.12,681.072 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="658.265,1411.34 821.39,1400.29 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1288.09,231.842 1286.32,186.395 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1288.09,231.842 1357.49,242.337 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1288.09,231.842 1337.97,172.684 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1288.09,231.842 1325.57,284.807 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1780.13,763.749 1828.62,695.053 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1780.13,763.749 1630.42,770.141 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1780.13,763.749 1683.32,706.632 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1780.13,763.749 1745.81,626.024 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1780.13,763.749 1659.87,686.32 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1780.13,763.749 1770.09,926.74 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1780.13,763.749 1696.71,642.681 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1780.13,763.749 1841.35,687.149 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1773.32,162.103 1667.16,128.893 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1773.32,162.103 1902.56,224.658 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1773.32,162.103 1822.06,281.577 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1773.32,162.103 1733.48,134.754 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1388.69,742.037 1516.11,792.546 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1388.69,742.037 1379.49,902.623 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1388.69,742.037 1295.72,630.418 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1388.69,742.037 1500.12,796.671 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1388.69,742.037 1319.71,614.233 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1388.69,742.037 1494.05,691.31 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1388.69,742.037 1316.19,726.7 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1388.69,742.037 1364.46,786.721 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1388.69,742.037 1292.89,668.564 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1388.69,742.037 1499.38,721.575 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1388.69,742.037 1478.87,738.61 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1388.69,742.037 1398.97,594.793 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1326.28,1110.96 1295.13,1087.44 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1326.28,1110.96 1310.36,1031.89 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1326.28,1110.96 1253.25,1218.33 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1326.28,1110.96 1209.48,1175.26 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1326.28,1110.96 1393.07,1076.48 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1326.28,1110.96 1354.65,1183.44 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1326.28,1110.96 1425.42,1060.58 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="976.358,636.203 814.732,652.033 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="976.358,636.203 937.144,552.433 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="976.358,636.203 966.714,694.317 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="976.358,636.203 1070.34,744.599 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="976.358,636.203 831.69,709.673 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="976.358,636.203 902.058,533.174 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="976.358,636.203 880.766,743.567 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="976.358,636.203 1122.48,571.934 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="976.358,636.203 1023.43,481.938 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="976.358,636.203 1101.25,530.745 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="976.358,636.203 1064.12,681.072 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="976.358,636.203 1010.67,556.319 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="976.358,636.203 990.697,689.017 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1857.13,368.615 1902.56,224.658 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1857.13,368.615 1822.06,281.577 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1857.13,368.615 1767.22,375.57 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1857.13,368.615 1784.76,366.428 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1857.13,368.615 1833.29,459.766 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1857.13,368.615 1765.88,476.23 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1250.85,552.616 1295.72,630.418 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1250.85,552.616 1319.71,614.233 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1250.85,552.616 1179.16,629.458 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1250.85,552.616 1122.48,571.934 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1250.85,552.616 1236.16,474.909 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1250.85,552.616 1292.89,668.564 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1250.85,552.616 1101.25,530.745 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1250.85,552.616 1208.53,508.3 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1250.85,552.616 1398.97,594.793 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1667.16,128.893 1567.51,244.377 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1667.16,128.893 1513.91,120.922 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1667.16,128.893 1733.48,134.754 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1553.69,679.768 1516.11,792.546 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1553.69,679.768 1500.12,796.671 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1553.69,679.768 1630.42,770.141 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1553.69,679.768 1683.32,706.632 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1553.69,679.768 1531.03,627.61 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1553.69,679.768 1494.05,691.31 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1553.69,679.768 1659.87,686.32 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1553.69,679.768 1499.38,721.575 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1553.69,679.768 1696.71,642.681 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1553.69,679.768 1478.87,738.61 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1553.69,679.768 1569.03,541.599 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="821.39,1400.29 973.963,1409.37 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="821.39,1400.29 802.437,1287.4 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="821.39,1400.29 749.111,1264.31 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="821.39,1400.29 840.398,1321.59 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1690.6,963.763 1668.11,985.393 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1690.6,963.763 1652.98,998.948 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1690.6,963.763 1770.09,926.74 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1690.6,963.763 1576.73,1044.44 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1690.6,963.763 1616,1082.9 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1690.6,963.763 1697.61,979.146 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1295.13,1087.44 1310.36,1031.89 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1295.13,1087.44 1253.25,1218.33 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1295.13,1087.44 1209.48,1175.26 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1295.13,1087.44 1393.07,1076.48 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1295.13,1087.44 1354.65,1183.44 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1295.13,1087.44 1425.42,1060.58 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1295.13,1087.44 1208.98,968.883 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1743.47,1309.75 1725.06,1409.13 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1743.47,1309.75 1703.62,1329.21 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1743.47,1309.75 1837.16,1354.59 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1743.47,1309.75 1588.05,1339.32 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1743.47,1309.75 1860.38,1367.47 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1743.47,1309.75 1648.15,1312.42 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1743.47,1309.75 1700.35,1258.76 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1743.47,1309.75 1699.33,1286.66 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="769.406,634.153 814.732,652.033 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="769.406,634.153 743.459,765.44 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="769.406,634.153 720.554,754.819 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="769.406,634.153 715.316,738.187 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="769.406,634.153 772.628,583.151 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="769.406,634.153 831.69,709.673 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="769.406,634.153 880.766,743.567 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="769.406,634.153 723.281,539.905 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="769.406,634.153 660.083,606.633 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="769.406,634.153 744.524,577.068 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="769.406,634.153 814.958,495.066 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="769.406,634.153 645.821,653.715 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1013.57,858.594 885.027,845.118 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1013.57,858.594 1103.28,794.582 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1013.57,858.594 1096.83,822.995 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1013.57,858.594 1064.61,777.473 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1013.57,858.594 931.568,805.646 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1013.57,858.594 883.577,862.02 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1013.57,858.594 1146.94,918.463 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1013.57,858.594 952.053,913.176 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1013.57,858.594 1000.78,1015.41 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1013.57,858.594 1105.22,922.54 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1013.57,858.594 920.444,897.003 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1013.57,858.594 1070.34,744.599 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1013.57,858.594 1166.44,840.56 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1013.57,858.594 1141.51,950.168 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1013.57,858.594 1075.73,956.926 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1013.57,858.594 977.67,851.154 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1516.11,792.546 1500.12,796.671 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1516.11,792.546 1630.42,770.141 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1516.11,792.546 1506.35,884.386 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1516.11,792.546 1494.05,691.31 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1516.11,792.546 1364.46,786.721 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1516.11,792.546 1499.38,721.575 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1516.11,792.546 1478.87,738.61 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="690.947,234.278 699.967,386.637 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="690.947,234.278 682.991,300.358 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="690.947,234.278 648.237,371.723 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="690.947,234.278 675.106,198.753 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1492.02,318.88 1486.99,397.629 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1492.02,318.88 1567.51,244.377 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1492.02,318.88 1455.36,452.296 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1492.02,318.88 1506.91,203.128 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1492.02,318.88 1552.41,269.571 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1492.02,318.88 1357.49,242.337 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1492.02,318.88 1578.63,356.784 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1067.85,298.664 1051.73,175.744 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1067.85,298.664 1076.15,249.713 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1067.85,298.664 960.434,383.949 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1067.85,298.664 1077.93,399.032 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1067.85,298.664 992.901,246.941 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="821.658,406.573 699.967,386.637 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="821.658,406.573 704.229,460.25 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="821.658,406.573 884.188,365.667 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="821.658,406.573 902.058,533.174 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="821.658,406.573 960.434,383.949 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="821.658,406.573 814.958,495.066 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1486.99,397.629 1442.11,541.959 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1486.99,397.629 1455.36,452.296 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1486.99,397.629 1552.41,269.571 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1486.99,397.629 1578.63,356.784 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="699.967,386.637 682.991,300.358 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="699.967,386.637 704.229,460.25 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="699.967,386.637 648.237,371.723 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="699.967,386.637 723.281,539.905 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="699.967,386.637 814.958,495.066 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="885.027,845.118 743.459,765.44 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="885.027,845.118 931.568,805.646 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="885.027,845.118 883.577,862.02 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="885.027,845.118 952.053,913.176 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="885.027,845.118 920.444,897.003 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="885.027,845.118 831.69,709.673 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="885.027,845.118 880.766,743.567 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="885.027,845.118 899.787,992.654 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="885.027,845.118 977.67,851.154 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="885.027,845.118 878.204,968.143 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="885.027,845.118 876.41,950.546 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1103.28,794.582 1096.83,822.995 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1103.28,794.582 1064.61,777.473 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1103.28,794.582 1146.94,918.463 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1103.28,794.582 1105.22,922.54 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1103.28,794.582 1070.34,744.599 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1103.28,794.582 1166.44,840.56 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1103.28,794.582 1141.51,950.168 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1103.28,794.582 977.67,851.154 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1103.28,794.582 1064.12,681.072 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1103.28,794.582 990.697,689.017 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1413.05,1321.03 1551,1321.17 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1413.05,1321.03 1280.49,1316.75 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1413.05,1321.03 1499.77,1253.52 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1413.05,1321.03 1358.02,1312.65 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1413.05,1321.03 1329.99,1298.51 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1413.05,1321.03 1354.65,1183.44 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1413.05,1321.03 1480.21,1175.05 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1413.05,1321.03 1438.06,1350.33 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="744.715,1013.21 732.051,1036.95 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="744.715,1013.21 653.658,1076.62 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="744.715,1013.21 899.787,992.654 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="744.715,1013.21 699.749,877.716 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="744.715,1013.21 878.204,968.143 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="744.715,1013.21 780.937,1089.48 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="744.715,1013.21 876.41,950.546 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1551,1321.17 1703.62,1329.21 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1551,1321.17 1565.06,1420.1 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1551,1321.17 1499.77,1253.52 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1551,1321.17 1588.05,1339.32 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1551,1321.17 1648.15,1312.42 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1551,1321.17 1700.35,1258.76 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1551,1321.17 1480.21,1175.05 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1551,1321.17 1699.33,1286.66 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1551,1321.17 1438.06,1350.33 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1790.1,1139.96 1869.69,1148.62 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1790.1,1139.96 1700.35,1258.76 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1790.1,1139.96 1804.23,1135.38 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="814.732,652.033 937.144,552.433 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="814.732,652.033 743.459,765.44 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="814.732,652.033 720.554,754.819 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="814.732,652.033 715.316,738.187 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="814.732,652.033 772.628,583.151 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="814.732,652.033 966.714,694.317 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="814.732,652.033 831.69,709.673 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="814.732,652.033 902.058,533.174 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="814.732,652.033 880.766,743.567 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="814.732,652.033 723.281,539.905 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="814.732,652.033 660.083,606.633 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="814.732,652.033 744.524,577.068 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="814.732,652.033 814.958,495.066 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1902.56,224.658 1822.06,281.577 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1657.49,357.488 1567.51,244.377 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1657.49,357.488 1767.22,375.57 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1657.49,357.488 1641.98,512.364 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1657.49,357.488 1659.71,484.598 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1657.49,357.488 1784.76,366.428 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1657.49,357.488 1669,510.764 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1657.49,357.488 1552.41,269.571 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1657.49,357.488 1765.88,476.23 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1657.49,357.488 1578.63,356.784 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1567.51,244.377 1513.91,120.922 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1567.51,244.377 1506.91,203.128 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1567.51,244.377 1552.41,269.571 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1567.51,244.377 1578.63,356.784 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1087.2,1259.43 1025.75,1329.75 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1087.2,1259.43 1149.38,1182.41 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1087.2,1259.43 1014.21,1402.67 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1087.2,1259.43 951.823,1199.08 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1087.2,1259.43 1012.63,1207.07 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1087.2,1259.43 1176.38,1245.3 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1087.2,1259.43 1209.48,1175.26 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1087.2,1259.43 1061.05,1149.92 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1087.2,1259.43 1002.89,1302.76 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1087.2,1259.43 1187.61,1380 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1087.2,1259.43 1088.62,1202.86 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1051.73,175.744 1076.15,249.713 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1051.73,175.744 992.901,246.941 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1725.06,1409.13 1703.62,1329.21 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1725.06,1409.13 1565.06,1420.1 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1725.06,1409.13 1837.16,1354.59 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1725.06,1409.13 1588.05,1339.32 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1725.06,1409.13 1860.38,1367.47 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1725.06,1409.13 1648.15,1312.42 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1725.06,1409.13 1700.35,1258.76 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1725.06,1409.13 1699.33,1286.66 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1442.11,541.959 1319.71,614.233 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1442.11,541.959 1455.36,452.296 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1442.11,541.959 1531.03,627.61 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1442.11,541.959 1494.05,691.31 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1442.11,541.959 1398.97,594.793 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1442.11,541.959 1569.03,541.599 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1025.75,1329.75 973.963,1409.37 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1025.75,1329.75 1014.21,1402.67 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1025.75,1329.75 951.823,1199.08 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1025.75,1329.75 1012.63,1207.07 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1025.75,1329.75 1002.89,1302.76 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1025.75,1329.75 1088.62,1202.86 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="937.144,552.433 1059.14,478.073 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="937.144,552.433 966.714,694.317 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="937.144,552.433 902.058,533.174 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="937.144,552.433 1023.43,481.938 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="937.144,552.433 1010.67,556.319 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="937.144,552.433 990.697,689.017 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="937.144,552.433 814.958,495.066 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1096.83,822.995 1064.61,777.473 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1096.83,822.995 1146.94,918.463 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1096.83,822.995 1105.22,922.54 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1096.83,822.995 1070.34,744.599 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1096.83,822.995 1166.44,840.56 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1096.83,822.995 1141.51,950.168 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1096.83,822.995 1075.73,956.926 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1096.83,822.995 977.67,851.154 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1096.83,822.995 1064.12,681.072 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="973.963,1409.37 1014.21,1402.67 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="973.963,1409.37 1002.89,1302.76 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="973.963,1409.37 840.398,1321.59 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1828.62,695.053 1683.32,706.632 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1828.62,695.053 1745.81,626.024 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1828.62,695.053 1696.71,642.681 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1828.62,695.053 1841.35,687.149 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1703.62,1329.21 1837.16,1354.59 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1703.62,1329.21 1588.05,1339.32 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1703.62,1329.21 1860.38,1367.47 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1703.62,1329.21 1648.15,1312.42 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1703.62,1329.21 1700.35,1258.76 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1703.62,1329.21 1699.33,1286.66 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1064.61,777.473 931.568,805.646 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1064.61,777.473 1146.94,918.463 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1064.61,777.473 1105.22,922.54 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1064.61,777.473 966.714,694.317 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1064.61,777.473 1070.34,744.599 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1064.61,777.473 1166.44,840.56 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1064.61,777.473 977.67,851.154 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1064.61,777.473 1064.12,681.072 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1064.61,777.473 990.697,689.017 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="653.963,794.006 743.459,765.44 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="653.963,794.006 720.554,754.819 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="653.963,794.006 715.316,738.187 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="653.963,794.006 699.749,877.716 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="653.963,794.006 645.821,653.715 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="732.051,1036.95 653.658,1076.62 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="732.051,1036.95 699.749,877.716 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="732.051,1036.95 878.204,968.143 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="732.051,1036.95 780.937,1089.48 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="907.854,1137.19 951.823,1199.08 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="907.854,1137.19 1000.78,1015.41 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="907.854,1137.19 1012.63,1207.07 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="907.854,1137.19 1061.05,1149.92 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="907.854,1137.19 899.787,992.654 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="907.854,1137.19 1021.66,1027.08 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="907.854,1137.19 780.937,1089.48 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="743.459,765.44 720.554,754.819 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="743.459,765.44 715.316,738.187 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="743.459,765.44 831.69,709.673 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="743.459,765.44 880.766,743.567 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="743.459,765.44 699.749,877.716 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="743.459,765.44 645.821,653.715 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1565.06,1420.1 1588.05,1339.32 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1565.06,1420.1 1648.15,1312.42 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1565.06,1420.1 1438.06,1350.33 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1837.16,1354.59 1860.38,1367.47 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1837.16,1354.59 1699.33,1286.66 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1379.49,902.623 1310.36,1031.89 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1379.49,902.623 1500.12,796.671 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1379.49,902.623 1506.35,884.386 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1379.49,902.623 1484.67,956.013 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1379.49,902.623 1364.46,786.721 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1280.49,1316.75 1358.02,1312.65 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1280.49,1316.75 1253.25,1218.33 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1280.49,1316.75 1176.38,1245.3 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1280.49,1316.75 1209.48,1175.26 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1280.49,1316.75 1220.93,1415.85 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1280.49,1316.75 1203.36,1420.2 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1280.49,1316.75 1187.61,1380 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1280.49,1316.75 1329.99,1298.51 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1280.49,1316.75 1354.65,1183.44 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1280.49,1316.75 1438.06,1350.33 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1149.38,1182.41 1012.63,1207.07 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1149.38,1182.41 1253.25,1218.33 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1149.38,1182.41 1176.38,1245.3 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1149.38,1182.41 1209.48,1175.26 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1149.38,1182.41 1061.05,1149.92 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1149.38,1182.41 1088.62,1202.86 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1014.21,1402.67 1002.89,1302.76 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1822.06,281.577 1767.22,375.57 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1822.06,281.577 1784.76,366.428 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1059.14,478.073 1122.48,571.934 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1059.14,478.073 960.434,383.949 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1059.14,478.073 1023.43,481.938 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1059.14,478.073 1077.93,399.032 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1059.14,478.073 1101.25,530.745 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1059.14,478.073 1010.67,556.319 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1059.14,478.073 1208.53,508.3 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1724.14,547.408 1641.98,512.364 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1724.14,547.408 1659.71,484.598 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1724.14,547.408 1669,510.764 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1724.14,547.408 1833.29,459.766 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1724.14,547.408 1745.81,626.024 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1724.14,547.408 1659.87,686.32 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1724.14,547.408 1765.88,476.23 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1724.14,547.408 1696.71,642.681 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1724.14,547.408 1569.03,541.599 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1767.22,375.57 1659.71,484.598 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1767.22,375.57 1784.76,366.428 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1767.22,375.57 1833.29,459.766 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1767.22,375.57 1765.88,476.23 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1668.11,985.393 1652.98,998.948 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1668.11,985.393 1770.09,926.74 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1668.11,985.393 1576.73,1044.44 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1668.11,985.393 1616,1082.9 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1668.11,985.393 1697.61,979.146 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="931.568,805.646 883.577,862.02 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="931.568,805.646 952.053,913.176 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="931.568,805.646 920.444,897.003 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="931.568,805.646 966.714,694.317 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="931.568,805.646 1070.34,744.599 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="931.568,805.646 831.69,709.673 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="931.568,805.646 880.766,743.567 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="931.568,805.646 977.67,851.154 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="931.568,805.646 876.41,950.546 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="931.568,805.646 990.697,689.017 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="883.577,862.02 952.053,913.176 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="883.577,862.02 920.444,897.003 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="883.577,862.02 831.69,709.673 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="883.577,862.02 880.766,743.567 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="883.577,862.02 899.787,992.654 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="883.577,862.02 977.67,851.154 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="883.577,862.02 878.204,968.143 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="883.577,862.02 876.41,950.546 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1499.77,1253.52 1358.02,1312.65 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1499.77,1253.52 1588.05,1339.32 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1499.77,1253.52 1549.18,1140.55 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1499.77,1253.52 1648.15,1312.42 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1499.77,1253.52 1354.65,1183.44 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1499.77,1253.52 1480.21,1175.05 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1499.77,1253.52 1438.06,1350.33 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1310.36,1031.89 1393.07,1076.48 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1310.36,1031.89 1161.98,992.257 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1310.36,1031.89 1354.65,1183.44 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1310.36,1031.89 1425.42,1060.58 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1310.36,1031.89 1208.98,968.883 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1869.69,1148.62 1804.23,1135.38 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1295.72,630.418 1319.71,614.233 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1295.72,630.418 1179.16,629.458 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1295.72,630.418 1316.19,726.7 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1295.72,630.418 1292.89,668.564 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1295.72,630.418 1208.53,508.3 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1295.72,630.418 1398.97,594.793 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1146.94,918.463 1119.78,991.659 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1146.94,918.463 1105.22,922.54 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1146.94,918.463 1166.44,840.56 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1146.94,918.463 1141.51,950.168 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1146.94,918.463 1075.73,956.926 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1146.94,918.463 1161.98,992.257 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1146.94,918.463 1208.98,968.883 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="951.823,1199.08 1012.63,1207.07 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="951.823,1199.08 1061.05,1149.92 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="951.823,1199.08 1002.89,1302.76 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="951.823,1199.08 1088.62,1202.86 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1119.78,991.659 1000.78,1015.41 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1119.78,991.659 1105.22,922.54 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1119.78,991.659 1166.44,840.56 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1119.78,991.659 1141.51,950.168 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1119.78,991.659 1075.73,956.926 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1119.78,991.659 1021.66,1027.08 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1119.78,991.659 1161.98,992.257 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1119.78,991.659 1208.98,968.883 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="698.25,1238.58 802.437,1287.4 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="698.25,1238.58 749.111,1264.31 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="720.554,754.819 715.316,738.187 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="720.554,754.819 831.69,709.673 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="720.554,754.819 880.766,743.567 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="720.554,754.819 699.749,877.716 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="720.554,754.819 660.083,606.633 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="720.554,754.819 645.821,653.715 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="952.053,913.176 1000.78,1015.41 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="952.053,913.176 1105.22,922.54 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="952.053,913.176 920.444,897.003 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="952.053,913.176 899.787,992.654 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="952.053,913.176 1075.73,956.926 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="952.053,913.176 977.67,851.154 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="952.053,913.176 878.204,968.143 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="952.053,913.176 1021.66,1027.08 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="952.053,913.176 876.41,950.546 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1000.78,1015.41 1105.22,922.54 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1000.78,1015.41 920.444,897.003 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1000.78,1015.41 1061.05,1149.92 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1000.78,1015.41 899.787,992.654 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1000.78,1015.41 1141.51,950.168 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1000.78,1015.41 1075.73,956.926 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1000.78,1015.41 878.204,968.143 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1000.78,1015.41 1021.66,1027.08 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1000.78,1015.41 1161.98,992.257 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1000.78,1015.41 876.41,950.546 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1105.22,922.54 1166.44,840.56 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1105.22,922.54 1141.51,950.168 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1105.22,922.54 1075.73,956.926 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1105.22,922.54 977.67,851.154 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1105.22,922.54 1021.66,1027.08 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1105.22,922.54 1161.98,992.257 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1105.22,922.54 1208.98,968.883 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1286.32,186.395 1357.49,242.337 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1286.32,186.395 1337.97,172.684 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1286.32,186.395 1325.57,284.807 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1358.02,1312.65 1253.25,1218.33 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1358.02,1312.65 1329.99,1298.51 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1358.02,1312.65 1354.65,1183.44 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1358.02,1312.65 1438.06,1350.33 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="682.991,300.358 704.229,460.25 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="682.991,300.358 648.237,371.723 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="682.991,300.358 675.106,198.753 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="715.316,738.187 831.69,709.673 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="715.316,738.187 699.749,877.716 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="715.316,738.187 660.083,606.633 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="715.316,738.187 645.821,653.715 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="802.437,1287.4 749.111,1264.31 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="802.437,1287.4 840.398,1321.59 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="772.628,583.151 704.229,460.25 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="772.628,583.151 831.69,709.673 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="772.628,583.151 902.058,533.174 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="772.628,583.151 723.281,539.905 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="772.628,583.151 660.083,606.633 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="772.628,583.151 744.524,577.068 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="772.628,583.151 814.958,495.066 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="772.628,583.151 645.821,653.715 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1500.12,796.671 1630.42,770.141 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1500.12,796.671 1506.35,884.386 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1500.12,796.671 1494.05,691.31 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1500.12,796.671 1484.67,956.013 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1500.12,796.671 1364.46,786.721 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1500.12,796.671 1499.38,721.575 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1500.12,796.671 1478.87,738.61 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1012.63,1207.07 1061.05,1149.92 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1012.63,1207.07 1002.89,1302.76 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1012.63,1207.07 1088.62,1202.86 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1253.25,1218.33 1176.38,1245.3 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1253.25,1218.33 1209.48,1175.26 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1253.25,1218.33 1329.99,1298.51 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1253.25,1218.33 1354.65,1183.44 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1630.42,770.141 1683.32,706.632 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1630.42,770.141 1494.05,691.31 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1630.42,770.141 1659.87,686.32 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1630.42,770.141 1499.38,721.575 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1630.42,770.141 1696.71,642.681 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1630.42,770.141 1478.87,738.61 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1652.98,998.948 1770.09,926.74 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1652.98,998.948 1576.73,1044.44 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1652.98,998.948 1616,1082.9 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1652.98,998.948 1697.61,979.146 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="920.444,897.003 880.766,743.567 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="920.444,897.003 899.787,992.654 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="920.444,897.003 977.67,851.154 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="920.444,897.003 878.204,968.143 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="920.444,897.003 876.41,950.546 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1176.38,1245.3 1209.48,1175.26 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1176.38,1245.3 1061.05,1149.92 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1176.38,1245.3 1187.61,1380 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1176.38,1245.3 1329.99,1298.51 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1176.38,1245.3 1088.62,1202.86 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="704.229,460.25 648.237,371.723 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="704.229,460.25 723.281,539.905 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="704.229,460.25 660.083,606.633 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="704.229,460.25 744.524,577.068 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="704.229,460.25 814.958,495.066 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1641.98,512.364 1659.71,484.598 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1641.98,512.364 1669,510.764 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1641.98,512.364 1531.03,627.61 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1641.98,512.364 1745.81,626.024 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1641.98,512.364 1765.88,476.23 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1641.98,512.364 1696.71,642.681 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1641.98,512.364 1569.03,541.599 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="966.714,694.317 1070.34,744.599 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="966.714,694.317 831.69,709.673 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="966.714,694.317 880.766,743.567 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="966.714,694.317 977.67,851.154 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="966.714,694.317 1064.12,681.072 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="966.714,694.317 1010.67,556.319 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="966.714,694.317 990.697,689.017 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1319.71,614.233 1179.16,629.458 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1319.71,614.233 1236.16,474.909 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1319.71,614.233 1316.19,726.7 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1319.71,614.233 1292.89,668.564 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1319.71,614.233 1208.53,508.3 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1319.71,614.233 1398.97,594.793 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1513.91,120.922 1506.91,203.128 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1513.91,120.922 1552.41,269.571 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1209.48,1175.26 1061.05,1149.92 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1209.48,1175.26 1354.65,1183.44 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1209.48,1175.26 1088.62,1202.86 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1659.71,484.598 1669,510.764 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1659.71,484.598 1765.88,476.23 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1659.71,484.598 1578.63,356.784 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1659.71,484.598 1696.71,642.681 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1659.71,484.598 1569.03,541.599 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1070.34,744.599 1166.44,840.56 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1070.34,744.599 1179.16,629.458 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1070.34,744.599 977.67,851.154 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1070.34,744.599 1064.12,681.072 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1070.34,744.599 990.697,689.017 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="831.69,709.673 880.766,743.567 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="831.69,709.673 744.524,577.068 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="831.69,709.673 990.697,689.017 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1220.93,1415.85 1203.36,1420.2 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1220.93,1415.85 1187.61,1380 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1220.93,1415.85 1329.99,1298.51 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1203.36,1420.2 1187.61,1380 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="884.188,365.667 960.434,383.949 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="884.188,365.667 814.958,495.066 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="884.188,365.667 992.901,246.941 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1455.36,452.296 1578.63,356.784 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1455.36,452.296 1398.97,594.793 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1455.36,452.296 1569.03,541.599 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1506.35,884.386 1484.67,956.013 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1506.35,884.386 1499.38,721.575 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1506.35,884.386 1478.87,738.61 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1061.05,1149.92 1002.89,1302.76 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1061.05,1149.92 1021.66,1027.08 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1061.05,1149.92 1088.62,1202.86 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1784.76,366.428 1833.29,459.766 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1784.76,366.428 1765.88,476.23 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1588.05,1339.32 1648.15,1312.42 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1588.05,1339.32 1700.35,1258.76 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1588.05,1339.32 1699.33,1286.66 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1588.05,1339.32 1438.06,1350.33 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1669,510.764 1745.81,626.024 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1669,510.764 1765.88,476.23 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1669,510.764 1696.71,642.681 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1669,510.764 1569.03,541.599 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="902.058,533.174 960.434,383.949 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="902.058,533.174 1023.43,481.938 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="902.058,533.174 1010.67,556.319 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="902.058,533.174 744.524,577.068 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="902.058,533.174 814.958,495.066 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="880.766,743.567 977.67,851.154 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="880.766,743.567 990.697,689.017 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="653.658,1076.62 780.937,1089.48 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1683.32,706.632 1745.81,626.024 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1683.32,706.632 1659.87,686.32 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1683.32,706.632 1696.71,642.681 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1683.32,706.632 1841.35,687.149 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1166.44,840.56 1141.51,950.168 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1166.44,840.56 1075.73,956.926 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1166.44,840.56 1161.98,992.257 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1166.44,840.56 1208.98,968.883 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1393.07,1076.48 1484.67,956.013 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1393.07,1076.48 1354.65,1183.44 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1393.07,1076.48 1425.42,1060.58 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1393.07,1076.48 1480.21,1175.05 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1833.29,459.766 1765.88,476.23 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1531.03,627.61 1494.05,691.31 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1531.03,627.61 1659.87,686.32 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1531.03,627.61 1499.38,721.575 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1531.03,627.61 1478.87,738.61 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1531.03,627.61 1398.97,594.793 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1531.03,627.61 1569.03,541.599 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="899.787,992.654 977.67,851.154 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="899.787,992.654 878.204,968.143 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="899.787,992.654 1021.66,1027.08 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="899.787,992.654 780.937,1089.48 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="899.787,992.654 876.41,950.546 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1076.15,249.713 1077.93,399.032 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1076.15,249.713 992.901,246.941 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1494.05,691.31 1364.46,786.721 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1494.05,691.31 1499.38,721.575 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1494.05,691.31 1478.87,738.61 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1494.05,691.31 1398.97,594.793 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1179.16,629.458 1122.48,571.934 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1179.16,629.458 1292.89,668.564 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1179.16,629.458 1101.25,530.745 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1179.16,629.458 1064.12,681.072 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1179.16,629.458 1208.53,508.3 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1506.91,203.128 1552.41,269.571 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1506.91,203.128 1357.49,242.337 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1549.18,1140.55 1576.73,1044.44 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1549.18,1140.55 1616,1082.9 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1549.18,1140.55 1425.42,1060.58 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1549.18,1140.55 1480.21,1175.05 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1745.81,626.024 1659.87,686.32 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1745.81,626.024 1765.88,476.23 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1745.81,626.024 1696.71,642.681 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1745.81,626.024 1841.35,687.149 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1141.51,950.168 1075.73,956.926 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1141.51,950.168 1021.66,1027.08 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1141.51,950.168 1161.98,992.257 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1141.51,950.168 1208.98,968.883 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1075.73,956.926 977.67,851.154 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1075.73,956.926 1021.66,1027.08 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1075.73,956.926 1161.98,992.257 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1075.73,956.926 1208.98,968.883 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1659.87,686.32 1696.71,642.681 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1122.48,571.934 1236.16,474.909 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1122.48,571.934 1023.43,481.938 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1122.48,571.934 1101.25,530.745 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1122.48,571.934 1064.12,681.072 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1122.48,571.934 1010.67,556.319 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1122.48,571.934 1208.53,508.3 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="960.434,383.949 1023.43,481.938 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="960.434,383.949 1077.93,399.032 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="960.434,383.949 992.901,246.941 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1236.16,474.909 1101.25,530.745 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1236.16,474.909 1208.53,508.3 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="977.67,851.154 878.204,968.143 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="977.67,851.154 876.41,950.546 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="977.67,851.154 990.697,689.017 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="878.204,968.143 1021.66,1027.08 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="878.204,968.143 780.937,1089.48 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="878.204,968.143 876.41,950.546 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1552.41,269.571 1578.63,356.784 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1857.57,916.675 1770.09,926.74 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1316.19,726.7 1364.46,786.721 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1316.19,726.7 1292.89,668.564 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1316.19,726.7 1478.87,738.61 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1316.19,726.7 1398.97,594.793 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1770.09,926.74 1697.61,979.146 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1357.49,242.337 1337.97,172.684 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1357.49,242.337 1325.57,284.807 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1023.43,481.938 1077.93,399.032 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1023.43,481.938 1101.25,530.745 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1023.43,481.938 1010.67,556.319 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1002.89,1302.76 1088.62,1202.86 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1021.66,1027.08 1161.98,992.257 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1484.67,956.013 1576.73,1044.44 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1484.67,956.013 1425.42,1060.58 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1337.97,172.684 1325.57,284.807 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1364.46,786.721 1292.89,668.564 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1364.46,786.721 1499.38,721.575 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1364.46,786.721 1478.87,738.61 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1329.99,1298.51 1354.65,1183.44 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1329.99,1298.51 1438.06,1350.33 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="723.281,539.905 660.083,606.633 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="723.281,539.905 744.524,577.068 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="723.281,539.905 814.958,495.066 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="723.281,539.905 645.821,653.715 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1161.98,992.257 1208.98,968.883 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1292.89,668.564 1398.97,594.793 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1499.38,721.575 1478.87,738.61 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1499.38,721.575 1398.97,594.793 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1576.73,1044.44 1616,1082.9 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1576.73,1044.44 1425.42,1060.58 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1576.73,1044.44 1480.21,1175.05 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1576.73,1044.44 1697.61,979.146 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1648.15,1312.42 1700.35,1258.76 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1648.15,1312.42 1699.33,1286.66 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="660.083,606.633 744.524,577.068 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="660.083,606.633 645.821,653.715 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1696.71,642.681 1841.35,687.149 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1696.71,642.681 1569.03,541.599 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1354.65,1183.44 1425.42,1060.58 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1354.65,1183.44 1480.21,1175.05 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1077.93,399.032 1101.25,530.745 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1700.35,1258.76 1699.33,1286.66 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1700.35,1258.76 1804.23,1135.38 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1616,1082.9 1697.61,979.146 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1101.25,530.745 1064.12,681.072 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1101.25,530.745 1010.67,556.319 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1101.25,530.745 1208.53,508.3 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="749.111,1264.31 840.398,1321.59 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1425.42,1060.58 1480.21,1175.05 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1064.12,681.072 1010.67,556.319 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1064.12,681.072 990.697,689.017 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="1010.67,556.319 990.697,689.017 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="744.524,577.068 814.958,495.066 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="744.524,577.068 645.821,653.715 "/>
<polyline clip-path="url(#clip742)" style="stroke:#808080; stroke-linecap:round; stroke-linejoin:round; stroke-width:4; stroke-opacity:0.4; fill:none" points="870.545,190.141 992.901,246.941 "/>
<circle clip-path="url(#clip742)" cx="1417.16" cy="451.056" r="18" fill="#00a9ad" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="791.637" cy="568.175" r="18" fill="#6b9e32" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1107.74" cy="293.733" r="18" fill="#c271d2" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1212.88" cy="1068.81" r="18" fill="#ac8d18" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="658.401" cy="972.437" r="18" fill="#c271d2" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1336.49" cy="1316.15" r="18" fill="#ed5d92" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1913.94" cy="1003.43" r="18" fill="#8e971d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1798.97" cy="430.447" r="18" fill="#c68125" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="869.21" cy="360.079" r="18" fill="#e26f46" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1410.21" cy="376.625" r="18" fill="#ed5d92" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="717.983" cy="1300.2" r="18" fill="#00a98d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1730.78" cy="652.236" r="18" fill="#c68125" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1160.59" cy="743.112" r="18" fill="#c271d2" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="658.265" cy="1411.34" r="18" fill="#00a98d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1288.09" cy="231.842" r="18" fill="#00a98d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1780.13" cy="763.749" r="18" fill="#c68125" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1773.32" cy="162.103" r="18" fill="#8e971d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1388.69" cy="742.037" r="18" fill="#ac8d18" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1326.28" cy="1110.96" r="18" fill="#00a9ad" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="976.358" cy="636.203" r="18" fill="#e26f46" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1857.13" cy="368.615" r="18" fill="#00a98d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1250.85" cy="552.616" r="18" fill="#c271d2" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1667.16" cy="128.893" r="18" fill="#00a98d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1553.69" cy="679.768" r="18" fill="#ed5d92" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="821.39" cy="1400.29" r="18" fill="#c68125" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1690.6" cy="963.763" r="18" fill="#00a98d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1295.13" cy="1087.44" r="18" fill="#00a9ad" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1743.47" cy="1309.75" r="18" fill="#8e971d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="769.406" cy="634.153" r="18" fill="#009af9" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1013.57" cy="858.594" r="18" fill="#3da44d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1516.11" cy="792.546" r="18" fill="#00a9ad" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="690.947" cy="234.278" r="18" fill="#3da44d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1492.02" cy="318.88" r="18" fill="#ed5d92" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1067.85" cy="298.664" r="18" fill="#3da44d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="821.658" cy="406.573" r="18" fill="#e26f46" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1486.99" cy="397.629" r="18" fill="#00a9ad" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="699.967" cy="386.637" r="18" fill="#e26f46" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="885.027" cy="845.118" r="18" fill="#e26f46" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1103.28" cy="794.582" r="18" fill="#3da44d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1413.05" cy="1321.03" r="18" fill="#c68125" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="744.715" cy="1013.21" r="18" fill="#c271d2" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1551" cy="1321.17" r="18" fill="#00a98d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1790.1" cy="1139.96" r="18" fill="#00a8cb" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="814.732" cy="652.033" r="18" fill="#009af9" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1902.56" cy="224.658" r="18" fill="#8e971d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1657.49" cy="357.488" r="18" fill="#c68125" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1567.51" cy="244.377" r="18" fill="#c68125" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1087.2" cy="1259.43" r="18" fill="#00a9ad" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1051.73" cy="175.744" r="18" fill="#c271d2" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1725.06" cy="1409.13" r="18" fill="#8e971d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1442.11" cy="541.959" r="18" fill="#ac8d18" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1025.75" cy="1329.75" r="18" fill="#00a9ad" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="937.144" cy="552.433" r="18" fill="#009af9" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1096.83" cy="822.995" r="18" fill="#c271d2" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="973.963" cy="1409.37" r="18" fill="#ed5d92" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1828.62" cy="695.053" r="18" fill="#c68125" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1703.62" cy="1329.21" r="18" fill="#8e971d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1064.61" cy="777.473" r="18" fill="#3da44d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="653.963" cy="794.006" r="18" fill="#3da44d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="732.051" cy="1036.95" r="18" fill="#c271d2" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="907.854" cy="1137.19" r="18" fill="#c271d2" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="743.459" cy="765.44" r="18" fill="#e26f46" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1565.06" cy="1420.1" r="18" fill="#00a98d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1837.16" cy="1354.59" r="18" fill="#00a8cb" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1379.49" cy="902.623" r="18" fill="#00a9ad" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1280.49" cy="1316.75" r="18" fill="#ed5d92" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1149.38" cy="1182.41" r="18" fill="#00a9ad" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1014.21" cy="1402.67" r="18" fill="#ed5d92" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1822.06" cy="281.577" r="18" fill="#00a98d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1059.14" cy="478.073" r="18" fill="#e26f46" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1724.14" cy="547.408" r="18" fill="#ed5d92" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1767.22" cy="375.57" r="18" fill="#c68125" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1668.11" cy="985.393" r="18" fill="#00a98d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="931.568" cy="805.646" r="18" fill="#e26f46" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="883.577" cy="862.02" r="18" fill="#e26f46" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1499.77" cy="1253.52" r="18" fill="#c68125" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1310.36" cy="1031.89" r="18" fill="#00a9ad" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1869.69" cy="1148.62" r="18" fill="#00a8cb" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1295.72" cy="630.418" r="18" fill="#c271d2" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1146.94" cy="918.463" r="18" fill="#c271d2" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="951.823" cy="1199.08" r="18" fill="#ac8d18" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1119.78" cy="991.659" r="18" fill="#ac8d18" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="698.25" cy="1238.58" r="18" fill="#8e971d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="720.554" cy="754.819" r="18" fill="#e26f46" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="952.053" cy="913.176" r="18" fill="#3da44d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1000.78" cy="1015.41" r="18" fill="#c271d2" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1105.22" cy="922.54" r="18" fill="#c271d2" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1286.32" cy="186.395" r="18" fill="#00a98d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1358.02" cy="1312.65" r="18" fill="#ed5d92" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="682.991" cy="300.358" r="18" fill="#e26f46" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="715.316" cy="738.187" r="18" fill="#e26f46" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="802.437" cy="1287.4" r="18" fill="#00a98d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="772.628" cy="583.151" r="18" fill="#009af9" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1500.12" cy="796.671" r="18" fill="#00a9ad" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1012.63" cy="1207.07" r="18" fill="#ac8d18" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1253.25" cy="1218.33" r="18" fill="#00a9ad" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1630.42" cy="770.141" r="18" fill="#ed5d92" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1652.98" cy="998.948" r="18" fill="#00a98d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="920.444" cy="897.003" r="18" fill="#3da44d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1176.38" cy="1245.3" r="18" fill="#00a9ad" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="704.229" cy="460.25" r="18" fill="#009af9" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1641.98" cy="512.364" r="18" fill="#ed5d92" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="648.237" cy="371.723" r="18" fill="#e26f46" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="966.714" cy="694.317" r="18" fill="#e26f46" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1319.71" cy="614.233" r="18" fill="#c271d2" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1513.91" cy="120.922" r="18" fill="#c68125" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1209.48" cy="1175.26" r="18" fill="#00a9ad" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1659.71" cy="484.598" r="18" fill="#ed5d92" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1070.34" cy="744.599" r="18" fill="#3da44d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="831.69" cy="709.673" r="18" fill="#009af9" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1220.93" cy="1415.85" r="18" fill="#c68125" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1203.36" cy="1420.2" r="18" fill="#c68125" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="884.188" cy="365.667" r="18" fill="#e26f46" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1455.36" cy="452.296" r="18" fill="#00a9ad" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1506.35" cy="884.386" r="18" fill="#ed5d92" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1061.05" cy="1149.92" r="18" fill="#ac8d18" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1784.76" cy="366.428" r="18" fill="#00a98d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1588.05" cy="1339.32" r="18" fill="#00a98d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1669" cy="510.764" r="18" fill="#ed5d92" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="902.058" cy="533.174" r="18" fill="#009af9" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="880.766" cy="743.567" r="18" fill="#e26f46" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="653.658" cy="1076.62" r="18" fill="#ac8d18" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1683.32" cy="706.632" r="18" fill="#c68125" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1166.44" cy="840.56" r="18" fill="#c271d2" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1393.07" cy="1076.48" r="18" fill="#ed5d92" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1833.29" cy="459.766" r="18" fill="#c68125" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1531.03" cy="627.61" r="18" fill="#00a9ad" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1733.48" cy="134.754" r="18" fill="#8e971d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="899.787" cy="992.654" r="18" fill="#3da44d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="675.106" cy="198.753" r="18" fill="#3da44d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1076.15" cy="249.713" r="18" fill="#c271d2" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1494.05" cy="691.31" r="18" fill="#00a9ad" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1179.16" cy="629.458" r="18" fill="#c271d2" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1506.91" cy="203.128" r="18" fill="#c68125" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1549.18" cy="1140.55" r="18" fill="#c68125" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1745.81" cy="626.024" r="18" fill="#c68125" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="699.749" cy="877.716" r="18" fill="#3da44d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1141.51" cy="950.168" r="18" fill="#c271d2" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1075.73" cy="956.926" r="18" fill="#c271d2" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1659.87" cy="686.32" r="18" fill="#ed5d92" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1122.48" cy="571.934" r="18" fill="#3da44d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="960.434" cy="383.949" r="18" fill="#e26f46" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1236.16" cy="474.909" r="18" fill="#c271d2" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="977.67" cy="851.154" r="18" fill="#3da44d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="878.204" cy="968.143" r="18" fill="#3da44d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1552.41" cy="269.571" r="18" fill="#ed5d92" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1857.57" cy="916.675" r="18" fill="#8e971d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1316.19" cy="726.7" r="18" fill="#ac8d18" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1770.09" cy="926.74" r="18" fill="#00a98d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1357.49" cy="242.337" r="18" fill="#c68125" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1023.43" cy="481.938" r="18" fill="#e26f46" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1002.89" cy="1302.76" r="18" fill="#00a9ad" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1021.66" cy="1027.08" r="18" fill="#c271d2" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1484.67" cy="956.013" r="18" fill="#ed5d92" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1765.88" cy="476.23" r="18" fill="#c68125" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1578.63" cy="356.784" r="18" fill="#ed5d92" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1187.61" cy="1380" r="18" fill="#ed5d92" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1337.97" cy="172.684" r="18" fill="#00a98d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1364.46" cy="786.721" r="18" fill="#00a9ad" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1329.99" cy="1298.51" r="18" fill="#ed5d92" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1860.38" cy="1367.47" r="18" fill="#00a8cb" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="723.281" cy="539.905" r="18" fill="#009af9" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1161.98" cy="992.257" r="18" fill="#ac8d18" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1292.89" cy="668.564" r="18" fill="#ac8d18" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1499.38" cy="721.575" r="18" fill="#00a9ad" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1576.73" cy="1044.44" r="18" fill="#c68125" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1648.15" cy="1312.42" r="18" fill="#00a98d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="660.083" cy="606.633" r="18" fill="#009af9" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1696.71" cy="642.681" r="18" fill="#ed5d92" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1354.65" cy="1183.44" r="18" fill="#ed5d92" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1077.93" cy="399.032" r="18" fill="#3da44d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1700.35" cy="1258.76" r="18" fill="#8e971d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1616" cy="1082.9" r="18" fill="#00a98d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1101.25" cy="530.745" r="18" fill="#3da44d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="749.111" cy="1264.31" r="18" fill="#00a98d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1425.42" cy="1060.58" r="18" fill="#ed5d92" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1208.98" cy="968.883" r="18" fill="#ac8d18" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1480.21" cy="1175.05" r="18" fill="#c68125" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1325.57" cy="284.807" r="18" fill="#c68125" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1064.12" cy="681.072" r="18" fill="#3da44d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1088.62" cy="1202.86" r="18" fill="#00a9ad" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1010.67" cy="556.319" r="18" fill="#e26f46" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="744.524" cy="577.068" r="18" fill="#009af9" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1208.53" cy="508.3" r="18" fill="#3da44d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="780.937" cy="1089.48" r="18" fill="#c271d2" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1478.87" cy="738.61" r="18" fill="#00a9ad" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1841.35" cy="687.149" r="18" fill="#c68125" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="840.398" cy="1321.59" r="18" fill="#c68125" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1398.97" cy="594.793" r="18" fill="#ac8d18" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1699.33" cy="1286.66" r="18" fill="#8e971d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1697.61" cy="979.146" r="18" fill="#00a98d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="876.41" cy="950.546" r="18" fill="#3da44d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="870.545" cy="190.141" r="18" fill="#c271d2" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1804.23" cy="1135.38" r="18" fill="#00a8cb" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1569.03" cy="541.599" r="18" fill="#00a9ad" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="990.697" cy="689.017" r="18" fill="#e26f46" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="814.958" cy="495.066" r="18" fill="#009af9" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="645.821" cy="653.715" r="18" fill="#e26f46" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="992.901" cy="246.941" r="18" fill="#3da44d" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
<circle clip-path="url(#clip742)" cx="1438.06" cy="1350.33" r="18" fill="#c68125" fill-rule="evenodd" fill-opacity="1" stroke="#000000" stroke-opacity="1" stroke-width="3.2"/>
</svg>





```julia

```
