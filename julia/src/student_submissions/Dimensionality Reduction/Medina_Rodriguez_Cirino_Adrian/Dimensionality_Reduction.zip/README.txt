Debido a la naturaleza del ejercicio 4, las imágenes que se procesan en la carpeta dat y las imágenes resultantes de la carpeta fig, se subieron a 
una liga en drive, se pide descargar las carpetas fig y dat de dicha liga y remplazar las vacías que vienen en el zip para correr correctamente 
Dimensionality_Reduction.ipynb y para visualizar los resultados ya obtenidos.

https://drive.google.com/drive/folders/1bB3xr0HKkXYfo02UrQmYv-L7sBzVfjlp?usp=sharing
Gracias.