using CSV
using DataFrames
using CategoricalArrays
using Random
using Statistics
using MLJ
using MLJLinearModels  # For LogisticClassifier with penalties
using MLJBase          # For confusion_matrix, etc.
using Statistics       # For mean(), etc.
using Plots

# Función para calcular la curva ROC
function calcular_roc(y_true, y_scores)
    # Ordenar las predicciones de mayor a menor probabilidad
    orden = sortperm(y_scores, rev=true)
    y_true_ordenado = y_true[orden]
    
    # Calcular acumulados de verdaderos positivos y falsos positivos
    tp = cumsum(y_true_ordenado)
    fp = cumsum(1 .- y_true_ordenado)
    
    # Total de positivos y negativos
    P = sum(y_true)
    N = length(y_true) - P
    
    # Calcular TPR y FPR
    tpr = tp / P
    fpr = fp / N
    
    # Añadir (0,0) al inicio y (1,1) al final para cerrar la curva
    fpr = [0.0; fpr; 1.0]
    tpr = [0.0; tpr; 1.0]
    
    return fpr, tpr
end

# Función para calcular el AUC usando la Regla del Trapecio
function calcular_auc(fpr, tpr)
    auc = 0.0
    for i in 2:length(fpr)
        auc += (fpr[i] - fpr[i-1]) * (tpr[i] + tpr[i-1]) / 2
    end
    return auc
end

# Load the CSV
df = CSV.read("dat/Smarket.csv", DataFrame)

println("Initial shape of Smarket data: ", size(df))
println("Columns in Smarket: ", names(df))

# Basic data checks/cleaning

# a) Drop missing rows if any
println("Checking missing values per column:")
for c in names(df)
    n_missing = count(ismissing, df[!, c])
    println("  * ", c, " => ", n_missing, " missing")
end

println("\nDropping missing rows (if any found):")
df = dropmissing(df)
println("Shape after dropmissing: ", size(df))

# b) Ensure 'Direction' as categorical
df.Direction = categorical(df.Direction)


# Define features and target
# Typically, features are: Lag1, Lag2, Lag3, Lag4, Lag5, Volume
# Target is Direction
feature_cols = [:Lag1, :Lag2, :Lag3, :Lag4, :Lag5, :Volume]
target_col   = :Direction

# Extract features (X) and target (y)
X = df[:, feature_cols]
y = df[!, target_col]

println("\nSelected feature columns: ", feature_cols)
println("Target column: ", target_col)

# Split into train and test sets
Random.seed!(123)  # for reproducibility
n = nrow(X)
train_ratio = 0.8
train_size = Int(floor(train_ratio * n))

indices = shuffle(1:n)
train_indices = indices[1:train_size]
test_indices = indices[train_size+1:end]

X_train = X[train_indices, :]
y_train = y[train_indices]
X_test  = X[test_indices, :]
y_test  = y[test_indices]

println("\nTrain size: ", size(X_train), " | Test size: ", size(X_test))

# Labels to binary
y_test_bin = Int.(y_test .== "Up")

########################################################################
# LASSO
########################################################################

println("\n=== LASSO Logistic Regression ===")

# Load or define the logistic regression model with an L1 penalty
LogisticLasso = @load LogisticClassifier pkg=MLJLinearModels verbosity=0

# Create an instance with penalty = :l1 (LASSO).
model_lasso = LogisticLasso(
    penalty = :l1,
    lambda  = 0.1 
)

# Wrap it in a machine together with training data
mach_lasso = machine(model_lasso, X_train, y_train)

# Train the model
fit!(mach_lasso)

# Use the trained model to make predictions on X_test
#    For classification, 'predict' returns the probabilistic predictions by default.
preds_prob = predict(mach_lasso, X_test)

# Convert probabilistic predictions to class labels (Up or Down)
#    'mode' picks the label with highest probability in each NamedTuple row
yhat_lasso = mode.(preds_prob)

# Evaluate performance: confusion matrix, accuracy, etc.
cm_lasso = confusion_matrix(y_test, yhat_lasso)
accuracy_lasso = mean(yhat_lasso .== y_test)

println("Confusion Matrix (LASSO):")
println(cm_lasso)
println("Accuracy (LASSO): ", accuracy_lasso)

y_scores_lasso = Int.(yhat_lasso .== "Up")
# ROC
fpr_lasso, tpr_lasso = calcular_roc(y_test_bin, y_scores_lasso)

# AUC
auc_lasso = calcular_auc(fpr_lasso, tpr_lasso)

println("AUC (LASSO): ", auc_lasso)

# Plot

plot(
    fpr_lasso, tpr_lasso,
    label = "LASSO (AUC=$(round(auc_lasso, digits=3)))",
    xlabel = "False Positive Rate",
    ylabel = "True Positive Rate",
    title = "ROC Curve - LASSO Logistic Regression",
    linewidth = 2,
    linecolor = :blue,
    legend = :best
)

# Agregar una línea de referencia (AUC = 0.5)
plot!(
    [0, 1], [0, 1],
    label = "Random Guess (AUC=0.5)",
    linestyle = :dash,
    linecolor = :black
)

# Guardar la figura
savefig("fig/lasso_roc.png")
println("ROC curve saved to fig/lasso_roc.png")


########################################################################
# Ridge
########################################################################

println("\n=== Ridge Logistic Regression ===")

# Load or define the logistic regression model with an L2 penalty
LogisticRidge = @load LogisticClassifier pkg=MLJLinearModels verbosity=0

# Create an instance with penalty = :l2 (Ridge).   
model_ridge = LogisticRidge(
    penalty = :l2,
    lambda  = 1.0  
)

# Wrap it in a machine together with training data
mach_ridge = machine(model_ridge, X_train, y_train)

# Train the model
fit!(mach_ridge)

# Use the trained model to make predictions on X_test
preds_prob_ridge = predict(mach_ridge, X_test)

# Convert probabilistic predictions to class labels (Up or Down)
yhat_ridge = mode.(preds_prob_ridge)

# Evaluate performance: confusion matrix, accuracy, etc.
cm_ridge = confusion_matrix(y_test, yhat_ridge)
accuracy_ridge = mean(yhat_ridge .== y_test)

println("Confusion Matrix (Ridge):")
println(cm_ridge)
println("Accuracy (Ridge): ", accuracy_ridge)

y_scores_ridge = Int.(yhat_ridge .== "Up")
# ROC
fpr_ridge, tpr_ridge = calcular_roc(y_test_bin, y_scores_ridge)

# AUC
auc_ridge = calcular_auc(fpr_ridge, tpr_ridge)

println("AUC (Ridge): ", auc_ridge)

# Plot

plot(
    fpr_ridge, tpr_ridge,
    label = "Ridge (AUC=$(round(auc_ridge, digits=3)))",
    xlabel = "False Positive Rate",
    ylabel = "True Positive Rate",
    title = "ROC Curve - Ridge Logistic Regression",
    linewidth = 2,
    linecolor = :blue,
    legend = :best
)

# Agregar una línea de referencia (AUC = 0.5)
plot!(
    [0, 1], [0, 1],
    label = "Random Guess (AUC=0.5)",
    linestyle = :dash,
    linecolor = :black
)

# Guardar la figura
savefig("fig/ridge_roc.png")
println("ROC curve saved to fig/ridge_roc.png")


########################################################################
# Elastic Net
########################################################################

println("\n=== Elastic Net Logistic Regression ===")

# Load the LogisticClassifier from MLJLinearModels:
#    If not already loaded, it will download/install automatically.
LogisticENet = @load LogisticClassifier pkg=MLJLinearModels verbosity=0

# Create an instance of LogisticClassifier with penalty = :en.
#    'gamma' controls the blend between L1 (lasso) and L2 (ridge):
#       gamma = 0.0 => pure ridge (L2)
#       gamma = 1.0 => pure lasso (L1)
#       0 < gamma < 1 => elastic net blend
#    'lambda' is the overall regularization strength.
model_enet = LogisticENet(
    penalty = :en,   # :en stands for elastic net
    gamma   = 0.5,   # 50% L1, 50% L2
    lambda  = 0.1    
)

# Wrap the model and training data in a machine:
mach_enet = machine(model_enet, X_train, y_train)

# Fit the model:
fit!(mach_enet)

# Obtain probabilistic predictions on X_test:
preds_prob_enet = predict(mach_enet, X_test)

# Convert these probabilities to predicted classes (Up or Down):
yhat_enet = mode.(preds_prob_enet)

# Evaluate performance using confusion matrix and accuracy:
cm_enet = confusion_matrix(y_test, yhat_enet)
accuracy_enet = mean(yhat_enet .== y_test)

println("Confusion Matrix (Elastic Net):")
println(cm_enet)
println("Accuracy (Elastic Net): ", accuracy_enet)

y_scores_enet = Int.(yhat_enet .== "Up")
# ROC
fpr_enet, tpr_enet = calcular_roc(y_test_bin, y_scores_enet)

# AUC
auc_enet = calcular_auc(fpr_enet, tpr_enet)

println("AUC (Elastic Net): ", auc_enet)

# Plot

plot(
    fpr_enet, tpr_enet,
    label = "Elastic Net (AUC=$(round(auc_enet, digits=3)))",
    xlabel = "False Positive Rate",
    ylabel = "True Positive Rate",
    title = "ROC Curve - Elastic Net Logistic Regression",
    linewidth = 2,
    linecolor = :blue,
    legend = :best
)

# Agregar una línea de referencia (AUC = 0.5)
plot!(
    [0, 1], [0, 1],
    label = "Random Guess (AUC=0.5)",
    linestyle = :dash,
    linecolor = :black
)

# Guardar la figura
savefig("fig/enet_roc.png")
println("ROC curve saved to fig/enet_roc.png")



########################################################################
# Decision Tree
########################################################################

using DecisionTree

println("\n=== Decision Tree Classifier ===")

# Load the DecisionTreeClassifier from the DecisionTree package via MLJ.
TreeModel = @load DecisionTreeClassifier pkg=DecisionTree verbosity=0

# Define the decision tree model:
#    - max_depth = 5 restricts the maximum depth of the tree
#    - min_samples_leaf = 5 sets the minimum number of samples in each leaf
model_tree = TreeModel(
    max_depth = 5,
    min_samples_leaf = 5
    # display_depth = 0  # (optional) controlling how the tree is displayed if needed
)

# Wrap the model and training data in a "machine"
mach_tree = machine(model_tree, X_train, y_train)

# Fit the model
fit!(mach_tree)

# Predict on the test data
#    For classification, predict returns the predicted class labels by default.
yhat_tree = predict(mach_tree, X_test)

# Convert these probabilities to predicted classes (Up or Down):
yhat_tree = mode.(yhat_tree)

# Evaluate performance: confusion matrix and accuracy
cm_tree = confusion_matrix(y_test, yhat_tree)
accuracy_tree = mean(yhat_tree .== y_test)

println("Confusion Matrix (Decision Tree):")
println(cm_tree)
println("Accuracy (Decision Tree): ", accuracy_tree)

y_scores_tree = Int.(yhat_tree .== "Up")
# ROC
fpr_tree, tpr_tree = calcular_roc(y_test_bin, y_scores_tree)

# AUC
auc_tree = calcular_auc(fpr_tree, tpr_tree)

println("AUC (Decision Tree): ", auc_tree)

# Plot

plot(
    fpr_tree, tpr_tree,
    label = "Decision Tree (AUC=$(round(auc_tree, digits=3)))",
    xlabel = "False Positive Rate",
    ylabel = "True Positive Rate",
    title = "ROC Curve - Decision Tree Logistic Regression",
    linewidth = 2,
    linecolor = :blue,
    legend = :best
)

# Agregar una línea de referencia (AUC = 0.5)
plot!(
    [0, 1], [0, 1],
    label = "Random Guess (AUC=0.5)",
    linestyle = :dash,
    linecolor = :black
)

# Guardar la figura
savefig("fig/decisionTree.png")
println("ROC curve saved to fig/decisionTree.png")



########################################################################
# Random Forest
########################################################################

println("\n=== Random Forest Classifier ===")

# Load the RandomForestClassifier from the DecisionTree package via MLJ.
RFModel = @load RandomForestClassifier pkg=DecisionTree verbosity=0

# Define the random forest model:
#    - n_trees = number of decision trees in the forest
#    - max_depth = maximum depth for each tree
#    - min_samples_leaf = minimum number of samples per leaf
model_rf = RFModel(
    n_trees         = 100,  # Example number of trees
    max_depth       = 10,   # Example max depth
    min_samples_leaf = 5    # Example min samples per leaf
)

# Wrap the model and training data in a "machine"
mach_rf = machine(model_rf, X_train, y_train)

# Fit the random forest model
fit!(mach_rf)

# Predict on the test data
#    For classification, `predict` returns the predicted class labels by default.
yhat_rf = predict(mach_rf, X_test)

# Convert these probabilities to predicted classes (Up or Down):
yhat_rf = mode.(yhat_rf)

# Evaluate performance: confusion matrix and accuracy
cm_rf = confusion_matrix(y_test, yhat_rf)
accuracy_rf = mean(yhat_rf .== y_test)

println("Confusion Matrix (Random Forest):")
println(cm_rf)
println("Accuracy (Random Forest): ", accuracy_rf)

y_scores_rf = Int.(yhat_rf .== "Up")
# ROC
fpr_rf, tpr_rf = calcular_roc(y_test_bin, y_scores_rf)

# AUC
auc_rf = calcular_auc(fpr_rf, tpr_rf)

println("AUC (Random Forest): ", auc_rf)

# Plot

plot(
    fpr_rf, tpr_rf,
    label = "Random Forest (AUC=$(round(auc_rf, digits=3)))",
    xlabel = "False Positive Rate",
    ylabel = "True Positive Rate",
    title = "ROC Curve - Random Forest Logistic Regression",
    linewidth = 2,
    linecolor = :blue,
    legend = :best
)

# Agregar una línea de referencia (AUC = 0.5)
plot!(
    [0, 1], [0, 1],
    label = "Random Guess (AUC=0.5)",
    linestyle = :dash,
    linecolor = :black
)

# Guardar la figura
savefig("fig/randomForest.png")
println("ROC curve saved to fig/randomForest.png")


########################################################################
# Nearest Neighbors
########################################################################

using Distances 

# Load the KNNClassifier constructor from NearestNeighborModels into KNN
KNN = @load KNNClassifier pkg=NearestNeighborModels verbosity=0

println("\n=== Nearest Neighbors Classifier ===")

# Define your k-NN model
#    - K = 5 is an example
#    - metric = Distances.Euclidean() is a Distances.Metric object
knn_model = KNN(
    K      = 5,
    metric = Distances.Euclidean()
)

# Create a machine with the model, training features, and labels
mach_knn = machine(knn_model, X_train, y_train)

# Fit (train) the k-NN model
fit!(mach_knn)

# Predict on the test data
yhat_knn = predict(mach_knn, X_test)

# Convert these probabilities to predicted classes (Up or Down):
yhat_knn = mode.(yhat_knn)

# Evaluate performance
cm_knn = confusion_matrix(y_test, yhat_knn)
accuracy_knn = mean(yhat_knn .== y_test)

println("Confusion Matrix (k-NN):")
println(cm_knn)
println("Accuracy (k-NN): ", accuracy_knn)


y_scores_knn = Int.(yhat_knn .== "Up")
# ROC
fpr_knn, tpr_knn = calcular_roc(y_test_bin, y_scores_knn)

# AUC
auc_knn = calcular_auc(fpr_knn, tpr_knn)

println("AUC (Random Forest): ", auc_knn)

# Plot

plot(
    fpr_knn, tpr_knn,
    label = "Nearest Neighbors (AUC=$(round(auc_knn, digits=3)))",
    xlabel = "False Positive Rate",
    ylabel = "True Positive Rate",
    title = "ROC Curve - Nearest Neighbors Logistic Regression",
    linewidth = 2,
    linecolor = :blue,
    legend = :best
)

# Agregar una línea de referencia (AUC = 0.5)
plot!(
    [0, 1], [0, 1],
    label = "Random Guess (AUC=0.5)",
    linestyle = :dash,
    linecolor = :black
)

# Guardar la figura
savefig("fig/nearestNeighbors.png")
println("ROC curve saved to fig/nearestNeighbors.png")

########################################################################
# SVM
########################################################################
using LIBSVM  # Required to use the SVC model from the LIBSVM package

println("\n=== Support Vector Machine (SVM) Classifier ===")

# 1) Load the SVC model from LIBSVM
SVC = @load SVC pkg=LIBSVM verbosity=0

# 2) Define the SVM model with chosen parameters
model_svm = SVC(
    cost   = 1.0,         # Penalty parameter C
    gamma  = 0.0          
)

# 3) Create a machine with the SVM model and training data
mach_svm = machine(model_svm, X_train, y_train)

# 4) Fit (train) the model
fit!(mach_svm)

# 5) Predict on the test set
yhat_svm = predict(mach_svm, X_test)

# 6) Evaluate the model using confusion matrix and accuracy
cm_svm = confusion_matrix(y_test, yhat_svm)
accuracy_svm = mean(yhat_svm .== y_test)

println("Confusion Matrix (SVM):")
println(cm_svm)
println("Accuracy (SVM): ", accuracy_svm)


y_scores_svm = Int.(yhat_svm .== "Up")
# ROC
fpr_svm, tpr_svm = calcular_roc(y_test_bin, y_scores_svm)

# AUC
auc_svm = calcular_auc(fpr_svm, tpr_svm)

println("AUC (Random Forest): ", auc_svm)

# Plot

plot(
    fpr_svm, tpr_svm,
    label = "SVM (AUC=$(round(auc_svm, digits=3)))",
    xlabel = "False Positive Rate",
    ylabel = "True Positive Rate",
    title = "ROC Curve - SVM Logistic Regression",
    linewidth = 2,
    linecolor = :blue,
    legend = :best
)

# Agregar una línea de referencia (AUC = 0.5)
plot!(
    [0, 1], [0, 1],
    label = "Random Guess (AUC=0.5)",
    linestyle = :dash,
    linecolor = :black
)

# Guardar la figura
savefig("fig/svm.png")
println("ROC curve saved to fig/svm.png")