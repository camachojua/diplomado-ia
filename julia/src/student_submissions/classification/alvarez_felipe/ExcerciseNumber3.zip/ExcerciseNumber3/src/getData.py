import requests

def download_smarket_csv(url: str, output_file: str = "dat/Smarket.csv"):
    """
    Descarga el archivo CSV de la URL especificada y lo guarda localmente.
    
    Parameters
    ----------
    url : str
        Dirección web de donde descargar el CSV (Smarket).
    output_file : str
        Nombre de archivo local donde se guardará el CSV.
    """
    print(f"Downloading Smarket data from:\n{url}\n")
    
    response = requests.get(url)
    response.raise_for_status()  # Levanta excepción si ocurre algún error

    with open(output_file, "wb") as f:
        f.write(response.content)
    
    print(f"File saved as: {output_file}")

if __name__ == "__main__":
    # URL de ejemplo donde se encuentra Smarket.csv
    url_smarket = "https://raw.githubusercontent.com/selva86/datasets/master/Smarket.csv"
    
    # Descarga y guarda localmente
    download_smarket_csv(url=url_smarket, output_file="dat/Smarket.csv")
