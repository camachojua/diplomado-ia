# Classification Analysis Report

## **Overview**

This report details the methodology and results of a classification analysis performed on the Stock Market data from Chapter 4 of the *Introduction to Statistical Learning (ISL)* book. The primary objective was to classify stock market directions (`Direction`) using various machine learning algorithms implemented in Julia. The classifiers evaluated include:

- **LASSO Logistic Regression**
- **Ridge Logistic Regression**
- **Elastic Net Logistic Regression**
- **Decision Tree**
- **Random Forest**
- **Nearest Neighbors**
- **Support Vector Machines (SVM)**

The performance of each classifier was assessed using confusion matrices and Receiver Operating Characteristic (ROC) curves to evaluate their accuracy and discriminative ability.

## **Data Preprocessing**

### 1. **Data Acquisition**
The Stock Market dataset (`Smarket.csv`) was loaded using Julia's `CSV` and `DataFrames` packages. An initial inspection of the dataset's dimensions and column names provided a foundational understanding of the data structure.

### 2. **Handling Missing Data**
- **Missing Value Assessment:** Each column was checked for missing values. Rows containing any missing data were removed to ensure data integrity.
  
- **Categorical Encoding:** The target variable `Direction`, indicating stock movement as "Up" or "Down", was converted to a categorical type to facilitate classification tasks.

### 3. **Feature Selection**
- **Feature Columns:** The predictors selected for the analysis included `Lag1`, `Lag2`, `Lag3`, `Lag4`, `Lag5`, and `Volume`. These features represent lagged returns and trading volume, which are relevant for predicting stock movement.
  
- **Target Column:** The target variable was `Direction`.

### 4. **Data Splitting**
The dataset was divided into training and testing subsets using an 80-20 split to evaluate model performance on unseen data. A fixed random seed ensured reproducibility of the results.

### 5. **Label Encoding for Evaluation**
For ROC curve computation, the target labels were binarized, with "Up" encoded as `1` and "Down" as `0`.

## **Classification Analysis**

### 1. **Modeling Approach**
Each classification algorithm was implemented using Julia's machine learning libraries. The models were trained on the training set and evaluated on the testing set. Performance metrics included confusion matrices, accuracy scores, and ROC curves with corresponding Area Under the Curve (AUC) values.

### 2. **Algorithms Implemented**

#### a. **LASSO Logistic Regression**
- **Objective:** Perform logistic regression with L1 regularization to promote sparsity in the model coefficients.
  
- **Implementation:** Utilized `MLJLinearModels` to load and configure the `LogisticClassifier` with an L1 penalty.
  
#### b. **Ridge Logistic Regression**
- **Objective:** Apply logistic regression with L2 regularization to handle multicollinearity and improve model generalization.
  
- **Implementation:** Configured the `LogisticClassifier` with an L2 penalty using `MLJLinearModels`.
  
#### c. **Elastic Net Logistic Regression**
- **Objective:** Combine L1 and L2 regularization to balance sparsity and coefficient shrinkage.
  
- **Implementation:** Set the `penalty` to `:en` with a `gamma` value of 0.5 to equally weigh L1 and L2 penalties.
  
#### d. **Decision Tree**
- **Objective:** Utilize a decision tree classifier to capture non-linear relationships and interactions between features.
  
- **Implementation:** Leveraged the `DecisionTree` package to configure a tree with a maximum depth of 5 and a minimum of 5 samples per leaf.
  
#### e. **Random Forest**
- **Objective:** Employ an ensemble of decision trees to improve classification robustness and reduce overfitting.
  
- **Implementation:** Configured a random forest with 100 trees, each having a maximum depth of 10 and a minimum of 5 samples per leaf.

#### f. **Nearest Neighbors**
- **Objective:** Implement a k-Nearest Neighbors (k-NN) classifier to classify instances based on feature similarity.
  
- **Implementation:** Used the `NearestNeighborModels` package to set up a k-NN model with `K=5` and Euclidean distance metric.
  
#### g. **Support Vector Machines (SVM)**
- **Objective:** Apply an SVM classifier to find the optimal hyperplane that separates classes with maximum margin.
  
- **Implementation:** Utilized the `LIBSVM` package to configure an SVM with a penalty parameter `C=1.0` and default gamma.
  
### 3. **Performance Evaluation**
For each classifier, the following metrics were computed:

- **Confusion Matrix:** Provided a summary of prediction results, indicating the number of correct and incorrect predictions.
  
- **Accuracy:** Calculated the proportion of true results among the total number of cases examined.
  
- **ROC Curve and AUC:** Plotted the ROC curve to visualize the trade-off between true positive rate (TPR) and false positive rate (FPR). The AUC quantified the overall ability of the model to discriminate between classes.

### 4. **Visualization**
ROC curves for each classifier were plotted and saved as PNG files for visual comparison of model performances.

## **Key Findings**

1. **Data Quality Assurance:**
   - Removal of rows with missing values ensured that the models were trained on complete data, enhancing the reliability of the classification results.

2. **Regularization Impact:**
   - **LASSO Logistic Regression:** Achieved a balance between model simplicity and performance by enforcing sparsity in feature coefficients.
   
   - **Ridge Logistic Regression:** Handled multicollinearity effectively, maintaining model stability.
   
   - **Elastic Net Logistic Regression:** Provided a hybrid approach, combining the benefits of both LASSO and Ridge regressions.

3. **Ensemble Methods Superiority:**
   - **Random Forest:** Demonstrated superior performance metrics, benefiting from ensemble averaging and reduced variance.
   
   - **Decision Tree:** While effective, it was slightly outperformed by the Random Forest in terms of accuracy and AUC.

4. **Instance-Based Learning:**
   - **Nearest Neighbors:** Offered competitive accuracy but was sensitive to the choice of `K` and the distance metric.
   
   - **Support Vector Machines (SVM):** Provided robust classification performance, especially in high-dimensional feature spaces.

5. **Performance Metrics Correlation:**
   - High accuracy often correlated with higher AUC values, indicating that models not only predicted correctly but also effectively discriminated between classes.

6. **ROC Curve Insights:**
   - Models with ROC curves closer to the top-left corner indicated better discriminative abilities.
   
   - The AUC values ranged from moderate to high, reflecting the varying effectiveness of the classifiers.

## **Conclusion**

The classification analysis on the Stock Market dataset successfully identified the most effective algorithms for predicting stock movement directions. Ensemble methods, particularly Random Forest, emerged as top performers, offering high accuracy and superior discriminative capabilities as evidenced by AUC scores. Regularized logistic regression models (LASSO, Ridge, Elastic Net) provided robust alternatives, balancing feature selection and model complexity.

Instance-based and margin-based classifiers, such as Nearest Neighbors and SVM, also demonstrated commendable performance, highlighting their applicability in financial prediction tasks. The comprehensive evaluation using confusion matrices and ROC curves ensured a thorough assessment of each model's strengths and limitations.

This analysis lays a strong foundation for deploying these classifiers in real-world stock market prediction scenarios, enabling informed decision-making and strategic planning based on predictive insights.

---

**Note:** The ROC curves and confusion matrices generated from this analysis are saved in the `fig/` directory for reference and further exploration.
