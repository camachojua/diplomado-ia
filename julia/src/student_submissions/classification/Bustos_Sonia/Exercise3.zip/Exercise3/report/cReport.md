# Comparación de Algoritmos de Clasificación

## Introducción
El objetivo principal es evaluar la precisión de varios algoritmos de clasificación mediante el uso de matrices de confusión y curvas ROC. Para ello, se han implementado los siguientes modelos de clasificación: LASSO, Ridge, Elastic Net, Decision Tree, Random Forest, Nearest Neighbors(KNN) y Support Vector Machines (SVM).

Utilizaremos un conjunto de datos "Stock Market" del Capítulo 4 del libro ISL para entrenar y probar cada uno de estos modelos. Las visualizaciones de las matrices de confusión y las curvas ROC se proporcionarán para facilitar una mejor comprensión de la efectividad de cada algoritmo. Nuestro objetivo es identificar cuál de estos modelos ofrece el mejor rendimiento en términos de precisión y capacidad de clasificación.

---
## Carga de Librerías
``` julia
using CSV, MLJ, DataFrames, StatsBase, Plots, Random, DataStructures, ROCAnalysis,
using GLMNet, MLBase, DecisionTree, NearestNeighbors, LinearAlgebra, LIBSVM
```	
- **`CSV`**: Para la lectura y manipulación de archivos CSV.
- **`MLJ`**: Framework para machine learning en Julia.
- **`DataFrames`**: Manipulación de datos tabulares.
- **`StatsBase`**: Cálculo de estadísticas descriptivas.
- **`Plots`**: Visualización de datos.
- **`Random`**: Generación de números aleatorios.
- **`LinearAlgebra`**: Proporciona herramientas para álgebra lineal.
- **`ROCAnalysis`**: Análisis de curvas ROC para evaluar modelos de clasificación.
- **`GLMNet`**, **`MLBase`**, **`DecisionTree`**, **`NearestNeighbors`**, **`LIBSVM`**: Conjunto de bibliotecas para entrenar y evaluar modelos de machine learning como regresión, árboles de decisión y máquinas de soporte vectorial.

---
## Cargamos los datos

``` julia
Smarket_path = joinpath("..", "dat", "Smarket.csv")
Smarket_df = CSV.read(Smarket_path, DataFrame)
``` 


El DataFrame tiene **1250 filas** y **9 columnas**.


Se mostrarán las **primeras 13** y las **últimas 13** filas debido a la cantidad de filas.
| **Year**<br>`Int64` | **Lag1**<br>`Float64` | **Lag2**<br>`Float64` | **Lag3**<br>`Float64` | **Lag4**<br>`Float64` | **Lag5**<br>`Float64` | **Volume**<br>`Float64` | **Today**<br>`Float64` | **Direction**<br>`InlineStrings.String7` |
|--------------------:|----------------------:|----------------------:|----------------------:|----------------------:|----------------------:|------------------------:|-----------------------:|-----------------------------------------:|
| 2001                | 0.381                 | -0.192                | -2.624                | -1.055                | 5.01                  | 1.1913                  | 0.959                  | Up                                       |
| 2001                | 0.959                 | 0.381                 | -0.192                | -2.624                | -1.055                | 1.2965                  | 1.032                  | Up                                       |
| 2001                | 1.032                 | 0.959                 | 0.381                 | -0.192                | -2.624                | 1.4112                  | -0.623                 | Down                                     |
| 2001                | -0.623                | 1.032                 | 0.959                 | 0.381                 | -0.192                | 1.276                   | 0.614                  | Up                                       |
| 2001                | 0.614                 | -0.623                | 1.032                 | 0.959                 | 0.381                 | 1.2057                  | 0.213                  | Up                                       |
| 2001                | 0.213                 | 0.614                 | -0.623                | 1.032                 | 0.959                 | 1.3491                  | 1.392                  | Up                                       |
| 2001                | 1.392                 | 0.213                 | 0.614                 | -0.623                | 1.032                 | 1.445                   | -0.403                 | Down                                     |
| 2001                | -0.403                | 1.392                 | 0.213                 | 0.614                 | -0.623                | 1.4078                  | 0.027                  | Up                                       |
| 2001                | 0.027                 | -0.403                | 1.392                 | 0.213                 | 0.614                 | 1.164                   | 1.303                  | Up                                       |
| 2001                | 1.303                 | 0.027                 | -0.403                | 1.392                 | 0.213                 | 1.2326                  | 0.287                  | Up                                       |
| 2001                | 0.287                 | 1.303                 | 0.027                 | -0.403                | 1.392                 | 1.309                   | -0.498                 | Down                                     |
| 2001                | -0.498                | 0.287                 | 1.303                 | 0.027                 | -0.403                | 1.258                   | -0.189                 | Down                                     |
| 2001                | -0.189                | -0.498                | 0.287                 | 1.303                 | 0.027                 | 1.098                   | 0.68                   | Up                                       |
⁝|⁝|⁝|⁝|⁝|⁝|⁝|⁝|⁝|
| 2005                | 0.084                 | 0.281                 | -0.122                | -0.501                | 0.128                 | 1.87655                 | 0.555                  | Up                                       |
| 2005                | 0.555                 | 0.084                 | 0.281                 | -0.122                | -0.501                | 2.39002                 | 0.419                  | Up                                       |
| 2005                | 0.419                 | 0.555                 | 0.084                 | 0.281                 | -0.122                | 2.14552                 | -0.141                 | Down                                     |
| 2005                | -0.141                | 0.419                 | 0.555                 | 0.084                 | 0.281                 | 2.18059                 | -0.285                 | Down                                     |
| 2005                | -0.285                | -0.141                | 0.419                 | 0.555                 | 0.084                 | 2.58419                 | -0.584                 | Down                                     |
| 2005                | -0.584                | -0.285                | -0.141                | 0.419                 | 0.555                 | 2.20881                 | -0.024                 | Down                                     |
| 2005                | -0.024                | -0.584                | -0.285                | -0.141                | 0.419                 | 1.99669                 | 0.252                  | Up                                       |
| 2005                | 0.252                 | -0.024                | -0.584                | -0.285                | -0.141                | 2.06517                 | 0.422                  | Up                                       |
| 2005                | 0.422                 | 0.252                 | -0.024                | -0.584                | -0.285                | 1.8885                  | 0.043                  | Up                                       |
| 2005                | 0.043                 | 0.422                 | 0.252                 | -0.024                | -0.584                | 1.28581                 | -0.955                 | Down                                     |
| 2005                | -0.955                | 0.043                 | 0.422                 | 0.252                 | -0.024                | 1.54047                 | 0.13                   | Up                                       |
| 2005                | 0.13                  | -0.955                | 0.043                 | 0.422                 | 0.252                 | 1.42236                 | -0.298                 | Down                                     |
| 2005                | -0.298                | 0.13                  | -0.955                | 0.043                 | 0.422                 | 1.38254                 | -0.489                 | Down                                     |


### Descripción del dataset
``` julia
des_Smarket = describe(Smarket_df)
size(Smarket_df) # (1250,9)
``` 

| **variable**<br>`Symbol` | **mean**<br>`U{Nothing, Float64}` | **min**<br>`Any` | **median**<br>`U{Nothing, Float64}` | **max**<br>`Any` | **nmissing**<br>`Int64` | **eltype**<br>`DataType` |
|-------------------------:|----------------------------------:|-----------------:|------------------------------------:|-----------------:|------------------------:|-------------------------:|
| Year                     | 2003.02                           | 2001             | 2003.0                              | 2005             | 0                       | Int64                    |
| Lag1                     | 0.0038344                         | -4.922           | 0.039                               | 5.733            | 0                       | Float64                  |
| Lag2                     | 0.0039192                         | -4.922           | 0.039                               | 5.733            | 0                       | Float64                  |
| Lag3                     | 0.001716                          | -4.922           | 0.0385                              | 5.733            | 0                       | Float64                  |
| Lag4                     | 0.001636                          | -4.922           | 0.0385                              | 5.733            | 0                       | Float64                  |
| Lag5                     | 0.0056096                         | -4.922           | 0.0385                              | 5.733            | 0                       | Float64                  |
| Volume                   | 1.4783                            | 0.35607          | 1.42295                             | 3.15247          | 0                       | Float64                  |
| Today                    | 0.0031384                         | -4.922           | 0.0385                              | 5.733            | 0                       | Float64                  |
| Direction                | nothing                           | Down             | nothing                             | Up               | 0                       | String7                  |

---
## División en Conjunto de Entrenamiento y Prueba
### Definir Variables Predictoras y Objetivo
La columna objetivo es `Direction` (y), y las variables predictoras (X) son todas las demás excepto `Direction`.

``` julia
# Variable objetivo
# Columna 'Direction' como variable objetivo
y = Smarket_df.Direction

# Variables predictoras (excluye 'Direction')
# Todas las columnas excepto 'Direction' como predictoras
X = select(Smarket_df, Not(:Direction)) 
```

#### Convertir `X` a una matriz y codificar `y` a valores numéricos

``` julia
# Convertir las variables predictoras a matriz.
X_matrix = Matrix(X)  

# Crear un mapeo para las etiquetas de la variable objetivo.
labels_map = labelmap(y)

# Codificar las etiquetas como números.
y_encoded = labelencode(labels_map, y)  
```
`labels_map` = LabelMap (with 2 labels):
<p style="margin-left: 100px;">[1] Up </p>
<p style="margin-left: 100px;">[2] Down</p>

### División del DataFrame
Dividir los datos en un 80% de entrenamiento y 20% de prueba.

Función para calcular la precisión de las predicciones de un modelo.

``` julia
function perclass_splits(y, at)
    uids = unique(y)
    keepids = []

    for ui in uids
        curids = findall(y .== ui)
        rowids = randsubseq(curids, at)
        push!(keepids, rowids...)
    end
    return keepids
end
```
**Parámetros:**
 - y: Vector con las etiquetas codificadas de la variable objetivo.

 - at: Proporción de datos a incluir en el conjunto de entrenamiento (por clase).

**Retorna:**
- Vector con los índices de las filas seleccionadas para el conjunto de entrenamiento.


#### Dividir datos
La función `perclass_splits` divide los datos respetando la proporción entre clases.

``` julia
train_ids = perclass_splits(y_encoded, 0.8) 

test_ids = setdiff(1:length(y_encoded), train_ids)
```
En `train_ids` el 0.8 representa la proporción de datos de entrenamiento.

`setdiff` se usa para garantizar que los índices restantes formen el conjunto de prueba.


**Validación de proporciones de clases en los conjuntos**

```julia
println("Proporciones en el conjunto de entrenamiento:")
println(countmap(y_encoded[train_ids]))

println("Proporciones en el conjunto de prueba:")
println(countmap(y_encoded[test_ids]))
```

Proporciones en el conjunto de entrenamiento:
Dict(2 => 486, 1 => 526)
Proporciones en el conjunto de prueba:
Dict(2 => 116, 1 => 122)

>Dado que el proceso de división en conjuntos de entrenamiento y prueba utiliza generación aleatoria, los resultados pueden variar ligeramente entre ejecuciones. 
>Esto afecta métricas como `accuracy`, `recall` y `precision`, aunque estas variaciones suelen ser menores (décimas o centésimas).
---
#### Evaluar precisión de algoritmos (`findaccuracy`)

Función para calcular la precisión de las predicciones de un modelo.

``` julia
function findaccuracy(predictions, groundtruthvals)
	# Cuenta cuántas predicciones son correctas
    correct = sum(predictions .== groundtruthvals) 
	
	# Divide entre el total de observaciones
    accuracy = correct / length(groundtruthvals) 

	# Devuelve el valor de precisión
    return accuracy                       
end
```

**Parámetros:**
 - predictions: Vector con las predicciones del modelo.

 - groundtruthvals: Vector con los valores reales de la variable objetivo.

**Retorna:**
 - accuracy: Proporción de predicciones correctas (número entre 0 y 1).

---
## Algoritmos
> Métodos de regularización
Utilizaremos las siguientes técnicas de regularización, seleccionando una técnica regulada por el parámetro alpha dado a glmnet(_args):
> - Lasso: alfa = 1
> - Ridge: alfa = 0
> - Elastic Net: 0 < alfa < 1
### LASSO (Least Absolute Shrinkage Selection Operator)
#### Entrenar el modelo


``` julia
begin
	path_lasso = glmnet(X_matrix[train_ids, :], y_encoded[train_ids])
	
	# Va a buscar el mejor alpha para hacer la proyección.
	cv_lasso = glmnetcv(X_matrix[train_ids, :], y_encoded[train_ids]) 
	
	lambda_lasso = path_lasso.lambda[argmin(cv_lasso.meanloss)]
	
	path_lasso = glmnet(X_matrix[train_ids, :], y_encoded[train_ids], lambda=[lambda_lasso])
end
```
||df  | pct_dev      |    $$\lambda$$|
|-------------------------:|-------------------------:|-------------------------:|-------------------------:|
[1]  | 7 | 0.551364 | 0.00465059|

`lambda` controla la intensidad de regularización: valores altos fuerzan coeficientes más pequeños, mientras que valores bajos permiten mayor flexibilidad.

`cv_lasso.meanloss` mide la pérdida promedio durante la validación cruzada, y seleccionamos el valor de `lambda` que minimiza esta pérdida.

#### Realizar predicciones

``` julia
begin
	q_lasso = X_matrix[test_ids, :]  # Variables predictoras para los datos de prueba
	probabilities_lasso = GLMNet.predict(path_lasso, q_lasso)
	
    # Asignar clases a predicciones continuas
	assign_class(predicted_value) = argmin(abs.(predicted_value .- [1, 2]))
	
	predictions_lasso = assign_class.(probabilities_lasso)
end
```

`assign_class`: Ajustada para asignar etiquetas codificadas correctamente. Toma predicciones continuas y las asigna a la clase más cercana (1 o 2). 

#### Evaluar el modelo
``` julia
accuracy_lasso = findaccuracy(predictions_lasso, y_encoded[test_ids])
```

---
### Ridge Regression
Usaremos la funcion `findaccuracy` con alpha = 0.
#### Entrenar el modelo

``` julia
# Elegimos la mejor lambda con la cual predecir. 
begin
	path_ridge = glmnet(X_matrix[train_ids, :], y_encoded[train_ids], alpha = 0); 
	cv_ridge = glmnetcv(X_matrix[train_ids, :], y_encoded[train_ids], alpha = 0)
	
	lambda_ridge = path_ridge.lambda[argmin(cv_ridge.meanloss)]
	
	path_ridge = glmnet(X_matrix[train_ids, :], y_encoded[train_ids], alpha = 0, lambda =[lambda_ridge]);
end 
```
||df  | pct_dev      |    $$\lambda$$|
|-------------------------:|-------------------------:|-------------------------:|-------------------------:|
[1]  | 8 | 0.549649 | 0.0368551|

#### Realizar predicciones

``` julia
begin
	q_ridge = X_matrix[test_ids,:];
	
	probabilities_ridge = GLMNet.predict(path_ridge,q_ridge)
	
	predictions_ridge = assign_class.(probabilities_ridge) 
end
```

#### Evaluar el modelo
``` julia
accuracy_ridge = findaccuracy(predictions_ridge, y_encoded[test_ids])
```
---
###  Elastic Net Regularization 
Usaremos la funcion `findaccuracy` con alpha = 0.5.
#### Entrenar el modelo


``` julia
# Elegimos la mejor lambda con la cual predecir. 
begin
	path_elastic_net = glmnet(X_matrix[train_ids, :], y_encoded[train_ids], alpha = 0.5); 
	cv_elastic_net = glmnetcv(X_matrix[train_ids, :], y_encoded[train_ids], alpha = 0.5)
	
	lambda_elastic_net = path_elastic_net.lambda[argmin(cv_elastic_net.meanloss)]
	
	path_elastic_net = glmnet(X_matrix[train_ids, :], y_encoded[train_ids], alpha = 0.5, lambda = [lambda_elastic_net]);
end 
```
||df  | pct_dev      |    $$\lambda$$|
|-------------------------:|-------------------------:|-------------------------:|-------------------------:|
[1]  |  6  | 0.550589 | 0.0122956|

#### Realizar predicciones

``` julia
begin
	q_elastic_net = X_matrix[test_ids,:];
	
	probabilities_elastic_net = GLMNet.predict(path_elastic_net,q_elastic_net)
	
	predictions_elastic_net = assign_class.(probabilities_elastic_net) 
end
```
#### Evaluar el modelo
``` julia
accuracy_elastic_net = findaccuracy(predictions_elastic_net, y_encoded[test_ids])
```
---
###  Decision Tree
#### Entrenar el modelo

`max_depth` limita la profundidad del árbol para evitar el sobreajuste.
En este caso, se fija en 2 para crear un modelo sencillo que generalice mejor.

``` julia
begin
	model_DT = DecisionTreeClassifier(max_depth = 2)
	DecisionTree.fit!(model_DT, X_matrix[train_ids,:], y_encoded[train_ids])
end
```
<small>
DecisionTreeClassifier
<div style="display: flex; justify-content: space-between;">
  <div style="text-align: left;
  ">max_depth:</div>
  <div style="text-align: right;">2</div>
</div>

<div style="display: flex; justify-content: space-between;">
  <div style="text-align: left;">min_samples_leaf:</div>
  <div style="text-align: right;">1</div>
</div>

<div style="display: flex; justify-content: space-between;">
  <div style="text-align: left;">min_samples_split:</div>
  <div style="text-align: right;">2</div>
</div>
<div style="display: flex; justify-content: space-between;">
  <div style="text-align: left;">min_purity_increase:</div>
  <div style="text-align: right;">0.0</div>
</div>
<div style="display: flex; justify-content: space-between;">
  <div style="text-align: left;">pruning_purity_threshold:</div>
  <div style="text-align: right;">1.0</div>
</div>
<div style="display: flex; justify-content: space-between;">
  <div style="text-align: left;">n_subfeatures:</div>
  <div style="text-align: right;">0</div>
</div>
<div style="display: flex; justify-content: space-between;">
  <div style="text-align: left;">classes:</div>
  <div style="text-align: right;">[1, 2]</div>
</div>
<div style="display: flex; justify-content: space-between;">
  <div style="text-align: left;">root:</div>
  <div style="text-align: right;">Decision Tree</div>
</div>
<div style="display: flex; justify-content: space-between;">
</div>
Leaves: 2

Depth: 1
</small>

#### Realizar predicciones
``` julia
begin
	q_DT = X_matrix[test_ids,:]
	predictions_DT = DecisionTree.predict(model_DT,q_DT)
end
```

#### Evaluar el modelo
``` julia
accuracy_DT = findaccuracy(predictions_DT, y_encoded[test_ids])
```
---
### Random Forest
El `RandomForestClassifier` se encuenta en la paqueteria `DecisionTrree`.
#### Entrenar el modelo

`n_trees` controla el número de árboles. Un mayor número de árboles generalmente mejora la estabilidad del modelo, aunque también aumenta el tiempo de entrenamiento.
Aquí se utiliza 20 como un compromiso entre precisión y eficiencia.

``` julia
begin
	model_RF= RandomForestClassifier(n_trees = 20)
	DecisionTree.fit!(model_RF , X_matrix[train_ids,:], y_encoded[train_ids])
end
```
<small>
RandomForestClassifier
<div style="display: flex; justify-content: space-between;">
  <div style="text-align: left;">n_trees:</div>
  <div style="text-align: right;">20</div>
</div>
<div style="display: flex; justify-content: space-between;">
  <div style="text-align: left;">n_subfeatures:</div>
  <div style="text-align: right;">-1</div>
</div>
<div style="display: flex; justify-content: space-between;">
  <div style="text-align: left;">partial_sampling:</div>
  <div style="text-align: right;">0.7</div>
</div>
<div style="display: flex; justify-content: space-between;">
  <div style="text-align: left;">max_depth:</div>
  <div style="text-align: right;">-1</div>
</div>
<div style="display: flex; justify-content: space-between;">
  <div style="text-align: left;">min_samples_leaf:</div>
  <div style="text-align: right;">1</div>
</div>
<div style="display: flex; justify-content: space-between;">
  <div style="text-align: left;">min_samples_split:</div>
  <div style="text-align: right;">2</div>
</div>
<div style="display: flex; justify-content: space-between;">
  <div style="text-align: left;">min_purity_increase:</div>
  <div style="text-align: right;">0.0</div>
</div>
<div style="display: flex; justify-content: space-between;">
  <div style="text-align: left;">classes:</div>
  <div style="text-align: right;">[1, 2]</div>
</div>
<div style="display: flex; justify-content: space-between;">
  <div style="text-align: left;">ensemble:</div>
  <div style="text-align: right;">Ensemble of Decision Trees</div>
</div>
<div style="display: flex; justify-content: space-between;">
</div>

Trees: 20
Avg Leaves: 9.9
Avg Depth: 4.1
</small>


`partial_sampling=0.7` indica que cada árbol utiliza un subconjunto del 70% de los datos para entrenarse.
#### Realizar predicciones
``` julia
begin
	q_RF = X_matrix[test_ids,:]
	predictions_RF = DecisionTree.predict(model_RF,q_RF)
end
```
#### Evaluar el modelo
``` julia
accuracy_RF = findaccuracy(predictions_RF, y_encoded[test_ids])
```
---
### Nearest Neighbors
#### Entrenar el modelo

KDTree se utiliza para organizar los datos de entrenamiento en una estructura de datos que permite búsquedas eficientes de los vecinos más cercanos. 

``` julia
begin
	Xtrain_nn = X_matrix[train_ids,:]
	ytrain_nn = y_encoded[train_ids]
	kdtree = KDTree(Xtrain_nn')
end
```
> `Xtrain_nn'` La transposición (') es necesaria porque KDTree espera que los puntos estén representados como columnas en lugar de filas.

<small>
KDTree{StaticArraysCore.SVector{8, Float64}, Euclidean, Float64, StaticArraysCore.SVector{8, Float64}}
  
  Number of points: 1012
  Dimensions: 8
  Metric: Euclidean(0.0)
  Reordered: true
  </small>

#### Realizar predicciones

``` julia
queries = X_matrix[test_ids,:]

idxs, dists = knn(kdtree,queries', 5, true)

begin
	c = ytrain_nn[hcat(idxs...)]

	# Cuenta cuántas veces aparece cada etiqueta entre los 5 vecinos.
	possible_labels = map(i->counter(c[:,i]),1:size(c,2))
end

predictions_nn = map(i->parse(Int,string(string(argmax(possible_labels[i])))),1:size(c,2))
```


**Parámetros en knn:**
* `kdtree`: La estructura KDTree construida con los datos de entrenamiento (`Xtrain_nn'`).
* `queries'`: Las consultas (puntos de prueba) a las que queremos buscar sus vecinos más cercanos. 
* `5`: Es el número de vecinos más cercanos a buscar para cada punto en queries. Esto significa que el algoritmo devolverá los 5 puntos más cercanos del conjunto de entrenamiento (`Xtrain_nn'`) para cada punto del conjunto de prueba.
* `true`: Indica que también se devolverán las distancias (además de los índices) de los vecinos más cercanos.

**Salida en knn:**
* `idxs`: Índices de los 5 vecinos más cercanos para cada punto en queries.
* `dists`: Distancias correspondientes a esos 5 vecinos.

**Recopilar etiquetas:**
* `c`: Usando los índices (`idxs`), se extraen las etiquetas (`ytrain_nn`) de los 5 vecinos más cercanos.

**Asignar clase:**
* `argmax(possible_labels[i])`: La etiqueta más común entre los 5 vecinos se selecciona como la predicción para el punto de prueba actual.



#### Evaluar el modelo
``` julia
accuracy_nn = findaccuracy(predictions_nn, y_encoded[test_ids])
```
---
### Support Vector Machines (SVM)
Se usará la paqueteria `LIBSVM`.
#### Entrenar el modelo
``` julia
begin
	Xtrain_SVM = X_matrix[train_ids,:]
	ytrain_SVM = y_encoded[train_ids]
	model_SVM = svmtrain(Xtrain_SVM', ytrain_SVM)
end
```
<small>
LIBSVM.SVM{Int64,LIBSVM.Kernel.KERNEL}(

SVMtype = SVC
Kernel = RadialBasis::KERNEL = 2
weights = nothing
nfeatures = 8
ntrain = 1012
nclasses = 2
labels = [1, 2]
libsvmlabel = [1, 2]
libsvmweight = []
libsvmweightlabel = []
)

</small>

#### Realizar predicciones
``` julia
predictions_SVM, decision_values = svmpredict(model_SVM, X_matrix[test_ids,:]') 
```

#### Evaluar el modelo
``` julia
accuracy_SVM = findaccuracy(predictions_SVM, y_encoded[test_ids])
```
---

## Resultados de los Modelos
``` julia
begin
	overall_accuracies = zeros(7)
	algorithms = ["LASSO","RIDGE","ELASTIC NET", "DECISION TREE", "RANDOM FOREST", "NEAREST NEIGHBORS", "SVM"]
	ytest = y_encoded[test_ids]
end

begin
	overall_accuracies[1] = accuracy_lasso
	overall_accuracies[2] = accuracy_ridge
	overall_accuracies[3] = accuracy_elastic_net
	overall_accuracies[4] = accuracy_DT
	overall_accuracies[5] = accuracy_RF
	overall_accuracies[6] = accuracy_nn
	overall_accuracies[7] = accuracy_SVM
end

hcat(algorithms, overall_accuracies) 
```

| **Algorithms** | **Accuracy** |
|------------------:|-----------:|
| LASSO             | 0.983193   |
| RIDGE             | 0.97479   |
| ELASTIC NET       | 0.983193   |
| DECISION TREE     | 1.0        |
| RANDOM FOREST     | 1.0        |
| NEAREST NEIGHBORS | 0.87395   |
| SVM               | 0.962185   |
---

## Matriz de Confusión
La matriz de confusión es una herramienta clave para evaluar el rendimiento de un modelo de clasificación. Es una tabla que describe el desempeño del modelo al comparar las predicciones con los valores reales. En una matriz de confusión binaria, las filas representan las instancias reales (clases verdaderas) y las columnas representan las instancias predichas por el modelo.

> Convertimos las predicciones a vectores para asegurar compatibilidad con las métricas de evaluación.
``` julia
begin
	predictions_lasso_vector = vec(predictions_lasso)
	predictions_ridge_vector = vec(predictions_ridge)
	predictions_EN_vector = vec(predictions_elastic_net)
	predictions_DT_vector = vec(predictions_DT)
	predictions_RF_vector = vec(predictions_RF)
	predictions_nn_vector = vec(predictions_nn)
	predictions_SVM_vector = vec(predictions_SVM)
end
```


Obtenemos la matriz de confusión de cada algoritmo.
```julia
begin
	cm_lasso = confusmat(2, y_encoded[test_ids], predictions_lasso_vector) 
	cm_ridge = confusmat(2, y_encoded[test_ids], predictions_ridge_vector) 
	cm_EN = confusmat(2, y_encoded[test_ids], predictions_EN_vector) 
	cm_DT = confusmat(2, y_encoded[test_ids], predictions_DT_vector) 
	cm_RF = confusmat(2, y_encoded[test_ids], predictions_RF_vector) 
	cm_nn = confusmat(2, y_encoded[test_ids], predictions_nn_vector) 
	cm_SVM = confusmat(2, y_encoded[test_ids], predictions_SVM_vector) 
end
```

```julia
println("Matriz de Confusión\n\n- LASSO:", cm_lasso,
	"\n\n- RIDGE:",cm_ridge,"\n\n- ELASTIC NET:",cm_EN,"\n\n- DECISION TREE:",cm_DT,
	"\n\n- RANDOM FOREST:",cm_EN,"\n\n- NEAREST NEIGHBORS:",cm_nn,
	"\n\n- SVM:",cm_SVM)
```
**Matriz de Confusión**

- LASSO: 
$$\begin{bmatrix}
120 & 2 \\
2 & 114
\end{bmatrix}$$


- RIDGE:
$$\begin{bmatrix}
118 & 4 \\
2 & 114
\end{bmatrix}$$

- ELASTIC NET: 
$$\begin{bmatrix}
120 & 2 \\
2 & 114
\end{bmatrix}$$

- DECISION TREE: 
$$\begin{bmatrix}
122 & 0 \\
0 & 116
\end{bmatrix}$$

- RANDOM FOREST:
$$\begin{bmatrix}
122 & 0 \\
0 & 116
\end{bmatrix}$$

- NEAREST NEIGHBORS: 
$$\begin{bmatrix}
102 & 20 \\
10 & 106
\end{bmatrix}$$

- SVM: 
$$\begin{bmatrix}
116 & 6 \\
3 & 113
\end{bmatrix}$$

1. **LASSO, Ridge y Elastic Net:**  
   - Estos modelos presentan una distribución equilibrada entre verdaderos positivos y verdaderos negativos. Sin embargo, muestran algunos falsos negativos, lo que implica que no identificaron correctamente ciertas instancias positivas.
   - Esto podría significar que hay un leve sesgo hacia la clase negativa.

2. **Decision Tree y Random Forest:**  
   - Estos modelos no presentan errores (ni falsos positivos ni falsos negativos), lo que sugiere sobreajuste. 


3. **Nearest Neighbors:**  
   - Este modelo tiene más falsos positivos y falsos negativos comparado con los demás. Esto sugiere que su capacidad para distinguir entre clases es limitada, posiblemente debido a la elección de número de vecinos.

4. **SVM:**  
   - Tiene menos errores que Nearest Neighbors, pero más que los modelos regularizados. Esto indica que está funcionando bien.

### Normalizar por clase 
``` julia
function normalize(cm)
	# Calcula la suma de cada fila de la matriz.
    row_sums = sum(cm, dims=2)

	# Si todas las filas tienen suma mayor a cero (all(row_sums .> 0)), se devuelve la matriz normalizada.
    # Si no, devuelve una matriz de ceros del mismo tamaño que la original.
    return all(row_sums .> 0) ? cm ./ row_sums : fill(0, size(cm))
end
```
- `row_sums = sum(cm, dims=2)`: Calcula la suma de cada fila de la matriz. La opción `dims=2` indica que el cálculo se realiza a lo largo de las filas.

- `all(row_sums .> 0)`: Verifica si todas las filas tienen una suma mayor que cero. Esto asegura que no haya divisiones por cero. 
	> <small>Algo que puede ocurrir si una clase no tiene predicciones</small>

- `cm ./ row_sums`: Realiza la normalización dividiendo cada elemento de la matriz por la suma de su respectiva fila.

- `fill(0, size(cm))`: Si alguna fila tiene una suma igual a cero, devuelve una matriz llena de ceros con las mismas dimensiones que `cm`.




``` julia
begin
	cm_normalized_lasso = normalize(cm_lasso)
	cm_normalized_ridge = normalize(cm_ridge)
	cm_normalized_EN = normalize(cm_EN)
	cm_normalized_DT = normalize(cm_DT)
	cm_normalized_RF = normalize(cm_RF)
	cm_normalized_nn = normalize(cm_nn)
	cm_normalized_SVM = normalize(cm_SVM)
end
``` 
``` julia
println("Matriz Normalizada\n\n- LASSO:", cm_normalized_lasso,
	"\n\n- RIDGE:",cm_normalized_ridge,"\n\n- ELASTIC NET:",cm_normalized_EN,"\n\n- DECISION TREE:",cm_normalized_DT,
	"\n\n- RANDOM FOREST:",cm_normalized_EN,"\n\n- NEAREST NEIGHBORS:",cm_normalized_nn,
	"\n\n- SVM:",cm_normalized_SVM)
```

**Matriz Normalizada**
- LASSO: 
$$\begin{bmatrix}
0.9836065573770492 & 0.01639344262295082 \\
0.017241379310344827 & 0.9827586206896551
\end{bmatrix}$$


- RIDGE:
$$\begin{bmatrix}
0.9672131147540983 & 0.03278688524590164 \\
0.017241379310344827 & 0.9827586206896551
\end{bmatrix}$$

- ELASTIC NET: $$\begin{bmatrix}
0.9836065573770492 & 0.01639344262295082 \\
0.017241379310344827 & 0.9827586206896551
\end{bmatrix}$$

- DECISION TREE: 
$$\begin{bmatrix}
1.0 & 0.0 \\
0.0 & 1.0
\end{bmatrix}$$

- RANDOM FOREST:
$$\begin{bmatrix}
1.0 & 0.0 \\
0.0 & 1.0
\end{bmatrix}$$

- NEAREST NEIGHBORS: 
$$\begin{bmatrix}
0.8360655737704918 & 0.16393442622950818 \\
0.08620689655172414 & 0.9137931034482759
\end{bmatrix}$$

- SVM: 
$$\begin{bmatrix}
0.9508196721311475 & 0.04918032786885246 \\
0.02586206896551724 & 0.9741379310344828
\end{bmatrix}$$

> En una matriz normalizada, los valores en las filas indican las proporciones de instancias reales correctamente clasificadas (valores diagonales) o incorrectamente clasificadas (valores fuera de la diagonal).

#### Comparación entre Modelos
* Métodos de regularización (LASSO, Ridge, Elastic Net):

	- Rendimiento consistente con valores altos en la diagonal (≥ 0.96).
	- Ridge muestra una ligera caída en la precisión para la clase "Up" (0.967 frente a 0.983 en LASSO y Elastic Net).

* Modelos basados en árboles (Decision Tree, Random Forest):

	- Desempeño perfecto en la matriz proporcionada. Esto podría indicar sobreajuste, especialmente en datos pequeños o si no se regulariza adecuadamente.

* Nearest Neighbors: Menor rendimiento relativo con una proporción significativa de errores. 

* SVM: Alto rendimiento, con proporciones de clasificación correcta muy cercanas a los modelos lineales.
---
## ROC Curve y métricas asociadas 
La **curva ROC** es una representación gráfica que muestra la capacidad de un modelo de clasificación para discriminar entre clases. En ella se grafican la **Tasa de Verdaderos Positivos (True Positive Rate)** frente a la Tasa de Falsos Positivos **(False Positive Rate)**.


Función para calcular las métricas ROC.
``` julia
function calculate_ROC_metrics(y_true, y_pred_vector)
    ROC = MLBase.roc(y_true, y_pred_vector)
    return (ROC, MLBase.recall(ROC), MLBase.precision(ROC))
end
```
La función calcula:
 - ROC: Puntos para construir la curva ROC.
 - Recall: Proporción de instancias positivas correctamente clasificadas.
 - Precision: Proporción de predicciones positivas correctas.


Aplicamos a cada algoritmo.
``` julia
begin
	ROC_lasso, recall_lasso, precision_lasso = calculate_ROC_metrics(y_encoded[test_ids], predictions_lasso_vector)
	
	ROC_ridge, recall_ridge, precision_ridge = calculate_ROC_metrics(y_encoded[test_ids], predictions_ridge_vector)
	
	ROC_EN, recall_EN, precision_EN = calculate_ROC_metrics(y_encoded[test_ids], predictions_EN_vector)
	
	ROC_DT, recall_DT, precision_DT = calculate_ROC_metrics(y_encoded[test_ids], predictions_DT_vector)
	
	ROC_RF, recall_RF, precision_RF = calculate_ROC_metrics(y_encoded[test_ids], predictions_RF_vector)
	
	ROC_nn, recall_nn, precision_nn = calculate_ROC_metrics(y_encoded[test_ids], predictions_nn_vector)
	
	ROC_SVM, recall_SVM, precision_SVM = calculate_ROC_metrics(y_encoded[test_ids], predictions_SVM_vector)
end
```
#### Recall
Mide la capacidad del modelo para encontrar todas las instancias positivas. Es el porcentaje de predicciones positivas correctas sobre todas las instancias reales positivas.

``` julia
println("Recall:\n\n- LASSO: ", recall_value_lasso,
	"\n\n- RIDGE: ",recall_value_ridge,"\n\n- ELASTIC NET: ",recall_value_EN,"\n\n- DECISION TREE: ",recall_value_DT,
	"\n\n- RANDOM FOREST: ",recall_value_RF,"\n\n- NEAREST NEIGHBORS: ",recall_value_nn,
	"\n\n- SVM: ",recall_value_SVM)
```

**Recall**
- LASSO: 0.9831932773109243

- RIDGE: 0.9747899159663865

- ELASTIC NET: 0.9831932773109243

- DECISION TREE: 1.0

- RANDOM FOREST: 1.0

- NEAREST NEIGHBORS: 0.8739495798319328

- SVM: 0.9621848739495799

#### Precisión
Mide la exactitud de las predicciones positivas. Es el porcentaje de predicciones positivas correctas sobre todas las predicciones positivas.
``` julia
println("Precision:\n\n- LASSO: ", precision_value_lasso,
	"\n\n- RIDGE: ",precision_value_ridge,"\n\n- ELASTIC NET: ",recall_value_EN,"\n\n- DECISION TREE: ",precision_value_DT,
	"\n\n- RANDOM FOREST: ",precision_value_RF,"\n\n- NEAREST NEIGHBORS: ",precision_value_nn,
	"\n\n- SVM: ",precision_value_SVM)
```
**Precision**

- LASSO: 1.0

- RIDGE: 1.0

- ELASTIC NET: 1.0

- DECISION TREE: 1.0

- RANDOM FOREST: 1.0

- NEAREST NEIGHBORS: 1.0

- SVM: 1.0

## Gráfica

Convertir etiquetas verdaderas en binario: 1 para `Up` y 0 para `Down`

```julia
y_test_binary = y_encoded[test_ids] .- 1  # Resta 1 para que [1, 2] pase a [0, 1]
```
```julia
# Función para calcular TPR y FPR
function TPR_FPR_roc(y_true, y_score)
    thresholds = sort(unique(y_score), rev=true)  # Umbrales
    tpr = Float64[]
    fpr = Float64[]

    for t in thresholds
        # Clasificar según el umbral actual
        y_pred = y_score .>= t

        # Calcular TP, FP, TN, FN
        TP = sum((y_pred .== 1) .& (y_true .== 1))
        FP = sum((y_pred .== 1) .& (y_true .== 0))
        TN = sum((y_pred .== 0) .& (y_true .== 0))
        FN = sum((y_pred .== 0) .& (y_true .== 1))

        # Calcular TPR y FPR
        push!(tpr, TP / (TP + FN))
        push!(fpr, FP / (FP + TN))
    end

    return fpr, tpr
end
```


``` julia
begin
	# Calcular TPR y FPR
	fpr_lasso, tpr_lasso = TPR_FPR_roc(y_test_binary, probabilities_lasso)
	fpr_ridge, tpr_ridge = TPR_FPR_roc(y_test_binary, probabilities_ridge)
	fpr_elastic_net, tpr_elastic_net = TPR_FPR_roc(y_test_binary, probabilities_elastic_net)
	
	fpr_DT, tpr_DT = TPR_FPR_roc(y_test_binary, predictions_DT_vector)
	fpr_RF, tpr_RF = TPR_FPR_roc(y_test_binary, predictions_RF_vector)
	fpr_nn, tpr_nn = TPR_FPR_roc(y_test_binary, predictions_nn_vector)
	fpr_SVM, tpr_SVM = TPR_FPR_roc(y_test_binary, predictions_SVM_vector)
end
```

``` julia
begin
	# Graficar la curva ROC
	plot(fpr_lasso, tpr_lasso, label="LASSO", lw=1)
	plot!(fpr_ridge, tpr_ridge, label="RIDGE", lw=1)
	plot!(fpr_elastic_net, tpr_elastic_net, label="ELASTIC NET", lw=1)
	plot!(fpr_DT, tpr_DT, label="DECISION TREE", lw=1)
	plot!(fpr_RF, tpr_RF, label="RANDOM FOREST", lw=1)
	plot!(fpr_SVM, tpr_SVM, label="NEAREST NEIGHBORS", lw=1)
	plot!(fpr_SVM, tpr_SVM, label="SVM", lw=1)
	plot!([0, 1], [0, 1], linestyle=:dash, label="Base Line", lw=1)
	xlabel!("False Positive Rate")
	ylabel!("True Positive Rate")
	title!("ROC Curves")

	# Guardamos la gráfica generada.
	
	ROC_Curves = joinpath("..","fig","ROC_Curves.png")
	savefig(ROC_Curves)

end
```

![ROC_Curves](../fig/ROC_Curves.png)


---
## Conclusión

| **Modelo**       | **Accuracy** | **Recall** | **Precision** | 
  |-------------------|--------------|------------|---------------|
  | LASSO            | 0.983193      | 0.983193 | 1.0           |
  | Ridge            | 0.97479 | 0.974789 | 1.0           | 
  | Elastic Net      | 0.983193| 0.98319327 | 1.0           | 
| Decision Tree      |1.0      | 1.0      | 1.0           | 
| Random Forest      | 1.0      | 1.0     | 1.0           |
| Nearest Neighbors      | 0.87395 | 0.87394957 | 1.0           | 
| SVM      | 0.962185| 0.9621848| 1.0           |


**LASSO, Ridge y Elastic Net:** Estos modelos tienen un desempeño muy similar, con valores de `accuracy` cercanos a 0.98. Esto sugiere que las técnicas de regularización (que penalizan coeficientes grandes) son efectivas para manejar posibles correlaciones entre las variables predictoras. **Elastic Net** combina las propiedades de **LASSO** y **Ridge**, lo que explica su rendimiento comparable.

**Decision Tree** y **Random Forest** tienen `accuracy` perfecto (1.0), pero es probable que estén sobreajustados, ya que es raro que un modelo sea perfecto en datos reales. 

**SVM** mostró un rendimiento robusto (0.96) y es un candidato sólido para problemas no lineales.

**Nearest Neighbors** tuvo el desempeño más bajo (0.87), Esto es esperado, ya que es sensible a la selección del valor de número de vecinos.