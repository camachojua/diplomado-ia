using CSV, MLJ, GLMNet, DataFrames, StatsBase, Plots, Random 
using DecisionTree, MLBase,NearestNeighbors, LinearAlgebra, LIBSVM
using DataStructures, ROCAnalysis


Smarket_path = joinpath("..", "dat", "Smarket.csv")

Smarket_df = CSV.read(Smarket_path, DataFrame)


des_Smarket = describe(Smarket_df)

size(Smarket_df)


## División en Conjunto de Entrenamiento y Prueba
### Definir Variables Predictoras y Objetivo

# Variable objetivo
# Columna 'Direction' como variable objetivo
y = Smarket_df.Direction


# Variables predictoras (excluye 'Direction')
X = select(Smarket_df, Not(:Direction)) # Todas las columnas excepto 'Direction' como predictoras

#### Convertir X a una matriz y codificar `y` a valores numéricos



X_matrix = Matrix(X)  # Convertir las variables predictoras a matriz


labels_map = labelmap(y)  # Crear un mapeo para las etiquetas de la variable objetivo


y_encoded = labelencode(labels_map, y)  # Codificar las etiquetas como números


### División del DataFrame



# Función para dividir los datos por clase
function perclass_splits(y, at)
    uids = unique(y)
    keepids = []

    for ui in uids
        curids = findall(y .== ui)
        rowids = randsubseq(curids, at)
        push!(keepids, rowids...)
    end
    return keepids
end


md"""
#### Dividir el conjunto de entrenamiento y prueba
Divide los datos en un 80% de entrenamiento y un 20% de prueba.
"""

train_ids = perclass_splits(y_encoded, 0.8) 


test_ids = setdiff(1:length(y_encoded), train_ids)


begin
	# Validación de proporciones de clases en los conjuntos
println("Proporciones en el conjunto de entrenamiento:")
println(countmap(y_encoded[train_ids]))

println("Proporciones en el conjunto de prueba:")
println(countmap(y_encoded[test_ids]))

end


## LASSO 
### Entrenar el modelo

begin
	path_lasso = glmnet(X_matrix[train_ids, :], y_encoded[train_ids])
	
	# Va a buscar el mejor alpha para hacer la proyección.
	cv_lasso = glmnetcv(X_matrix[train_ids, :], y_encoded[train_ids]) 
	
	lambda_lasso = path_lasso.lambda[argmin(cv_lasso.meanloss)]
	
	path_lasso = glmnet(X_matrix[train_ids, :], y_encoded[train_ids], lambda=[lambda_lasso])
end


### Realizar predicciones

begin
	q_lasso = X_matrix[test_ids, :]  # Variables predictoras para los datos de prueba
	probabilities_lasso = GLMNet.predict(path_lasso, q_lasso)
	# Asignar clases a predicciones continuas
	assign_class(predicted_value) = argmin(abs.(predicted_value .- [1, 2]))
	
	predictions_lasso = assign_class.(probabilities_lasso)
end




### Evaluar el modelo

function findaccuracy(predictions, groundtruthvals)
	# Cuenta cuántas predicciones son correctas
    correct = sum(predictions .== groundtruthvals) 
	
	# Divide entre el total de observaciones
    accuracy = correct / length(groundtruthvals) 

	# Devuelve el valor de precisión
    return accuracy                       
end


accuracy_lasso = findaccuracy(predictions_lasso, y_encoded[test_ids])

# Imprimir el resultado
println("Accuracy: ", accuracy_lasso)


## Ridge Regression
### Entrenar el modelo

begin
	path_ridge = glmnet(X_matrix[train_ids, :], y_encoded[train_ids], alpha=0); 
	cv_ridge = glmnetcv(X_matrix[train_ids, :], y_encoded[train_ids], alpha=0)
	
	lambda_ridge = path_ridge.lambda[argmin(cv_ridge.meanloss)]
	
	path_ridge = glmnet(X_matrix[train_ids, :], y_encoded[train_ids], alpha=0, lambda=[lambda_ridge]);
end 



### Realizar predicciones

begin
	q_ridge = X_matrix[test_ids,:];
	
	probabilities_ridge = GLMNet.predict(path_ridge,q_ridge)
	
	predictions_ridge = assign_class.(probabilities_ridge) 
end


### Evaluar el modelo

accuracy_ridge = findaccuracy(predictions_ridge, y_encoded[test_ids])


# Imprimir el resultado
println("Accuracy: ", accuracy_ridge)


##  Elastic Net Regularization 
### Entrenar el modelo

# Elegimos la mejor lambda con la cual predecir. 
begin
	path_elastic_net = glmnet(X_matrix[train_ids, :], y_encoded[train_ids], alpha = 0.5); 
	cv_elastic_net = glmnetcv(X_matrix[train_ids, :], y_encoded[train_ids], alpha = 0.5)
	
	lambda_elastic_net = path_elastic_net.lambda[argmin(cv_elastic_net.meanloss)]
	
	path_elastic_net = glmnet(X_matrix[train_ids, :], y_encoded[train_ids], alpha = 0.5, lambda = [lambda_elastic_net]);
end 


### Realizar predicciones

begin
	q_elastic_net = X_matrix[test_ids,:];
	
	probabilities_elastic_net = GLMNet.predict(path_elastic_net,q_elastic_net)
	
	predictions_elastic_net = assign_class.(probabilities_elastic_net) 
end


### Evaluar el modelo



accuracy_elastic_net = findaccuracy(predictions_elastic_net, y_encoded[test_ids])

# Imprimir el resultado
println("Accuracy: ", accuracy_elastic_net)


##  Decision Tree
### Entrenar el modelo

begin
	model_DT = DecisionTreeClassifier(max_depth = 2)
	DecisionTree.fit!(model_DT, X_matrix[train_ids,:], y_encoded[train_ids])
end


### Realizar predicciones

begin
	q_DT = X_matrix[test_ids,:]
	predictions_DT = DecisionTree.predict(model_DT,q_DT)
end


### Evaluar el modelo

accuracy_DT = findaccuracy(predictions_DT, y_encoded[test_ids])


## Random Forest
### Entrenar el modelo

# ╔═╡ 1a61ca35-acd0-4b5b-90cb-74eb14894a2e
begin
	model_RF= RandomForestClassifier(n_trees = 20)
	DecisionTree.fit!(model_RF , X_matrix[train_ids,:], y_encoded[train_ids])
end


### Realizar predicciones

begin
	q_RF = X_matrix[test_ids,:]
	predictions_RF = DecisionTree.predict(model_RF,q_RF)
end


### Evaluar el modelo

accuracy_RF = findaccuracy(predictions_RF, y_encoded[test_ids])


## Nearest Neighbors
### Entrenar el modelo

begin
	Xtrain_nn = X_matrix[train_ids,:]
	ytrain_nn = y_encoded[train_ids]
	kdtree = KDTree(Xtrain_nn')
end


### Realizar predicciones

queries = X_matrix[test_ids,:]


idxs, dists = knn(kdtree,queries', 5, true)


begin
	c = ytrain_nn[hcat(idxs...)]
	#DataStructures (counter)
	possible_labels = map(i->counter(c[:,i]),1:size(c,2))
end

predictions_nn = map(i->parse(Int,string(string(argmax(possible_labels[i])))),1:size(c,2))


### Evaluar el modelo

accuracy_nn= findaccuracy(predictions_nn, y_encoded[test_ids])


## Support Vector Machines (SVM)

begin
	Xtrain_SVM = X_matrix[train_ids,:]
	ytrain_SVM = y_encoded[train_ids]
	model_SVM = svmtrain(Xtrain_SVM', ytrain_SVM, probability=true)
end


### Realizar predicciones

predictions_SVM, decision_values = svmpredict(model_SVM, X_matrix[test_ids,:]') 


md"""
### Evaluar el modelo
"""


accuracy_SVM = findaccuracy(predictions_SVM, y_encoded[test_ids])




## Resultados por Algoritmo

begin
	overall_accuracies = zeros(7)
	algorithms = ["LASSO","RIDGE","ELASTIC NET", "DECISION TREE", "RANDOM FOREST", "NEAREST NEIGHBORS", "SVM"]
	ytest = y_encoded[test_ids]
end

begin
	overall_accuracies[1] = accuracy_lasso
	overall_accuracies[2] = accuracy_ridge
	overall_accuracies[3] = accuracy_elastic_net
	overall_accuracies[4] = accuracy_DT
	overall_accuracies[5] = accuracy_RF
	overall_accuracies[6] = accuracy_nn
	overall_accuracies[7] = accuracy_SVM
end


hcat(algorithms, overall_accuracies) 


## Matriz de Confusión



# Convertir predictions_algoritms a un vector 
begin
	predictions_lasso_vector = vec(predictions_lasso)
	predictions_ridge_vector = vec(predictions_ridge)
	predictions_EN_vector = vec(predictions_elastic_net)
	predictions_DT_vector = vec(predictions_DT)
	predictions_RF_vector = vec(predictions_RF)
	predictions_nn_vector = vec(predictions_nn)
	predictions_SVM_vector = vec(predictions_SVM)
end

#
begin
	cm_lasso = confusmat(2, y_encoded[test_ids], predictions_lasso_vector) 
	cm_ridge = confusmat(2, y_encoded[test_ids], predictions_ridge_vector) 
	cm_EN = confusmat(2, y_encoded[test_ids], predictions_EN_vector) 
	cm_DT = confusmat(2, y_encoded[test_ids], predictions_DT_vector) 
	cm_RF = confusmat(2, y_encoded[test_ids], predictions_RF_vector) 
	cm_nn = confusmat(2, y_encoded[test_ids], predictions_nn_vector) 
	cm_SVM = confusmat(2, y_encoded[test_ids], predictions_SVM_vector) 
end


println("Matriz de Confusión\n\n- LASSO:", cm_lasso,
	"\n\n- RIDGE:",cm_ridge,"\n\n- ELASTIC NET:",cm_EN,"\n\n- DECISION TREE:",cm_DT,
	"\n\n- RANDOM FOREST:",cm_RF,"\n\n- NEAREST NEIGHBORS:",cm_nn,
	"\n\n- SVM:",cm_SVM)


md"""
### Normalizar por clase 
"""


function normalize(cm)
    row_sums = sum(cm, dims=2)
    return all(row_sums .> 0) ? cm ./ row_sums : fill(0, size(cm))
end

# ╔═╡ 1f78ce5a-5216-4c22-ab25-77f16d903763
begin
	cm_normalized_lasso = normalize(cm_lasso)
	cm_normalized_ridge = normalize(cm_ridge)
	cm_normalized_EN = normalize(cm_EN)
	cm_normalized_DT = normalize(cm_DT)
	cm_normalized_RF = normalize(cm_RF)
	cm_normalized_nn = normalize(cm_nn)
	cm_normalized_SVM = normalize(cm_SVM)
end


println("Matriz Normalizada\n\n- LASSO:", cm_normalized_lasso,
	"\n\n- RIDGE:",cm_normalized_ridge,"\n\n- ELASTIC NET:",cm_normalized_EN,"\n\n- DECISION TREE:",cm_normalized_DT,
	"\n\n- RANDOM FOREST:",cm_normalized_RF,"\n\n- NEAREST NEIGHBORS:",cm_normalized_nn,
	"\n\n- SVM:",cm_normalized_SVM)


## Curva ROC y métricas asociadas 



function calculate_ROC_metrics(y_true, y_pred_vector)
    ROC = MLBase.roc(y_true, y_pred_vector)
    return (MLBase.recall(ROC), MLBase.precision(ROC))
end


begin
	recall_lasso, precision_lasso = calculate_ROC_metrics(y_encoded[test_ids], predictions_lasso_vector)
	
	recall_ridge, precision_ridge = calculate_ROC_metrics(y_encoded[test_ids], predictions_ridge_vector)
	
	recall_EN, precision_EN = calculate_ROC_metrics(y_encoded[test_ids], predictions_EN_vector)
	
	recall_DT, precision_DT = calculate_ROC_metrics(y_encoded[test_ids], predictions_DT_vector)
	
	recall_RF, precision_RF = calculate_ROC_metrics(y_encoded[test_ids], predictions_RF_vector)
	
	recall_nn, precision_nn = calculate_ROC_metrics(y_encoded[test_ids], predictions_nn_vector)
	
	recall_SVM, precision_SVM = calculate_ROC_metrics(y_encoded[test_ids], predictions_SVM_vector)
end


println("Recall:\n\n- LASSO: ", recall_lasso,
	"\n\n- RIDGE: ", recall_ridge, "\n\n- ELASTIC NET: ", recall_EN, "\n\n- DECISION TREE: ", recall_DT,
	"\n\n- RANDOM FOREST: ", recall_RF, "\n\n- NEAREST NEIGHBORS: ", recall_nn,
	"\n\n- SVM: ", recall_SVM)


println("Precision:\n\n- LASSO: ", precision_lasso,
	"\n\n- RIDGE: ", precision_ridge, "\n\n- ELASTIC NET: ", precision_EN, "\n\n- DECISION TREE: ", precision_DT,
	"\n\n- RANDOM FOREST: ", precision_RF, "\n\n- NEAREST NEIGHBORS: ", precision_nn,
	"\n\n- SVM: ", precision_SVM)


# Convertir etiquetas verdaderas en binario: 1 para "Up" y 0 para "Down"
y_test_binary = y_encoded[test_ids] .- 1  # Resta 1 para que [1, 2] pase a [0, 1]



# Función para calcular TPR y FPR
function TPR_FPR_roc(y_true, y_score)
    thresholds = sort(unique(y_score), rev=true)  # Umbrales
    tpr = Float64[]
    fpr = Float64[]

    for t in thresholds
        # Clasificar según el umbral actual
        y_pred = y_score .>= t

        # Calcular TP, FP, TN, FN
        TP = sum((y_pred .== 1) .& (y_true .== 1))
        FP = sum((y_pred .== 1) .& (y_true .== 0))
        TN = sum((y_pred .== 0) .& (y_true .== 0))
        FN = sum((y_pred .== 0) .& (y_true .== 1))

        # Calcular TPR y FPR
        push!(tpr, TP / (TP + FN))
        push!(fpr, FP / (FP + TN))
    end

    return fpr, tpr
end


begin
	q = X_matrix[test_ids, :]
	probabilities_DT = DecisionTree.predict_proba(model_DT, q)
	probabilities_RF = DecisionTree.predict_proba(model_RF, q)
	
	probabilities_DT_positive = probabilities_DT[:, 2]  # Seleccionar columna 2
	probabilities_RF_positive = probabilities_RF[:, 2]  # Seleccionar columna 2
end



begin
	# Calcular TPR y FPR
	fpr_lasso, tpr_lasso = TPR_FPR_roc(y_test_binary, probabilities_lasso)
	fpr_ridge, tpr_ridge = TPR_FPR_roc(y_test_binary, probabilities_ridge)
	fpr_elastic_net, tpr_elastic_net = TPR_FPR_roc(y_test_binary, probabilities_elastic_net)
	
	fpr_DT, tpr_DT = TPR_FPR_roc(y_test_binary, predictions_DT_vector)
	fpr_RF, tpr_RF = TPR_FPR_roc(y_test_binary, predictions_RF_vector)
	fpr_nn, tpr_nn = TPR_FPR_roc(y_test_binary, predictions_nn_vector)
	fpr_SVM, tpr_SVM = TPR_FPR_roc(y_test_binary, predictions_SVM_vector)
end


begin
	# Graficar la curva ROC
	plot(fpr_lasso, tpr_lasso, label="LASSO", lw=1)
	plot!(fpr_ridge, tpr_ridge, label="RIDGE", lw=1)
	plot!(fpr_elastic_net, tpr_elastic_net, label="ELASTIC NET", lw=1)
	plot!(fpr_DT, tpr_DT, label="DECISION TREE", lw=1)
	plot!(fpr_RF, tpr_RF, label="RANDOM FOREST", lw=1)
	plot!(fpr_SVM, tpr_SVM, label="NEAREST NEIGHBORS", lw=1)
	plot!(fpr_SVM, tpr_SVM, label="SVM", lw=1)
	plot!([0, 1], [0, 1], linestyle=:dash, label="Base Line", lw=1)
	xlabel!("False Positive Rate")
	ylabel!("True Positive Rate")
	title!("ROC Curves")

	# Guardamos la gráfica generada.
	
	ROC_Curves = joinpath("..","fig","ROC_Curves.png")
	savefig(ROC_Curves)

end