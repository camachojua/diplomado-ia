### A Pluto.jl notebook ###
# v0.20.4

using Markdown
using InteractiveUtils

# ╔═╡ 28540dc6-cee6-481e-8e2c-f24676c7a83f
begin
	import Pkg
	Pkg.add("MLJ")
	Pkg.add("MLJBase")
	Pkg.add("MLJLinearModels")
	Pkg.add("DecisionTree")
	Pkg.add("MLJScikitLearnInterface")
	Pkg.add("CSV")
	Pkg.add("CategoricalArrays")
	Pkg.add("DecisionTree")
	Pkg.add("MLJDecisionTreeInterface")
	Pkg.add("NearestNeighborModels")
	Pkg.add("LIBSVM")
	Pkg.add("MLJLIBSVMInterface")
	Pkg.add("ROCAnalysis")
	Pkg.update()  
end

# ╔═╡ 6cc3f1a0-11b5-4fc5-af2e-27dcc90797e2
begin
	using DataFrames
    using CategoricalArrays
    using Random
	using MLJ
    using MLJBase: table
    using Plots
	using CSV
	using StatsBase
	using MLJLinearModels
	using MLJScikitLearnInterface 
	using MLJLIBSVMInterface  
	using DecisionTree
	using ROCAnalysis
end

# ╔═╡ 7018d62c-cf02-11ef-07a2-dbe529415c2c
md"""# Actividad 3 
	## Classification"""

# ╔═╡ c62481f9-2415-48b4-bf32-4e837f6c9569
md"""## Alan Eduardo Aquino Rosas"""

# ╔═╡ ec6c04c6-01d7-452a-ad34-45d349b5d812
md"""Durante esta actividad usando los datos de ISL Stock Market se tratara de predeccir si el modelo sube o baja(clasificasion) """

# ╔═╡ fb23e5d4-18a1-4594-a30c-f665ccadd25f
md"""Importacion de librerias necesarias"""

# ╔═╡ 008ffa09-0af4-49da-8f89-ae4ede63566a
md"""### Importacion de datos"""

# ╔═╡ 03905c4a-68f6-4898-8f74-73275ae33a2d
df = CSV.read("../dat/Smarket.csv", DataFrame; stringtype = String)

# ╔═╡ 457a03da-135b-4115-b5f7-a30476e9e01b
md"""Convertir la variable dependiente Direction a una columna categórica. Esto nos permitirá que MLJ maneje automáticamente el encoding de la columna, ya sea mediante one-hot encoding o label encoding."""

# ╔═╡ e94145fc-61c8-4030-b313-267440fa848f
df.Direction = categorical(df.Direction)

# ╔═╡ feb8dc31-b497-4d3b-9c46-e6dfc9499ed9
md"""#### Definir las variables independientes a utilizar para entrenar nuestro modelo."""

# ╔═╡ fc4d5fed-deda-453a-b709-b1007c9d7be3
begin
	independent_vars = [:Lag1, :Lag2, :Lag3, :Lag4, :Lag5, :Volume,  :Year]
	dependent_var = :Direction
end

# ╔═╡ 2d801156-af1d-4720-a4f6-70d5ed4c80e6
md"""#### División del dataset en Train-Validation y mezcla aleatoria (shuffle). """

# ╔═╡ 8a21fca4-b39b-44eb-a9ac-b62fcaf2a4a2
begin
	Random.seed!(123) #Ramdom  seed for reproductability
	indices = shuffle(1:nrow(df))
	train_ratio = 0.90
	train_size = Int(floor(train_ratio * nrow(df)))
	train_inds = indices[1:train_size]
	test_inds  = indices[train_size+1:end]

	train_df = df[train_inds, :]
	test_df  = df[test_inds, :]

	X_train = train_df[:, independent_vars]  # DataFrame for features
	y_train = train_df[!, dependent_var]    # CategoricalVector
	X_test  = test_df[:, independent_vars]
	y_test  = test_df[!, dependent_var]
	
end

# ╔═╡ d104871d-7923-46da-83c5-ed3547dcffd4
md""" #### Definicion de modelos"""

# ╔═╡ 6d293d2a-09ce-4505-8db2-d451c26000a3
models("LIBSVM")

# ╔═╡ 466b6d11-f80b-40df-b7e1-da4220a1cc26
begin

	    lasso_model = MLJLinearModels.LogisticClassifier(penalty=:l1, lambda=0.3)
	

	    ridge_model = MLJLinearModels.LogisticClassifier(penalty=:l2, lambda=0.3)
	

	    elastic_model = MLJLinearModels.LogisticClassifier(penalty=:en, lambda=0.4, gamma=0.5)
	

	    tree_model = (@load DecisionTreeClassifier pkg=DecisionTree  verbosity=0)() 
	
	    rf_model = (@load RandomForestClassifier pkg=DecisionTree  verbosity=0)()
		rf_model.n_trees = 20

	    knn_model = (@load KNNClassifier verbosity=0)() 

	    svm_model = (@load SVC pkg=LIBSVM verbosity=0)()
	    
end

# ╔═╡ dc8353a9-9a9b-41e0-b341-418888e9cd10
models_dict = Dict(
        "Lasso"       => lasso_model,
        "Ridge"       => ridge_model,
        "ElasticNet"  => elastic_model,
        "DecisionTree"=> tree_model,
        "RandomForest"=> rf_model,
        "KNN"         => knn_model,
         "SVM"         => svm_model
    )

# ╔═╡ 37db965a-f661-40f6-ae0d-1ebce488e2cd
md"""### Definición de función auxiliar (helper) para graficar puntos ROC."""

# ╔═╡ 699ea710-def6-469e-9351-9b0c0c2896ce
 function roc_points(y_true, y_scores; npoints=20)
      #LEVELS[1] ==DOWN AND [2] UP
        pos_class = levels(y_true)[2]  

        thresholds = range(1, 0, length=npoints)
        tprs = Float64[]
        fprs = Float64[]

        # We'll define a confusion matrix approach for each threshold
        for t in thresholds
            predicted = [score >= t ? pos_class : levels(y_true)[1] for score in y_scores]
            # compute confusion
            tp = sum(predicted[i] == pos_class && y_true[i] == pos_class for i in eachindex(y_true))
            tn = sum(predicted[i] != pos_class && y_true[i] != pos_class for i in eachindex(y_true))
            fp = sum(predicted[i] == pos_class && y_true[i] != pos_class for i in eachindex(y_true))
            fn = sum(predicted[i] != pos_class && y_true[i] == pos_class for i in eachindex(y_true))

			

        push!(tprs, tp + fn > 0 ? tp / (tp + fn) : 0.0)  # TPR = TP / (TP + FN)
        push!(fprs, fp + tn > 0 ? fp / (fp + tn) : 0.0)
        end
        return collect(thresholds), tprs, fprs
    end

# ╔═╡ 550949c3-6137-48ec-8466-c86eda884da2
md"""nicialización del plot para curvas ROC

Únicamente se realiza en el conjunto de validación cruzada (cross-validation set), ya que es el que nos interesa.
"""

# ╔═╡ 3d728127-d13c-43f9-abbb-0f43aa3b0be0
 plt = plot(title="Curvas ROC en Test Set", xlabel="FPR", ylabel="TPR")

# ╔═╡ ab17fb8f-4658-48ed-9ef7-9f8181143273
md"""### Entrenamiento de modelos definidos"""

# ╔═╡ e7e927db-8fd6-4392-88b5-18c7742f1da1
begin
	results = DataFrame(Model=String[], AUC=Float64[])
		for (model_name, model) in models_dict
	        @info "Training $model_name"
	        # machine + fit!
	        mach = MLJ.machine(model, X_train, y_train)
	        MLJ.fit!(mach)
	
	
	        prob_predictions = MLJ.predict(mach, X_test)
	
	    
	        pos_class = levels(y_test)[2]  # Up class
			println(pos_class)
	        y_scores = Float64[]
	        for dist in prob_predictions
				try
	            # dist is something like Categorical(prob_of_down, prob_of_up)
				
	            push!(y_scores, pdf(dist, pos_class))  # pdf is probability of pos_class
					catch e
        # Si ocurre un error, manejamos el caso donde `dist` no es una distribución
        if dist isa CategoricalValue
            push!(y_scores, (dist == pos_class) ? 1.0 : 0.0)
        else
            # En caso de que no sea ni un UnivariateFinite ni un CategoricalValue
            push!(y_scores, 0.0)
        end
    end
	        end

	
	        # Compute ROC points
	        thresholds, tprs ,fprs = roc_points(y_test, y_scores, npoints=100)
			println("FPRs: ", fprs)
println("TPRs: ", tprs)
	
	        # Plot the curve
	        plot!(plt, fprs, tprs, label=model_name)

			
	        auct = 0.0
	        for i in 2:length(fprs)
	            dx = fprs[i] - fprs[i-1]
	            yavg = (tprs[i] + tprs[i-1]) / 2
	            auct+= dx*yavg
	        end
	
			
	        push!(results, (model_name,auct))
	    end
	
end

# ╔═╡ 6df41e4d-6241-4654-b818-b84206a68022
plt

# ╔═╡ c4024e35-aeef-416d-8735-395075f3e7e5
begin
	plt
    println("\nAUC results for each model:")
    display(results)
end

# ╔═╡ 1ea2c58a-6e73-46b6-b5fe-64b4246b3e99
md"""### Conclusiones

Se observa que, en su mayoría, los modelos tuvieron un AUC entre 0.5 y 0.627 en el conjunto de prueba (test set), lo que indica que no generalizaron bien. Esto significa que no realizan un excelente trabajo al clasificar si el precio del stock bajará o subirá al día siguiente. El modelo que tuvo mejor rendimiento fue el random forest con un AUC de 0.627.
"""

# ╔═╡ Cell order:
# ╠═7018d62c-cf02-11ef-07a2-dbe529415c2c
# ╠═c62481f9-2415-48b4-bf32-4e837f6c9569
# ╠═ec6c04c6-01d7-452a-ad34-45d349b5d812
# ╠═fb23e5d4-18a1-4594-a30c-f665ccadd25f
# ╠═28540dc6-cee6-481e-8e2c-f24676c7a83f
# ╠═6cc3f1a0-11b5-4fc5-af2e-27dcc90797e2
# ╠═008ffa09-0af4-49da-8f89-ae4ede63566a
# ╠═03905c4a-68f6-4898-8f74-73275ae33a2d
# ╠═457a03da-135b-4115-b5f7-a30476e9e01b
# ╠═e94145fc-61c8-4030-b313-267440fa848f
# ╠═feb8dc31-b497-4d3b-9c46-e6dfc9499ed9
# ╠═fc4d5fed-deda-453a-b709-b1007c9d7be3
# ╠═2d801156-af1d-4720-a4f6-70d5ed4c80e6
# ╠═8a21fca4-b39b-44eb-a9ac-b62fcaf2a4a2
# ╠═d104871d-7923-46da-83c5-ed3547dcffd4
# ╠═6d293d2a-09ce-4505-8db2-d451c26000a3
# ╠═466b6d11-f80b-40df-b7e1-da4220a1cc26
# ╠═dc8353a9-9a9b-41e0-b341-418888e9cd10
# ╠═37db965a-f661-40f6-ae0d-1ebce488e2cd
# ╠═699ea710-def6-469e-9351-9b0c0c2896ce
# ╠═550949c3-6137-48ec-8466-c86eda884da2
# ╠═3d728127-d13c-43f9-abbb-0f43aa3b0be0
# ╠═ab17fb8f-4658-48ed-9ef7-9f8181143273
# ╠═e7e927db-8fd6-4392-88b5-18c7742f1da1
# ╠═6df41e4d-6241-4654-b818-b84206a68022
# ╠═c4024e35-aeef-416d-8735-395075f3e7e5
# ╠═1ea2c58a-6e73-46b6-b5fe-64b4246b3e99
