# Implementación de modelos de clasificación para predicción de la dirección del mercado

## Descripción del Proyecto
Este proyecto implementa varios modelos de clasificación utilizando el paquete `MLJ` en Julia, con el objetivo de predecir la dirección del mercado utilizando el dataset `Smarket.csv`. Los modelos utilizados incluyen regresión logística, LASSO, Ridge, Elastic Net, árboles de decisión, Random Forest, Nearest Neighbors y Support Vector Machines (SVM).

## Sobre el Dataset
En este proyecto examinamos los datos de Smarket, que forman parte de la biblioteca ISLP.
Este conjunto de datos consta de los rendimientos porcentuales del índice bursátil S&P 500 durante 1250 días, desde principios de 2001 hasta finales de 2005. Para cada fecha, se registraron los rendimientos porcentuales de cada uno de los cinco días de negociación anteriores, desde el **Lag1** hasta el **Lag5**. También se registraron **Volumen**
(la cantidad de acciones negociadas el día anterior, en miles de millones), **Today** (el rendimiento porcentual en la fecha en cuestión) y **Direcction** (si el mercado subió o bajó en esta fecha).

## Configuración del Entorno y Librerías
El código usa las siguientes librerías:


```julia
using MLJ
using MLJBase
using CSV
using DataFrames
using StatsBase
using Plots
using Distances
using MLJLinearModels
using MLJModels
using MLJDecisionTreeInterface
using NearestNeighborModels
using LIBSVM

```

## Procesamiento del Dataset
El dataset `Smarket.csv` fue cargado y preprocesado:


```julia
# Preparar los datos
data = CSV.read("Smarket.csv", DataFrame)
```




<div><div style = "float: left;"><span>1250×9 DataFrame</span></div><div style = "float: right;"><span style = "font-style: italic;">1225 rows omitted</span></div><div style = "clear: both;"></div></div><div class = "data-frame" style = "overflow-x: scroll;"><table class = "data-frame" style = "margin-bottom: 6px;"><thead><tr class = "header"><th class = "rowNumber" style = "font-weight: bold; text-align: right;">Row</th><th style = "text-align: left;">Year</th><th style = "text-align: left;">Lag1</th><th style = "text-align: left;">Lag2</th><th style = "text-align: left;">Lag3</th><th style = "text-align: left;">Lag4</th><th style = "text-align: left;">Lag5</th><th style = "text-align: left;">Volume</th><th style = "text-align: left;">Today</th><th style = "text-align: left;">Direction</th></tr><tr class = "subheader headerLastRow"><th class = "rowNumber" style = "font-weight: bold; text-align: right;"></th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "String7" style = "text-align: left;">String7</th></tr></thead><tbody><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1</td><td style = "text-align: right;">2001</td><td style = "text-align: right;">0.381</td><td style = "text-align: right;">-0.192</td><td style = "text-align: right;">-2.624</td><td style = "text-align: right;">-1.055</td><td style = "text-align: right;">5.01</td><td style = "text-align: right;">1.1913</td><td style = "text-align: right;">0.959</td><td style = "text-align: left;">Up</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">2</td><td style = "text-align: right;">2001</td><td style = "text-align: right;">0.959</td><td style = "text-align: right;">0.381</td><td style = "text-align: right;">-0.192</td><td style = "text-align: right;">-2.624</td><td style = "text-align: right;">-1.055</td><td style = "text-align: right;">1.2965</td><td style = "text-align: right;">1.032</td><td style = "text-align: left;">Up</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">3</td><td style = "text-align: right;">2001</td><td style = "text-align: right;">1.032</td><td style = "text-align: right;">0.959</td><td style = "text-align: right;">0.381</td><td style = "text-align: right;">-0.192</td><td style = "text-align: right;">-2.624</td><td style = "text-align: right;">1.4112</td><td style = "text-align: right;">-0.623</td><td style = "text-align: left;">Down</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">4</td><td style = "text-align: right;">2001</td><td style = "text-align: right;">-0.623</td><td style = "text-align: right;">1.032</td><td style = "text-align: right;">0.959</td><td style = "text-align: right;">0.381</td><td style = "text-align: right;">-0.192</td><td style = "text-align: right;">1.276</td><td style = "text-align: right;">0.614</td><td style = "text-align: left;">Up</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">5</td><td style = "text-align: right;">2001</td><td style = "text-align: right;">0.614</td><td style = "text-align: right;">-0.623</td><td style = "text-align: right;">1.032</td><td style = "text-align: right;">0.959</td><td style = "text-align: right;">0.381</td><td style = "text-align: right;">1.2057</td><td style = "text-align: right;">0.213</td><td style = "text-align: left;">Up</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">6</td><td style = "text-align: right;">2001</td><td style = "text-align: right;">0.213</td><td style = "text-align: right;">0.614</td><td style = "text-align: right;">-0.623</td><td style = "text-align: right;">1.032</td><td style = "text-align: right;">0.959</td><td style = "text-align: right;">1.3491</td><td style = "text-align: right;">1.392</td><td style = "text-align: left;">Up</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">7</td><td style = "text-align: right;">2001</td><td style = "text-align: right;">1.392</td><td style = "text-align: right;">0.213</td><td style = "text-align: right;">0.614</td><td style = "text-align: right;">-0.623</td><td style = "text-align: right;">1.032</td><td style = "text-align: right;">1.445</td><td style = "text-align: right;">-0.403</td><td style = "text-align: left;">Down</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">8</td><td style = "text-align: right;">2001</td><td style = "text-align: right;">-0.403</td><td style = "text-align: right;">1.392</td><td style = "text-align: right;">0.213</td><td style = "text-align: right;">0.614</td><td style = "text-align: right;">-0.623</td><td style = "text-align: right;">1.4078</td><td style = "text-align: right;">0.027</td><td style = "text-align: left;">Up</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9</td><td style = "text-align: right;">2001</td><td style = "text-align: right;">0.027</td><td style = "text-align: right;">-0.403</td><td style = "text-align: right;">1.392</td><td style = "text-align: right;">0.213</td><td style = "text-align: right;">0.614</td><td style = "text-align: right;">1.164</td><td style = "text-align: right;">1.303</td><td style = "text-align: left;">Up</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">10</td><td style = "text-align: right;">2001</td><td style = "text-align: right;">1.303</td><td style = "text-align: right;">0.027</td><td style = "text-align: right;">-0.403</td><td style = "text-align: right;">1.392</td><td style = "text-align: right;">0.213</td><td style = "text-align: right;">1.2326</td><td style = "text-align: right;">0.287</td><td style = "text-align: left;">Up</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">11</td><td style = "text-align: right;">2001</td><td style = "text-align: right;">0.287</td><td style = "text-align: right;">1.303</td><td style = "text-align: right;">0.027</td><td style = "text-align: right;">-0.403</td><td style = "text-align: right;">1.392</td><td style = "text-align: right;">1.309</td><td style = "text-align: right;">-0.498</td><td style = "text-align: left;">Down</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">12</td><td style = "text-align: right;">2001</td><td style = "text-align: right;">-0.498</td><td style = "text-align: right;">0.287</td><td style = "text-align: right;">1.303</td><td style = "text-align: right;">0.027</td><td style = "text-align: right;">-0.403</td><td style = "text-align: right;">1.258</td><td style = "text-align: right;">-0.189</td><td style = "text-align: left;">Down</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">13</td><td style = "text-align: right;">2001</td><td style = "text-align: right;">-0.189</td><td style = "text-align: right;">-0.498</td><td style = "text-align: right;">0.287</td><td style = "text-align: right;">1.303</td><td style = "text-align: right;">0.027</td><td style = "text-align: right;">1.098</td><td style = "text-align: right;">0.68</td><td style = "text-align: left;">Up</td></tr><tr><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1239</td><td style = "text-align: right;">2005</td><td style = "text-align: right;">0.555</td><td style = "text-align: right;">0.084</td><td style = "text-align: right;">0.281</td><td style = "text-align: right;">-0.122</td><td style = "text-align: right;">-0.501</td><td style = "text-align: right;">2.39002</td><td style = "text-align: right;">0.419</td><td style = "text-align: left;">Up</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1240</td><td style = "text-align: right;">2005</td><td style = "text-align: right;">0.419</td><td style = "text-align: right;">0.555</td><td style = "text-align: right;">0.084</td><td style = "text-align: right;">0.281</td><td style = "text-align: right;">-0.122</td><td style = "text-align: right;">2.14552</td><td style = "text-align: right;">-0.141</td><td style = "text-align: left;">Down</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1241</td><td style = "text-align: right;">2005</td><td style = "text-align: right;">-0.141</td><td style = "text-align: right;">0.419</td><td style = "text-align: right;">0.555</td><td style = "text-align: right;">0.084</td><td style = "text-align: right;">0.281</td><td style = "text-align: right;">2.18059</td><td style = "text-align: right;">-0.285</td><td style = "text-align: left;">Down</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1242</td><td style = "text-align: right;">2005</td><td style = "text-align: right;">-0.285</td><td style = "text-align: right;">-0.141</td><td style = "text-align: right;">0.419</td><td style = "text-align: right;">0.555</td><td style = "text-align: right;">0.084</td><td style = "text-align: right;">2.58419</td><td style = "text-align: right;">-0.584</td><td style = "text-align: left;">Down</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1243</td><td style = "text-align: right;">2005</td><td style = "text-align: right;">-0.584</td><td style = "text-align: right;">-0.285</td><td style = "text-align: right;">-0.141</td><td style = "text-align: right;">0.419</td><td style = "text-align: right;">0.555</td><td style = "text-align: right;">2.20881</td><td style = "text-align: right;">-0.024</td><td style = "text-align: left;">Down</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1244</td><td style = "text-align: right;">2005</td><td style = "text-align: right;">-0.024</td><td style = "text-align: right;">-0.584</td><td style = "text-align: right;">-0.285</td><td style = "text-align: right;">-0.141</td><td style = "text-align: right;">0.419</td><td style = "text-align: right;">1.99669</td><td style = "text-align: right;">0.252</td><td style = "text-align: left;">Up</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1245</td><td style = "text-align: right;">2005</td><td style = "text-align: right;">0.252</td><td style = "text-align: right;">-0.024</td><td style = "text-align: right;">-0.584</td><td style = "text-align: right;">-0.285</td><td style = "text-align: right;">-0.141</td><td style = "text-align: right;">2.06517</td><td style = "text-align: right;">0.422</td><td style = "text-align: left;">Up</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1246</td><td style = "text-align: right;">2005</td><td style = "text-align: right;">0.422</td><td style = "text-align: right;">0.252</td><td style = "text-align: right;">-0.024</td><td style = "text-align: right;">-0.584</td><td style = "text-align: right;">-0.285</td><td style = "text-align: right;">1.8885</td><td style = "text-align: right;">0.043</td><td style = "text-align: left;">Up</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1247</td><td style = "text-align: right;">2005</td><td style = "text-align: right;">0.043</td><td style = "text-align: right;">0.422</td><td style = "text-align: right;">0.252</td><td style = "text-align: right;">-0.024</td><td style = "text-align: right;">-0.584</td><td style = "text-align: right;">1.28581</td><td style = "text-align: right;">-0.955</td><td style = "text-align: left;">Down</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1248</td><td style = "text-align: right;">2005</td><td style = "text-align: right;">-0.955</td><td style = "text-align: right;">0.043</td><td style = "text-align: right;">0.422</td><td style = "text-align: right;">0.252</td><td style = "text-align: right;">-0.024</td><td style = "text-align: right;">1.54047</td><td style = "text-align: right;">0.13</td><td style = "text-align: left;">Up</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1249</td><td style = "text-align: right;">2005</td><td style = "text-align: right;">0.13</td><td style = "text-align: right;">-0.955</td><td style = "text-align: right;">0.043</td><td style = "text-align: right;">0.422</td><td style = "text-align: right;">0.252</td><td style = "text-align: right;">1.42236</td><td style = "text-align: right;">-0.298</td><td style = "text-align: left;">Down</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1250</td><td style = "text-align: right;">2005</td><td style = "text-align: right;">-0.298</td><td style = "text-align: right;">0.13</td><td style = "text-align: right;">-0.955</td><td style = "text-align: right;">0.043</td><td style = "text-align: right;">0.422</td><td style = "text-align: right;">1.38254</td><td style = "text-align: right;">-0.489</td><td style = "text-align: left;">Down</td></tr></tbody></table></div>



La forma de los datos de Smarket es [1250,9]. Las primeras 8 columnas contienen las variables independientes.


```julia
size(data)
```




    (1250, 9)




```julia
describe(data, :mean, :std, :eltype)
```




<div><div style = "float: left;"><span>9×4 DataFrame</span></div><div style = "clear: both;"></div></div><div class = "data-frame" style = "overflow-x: scroll;"><table class = "data-frame" style = "margin-bottom: 6px;"><thead><tr class = "header"><th class = "rowNumber" style = "font-weight: bold; text-align: right;">Row</th><th style = "text-align: left;">variable</th><th style = "text-align: left;">mean</th><th style = "text-align: left;">std</th><th style = "text-align: left;">eltype</th></tr><tr class = "subheader headerLastRow"><th class = "rowNumber" style = "font-weight: bold; text-align: right;"></th><th title = "Symbol" style = "text-align: left;">Symbol</th><th title = "Union{Nothing, Float64}" style = "text-align: left;">Union…</th><th title = "Union{Nothing, Float64}" style = "text-align: left;">Union…</th><th title = "DataType" style = "text-align: left;">DataType</th></tr></thead><tbody><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1</td><td style = "text-align: left;">Year</td><td style = "text-align: left;">2003.02</td><td style = "text-align: left;">1.40902</td><td style = "text-align: left;">Int64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">2</td><td style = "text-align: left;">Lag1</td><td style = "text-align: left;">0.0038344</td><td style = "text-align: left;">1.1363</td><td style = "text-align: left;">Float64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">3</td><td style = "text-align: left;">Lag2</td><td style = "text-align: left;">0.0039192</td><td style = "text-align: left;">1.13628</td><td style = "text-align: left;">Float64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">4</td><td style = "text-align: left;">Lag3</td><td style = "text-align: left;">0.001716</td><td style = "text-align: left;">1.1387</td><td style = "text-align: left;">Float64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">5</td><td style = "text-align: left;">Lag4</td><td style = "text-align: left;">0.001636</td><td style = "text-align: left;">1.13877</td><td style = "text-align: left;">Float64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">6</td><td style = "text-align: left;">Lag5</td><td style = "text-align: left;">0.0056096</td><td style = "text-align: left;">1.14755</td><td style = "text-align: left;">Float64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">7</td><td style = "text-align: left;">Volume</td><td style = "text-align: left;">1.4783</td><td style = "text-align: left;">0.360357</td><td style = "text-align: left;">Float64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">8</td><td style = "text-align: left;">Today</td><td style = "text-align: left;">0.0031384</td><td style = "text-align: left;">1.13633</td><td style = "text-align: left;">Float64</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9</td><td style = "text-align: left;">Direction</td><td style = "font-style: italic; text-align: left;"></td><td style = "font-style: italic; text-align: left;"></td><td style = "text-align: left;">String7</td></tr></tbody></table></div>



Se convirtió la columna `Direction` en una variable binaria (1 = Up, 0 = Down).


```julia
# Convertir 'Direction' a variable binaria (1 = Up, 0 = Down)
data.Direction = ifelse.(data.Direction .== "Up", 1, 0)
```




    1250-element Vector{Int64}:
     1
     1
     0
     1
     1
     1
     0
     1
     1
     1
     0
     0
     1
     ⋮
     1
     0
     0
     0
     0
     1
     1
     1
     0
     1
     0
     0



Seleccionamos las variables para predecir **Direction** utilizando **Lag1** a **Lag5** y **Volume**.


```julia
# Seleccionar las características y la variable objetivo
y = data.Direction
X = DataFrames.select(data, Not(:Direction))
```




<div><div style = "float: left;"><span>1250×8 DataFrame</span></div><div style = "float: right;"><span style = "font-style: italic;">1225 rows omitted</span></div><div style = "clear: both;"></div></div><div class = "data-frame" style = "overflow-x: scroll;"><table class = "data-frame" style = "margin-bottom: 6px;"><thead><tr class = "header"><th class = "rowNumber" style = "font-weight: bold; text-align: right;">Row</th><th style = "text-align: left;">Year</th><th style = "text-align: left;">Lag1</th><th style = "text-align: left;">Lag2</th><th style = "text-align: left;">Lag3</th><th style = "text-align: left;">Lag4</th><th style = "text-align: left;">Lag5</th><th style = "text-align: left;">Volume</th><th style = "text-align: left;">Today</th></tr><tr class = "subheader headerLastRow"><th class = "rowNumber" style = "font-weight: bold; text-align: right;"></th><th title = "Int64" style = "text-align: left;">Int64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th></tr></thead><tbody><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1</td><td style = "text-align: right;">2001</td><td style = "text-align: right;">0.381</td><td style = "text-align: right;">-0.192</td><td style = "text-align: right;">-2.624</td><td style = "text-align: right;">-1.055</td><td style = "text-align: right;">5.01</td><td style = "text-align: right;">1.1913</td><td style = "text-align: right;">0.959</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">2</td><td style = "text-align: right;">2001</td><td style = "text-align: right;">0.959</td><td style = "text-align: right;">0.381</td><td style = "text-align: right;">-0.192</td><td style = "text-align: right;">-2.624</td><td style = "text-align: right;">-1.055</td><td style = "text-align: right;">1.2965</td><td style = "text-align: right;">1.032</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">3</td><td style = "text-align: right;">2001</td><td style = "text-align: right;">1.032</td><td style = "text-align: right;">0.959</td><td style = "text-align: right;">0.381</td><td style = "text-align: right;">-0.192</td><td style = "text-align: right;">-2.624</td><td style = "text-align: right;">1.4112</td><td style = "text-align: right;">-0.623</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">4</td><td style = "text-align: right;">2001</td><td style = "text-align: right;">-0.623</td><td style = "text-align: right;">1.032</td><td style = "text-align: right;">0.959</td><td style = "text-align: right;">0.381</td><td style = "text-align: right;">-0.192</td><td style = "text-align: right;">1.276</td><td style = "text-align: right;">0.614</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">5</td><td style = "text-align: right;">2001</td><td style = "text-align: right;">0.614</td><td style = "text-align: right;">-0.623</td><td style = "text-align: right;">1.032</td><td style = "text-align: right;">0.959</td><td style = "text-align: right;">0.381</td><td style = "text-align: right;">1.2057</td><td style = "text-align: right;">0.213</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">6</td><td style = "text-align: right;">2001</td><td style = "text-align: right;">0.213</td><td style = "text-align: right;">0.614</td><td style = "text-align: right;">-0.623</td><td style = "text-align: right;">1.032</td><td style = "text-align: right;">0.959</td><td style = "text-align: right;">1.3491</td><td style = "text-align: right;">1.392</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">7</td><td style = "text-align: right;">2001</td><td style = "text-align: right;">1.392</td><td style = "text-align: right;">0.213</td><td style = "text-align: right;">0.614</td><td style = "text-align: right;">-0.623</td><td style = "text-align: right;">1.032</td><td style = "text-align: right;">1.445</td><td style = "text-align: right;">-0.403</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">8</td><td style = "text-align: right;">2001</td><td style = "text-align: right;">-0.403</td><td style = "text-align: right;">1.392</td><td style = "text-align: right;">0.213</td><td style = "text-align: right;">0.614</td><td style = "text-align: right;">-0.623</td><td style = "text-align: right;">1.4078</td><td style = "text-align: right;">0.027</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9</td><td style = "text-align: right;">2001</td><td style = "text-align: right;">0.027</td><td style = "text-align: right;">-0.403</td><td style = "text-align: right;">1.392</td><td style = "text-align: right;">0.213</td><td style = "text-align: right;">0.614</td><td style = "text-align: right;">1.164</td><td style = "text-align: right;">1.303</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">10</td><td style = "text-align: right;">2001</td><td style = "text-align: right;">1.303</td><td style = "text-align: right;">0.027</td><td style = "text-align: right;">-0.403</td><td style = "text-align: right;">1.392</td><td style = "text-align: right;">0.213</td><td style = "text-align: right;">1.2326</td><td style = "text-align: right;">0.287</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">11</td><td style = "text-align: right;">2001</td><td style = "text-align: right;">0.287</td><td style = "text-align: right;">1.303</td><td style = "text-align: right;">0.027</td><td style = "text-align: right;">-0.403</td><td style = "text-align: right;">1.392</td><td style = "text-align: right;">1.309</td><td style = "text-align: right;">-0.498</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">12</td><td style = "text-align: right;">2001</td><td style = "text-align: right;">-0.498</td><td style = "text-align: right;">0.287</td><td style = "text-align: right;">1.303</td><td style = "text-align: right;">0.027</td><td style = "text-align: right;">-0.403</td><td style = "text-align: right;">1.258</td><td style = "text-align: right;">-0.189</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">13</td><td style = "text-align: right;">2001</td><td style = "text-align: right;">-0.189</td><td style = "text-align: right;">-0.498</td><td style = "text-align: right;">0.287</td><td style = "text-align: right;">1.303</td><td style = "text-align: right;">0.027</td><td style = "text-align: right;">1.098</td><td style = "text-align: right;">0.68</td></tr><tr><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1239</td><td style = "text-align: right;">2005</td><td style = "text-align: right;">0.555</td><td style = "text-align: right;">0.084</td><td style = "text-align: right;">0.281</td><td style = "text-align: right;">-0.122</td><td style = "text-align: right;">-0.501</td><td style = "text-align: right;">2.39002</td><td style = "text-align: right;">0.419</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1240</td><td style = "text-align: right;">2005</td><td style = "text-align: right;">0.419</td><td style = "text-align: right;">0.555</td><td style = "text-align: right;">0.084</td><td style = "text-align: right;">0.281</td><td style = "text-align: right;">-0.122</td><td style = "text-align: right;">2.14552</td><td style = "text-align: right;">-0.141</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1241</td><td style = "text-align: right;">2005</td><td style = "text-align: right;">-0.141</td><td style = "text-align: right;">0.419</td><td style = "text-align: right;">0.555</td><td style = "text-align: right;">0.084</td><td style = "text-align: right;">0.281</td><td style = "text-align: right;">2.18059</td><td style = "text-align: right;">-0.285</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1242</td><td style = "text-align: right;">2005</td><td style = "text-align: right;">-0.285</td><td style = "text-align: right;">-0.141</td><td style = "text-align: right;">0.419</td><td style = "text-align: right;">0.555</td><td style = "text-align: right;">0.084</td><td style = "text-align: right;">2.58419</td><td style = "text-align: right;">-0.584</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1243</td><td style = "text-align: right;">2005</td><td style = "text-align: right;">-0.584</td><td style = "text-align: right;">-0.285</td><td style = "text-align: right;">-0.141</td><td style = "text-align: right;">0.419</td><td style = "text-align: right;">0.555</td><td style = "text-align: right;">2.20881</td><td style = "text-align: right;">-0.024</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1244</td><td style = "text-align: right;">2005</td><td style = "text-align: right;">-0.024</td><td style = "text-align: right;">-0.584</td><td style = "text-align: right;">-0.285</td><td style = "text-align: right;">-0.141</td><td style = "text-align: right;">0.419</td><td style = "text-align: right;">1.99669</td><td style = "text-align: right;">0.252</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1245</td><td style = "text-align: right;">2005</td><td style = "text-align: right;">0.252</td><td style = "text-align: right;">-0.024</td><td style = "text-align: right;">-0.584</td><td style = "text-align: right;">-0.285</td><td style = "text-align: right;">-0.141</td><td style = "text-align: right;">2.06517</td><td style = "text-align: right;">0.422</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1246</td><td style = "text-align: right;">2005</td><td style = "text-align: right;">0.422</td><td style = "text-align: right;">0.252</td><td style = "text-align: right;">-0.024</td><td style = "text-align: right;">-0.584</td><td style = "text-align: right;">-0.285</td><td style = "text-align: right;">1.8885</td><td style = "text-align: right;">0.043</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1247</td><td style = "text-align: right;">2005</td><td style = "text-align: right;">0.043</td><td style = "text-align: right;">0.422</td><td style = "text-align: right;">0.252</td><td style = "text-align: right;">-0.024</td><td style = "text-align: right;">-0.584</td><td style = "text-align: right;">1.28581</td><td style = "text-align: right;">-0.955</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1248</td><td style = "text-align: right;">2005</td><td style = "text-align: right;">-0.955</td><td style = "text-align: right;">0.043</td><td style = "text-align: right;">0.422</td><td style = "text-align: right;">0.252</td><td style = "text-align: right;">-0.024</td><td style = "text-align: right;">1.54047</td><td style = "text-align: right;">0.13</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1249</td><td style = "text-align: right;">2005</td><td style = "text-align: right;">0.13</td><td style = "text-align: right;">-0.955</td><td style = "text-align: right;">0.043</td><td style = "text-align: right;">0.422</td><td style = "text-align: right;">0.252</td><td style = "text-align: right;">1.42236</td><td style = "text-align: right;">-0.298</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1250</td><td style = "text-align: right;">2005</td><td style = "text-align: right;">-0.298</td><td style = "text-align: right;">0.13</td><td style = "text-align: right;">-0.955</td><td style = "text-align: right;">0.043</td><td style = "text-align: right;">0.422</td><td style = "text-align: right;">1.38254</td><td style = "text-align: right;">-0.489</td></tr></tbody></table></div>



La variable objetivo se convirtió a objetos categóricos ordenados


```julia
# Convertir y a un objeto categórico ordenado
y = coerce(y, OrderedFactor)

typeof(y)
```




    CategoricalVector{Int64, UInt32, Int64, CategoricalValue{Int64, UInt32}, Union{}}[90m (alias for [39m[90mCategoricalArrays.CategoricalArray{Int64, 1, UInt32, Int64, CategoricalArrays.CategoricalValue{Int64, UInt32}, Union{}}[39m[90m)[39m



Se optó por eliminar las columnas **Year** y **Today** pues no representan una relación directa con las predicciones de **Direction**


```julia
# Eliminamos las columnas 'Year' y 'Today'
X2 = DataFrames.select(X, Not([:Year, :Today]))
```




<div><div style = "float: left;"><span>1250×6 DataFrame</span></div><div style = "float: right;"><span style = "font-style: italic;">1225 rows omitted</span></div><div style = "clear: both;"></div></div><div class = "data-frame" style = "overflow-x: scroll;"><table class = "data-frame" style = "margin-bottom: 6px;"><thead><tr class = "header"><th class = "rowNumber" style = "font-weight: bold; text-align: right;">Row</th><th style = "text-align: left;">Lag1</th><th style = "text-align: left;">Lag2</th><th style = "text-align: left;">Lag3</th><th style = "text-align: left;">Lag4</th><th style = "text-align: left;">Lag5</th><th style = "text-align: left;">Volume</th></tr><tr class = "subheader headerLastRow"><th class = "rowNumber" style = "font-weight: bold; text-align: right;"></th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th></tr></thead><tbody><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1</td><td style = "text-align: right;">0.381</td><td style = "text-align: right;">-0.192</td><td style = "text-align: right;">-2.624</td><td style = "text-align: right;">-1.055</td><td style = "text-align: right;">5.01</td><td style = "text-align: right;">1.1913</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">2</td><td style = "text-align: right;">0.959</td><td style = "text-align: right;">0.381</td><td style = "text-align: right;">-0.192</td><td style = "text-align: right;">-2.624</td><td style = "text-align: right;">-1.055</td><td style = "text-align: right;">1.2965</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">3</td><td style = "text-align: right;">1.032</td><td style = "text-align: right;">0.959</td><td style = "text-align: right;">0.381</td><td style = "text-align: right;">-0.192</td><td style = "text-align: right;">-2.624</td><td style = "text-align: right;">1.4112</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">4</td><td style = "text-align: right;">-0.623</td><td style = "text-align: right;">1.032</td><td style = "text-align: right;">0.959</td><td style = "text-align: right;">0.381</td><td style = "text-align: right;">-0.192</td><td style = "text-align: right;">1.276</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">5</td><td style = "text-align: right;">0.614</td><td style = "text-align: right;">-0.623</td><td style = "text-align: right;">1.032</td><td style = "text-align: right;">0.959</td><td style = "text-align: right;">0.381</td><td style = "text-align: right;">1.2057</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">6</td><td style = "text-align: right;">0.213</td><td style = "text-align: right;">0.614</td><td style = "text-align: right;">-0.623</td><td style = "text-align: right;">1.032</td><td style = "text-align: right;">0.959</td><td style = "text-align: right;">1.3491</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">7</td><td style = "text-align: right;">1.392</td><td style = "text-align: right;">0.213</td><td style = "text-align: right;">0.614</td><td style = "text-align: right;">-0.623</td><td style = "text-align: right;">1.032</td><td style = "text-align: right;">1.445</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">8</td><td style = "text-align: right;">-0.403</td><td style = "text-align: right;">1.392</td><td style = "text-align: right;">0.213</td><td style = "text-align: right;">0.614</td><td style = "text-align: right;">-0.623</td><td style = "text-align: right;">1.4078</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9</td><td style = "text-align: right;">0.027</td><td style = "text-align: right;">-0.403</td><td style = "text-align: right;">1.392</td><td style = "text-align: right;">0.213</td><td style = "text-align: right;">0.614</td><td style = "text-align: right;">1.164</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">10</td><td style = "text-align: right;">1.303</td><td style = "text-align: right;">0.027</td><td style = "text-align: right;">-0.403</td><td style = "text-align: right;">1.392</td><td style = "text-align: right;">0.213</td><td style = "text-align: right;">1.2326</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">11</td><td style = "text-align: right;">0.287</td><td style = "text-align: right;">1.303</td><td style = "text-align: right;">0.027</td><td style = "text-align: right;">-0.403</td><td style = "text-align: right;">1.392</td><td style = "text-align: right;">1.309</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">12</td><td style = "text-align: right;">-0.498</td><td style = "text-align: right;">0.287</td><td style = "text-align: right;">1.303</td><td style = "text-align: right;">0.027</td><td style = "text-align: right;">-0.403</td><td style = "text-align: right;">1.258</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">13</td><td style = "text-align: right;">-0.189</td><td style = "text-align: right;">-0.498</td><td style = "text-align: right;">0.287</td><td style = "text-align: right;">1.303</td><td style = "text-align: right;">0.027</td><td style = "text-align: right;">1.098</td></tr><tr><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1239</td><td style = "text-align: right;">0.555</td><td style = "text-align: right;">0.084</td><td style = "text-align: right;">0.281</td><td style = "text-align: right;">-0.122</td><td style = "text-align: right;">-0.501</td><td style = "text-align: right;">2.39002</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1240</td><td style = "text-align: right;">0.419</td><td style = "text-align: right;">0.555</td><td style = "text-align: right;">0.084</td><td style = "text-align: right;">0.281</td><td style = "text-align: right;">-0.122</td><td style = "text-align: right;">2.14552</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1241</td><td style = "text-align: right;">-0.141</td><td style = "text-align: right;">0.419</td><td style = "text-align: right;">0.555</td><td style = "text-align: right;">0.084</td><td style = "text-align: right;">0.281</td><td style = "text-align: right;">2.18059</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1242</td><td style = "text-align: right;">-0.285</td><td style = "text-align: right;">-0.141</td><td style = "text-align: right;">0.419</td><td style = "text-align: right;">0.555</td><td style = "text-align: right;">0.084</td><td style = "text-align: right;">2.58419</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1243</td><td style = "text-align: right;">-0.584</td><td style = "text-align: right;">-0.285</td><td style = "text-align: right;">-0.141</td><td style = "text-align: right;">0.419</td><td style = "text-align: right;">0.555</td><td style = "text-align: right;">2.20881</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1244</td><td style = "text-align: right;">-0.024</td><td style = "text-align: right;">-0.584</td><td style = "text-align: right;">-0.285</td><td style = "text-align: right;">-0.141</td><td style = "text-align: right;">0.419</td><td style = "text-align: right;">1.99669</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1245</td><td style = "text-align: right;">0.252</td><td style = "text-align: right;">-0.024</td><td style = "text-align: right;">-0.584</td><td style = "text-align: right;">-0.285</td><td style = "text-align: right;">-0.141</td><td style = "text-align: right;">2.06517</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1246</td><td style = "text-align: right;">0.422</td><td style = "text-align: right;">0.252</td><td style = "text-align: right;">-0.024</td><td style = "text-align: right;">-0.584</td><td style = "text-align: right;">-0.285</td><td style = "text-align: right;">1.8885</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1247</td><td style = "text-align: right;">0.043</td><td style = "text-align: right;">0.422</td><td style = "text-align: right;">0.252</td><td style = "text-align: right;">-0.024</td><td style = "text-align: right;">-0.584</td><td style = "text-align: right;">1.28581</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1248</td><td style = "text-align: right;">-0.955</td><td style = "text-align: right;">0.043</td><td style = "text-align: right;">0.422</td><td style = "text-align: right;">0.252</td><td style = "text-align: right;">-0.024</td><td style = "text-align: right;">1.54047</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1249</td><td style = "text-align: right;">0.13</td><td style = "text-align: right;">-0.955</td><td style = "text-align: right;">0.043</td><td style = "text-align: right;">0.422</td><td style = "text-align: right;">0.252</td><td style = "text-align: right;">1.42236</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1250</td><td style = "text-align: right;">-0.298</td><td style = "text-align: right;">0.13</td><td style = "text-align: right;">-0.955</td><td style = "text-align: right;">0.043</td><td style = "text-align: right;">0.422</td><td style = "text-align: right;">1.38254</td></tr></tbody></table></div>



A continuación, ajustamos un modelo de regresión logística para predecir la dirección


```julia
# Definir y entrenar el modelo LogisticClassifier
logistic_model = @load LogisticClassifier pkg=MLJLinearModels

# Crear una máquina con los datos completos (X2 y y)
logistic_machine = machine(logistic_model(), X2, y)

# Entrenar el modelo
StatsBase.fit!(logistic_machine)
```

    [36m[1m[ [22m[39m[36m[1mInfo: [22m[39mFor silent loading, specify `verbosity=0`. 


    import MLJLinearModels ✔


    [36m[1m[ [22m[39m[36m[1mInfo: [22m[39mTraining machine(LogisticClassifier(lambda = 2.220446049250313e-16, …), …).
    [36m[1m┌ [22m[39m[36m[1mInfo: [22m[39mSolver: LBFGS{Optim.Options{Float64, Nothing}, NamedTuple{(), Tuple{}}}
    [36m[1m│ [22m[39m  optim_options: Optim.Options{Float64, Nothing}
    [36m[1m└ [22m[39m  lbfgs_options: NamedTuple{(), Tuple{}} NamedTuple()





    trained Machine; caches model-specific representations of data
      model: LogisticClassifier(lambda = 2.220446049250313e-16, …)
      args: 
        1:	Source @312 ⏎ Table{AbstractVector{Continuous}}
        2:	Source @129 ⏎ AbstractVector{OrderedFactor{2}}





```julia
# Hacer predicciones en el conjunto completo
y_pred = MLJ.predict(logistic_machine, X2)
y_pred[1:3]  # Mostrar las primeras 3 predicciones
```




    3-element UnivariateFiniteVector{OrderedFactor{2}, Int64, UInt32, Float64}:
     UnivariateFinite{OrderedFactor{2}}(0=>0.493, 1=>0.507)
     UnivariateFinite{OrderedFactor{2}}(0=>0.519, 1=>0.481)
     UnivariateFinite{OrderedFactor{2}}(0=>0.519, 1=>0.481)




```julia
# Calcular la entropía cruzada
cross_entropy_value = cross_entropy(y_pred, y) |> mean
cross_entropy_rounded = round(cross_entropy_value, digits = 3)
```




    0.691




```julia
# Obtener las predicciones en modo clase
y_pred_mode = predict_mode(logistic_machine, X2)

# Calcular la matriz de confusión
cm = confusion_matrix(y_pred_mode, y)
```




              ┌─────────────┐
              │Ground Truth │
    ┌─────────┼──────┬──────┤
    │Predicted│  0   │  1   │
    ├─────────┼──────┼──────┤
    │    0    │ 145  │ 141  │
    ├─────────┼──────┼──────┤
    │    1    │ 457  │ 507  │
    └─────────┴──────┴──────┘





```julia
MLJ.auc(y_pred, y)
```




    0.5387391821500349




```julia
rc = roc_curve(y_pred, y)
plt=plot(rc, legend=false)
```




    
![svg](output_23_0.svg)
    



La regresión logística predijo correctamente el movimiento del mercado el 52,2% de las veces.

Se dividió el dataset en conjuntos de entrenamiento (antes de 2005) y prueba (2005 en adelante).


```julia
# Dividir datos en entrenamiento y prueba basados en el año
train_idx = data.Year .< 2005  # Antes de 2005
test_idx = data.Year .>= 2005  # 2005 en adelante

X_train = DataFrames.select(X[train_idx, :], Not([:Year, :Today]))
y_train = y[train_idx]

X_test = DataFrames.select(X[test_idx, :], Not([:Year, :Today]))
y_test = y[test_idx]

# Convertir y_train e y_test a factores ordenados
y_train = coerce(y_train, OrderedFactor)
y_test = coerce(y_test, OrderedFactor)

X_train
```




<div><div style = "float: left;"><span>998×6 DataFrame</span></div><div style = "float: right;"><span style = "font-style: italic;">973 rows omitted</span></div><div style = "clear: both;"></div></div><div class = "data-frame" style = "overflow-x: scroll;"><table class = "data-frame" style = "margin-bottom: 6px;"><thead><tr class = "header"><th class = "rowNumber" style = "font-weight: bold; text-align: right;">Row</th><th style = "text-align: left;">Lag1</th><th style = "text-align: left;">Lag2</th><th style = "text-align: left;">Lag3</th><th style = "text-align: left;">Lag4</th><th style = "text-align: left;">Lag5</th><th style = "text-align: left;">Volume</th></tr><tr class = "subheader headerLastRow"><th class = "rowNumber" style = "font-weight: bold; text-align: right;"></th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th></tr></thead><tbody><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1</td><td style = "text-align: right;">0.381</td><td style = "text-align: right;">-0.192</td><td style = "text-align: right;">-2.624</td><td style = "text-align: right;">-1.055</td><td style = "text-align: right;">5.01</td><td style = "text-align: right;">1.1913</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">2</td><td style = "text-align: right;">0.959</td><td style = "text-align: right;">0.381</td><td style = "text-align: right;">-0.192</td><td style = "text-align: right;">-2.624</td><td style = "text-align: right;">-1.055</td><td style = "text-align: right;">1.2965</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">3</td><td style = "text-align: right;">1.032</td><td style = "text-align: right;">0.959</td><td style = "text-align: right;">0.381</td><td style = "text-align: right;">-0.192</td><td style = "text-align: right;">-2.624</td><td style = "text-align: right;">1.4112</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">4</td><td style = "text-align: right;">-0.623</td><td style = "text-align: right;">1.032</td><td style = "text-align: right;">0.959</td><td style = "text-align: right;">0.381</td><td style = "text-align: right;">-0.192</td><td style = "text-align: right;">1.276</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">5</td><td style = "text-align: right;">0.614</td><td style = "text-align: right;">-0.623</td><td style = "text-align: right;">1.032</td><td style = "text-align: right;">0.959</td><td style = "text-align: right;">0.381</td><td style = "text-align: right;">1.2057</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">6</td><td style = "text-align: right;">0.213</td><td style = "text-align: right;">0.614</td><td style = "text-align: right;">-0.623</td><td style = "text-align: right;">1.032</td><td style = "text-align: right;">0.959</td><td style = "text-align: right;">1.3491</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">7</td><td style = "text-align: right;">1.392</td><td style = "text-align: right;">0.213</td><td style = "text-align: right;">0.614</td><td style = "text-align: right;">-0.623</td><td style = "text-align: right;">1.032</td><td style = "text-align: right;">1.445</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">8</td><td style = "text-align: right;">-0.403</td><td style = "text-align: right;">1.392</td><td style = "text-align: right;">0.213</td><td style = "text-align: right;">0.614</td><td style = "text-align: right;">-0.623</td><td style = "text-align: right;">1.4078</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9</td><td style = "text-align: right;">0.027</td><td style = "text-align: right;">-0.403</td><td style = "text-align: right;">1.392</td><td style = "text-align: right;">0.213</td><td style = "text-align: right;">0.614</td><td style = "text-align: right;">1.164</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">10</td><td style = "text-align: right;">1.303</td><td style = "text-align: right;">0.027</td><td style = "text-align: right;">-0.403</td><td style = "text-align: right;">1.392</td><td style = "text-align: right;">0.213</td><td style = "text-align: right;">1.2326</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">11</td><td style = "text-align: right;">0.287</td><td style = "text-align: right;">1.303</td><td style = "text-align: right;">0.027</td><td style = "text-align: right;">-0.403</td><td style = "text-align: right;">1.392</td><td style = "text-align: right;">1.309</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">12</td><td style = "text-align: right;">-0.498</td><td style = "text-align: right;">0.287</td><td style = "text-align: right;">1.303</td><td style = "text-align: right;">0.027</td><td style = "text-align: right;">-0.403</td><td style = "text-align: right;">1.258</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">13</td><td style = "text-align: right;">-0.189</td><td style = "text-align: right;">-0.498</td><td style = "text-align: right;">0.287</td><td style = "text-align: right;">1.303</td><td style = "text-align: right;">0.027</td><td style = "text-align: right;">1.098</td></tr><tr><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">987</td><td style = "text-align: right;">0.392</td><td style = "text-align: right;">0.899</td><td style = "text-align: right;">-0.104</td><td style = "text-align: right;">0.544</td><td style = "text-align: right;">0.488</td><td style = "text-align: right;">1.5444</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">988</td><td style = "text-align: right;">0.194</td><td style = "text-align: right;">0.392</td><td style = "text-align: right;">0.899</td><td style = "text-align: right;">-0.104</td><td style = "text-align: right;">0.544</td><td style = "text-align: right;">1.6958</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">989</td><td style = "text-align: right;">-0.208</td><td style = "text-align: right;">0.194</td><td style = "text-align: right;">0.392</td><td style = "text-align: right;">0.899</td><td style = "text-align: right;">-0.104</td><td style = "text-align: right;">1.7939</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">990</td><td style = "text-align: right;">-0.749</td><td style = "text-align: right;">-0.208</td><td style = "text-align: right;">0.194</td><td style = "text-align: right;">0.392</td><td style = "text-align: right;">0.899</td><td style = "text-align: right;">2.335</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">991</td><td style = "text-align: right;">0.038</td><td style = "text-align: right;">-0.749</td><td style = "text-align: right;">-0.208</td><td style = "text-align: right;">0.194</td><td style = "text-align: right;">0.392</td><td style = "text-align: right;">1.4228</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">992</td><td style = "text-align: right;">0.904</td><td style = "text-align: right;">0.038</td><td style = "text-align: right;">-0.749</td><td style = "text-align: right;">-0.208</td><td style = "text-align: right;">0.194</td><td style = "text-align: right;">1.4837</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">993</td><td style = "text-align: right;">0.342</td><td style = "text-align: right;">0.904</td><td style = "text-align: right;">0.038</td><td style = "text-align: right;">-0.749</td><td style = "text-align: right;">-0.208</td><td style = "text-align: right;">1.3908</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">994</td><td style = "text-align: right;">0.046</td><td style = "text-align: right;">0.342</td><td style = "text-align: right;">0.904</td><td style = "text-align: right;">0.038</td><td style = "text-align: right;">-0.749</td><td style = "text-align: right;">0.9561</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">995</td><td style = "text-align: right;">-0.431</td><td style = "text-align: right;">0.046</td><td style = "text-align: right;">0.342</td><td style = "text-align: right;">0.904</td><td style = "text-align: right;">0.038</td><td style = "text-align: right;">0.922</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">996</td><td style = "text-align: right;">0.715</td><td style = "text-align: right;">-0.431</td><td style = "text-align: right;">0.046</td><td style = "text-align: right;">0.342</td><td style = "text-align: right;">0.904</td><td style = "text-align: right;">0.983</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">997</td><td style = "text-align: right;">-0.007</td><td style = "text-align: right;">0.715</td><td style = "text-align: right;">-0.431</td><td style = "text-align: right;">0.046</td><td style = "text-align: right;">0.342</td><td style = "text-align: right;">0.9259</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">998</td><td style = "text-align: right;">0.008</td><td style = "text-align: right;">-0.007</td><td style = "text-align: right;">0.715</td><td style = "text-align: right;">-0.431</td><td style = "text-align: right;">0.046</td><td style = "text-align: right;">0.8298</td></tr></tbody></table></div>



Ahora ajustamos un modelo de regresión logística utilizando solo el subconjunto de las observaciones que corresponden a fechas anteriores a 2005. Luego obtenemos las probabilidades pronosticadas de que el mercado de valores suba para cada uno de los días en nuestro conjunto de prueba, es decir, para los días de 2005.


```julia
logistic_machine = machine(logistic_model(), X_train, y_train)
StatsBase.fit!(logistic_machine)
```

    [36m[1m[ [22m[39m[36m[1mInfo: [22m[39mTraining machine(LogisticClassifier(lambda = 2.220446049250313e-16, …), …).
    [36m[1m┌ [22m[39m[36m[1mInfo: [22m[39mSolver: LBFGS{Optim.Options{Float64, Nothing}, NamedTuple{(), Tuple{}}}
    [36m[1m│ [22m[39m  optim_options: Optim.Options{Float64, Nothing}
    [36m[1m└ [22m[39m  lbfgs_options: NamedTuple{(), Tuple{}} NamedTuple()





    trained Machine; caches model-specific representations of data
      model: LogisticClassifier(lambda = 2.220446049250313e-16, …)
      args: 
        1:	Source @259 ⏎ Table{AbstractVector{Continuous}}
        2:	Source @022 ⏎ AbstractVector{OrderedFactor{2}}





```julia
# Predicciones en el conjunto de prueba
y_pred_test = MLJ.predict(logistic_machine, X_test)
y_pred_mode_test = predict_mode(logistic_machine, X_test)
```




    252-element CategoricalArrays.CategoricalArray{Int64,1,UInt32}:
     1
     1
     1
     1
     0
     1
     1
     1
     1
     1
     1
     0
     1
     ⋮
     0
     0
     0
     0
     0
     0
     0
     0
     1
     1
     1
     1




```julia
cm_test = confusion_matrix(y_pred_mode_test, y_test)
```




              ┌─────────────┐
              │Ground Truth │
    ┌─────────┼──────┬──────┤
    │Predicted│  0   │  1   │
    ├─────────┼──────┼──────┤
    │    0    │  77  │  97  │
    ├─────────┼──────┼──────┤
    │    1    │  34  │  44  │
    └─────────┴──────┴──────┘





```julia
# Curva ROC y AUC
rc_test = roc_curve(y_pred_test, y_test)
plot(rc_test, legend=false, xlabel="False Positive Rate", ylabel="True Positive Rate", title="ROC Curve")
```




    
![svg](output_30_0.svg)
    




```julia
auc_test = MLJ.auc(y_pred_test, y_test)
println("AUC: ", round(auc_test, digits=3))
```

    AUC: 0.52


La precisión de la prueba es de aproximadamente el 48%, mientras que la tasa de error es de aproximadamente el 52%.

Se optó por eliminar las variables que parecen no ser útiles para predecir la Dirección, con el objetivo de obtener un modelo más efectivo. Pues el uso de predictores que no tienen ninguna relación con la respuesta tiende a causar un deterioro en la tasa de
error de la prueba (ya que dichos predictores causan un aumento en la varianza sin una
disminución correspondiente en el sesgo), por lo que la eliminación de dichos predictores puede, a su vez, producir una mejora. A continuación, reajustamos la regresión logística utilizando solo **Lag1** y **Lag2**, que parecían tener el mayor poder predictivo en el
modelo de regresión logística original.


```julia
X_train = DataFrames.select(X_train, [:Lag1, :Lag2])
X_test = DataFrames.select(X_test, [:Lag1, :Lag2])
```




<div><div style = "float: left;"><span>252×2 DataFrame</span></div><div style = "float: right;"><span style = "font-style: italic;">227 rows omitted</span></div><div style = "clear: both;"></div></div><div class = "data-frame" style = "overflow-x: scroll;"><table class = "data-frame" style = "margin-bottom: 6px;"><thead><tr class = "header"><th class = "rowNumber" style = "font-weight: bold; text-align: right;">Row</th><th style = "text-align: left;">Lag1</th><th style = "text-align: left;">Lag2</th></tr><tr class = "subheader headerLastRow"><th class = "rowNumber" style = "font-weight: bold; text-align: right;"></th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th></tr></thead><tbody><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1</td><td style = "text-align: right;">-0.134</td><td style = "text-align: right;">0.008</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">2</td><td style = "text-align: right;">-0.812</td><td style = "text-align: right;">-0.134</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">3</td><td style = "text-align: right;">-1.167</td><td style = "text-align: right;">-0.812</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">4</td><td style = "text-align: right;">-0.363</td><td style = "text-align: right;">-1.167</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">5</td><td style = "text-align: right;">0.351</td><td style = "text-align: right;">-0.363</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">6</td><td style = "text-align: right;">-0.143</td><td style = "text-align: right;">0.351</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">7</td><td style = "text-align: right;">0.342</td><td style = "text-align: right;">-0.143</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">8</td><td style = "text-align: right;">-0.61</td><td style = "text-align: right;">0.342</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9</td><td style = "text-align: right;">0.398</td><td style = "text-align: right;">-0.61</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">10</td><td style = "text-align: right;">-0.863</td><td style = "text-align: right;">0.398</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">11</td><td style = "text-align: right;">0.6</td><td style = "text-align: right;">-0.863</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">12</td><td style = "text-align: right;">0.967</td><td style = "text-align: right;">0.6</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">13</td><td style = "text-align: right;">-0.949</td><td style = "text-align: right;">0.967</td></tr><tr><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">241</td><td style = "text-align: right;">0.555</td><td style = "text-align: right;">0.084</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">242</td><td style = "text-align: right;">0.419</td><td style = "text-align: right;">0.555</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">243</td><td style = "text-align: right;">-0.141</td><td style = "text-align: right;">0.419</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">244</td><td style = "text-align: right;">-0.285</td><td style = "text-align: right;">-0.141</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">245</td><td style = "text-align: right;">-0.584</td><td style = "text-align: right;">-0.285</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">246</td><td style = "text-align: right;">-0.024</td><td style = "text-align: right;">-0.584</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">247</td><td style = "text-align: right;">0.252</td><td style = "text-align: right;">-0.024</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">248</td><td style = "text-align: right;">0.422</td><td style = "text-align: right;">0.252</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">249</td><td style = "text-align: right;">0.043</td><td style = "text-align: right;">0.422</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">250</td><td style = "text-align: right;">-0.955</td><td style = "text-align: right;">0.043</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">251</td><td style = "text-align: right;">0.13</td><td style = "text-align: right;">-0.955</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">252</td><td style = "text-align: right;">-0.298</td><td style = "text-align: right;">0.13</td></tr></tbody></table></div>




```julia
size(X_train)
```




    (998, 2)



Se balancearon las clases en el conjunto de entrenamiento utilizando la función de balance_classes y se aplicó **escalado de características** usando `Standardizer()`.


```julia
function balance_classes(X, y)
    # Identificar índices de la clase minoritaria
    minority_idx = findall(y .== 1)
    n_to_add = length(y) - 2 * length(minority_idx)

    # Duplicar instancias de la clase minoritaria
    X_balanced = vcat(X, X[minority_idx[1:n_to_add], :])
    y_balanced = vcat(y, y[minority_idx[1:n_to_add]])

    return X_balanced, y_balanced
end
```




    balance_classes (generic function with 1 method)




```julia
# Aplicar SMOTE para balancear las clases
println("Balanceando las clases usando SMOTE...")
# Balancear las clases
X_train_balanced, y_train = balance_classes(X_train, y_train)
println("Datos balanceados: ", size(X_train_balanced))
println(typeof(X_train_balanced))
println(schema(X_train_balanced))

# Escalar las características (feature scaling)
println("Aplicando feature scaling...")
standardizer_model = Standardizer(count=true)

X_train = MLJ.transform(StatsBase.fit!(machine(standardizer_model, X_train_balanced)), X_train_balanced)
X_test = MLJ.transform(StatsBase.fit!(machine(standardizer_model, X_train_balanced)), X_test)

```

    Balanceando las clases usando SMOTE...
    Datos balanceados: (998, 2)
    DataFrame
    ScientificTypes.Schema{(:Lag1, :Lag2), Tuple{Continuous, Continuous}, Tuple{Float64, Float64}}(nothing, nothing, nothing)
    Aplicando feature scaling...


    [36m[1m[ [22m[39m[36m[1mInfo: [22m[39mTraining machine(Standardizer(features = Symbol[], …), …).
    [36m[1m[ [22m[39m[36m[1mInfo: [22m[39mTraining machine(Standardizer(features = Symbol[], …), …).





<div><div style = "float: left;"><span>252×2 DataFrame</span></div><div style = "float: right;"><span style = "font-style: italic;">227 rows omitted</span></div><div style = "clear: both;"></div></div><div class = "data-frame" style = "overflow-x: scroll;"><table class = "data-frame" style = "margin-bottom: 6px;"><thead><tr class = "header"><th class = "rowNumber" style = "font-weight: bold; text-align: right;">Row</th><th style = "text-align: left;">Lag1</th><th style = "text-align: left;">Lag2</th></tr><tr class = "subheader headerLastRow"><th class = "rowNumber" style = "font-weight: bold; text-align: right;"></th><th title = "Float64" style = "text-align: left;">Float64</th><th title = "Float64" style = "text-align: left;">Float64</th></tr></thead><tbody><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">1</td><td style = "text-align: right;">-0.109755</td><td style = "text-align: right;">0.00588647</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">2</td><td style = "text-align: right;">-0.661124</td><td style = "text-align: right;">-0.109591</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">3</td><td style = "text-align: right;">-0.949821</td><td style = "text-align: right;">-0.660953</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">4</td><td style = "text-align: right;">-0.295984</td><td style = "text-align: right;">-0.949646</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">5</td><td style = "text-align: right;">0.284661</td><td style = "text-align: right;">-0.295818</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">6</td><td style = "text-align: right;">-0.117074</td><td style = "text-align: right;">0.284821</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">7</td><td style = "text-align: right;">0.277342</td><td style = "text-align: right;">-0.11691</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">8</td><td style = "text-align: right;">-0.496852</td><td style = "text-align: right;">0.277502</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">9</td><td style = "text-align: right;">0.322883</td><td style = "text-align: right;">-0.496683</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">10</td><td style = "text-align: right;">-0.702599</td><td style = "text-align: right;">0.323042</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">11</td><td style = "text-align: right;">0.487155</td><td style = "text-align: right;">-0.702428</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">12</td><td style = "text-align: right;">0.78561</td><td style = "text-align: right;">0.487312</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">13</td><td style = "text-align: right;">-0.772537</td><td style = "text-align: right;">0.785764</td></tr><tr><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td><td style = "text-align: right;">&vellip;</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">241</td><td style = "text-align: right;">0.45056</td><td style = "text-align: right;">0.0676911</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">242</td><td style = "text-align: right;">0.339961</td><td style = "text-align: right;">0.450717</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">243</td><td style = "text-align: right;">-0.115448</td><td style = "text-align: right;">0.34012</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">244</td><td style = "text-align: right;">-0.232553</td><td style = "text-align: right;">-0.115283</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">245</td><td style = "text-align: right;">-0.475708</td><td style = "text-align: right;">-0.232387</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">246</td><td style = "text-align: right;">-0.0202998</td><td style = "text-align: right;">-0.475539</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">247</td><td style = "text-align: right;">0.204152</td><td style = "text-align: right;">-0.0201365</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">248</td><td style = "text-align: right;">0.3424</td><td style = "text-align: right;">0.204312</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">249</td><td style = "text-align: right;">0.0341866</td><td style = "text-align: right;">0.342559</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">250</td><td style = "text-align: right;">-0.777416</td><td style = "text-align: right;">0.0343491</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">251</td><td style = "text-align: right;">0.104938</td><td style = "text-align: right;">-0.777244</td></tr><tr><td class = "rowNumber" style = "font-weight: bold; text-align: right;">252</td><td style = "text-align: right;">-0.243125</td><td style = "text-align: right;">0.105099</td></tr></tbody></table></div>




```julia
# Diccionario para guardar los resultados de las curvas ROC
roc_curves = Dict{String, Any}()
```




    Dict{String, Any}()



## Modelos Entrenados
Se entrenaron los siguientes modelos de clasificación:

- **Regresión Logística**
- **LASSO (Logistic Regression con penalización L1)**
- **Ridge (Logistic Regression con penalización L2)**
- **Elastic Net**
- **Árbol de Decisión**
- **Random Forest**
- **KNN (K-Nearest Neighbors)**
- **SVM Lineal**
- **SVM con kernel RBF**

Para evaluar la efectividad de los modelos se calcularon diversas métricas de evaluación.

Las métricas registradas para cada modelo incluyen:

- **Accuracy**
- **Precision**
- **Recall**
- **AUC (Area Under the ROC Curve)**


```julia
logistic_machine = machine(logistic_model(), X_train, y_train)
StatsBase.fit!(logistic_machine)
```

    [36m[1m[ [22m[39m[36m[1mInfo: [22m[39mTraining machine(LogisticClassifier(lambda = 2.220446049250313e-16, …), …).
    [36m[1m┌ [22m[39m[36m[1mInfo: [22m[39mSolver: LBFGS{Optim.Options{Float64, Nothing}, NamedTuple{(), Tuple{}}}
    [36m[1m│ [22m[39m  optim_options: Optim.Options{Float64, Nothing}
    [36m[1m└ [22m[39m  lbfgs_options: NamedTuple{(), Tuple{}} NamedTuple()





    trained Machine; caches model-specific representations of data
      model: LogisticClassifier(lambda = 2.220446049250313e-16, …)
      args: 
        1:	Source @449 ⏎ Table{AbstractVector{Continuous}}
        2:	Source @730 ⏎ AbstractVector{OrderedFactor{2}}





```julia
# Predicciones en el conjunto de prueba
y_pred_test = MLJ.predict(logistic_machine, X_test)
y_pred_mode_test = predict_mode(logistic_machine, X_test)
```




    252-element CategoricalArrays.CategoricalArray{Int64,1,UInt32}:
     1
     1
     1
     1
     1
     1
     1
     1
     1
     1
     1
     0
     1
     ⋮
     0
     0
     1
     1
     1
     1
     1
     0
     1
     1
     1
     1




```julia
cm_test = confusion_matrix(y_pred_mode_test, y_test)
```




              ┌─────────────┐
              │Ground Truth │
    ┌─────────┼──────┬──────┤
    │Predicted│  0   │  1   │
    ├─────────┼──────┼──────┤
    │    0    │  35  │  35  │
    ├─────────┼──────┼──────┤
    │    1    │  76  │ 106  │
    └─────────┴──────┴──────┘





```julia
metrics_dict = Dict{String, Dict{String, Float64}}()

# Evaluación del modelo
println("Evaluando el modelo...")
cm = confusion_matrix(y_pred_mode_test, y_test)
accuracy_value = accuracy(y_pred_mode_test, y_test)  
precision_value = StatisticalMeasures.precision(y_pred_mode_test, y_test)
recall_value = recall(y_pred_mode_test, y_test)

println("Matriz de confusión:")
println(cm)

println("\nMétricas de evaluación:")
println("Accuracy: ", round(accuracy_value, digits=3)) 
println("Precision: ", round(precision_value, digits=3))
println("Recall: ", round(recall_value, digits=3))

# Guardar métricas para comparación posterior
metrics = Dict(
    "Accuracy" => round(accuracy_value, digits=3),
    "Precision" => round(precision_value, digits=3),
    "Recall" => round(recall_value, digits=3)
)
```

    Evaluando el modelo...
    Matriz de confusión:
    ConfusionMatrix{2}([35 35; 76 106])
    
    Métricas de evaluación:
    Accuracy: 0.56
    Precision: 0.582
    Recall: 0.752





    Dict{String, Float64} with 3 entries:
      "Accuracy"  => 0.56
      "Precision" => 0.582
      "Recall"    => 0.752




```julia
# Curva ROC y AUC
rc_test = roc_curve(y_pred_test, y_test)
plot(rc_test, legend=false, xlabel="False Positive Rate", ylabel="True Positive Rate", title="Logistic Classification ROC Curve")
```




    
![svg](output_46_0.svg)
    




```julia
auc_value = auc(y_pred_test, y_test)
println("AUC: ", round(auc_value, digits=3))

# Agregar AUC al diccionario
metrics["AUC"] = round(auc_value, digits=3)

metrics_dict["Logistic Classification"] = metrics

roc_curves["Logistic Classification"] = (rc_test, auc_value)
# Mostrar las métricas
println("Métricas guardadas: ", metrics_dict)
```

    AUC: 0.558
    Dict("Logistic Classification" => Dict("Accuracy" => 0.56, "Precision" => 0.582, "Recall" => 0.752, "AUC" => 0.558))



```julia
# Definir y entrenar el modelo LASSO
println("Entrenando modelo LASSO...")
log_reg_lasso = LogisticClassifier(lambda=0.01, penalty=:l1)
machine_log_reg_lasso = machine(log_reg_lasso, X_train, y_train)
StatsBase.fit!(machine_log_reg_lasso)

# Predicciones en el conjunto de prueba
y_pred_lasso = predict_mode(machine_log_reg_lasso, X_test)
```

    Entrenando modelo LASSO...


    [36m[1m[ [22m[39m[36m[1mInfo: [22m[39mTraining machine(LogisticClassifier(lambda = 0.01, …), …).
    [36m[1m┌ [22m[39m[36m[1mInfo: [22m[39mSolver: ProxGrad
    [36m[1m│ [22m[39m  accel: Bool true
    [36m[1m│ [22m[39m  max_iter: Int64 1000
    [36m[1m│ [22m[39m  tol: Float64 0.0001
    [36m[1m│ [22m[39m  max_inner: Int64 100
    [36m[1m│ [22m[39m  beta: Float64 0.8
    [36m[1m└ [22m[39m  gram: Bool false





    252-element CategoricalArrays.CategoricalArray{Int64,1,UInt32}:
     1
     1
     1
     1
     1
     1
     1
     1
     1
     1
     1
     1
     1
     ⋮
     1
     1
     1
     1
     1
     1
     1
     1
     1
     1
     1
     1




```julia
# Evaluación del modelo
println("Evaluando el modelo LASSO...")
cm = confusion_matrix(y_pred_lasso, y_test)
accuracy_lasso = MLJBase.accuracy(y_pred_lasso, y_test)  
precision_lasso = StatisticalMeasures.precision(y_pred_lasso, y_test)
recall_lasso = recall(y_pred_lasso, y_test)

println("Matriz de confusión:")
println(cm)

println("\nMétricas de evaluación:")
println("Accuracy: ", round(accuracy_lasso, digits=3)) 
println("Precision: ", round(precision_lasso, digits=3))
println("Recall: ", round(recall_lasso, digits=3))

# Guardar métricas para comparación posterior
lasso_metrics = Dict(
    "Accuracy" => round(accuracy_lasso, digits=3),
    "Precision" => round(precision_lasso, digits=3),
    "Recall" => round(recall_lasso, digits=3)
)
```

    Evaluando el modelo LASSO...
    Matriz de confusión:
    ConfusionMatrix{2}([2 0; 109 141])
    
    Métricas de evaluación:
    Accuracy: 0.567
    Precision: 0.564
    Recall: 1.0





    Dict{String, Float64} with 3 entries:
      "Accuracy"  => 0.567
      "Precision" => 0.564
      "Recall"    => 1.0




```julia
cm
```




              ┌─────────────┐
              │Ground Truth │
    ┌─────────┼──────┬──────┤
    │Predicted│  0   │  1   │
    ├─────────┼──────┼──────┤
    │    0    │  2   │  0   │
    ├─────────┼──────┼──────┤
    │    1    │ 109  │ 141  │
    └─────────┴──────┴──────┘





```julia
# Curva ROC y AUC
println("Graficando curva ROC...")
y_prob_lasso = MLJ.predict(machine_log_reg_lasso, X_test)
rc = roc_curve(y_prob_lasso, y_test)
plot(rc, legend=false, xlabel="False Positive Rate", ylabel="True Positive Rate", title="LASSO ROC Curve")
```

    Graficando curva ROC...





    
![svg](output_51_1.svg)
    




```julia
auc_lasso = auc(y_prob_lasso, y_test)
println("AUC: ", round(auc_value, digits=3))

# Agregar AUC al diccionario
lasso_metrics["AUC"] = round(auc_lasso, digits=3)

metrics_dict["LASSO"] = lasso_metrics

roc_curves["LASSO"] = (rc, auc_lasso)
# Mostrar las métricas
println("Métricas guardadas: ", lasso_metrics)
```

    AUC: 0.558
    Dict("Accuracy" => 0.567, "Precision" => 0.564, "Recall" => 1.0, "AUC" => 0.563)



```julia
# Definir y entrenar el modelo Ridge
println("Entrenando modelo Ridge...")
ridge_model = LogisticClassifier(lambda=0.1, penalty=:l2)  # Penalización L2
machine_ridge = machine(ridge_model, X_train, y_train)
StatsBase.fit!(machine_ridge)
```

    Entrenando modelo Ridge...


    [36m[1m[ [22m[39m[36m[1mInfo: [22m[39mTraining machine(LogisticClassifier(lambda = 0.1, …), …).
    [36m[1m┌ [22m[39m[36m[1mInfo: [22m[39mSolver: LBFGS{Optim.Options{Float64, Nothing}, NamedTuple{(), Tuple{}}}
    [36m[1m│ [22m[39m  optim_options: Optim.Options{Float64, Nothing}
    [36m[1m└ [22m[39m  lbfgs_options: NamedTuple{(), Tuple{}} NamedTuple()





    trained Machine; caches model-specific representations of data
      model: LogisticClassifier(lambda = 0.1, …)
      args: 
        1:	Source @872 ⏎ Table{AbstractVector{Continuous}}
        2:	Source @361 ⏎ AbstractVector{OrderedFactor{2}}





```julia
#Predicciones en el conjunto de prueba
y_pred_test_ridge = predict_mode(machine_ridge, X_test)

# Evaluación del modelo
println("Evaluando el modelo Ridge...")
accuracy_ridge = MLJBase.accuracy(y_pred_test_ridge, y_test)
precision_ridge = StatisticalMeasures.precision(y_pred_test_ridge, y_test)
recall_ridge = MLJBase.recall(y_pred_test_ridge, y_test)

println("Matriz de confusión:")
println(confusion_matrix(y_pred_test_ridge, y_test))

println("\nMétricas de evaluación Ridge:")
println("Accuracy: ", round(accuracy_ridge, digits=3))
println("Precision: ", round(precision_ridge, digits=3))
println("Recall: ", round(recall_ridge, digits=3))

# Guardar métricas para comparación posterior
metrics_ridge = Dict(
    "Accuracy" => round(accuracy_ridge, digits=3),
    "Precision" => round(precision_ridge, digits=3),
    "Recall" => round(recall_ridge, digits=3)
)

```

    Evaluando el modelo Ridge...
    Matriz de confusión:
    ConfusionMatrix{2}([26 18; 85 123])
    
    Métricas de evaluación Ridge:
    Accuracy: 0.591
    Precision: 0.591
    Recall: 0.872





    Dict{String, Float64} with 3 entries:
      "Accuracy"  => 0.591
      "Precision" => 0.591
      "Recall"    => 0.872




```julia
# Curva ROC y AUC
println("Graficando curva ROC para Ridge...")
y_prob_ridge = MLJBase.predict(machine_ridge, X_test)
roc_ridge = MLJBase.roc_curve(y_prob_ridge, y_test)
plot(roc_ridge, xlabel="False Positive Rate", ylabel="True Positive Rate", 
     legend=false, title="Ridge ROC Curve")
```

    Graficando curva ROC para Ridge...





    
![svg](output_55_1.svg)
    




```julia
auc_ridge = auc(y_prob_ridge, y_test)
println("AUC: ", round(auc_ridge, digits=3))

# Agregar AUC a las métricas
metrics_ridge["AUC"] = round(auc_ridge, digits=3)

metrics_dict["Ridge"] = metrics_ridge

roc_curves["Ridge"] = (roc_ridge, auc_ridge)

# Mostrar las métricas
println("Métricas guardadas: ", metrics_ridge)
```

    AUC: 0.558
    Métricas guardadas: Dict("Accuracy" => 0.591, "Precision" => 0.591, "Recall" => 0.872, "AUC" => 0.558)



```julia
# Definir y entrenar el modelo Elastic Net
println("Entrenando modelo Elastic Net...")
elastic_net_model = LogisticClassifier(lambda=0.01, gamma=0.01, penalty=:en)  # Elastic Net con L2 y L1
machine_elastic_net = machine(elastic_net_model, X_train, y_train)
StatsBase.fit!(machine_elastic_net)
```

    Entrenando modelo Elastic Net...


    [36m[1m[ [22m[39m[36m[1mInfo: [22m[39mTraining machine(LogisticClassifier(lambda = 0.01, …), …).
    [36m[1m┌ [22m[39m[36m[1mInfo: [22m[39mSolver: ProxGrad
    [36m[1m│ [22m[39m  accel: Bool true
    [36m[1m│ [22m[39m  max_iter: Int64 1000
    [36m[1m│ [22m[39m  tol: Float64 0.0001
    [36m[1m│ [22m[39m  max_inner: Int64 100
    [36m[1m│ [22m[39m  beta: Float64 0.8
    [36m[1m└ [22m[39m  gram: Bool false





    trained Machine; caches model-specific representations of data
      model: LogisticClassifier(lambda = 0.01, …)
      args: 
        1:	Source @142 ⏎ Table{AbstractVector{Continuous}}
        2:	Source @550 ⏎ AbstractVector{OrderedFactor{2}}





```julia
# Predicciones en el conjunto de prueba
y_pred_test_en = predict_mode(machine_elastic_net, X_test)

# Evaluación del modelo
println("Evaluando el modelo Elastic Net...")
accuracy_en = MLJBase.accuracy(y_pred_test_en, y_test)
precision_en = StatisticalMeasures.precision(y_pred_test_en, y_test)
recall_en = MLJBase.recall(y_pred_test_en, y_test)

println("Matriz de confusión:")
println(confusion_matrix(y_pred_test_en, y_test))

println("\nMétricas de evaluación Elastic Net:")
println("Accuracy: ", round(accuracy_en, digits=3))
println("Precision: ", round(precision_en, digits=3))
println("Recall: ", round(recall_en, digits=3))

# Guardar métricas para comparación posterior
metrics_en = Dict(
    "Accuracy" => round(accuracy_en, digits=3),
    "Precision" => round(precision_en, digits=3),
    "Recall" => round(recall_en, digits=3)
)
```

    Evaluando el modelo Elastic Net...
    Matriz de confusión:
    ConfusionMatrix{2}([2 0; 109 141])
    
    Métricas de evaluación Elastic Net:
    Accuracy: 0.567
    Precision: 0.564
    Recall: 1.0





    Dict{String, Float64} with 3 entries:
      "Accuracy"  => 0.567
      "Precision" => 0.564
      "Recall"    => 1.0




```julia
# Curva ROC y AUC
println("Graficando curva ROC para Elastic Net...")
y_prob_en = MLJBase.predict(machine_elastic_net, X_test)
roc_en = MLJBase.roc_curve(y_prob_en, y_test)
plot(roc_en, xlabel="False Positive Rate", ylabel="True Positive Rate", 
     legend=false, title="Elastic Net ROC Curve")
```

    Graficando curva ROC para Elastic Net...





    
![svg](output_59_1.svg)
    




```julia
auc_en = auc(y_prob_en, y_test)
println("AUC: ", round(auc_en, digits=3))

# Agregar AUC a las métricas
metrics_en["AUC"] = round(auc_en, digits=3)

metrics_dict["Elastic Net"] = metrics_en

roc_curves["Elastic Net"] = (roc_en, auc_en)

# Mostrar métricas guardadas
println("Métricas guardadas para Elastic Net: ", metrics_en)
```

    AUC: 0.563
    Métricas guardadas para Elastic Net: Dict("Accuracy" => 0.567, "Precision" => 0.564, "Recall" => 1.0, "AUC" => 0.563)



```julia
# Definir y entrenar el modelo Decision Tree
println("Entrenando modelo Decision Tree...")
tree_model = DecisionTreeClassifier(max_depth=3, min_samples_split=5, min_samples_leaf=2)
machine_tree = machine(tree_model, X_train, y_train)
StatsBase.fit!(machine_tree)

```

    Entrenando modelo Decision Tree...


    [36m[1m[ [22m[39m[36m[1mInfo: [22m[39mTraining machine(DecisionTreeClassifier(max_depth = 3, …), …).





    trained Machine; caches model-specific representations of data
      model: DecisionTreeClassifier(max_depth = 3, …)
      args: 
        1:	Source @795 ⏎ Table{AbstractVector{Continuous}}
        2:	Source @041 ⏎ AbstractVector{OrderedFactor{2}}





```julia
# Predicciones en el conjunto de prueba
y_pred_test_tree = predict_mode(machine_tree, X_test)

# Evaluación del modelo
println("Evaluando el modelo Decision Tree...")
accuracy_tree = MLJBase.accuracy(y_pred_test_tree, y_test)
precision_tree = StatisticalMeasures.precision(y_pred_test_tree, y_test)
recall_tree = MLJBase.recall(y_pred_test_tree, y_test)

println("Matriz de confusión:")
println(confusion_matrix(y_pred_test_tree, y_test))

println("\nMétricas de evaluación Decision Tree:")
println("Accuracy: ", round(accuracy_tree, digits=3))
println("Precision: ", round(precision_tree, digits=3))
println("Recall: ", round(recall_tree, digits=3))

# Guardar métricas para comparación posterior
metrics_tree = Dict(
    "Accuracy" => round(accuracy_tree, digits=3),
    "Precision" => round(precision_tree, digits=3),
    "Recall" => round(recall_tree, digits=3)
)
```

    Evaluando el modelo Decision Tree...
    Matriz de confusión:
    ConfusionMatrix{2}([62 66; 49 75])
    
    Métricas de evaluación Decision Tree:
    Accuracy: 0.544
    Precision: 0.605
    Recall: 0.532





    Dict{String, Float64} with 3 entries:
      "Accuracy"  => 0.544
      "Precision" => 0.605
      "Recall"    => 0.532




```julia
# Curva ROC y AUC
println("Graficando curva ROC para Decision Tree...")
y_prob_tree = MLJBase.predict(machine_tree, X_test)
roc_tree = MLJBase.roc_curve(y_prob_tree, y_test)
plot(roc_tree, xlabel="False Positive Rate", ylabel="True Positive Rate", 
     legend=false, title="Decision Tree ROC Curve")
```

    Graficando curva ROC para Decision Tree...





    
![svg](output_63_1.svg)
    




```julia
auc_tree = MLJBase.auc(y_prob_tree, y_test)
println("AUC: ", round(auc_tree, digits=3))

# Agregar AUC a las métricas
metrics_tree["AUC"] = round(auc_tree, digits=3)

metrics_dict["Decision Tree"] = metrics_tree

roc_curves["Decision Tree"] = (rc_test, auc_value)

# Mostrar las métricas
println("Métricas guardadas: ", metrics_tree)
```

    AUC: 0.53
    Métricas guardadas: Dict("Accuracy" => 0.544, "Precision" => 0.605, "Recall" => 0.532, "AUC" => 0.53)



```julia
# Definir y entrenar el modelo Random Forest
println("Entrenando modelo Random Forest...")
rf_model = RandomForestClassifier(
    n_trees=100,            # Número de árboles
    max_depth=5,            # Profundidad máxima
    min_samples_split=5,    # Mínimo de muestras para dividir un nodo
    min_samples_leaf=2      # Mínimo de muestras por hoja
)
machine_rf = machine(rf_model, X_train, y_train)
StatsBase.fit!(machine_rf)
```

    Entrenando modelo Random Forest...


    [36m[1m[ [22m[39m[36m[1mInfo: [22m[39mTraining machine(RandomForestClassifier(max_depth = 5, …), …).





    trained Machine; caches model-specific representations of data
      model: RandomForestClassifier(max_depth = 5, …)
      args: 
        1:	Source @572 ⏎ Table{AbstractVector{Continuous}}
        2:	Source @332 ⏎ AbstractVector{OrderedFactor{2}}





```julia
# Predicciones en el conjunto de prueba
y_pred_test_rf = predict_mode(machine_rf, X_test)

# Evaluación del modelo
println("Evaluando el modelo Random Forest...")
accuracy_rf = MLJBase.accuracy(y_pred_test_rf, y_test)
precision_rf = StatisticalMeasures.precision(y_pred_test_rf, y_test)
recall_rf = MLJBase.recall(y_pred_test_rf, y_test)

println("Matriz de confusión:")
println(confusion_matrix(y_pred_test_rf, y_test))

println("\nMétricas de evaluación Random Forest:")
println("Accuracy: ", round(accuracy_rf, digits=3))
println("Precision: ", round(precision_rf, digits=3))
println("Recall: ", round(recall_rf, digits=3))

# Guardar métricas para comparación posterior
metrics_rf = Dict(
    "Accuracy" => round(accuracy_rf, digits=3),
    "Precision" => round(precision_rf, digits=3),
    "Recall" => round(recall_rf, digits=3)
)
```

    Evaluando el modelo Random Forest...
    Matriz de confusión:
    ConfusionMatrix{2}([35 38; 76 103])
    
    Métricas de evaluación Random Forest:
    Accuracy: 0.548
    Precision: 0.575
    Recall: 0.73





    Dict{String, Float64} with 3 entries:
      "Accuracy"  => 0.548
      "Precision" => 0.575
      "Recall"    => 0.73




```julia
# Curva ROC y AUC
println("Graficando curva ROC para Random Forest...")
y_prob_rf = MLJBase.predict(machine_rf, X_test)
roc_rf = MLJBase.roc_curve(y_prob_rf, y_test)
plot(roc_rf, xlabel="False Positive Rate", ylabel="True Positive Rate", 
     legend=false, title="Random Forest ROC Curve")
```

    Graficando curva ROC para Random Forest...





    
![svg](output_67_1.svg)
    




```julia
auc_rf = MLJBase.auc(y_prob_rf, y_test)
println("AUC: ", round(auc_rf, digits=3))

# Agregar AUC a las métricas
metrics_rf["AUC"] = round(auc_rf, digits=3)

metrics_dict["Random Forest"] = metrics_rf

roc_curves["Random Forest"] = (roc_rf, auc_rf)

# Mostrar las métricas
println("Métricas guardadas: ", metrics_rf)
```

    AUC: 0.544
    Métricas guardadas: Dict("Accuracy" => 0.548, "Precision" => 0.575, "Recall" => 0.73, "AUC" => 0.544)



```julia
KNNClassifier = @load KNNClassifier pkg=NearestNeighborModels

# Definir y entrenar el modelo Nearest Neighbors
println("Entrenando modelo Nearest Neighbors...")
knn_model = KNNClassifier(
    K=3,              # Número de vecinos
    metric=Euclidean()   # Métrica de distancia
)
machine_knn = machine(knn_model, X_train, y_train)
StatsBase.fit!(machine_knn)
```

    [36m[1m[ [22m[39m[36m[1mInfo: [22m[39mFor silent loading, specify `verbosity=0`. 


    import NearestNeighborModels ✔
    Entrenando modelo Nearest Neighbors...


    [36m[1m[ [22m[39m[36m[1mInfo: [22m[39mTraining machine(KNNClassifier(K = 3, …), …).





    trained Machine; caches model-specific representations of data
      model: KNNClassifier(K = 3, …)
      args: 
        1:	Source @177 ⏎ Table{AbstractVector{Continuous}}
        2:	Source @651 ⏎ AbstractVector{OrderedFactor{2}}





```julia
# Predicciones en el conjunto de prueba
y_pred_test_knn = predict_mode(machine_knn, X_test)

# Evaluación del modelo
println("Evaluando el modelo Nearest Neighbors...")
accuracy_knn = MLJBase.accuracy(y_pred_test_knn, y_test)
precision_knn = StatisticalMeasures.precision(y_pred_test_knn, y_test)
recall_knn = MLJBase.recall(y_pred_test_knn, y_test)

println("Matriz de confusión:")
println(confusion_matrix(y_pred_test_knn, y_test))

println("\nMétricas de evaluación Nearest Neighbors:")
println("Accuracy: ", round(accuracy_knn, digits=3))
println("Precision: ", round(precision_knn, digits=3))
println("Recall: ", round(recall_knn, digits=3))

# Guardar métricas para comparación posterior
metrics_knn = Dict(
    "Accuracy" => round(accuracy_knn, digits=3),
    "Precision" => round(precision_knn, digits=3),
    "Recall" => round(recall_knn, digits=3)
)
```

    Evaluando el modelo Nearest Neighbors...
    Matriz de confusión:
    ConfusionMatrix{2}([48 55; 63 86])
    
    Métricas de evaluación Nearest Neighbors:
    Accuracy: 0.532
    Precision: 0.577
    Recall: 0.61





    Dict{String, Float64} with 3 entries:
      "Accuracy"  => 0.532
      "Precision" => 0.577
      "Recall"    => 0.61




```julia
# Curva ROC y AUC
println("Graficando curva ROC para Nearest Neighbors...")
y_prob_knn = MLJBase.predict(machine_knn, X_test)
roc_knn = MLJBase.roc_curve(y_prob_knn, y_test)
plot(roc_knn, xlabel="False Positive Rate", ylabel="True Positive Rate", 
     legend=false, title="Nearest Neighbors ROC Curve")
```

    Graficando curva ROC para Nearest Neighbors...





    
![svg](output_71_1.svg)
    




```julia
typeof(y_prob_knn)
```




    UnivariateFiniteVector{OrderedFactor{2}, Int64, UInt32, Float64}[90m (alias for [39m[90mUnivariateFiniteArray{OrderedFactor{2}, Int64, UInt32, Float64, 1}[39m[90m)[39m




```julia
auc_knn = MLJBase.auc(y_prob_knn, y_test)
println("AUC: ", round(auc_knn, digits=3))

# Agregar AUC a las métricas
metrics_knn["AUC"] = round(auc_knn, digits=3)

metrics_dict["Nearest Neighbors"] = metrics_knn

roc_curves["Nearest Neighbors"] = (roc_knn, auc_knn)

# Mostrar las métricas
println("Métricas guardadas: ", metrics_knn)
```

    AUC: 0.529
    Métricas guardadas: Dict("Accuracy" => 0.532, "Precision" => 0.577, "Recall" => 0.61, "AUC" => 0.529)



```julia
ProbabilisticSVC = @load ProbabilisticSVC pkg=LIBSVM

# Definir y entrenar el modelo SVM con kernel lineal
println("Entrenando modelo SVM con kernel Lineal...")
svm_model = ProbabilisticSVC(
    kernel=LIBSVM.Kernel.Linear,  # Usamos kernel Radial Basis
    gamma=0.0,                    # Valor de gamma
    cost=1.0,                     # Parámetro C
    tolerance=0.001,              # Tolerancia para la convergencia
    shrinking=true                # Habilitar heurísticas de encogimiento
)

machine_svm = machine(svm_model, X_train, y_train)
StatsBase.fit!(machine_svm)
```

    import MLJLIBSVMInterface ✔

    [36m[1m[ [22m[39m[36m[1mInfo: [22m[39mFor silent loading, specify `verbosity=0`. 


    
    Entrenando modelo SVM con kernel Lineal...


    [36m[1m[ [22m[39m[36m[1mInfo: [22m[39mTraining machine(ProbabilisticSVC(kernel = Linear, …), …).





    trained Machine; caches model-specific representations of data
      model: ProbabilisticSVC(kernel = Linear, …)
      args: 
        1:	Source @348 ⏎ Table{AbstractVector{Continuous}}
        2:	Source @676 ⏎ AbstractVector{OrderedFactor{2}}





```julia
# Predicciones en el conjunto de prueba
y_pred_test_svm = MLJBase.predict_mode(machine_svm, X_test)

# Evaluación del modelo
println("Evaluando el modelo SVM...")
accuracy_svm = MLJBase.accuracy(y_pred_test_svm, y_test)
precision_svm = StatisticalMeasures.precision(y_pred_test_svm, y_test)
recall_svm = MLJBase.recall(y_pred_test_svm, y_test)

println("Matriz de confusión:")
println(confusion_matrix(y_pred_test_svm, y_test))

println("\nMétricas de evaluación SVM:")
println("Accuracy: ", round(accuracy_svm, digits=3))
println("Precision: ", round(precision_svm, digits=3))
println("Recall: ", round(recall_svm, digits=3))

# Guardar métricas para comparación posterior
metrics_svm = Dict(
    "Accuracy" => round(accuracy_svm, digits=3),
    "Precision" => round(precision_svm, digits=3),
    "Recall" => round(recall_svm, digits=3)
)
```

    Evaluando el modelo SVM...
    Matriz de confusión:
    ConfusionMatrix{2}([9 10; 102 131])
    
    Métricas de evaluación SVM:
    Accuracy: 0.556
    Precision: 0.562
    Recall: 0.929





    Dict{String, Float64} with 3 entries:
      "Accuracy"  => 0.556
      "Precision" => 0.562
      "Recall"    => 0.929




```julia
# Curva ROC y AUC para SVM

println("Graficando curva ROC para SVM lineal...")
y_prob_svm = MLJBase.predict(machine_svm, X_test)
roc_svm = MLJBase.roc_curve(y_prob_svm, y_test)
plot(roc_svm, xlabel="False Positive Rate", ylabel="True Positive Rate", 
     legend=false, title="SVM ROC Curve")
```

    Graficando curva ROC para SVM lineal...





    
![svg](output_76_1.svg)
    




```julia
auc_svm = auc(y_prob_svm, y_test)
println("AUC: ", round(auc_svm, digits=3))

# Agregar AUC a las métricas
metrics_svm["AUC"] = round(auc_svm, digits=3)

metrics_dict["SVM lineal"] = metrics_svm

roc_curves["SVM lineal"] = (roc_svm, auc_svm)

# Mostrar las métricas
println("Métricas guardadas: ", metrics_svm)
```

    AUC: 0.44
    Métricas guardadas: Dict("Accuracy" => 0.556, "Precision" => 0.562, "Recall" => 0.929, "AUC" => 0.44)



```julia
# Definir y entrenar el modelo SVM con kernel RBF
println("Entrenando modelo SVM con kernel RBF...")
svm_model_rbf = ProbabilisticSVC(
    kernel=LIBSVM.Kernel.RadialBasis,  # Usamos kernel Radial Basis
    gamma=0.0,                    # Valor de gamma
    cost=1.0,                     # Parámetro C
    tolerance=0.001,              # Tolerancia para la convergencia
    shrinking=true                # Habilitar heurísticas de encogimiento
)

machine_svm_rbf = machine(svm_model_rbf, X_train, y_train)
StatsBase.fit!(machine_svm_rbf)
```

    Entrenando modelo SVM con kernel RBF...


    [36m[1m[ [22m[39m[36m[1mInfo: [22m[39mTraining machine(ProbabilisticSVC(kernel = RadialBasis, …), …).





    trained Machine; caches model-specific representations of data
      model: ProbabilisticSVC(kernel = RadialBasis, …)
      args: 
        1:	Source @778 ⏎ Table{AbstractVector{Continuous}}
        2:	Source @869 ⏎ AbstractVector{OrderedFactor{2}}





```julia
# Predicciones en el conjunto de prueba
y_pred_test_rbf = MLJ.predict_mode(machine_svm_rbf, X_test)

# Evaluación del modelo
println("Evaluando el modelo SVM con kernel RBF...")
accuracy_rbf = accuracy(y_pred_test_rbf, y_test)
precision_rbf = StatisticalMeasures.precision(y_pred_test_rbf, y_test)
recall_rbf = recall(y_pred_test_rbf, y_test)

println("Matriz de confusión:")
println(confusion_matrix(y_pred_test_rbf, y_test))

println("\nMétricas de evaluación SVM RBF:")
println("Accuracy: ", round(accuracy_rbf, digits=3))
println("Precision: ", round(precision_rbf, digits=3))
println("Recall: ", round(recall_rbf, digits=3))

# Guardar métricas para comparación posterior
metrics_rbf = Dict(
    "Accuracy" => round(accuracy_rbf, digits=3),
    "Precision" => round(precision_rbf, digits=3),
    "Recall" => round(recall_rbf, digits=3)
)

```

    Evaluando el modelo SVM con kernel RBF...
    Matriz de confusión:
    ConfusionMatrix{2}([22 38; 89 103])
    
    Métricas de evaluación SVM RBF:
    Accuracy: 0.496
    Precision: 0.536
    Recall: 0.73





    Dict{String, Float64} with 3 entries:
      "Accuracy"  => 0.496
      "Precision" => 0.536
      "Recall"    => 0.73




```julia
# Curva ROC y AUC
println("Graficando curva ROC para SVM RBF...")
y_prob_rbf = MLJBase.predict(machine_svm_rbf, X_test)
roc_rbf = MLJBase.roc_curve(y_prob_rbf, y_test)
plot(roc_rbf, xlabel="False Positive Rate", ylabel="True Positive Rate", 
     legend=false, title="SVM-RBF ROC Curve")
```

    Graficando curva ROC para SVM RBF...





    
![svg](output_80_1.svg)
    




```julia
auc_rbf = auc(y_prob_rbf, y_test)
println("AUC: ", round(auc_rbf, digits=3))

# Agregar AUC a las métricas
metrics_rbf["AUC"] = round(auc_rbf, digits=3)

metrics_dict["SVM-RBF"] = metrics_rbf

roc_curves["SVM-RBF"] = (roc_rbf, auc_rbf)

# Mostrar las métricas
println("Métricas guardadas: ", metrics_rbf)
```

    AUC: 0.445
    Métricas guardadas: Dict("Accuracy" => 0.496, "Precision" => 0.536, "Recall" => 0.73, "AUC" => 0.445)


## Resultados de los Modelos


```julia
# Crear listas para las columnas del DataFrame
algorithms = collect(keys(metrics_dict))
accuracies = [metrics_dict[algo]["Accuracy"] for algo in algorithms]
precisions = [metrics_dict[algo]["Precision"] for algo in algorithms]
recalls = [metrics_dict[algo]["Recall"] for algo in algorithms]
aucs = [metrics_dict[algo]["AUC"] for algo in algorithms]

# Construir el DataFrame
metrics_df = DataFrame(
    Algorithm = algorithms,
    Accuracy = accuracies,
    Precision = precisions,
    Recall = recalls,
    AUC = aucs
)

# Mostrar el DataFrame
println(metrics_df)
```

    [1m9×5 DataFrame[0m
    [1m Row [0m│[1m Algorithm               [0m[1m Accuracy [0m[1m Precision [0m[1m Recall  [0m[1m AUC     [0m
         │[90m String                  [0m[90m Float64  [0m[90m Float64   [0m[90m Float64 [0m[90m Float64 [0m
    ─────┼────────────────────────────────────────────────────────────────
       1 │ LASSO                       0.567      0.564    1.0      0.563
       2 │ Decision Tree               0.544      0.605    0.532    0.53
       3 │ Random Forest               0.548      0.575    0.73     0.544
       4 │ SVM lineal                  0.556      0.562    0.929    0.44
       5 │ Elastic Net                 0.567      0.564    1.0      0.563
       6 │ Ridge                       0.591      0.591    0.872    0.558
       7 │ Logistic Classification     0.56       0.582    0.752    0.558
       8 │ Nearest Neighbors           0.532      0.577    0.61     0.529
       9 │ SVM-RBF                     0.496      0.536    0.73     0.445


## Gráfica de las Curvas ROC
El código genera una **gráfica con todas las curvas ROC** de los modelos para facilitar la comparación visual. La gráfica se guarda en el archivo:

📁 `fig/roc_curves_all_models.png`


```julia
# Graficar todas las curvas ROC en una sola figura
plot()
for (name, (roc, auc_value)) in roc_curves
    plot!(roc, label="$name (AUC = $(round(auc_value, digits=3)))", legend=:bottomright)
end
xlabel!("False Positive Rate")
ylabel!("True Positive Rate")
title!("ROC Curves for All Models")
```




    
![svg](output_85_0.svg)
    



## Conclusiones
- Los modelos de LASSO y Elastic Net lograron el mejor área bajo la curva **(AUC) de ~0.56**.
- El modelo que implementa el algoritmo **Ridge** tuvo el mejor valor de accuracy es de 0.59 
- El modelo de **Random Forest** tuvo mejor balance entre precision y recall.
- Los modelos SVM tienen un rendimiento más bajo, lo cual sugiere que podrían necesitar un ajuste más detallado de hiperparámetros.
- **El balanceo de clases y el escalado de características fueron esenciales** para mejorar las métricas de evaluación.

