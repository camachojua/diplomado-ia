using MLJ
using MLJBase
using CSV
using DataFrames
using StatsBase
using Plots
using Distances
using MLJLinearModels
using MLJDecisionTreeInterface
using NearestNeighborModels
using LIBSVM

# Función para obtener la forma del dataset (número de filas y columnas)
function dataShape(data)
    rows, cols = size(data)
	println("No. of rows: $rows \nNo. of Columns: $cols \n")
end

function balance_classes(X, y)
    # Identificar índices de la clase minoritaria
    minority_idx = findall(y .== 1)
    n_to_add = length(y) - 2 * length(minority_idx)

    # Duplicar instancias de la clase minoritaria
    X_balanced = vcat(X, X[minority_idx[1:n_to_add], :])
    y_balanced = vcat(y, y[minority_idx[1:n_to_add]])

    return X_balanced, y_balanced
end

# Construye la ruta del archivo
dataset_path = joinpath(@__DIR__, "../dat/Smarket.csv")

# Verifica si el archivo existe
if !isfile(dataset_path)
    error("El archivo no existe en la ruta: $dataset_path")
end

# Carga el archivo
data = CSV.read(dataset_path, DataFrame)
println("Archivo cargado exitosamente.")

# Mostrar la forma del dataset (número de filas y columnas)
dataShape(data)

# Resumen estadístico de las columnas numéricas
println(describe(data))

# Convertir 'Direction' a variable binaria (1 = Up, 0 = Down)
data.Direction = ifelse.(data.Direction .== "Up", 1, 0)

# Seleccionar las características y la variable objetivo
X = DataFrames.select(data, Not(:Direction))
y = data.Direction

# Convertir y a un objeto categórico ordenado
y = coerce(y, OrderedFactor)

println(typeof(y))

# Eliminamos las columnas 'Year' y 'Today'
X2 = DataFrames.select(X, Not([:Year, :Today]))

# Definir y entrenar el modelo LogisticClassifier
logistic_model = @load LogisticClassifier pkg=MLJLinearModels

# Crear una máquina con los datos completos (X2 y y)
logistic_machine = machine(logistic_model(), X2, y)

# Entrenar el modelo
StatsBase.fit!(logistic_machine)

# Hacer predicciones en el conjunto completo
y_pred = MLJ.predict(logistic_machine, X2)
y_pred[1:3]  # Mostrar las primeras 3 predicciones

# Calcular la entropía cruzada
cross_entropy_value = cross_entropy(y_pred, y) |> mean
cross_entropy_rounded = round(cross_entropy_value, digits = 3)

# Obtener las predicciones en modo clase
y_pred_mode = predict_mode(logistic_machine, X2)

# Calcular la matriz de confusión
cm = confusion_matrix(y_pred_mode, y)

println(cm)

println("Accuracy: ", MLJ.accuracy(y_pred_mode, y))

MLJ.auc(y_pred, y)

rc = roc_curve(y_pred, y)
plt=plot(rc, legend=false)

# Guardar el gráfico en un archivo
ruta_archivo = joinpath("fig", "roc_curve.png")
savefig(ruta_archivo)

# Dividir datos en entrenamiento y prueba basados en el año
train_idx = data.Year .< 2005  # Antes de 2005
test_idx = data.Year .>= 2005  # 2005 en adelante

X_train = DataFrames.select(X[train_idx, :], Not([:Year, :Today]))
y_train = y[train_idx]

println("Conjunto de entrenamiento: ")
println(dataShape(X_train))

X_test = DataFrames.select(X[test_idx, :], Not([:Year, :Today]))
y_test = y[test_idx]

println("Conjunto de prueba: ")
println(dataShape(X_test))

# Convertir y_train e y_test a factores ordenados
y_train = coerce(y_train, OrderedFactor)
y_test = coerce(y_test, OrderedFactor)

logistic_machine = machine(logistic_model(), X_train, y_train)
StatsBase.fit!(logistic_machine)

# Predicciones en el conjunto de prueba
y_pred_test = MLJ.predict(logistic_machine, X_test)
y_pred_mode_test = predict_mode(logistic_machine, X_test)

cm_test = confusion_matrix(y_pred_mode_test, y_test)

# Curva ROC y AUC
rc_test = roc_curve(y_pred_test, y_test)
plot(rc_test, legend=false, xlabel="False Positive Rate", ylabel="True Positive Rate", title="ROC Curve")

# Guardar el gráfico en un archivo
ruta_archivo = joinpath("fig", "roc_curve_train.png")
savefig(ruta_archivo)

auc_test = MLJ.auc(y_pred_test, y_test)
println("AUC: ", round(auc_test, digits=3))

X_train = DataFrames.select(X_train, [:Lag1, :Lag2])
X_test = DataFrames.select(X_test, [:Lag1, :Lag2])

println("Nuevo conjunto de entrenamiento: ")
println(dataShape(X_train))

println("Nuevo conjunto de prueba: ")
println(dataShape(X_test))

# Aplicar SMOTE para balancear las clases
println("Balanceando las clases usando SMOTE...")
# Balancear las clases
X_train_balanced, y_train = balance_classes(X_train, y_train)
println("Datos balanceados: ", size(X_train_balanced))

# Escalar las características (feature scaling)
println("Aplicando feature scaling...")
standardizer_model = Standardizer(count=true)

X_train = MLJ.transform(StatsBase.fit!(machine(standardizer_model, X_train_balanced)), X_train_balanced)
X_test = MLJ.transform(StatsBase.fit!(machine(standardizer_model, X_train_balanced)), X_test)

# Diccionario para guardar los resultados de las curvas ROC
roc_curves = Dict{String, Any}()

logistic_machine = machine(logistic_model(), X_train, y_train)
StatsBase.fit!(logistic_machine)

# Predicciones en el conjunto de prueba
y_pred_test = MLJ.predict(logistic_machine, X_test)
y_pred_mode_test = predict_mode(logistic_machine, X_test)

metrics_dict = Dict{String, Dict{String, Float64}}()

# Evaluación del modelo
println("Evaluando el modelo...")
cm = confusion_matrix(y_pred_mode_test, y_test)
accuracy_value = accuracy(y_pred_mode_test, y_test)  
precision_value = StatisticalMeasures.precision(y_pred_mode_test, y_test)
recall_value = recall(y_pred_mode_test, y_test)

println("Matriz de confusión:")
println(cm)

println("\nMétricas de evaluación:")
println("Accuracy: ", round(accuracy_value, digits=3)) 
println("Precision: ", round(precision_value, digits=3))
println("Recall: ", round(recall_value, digits=3))

# Guardar métricas para comparación posterior
metrics = Dict(
    "Accuracy" => round(accuracy_value, digits=3),
    "Precision" => round(precision_value, digits=3),
    "Recall" => round(recall_value, digits=3)
)

# Curva ROC y AUC
rc_test = roc_curve(y_pred_test, y_test)
plot(rc_test, legend=false, xlabel="False Positive Rate", ylabel="True Positive Rate", title="Logistic Classification ROC Curve")

# Guardar el gráfico en un archivo
ruta_archivo = joinpath("fig", "roc_curve_control.png")
savefig(ruta_archivo)

auc_value = auc(y_pred_test, y_test)
println("AUC: ", round(auc_value, digits=3))

# Agregar AUC al diccionario
metrics["AUC"] = round(auc_value, digits=3)

metrics_dict["Logistic Classification"] = metrics

roc_curves["Logistic Classification"] = (rc_test, auc_value)

# Mostrar las métricas
#println("Métricas guardadas: ", metrics_dict)

# Definir y entrenar el modelo LASSO
println("Entrenando modelo LASSO...")
log_reg_lasso = LogisticClassifier(lambda=0.01, penalty=:l1)
machine_log_reg_lasso = machine(log_reg_lasso, X_train, y_train)
StatsBase.fit!(machine_log_reg_lasso)

# Predicciones en el conjunto de prueba
y_pred_lasso = predict_mode(machine_log_reg_lasso, X_test)

# Evaluación del modelo
println("Evaluando el modelo LASSO...")
cm = confusion_matrix(y_pred_lasso, y_test)
accuracy_lasso = MLJBase.accuracy(y_pred_lasso, y_test)  
precision_lasso = StatisticalMeasures.precision(y_pred_lasso, y_test)
recall_lasso = recall(y_pred_lasso, y_test)

println("Matriz de confusión:")
println(cm)

println("\nMétricas de evaluación:")
println("Accuracy: ", round(accuracy_lasso, digits=3)) 
println("Precision: ", round(precision_lasso, digits=3))
println("Recall: ", round(recall_lasso, digits=3))

# Guardar métricas para comparación posterior
lasso_metrics = Dict(
    "Accuracy" => round(accuracy_lasso, digits=3),
    "Precision" => round(precision_lasso, digits=3),
    "Recall" => round(recall_lasso, digits=3)
)

# Curva ROC y AUC
println("Graficando curva ROC...")
y_prob_lasso = MLJ.predict(machine_log_reg_lasso, X_test)
rc = roc_curve(y_prob_lasso, y_test)
plot(rc, legend=false, xlabel="False Positive Rate", ylabel="True Positive Rate", title="LASSO ROC Curve")

# Guardar el gráfico en un archivo
ruta_archivo = joinpath("fig", "roc_curve_lasso.png")
savefig(ruta_archivo)

auc_lasso = auc(y_prob_lasso, y_test)
println("AUC: ", round(auc_value, digits=3))

# Agregar AUC al diccionario
lasso_metrics["AUC"] = round(auc_lasso, digits=3)

metrics_dict["LASSO"] = lasso_metrics

roc_curves["LASSO"] = (rc, auc_lasso)

# Mostrar las métricas
#println("Métricas guardadas: ", metrics_dict)

# Definir y entrenar el modelo Ridge
println("Entrenando modelo Ridge...")
ridge_model = LogisticClassifier(lambda=0.1, penalty=:l2)  # Penalización L2
machine_ridge = machine(ridge_model, X_train, y_train)
StatsBase.fit!(machine_ridge)

#Predicciones en el conjunto de prueba
y_pred_test_ridge = predict_mode(machine_ridge, X_test)

# Evaluación del modelo
println("Evaluando el modelo Ridge...")
accuracy_ridge = MLJBase.accuracy(y_pred_test_ridge, y_test)
precision_ridge = StatisticalMeasures.precision(y_pred_test_ridge, y_test)
recall_ridge = MLJBase.recall(y_pred_test_ridge, y_test)

println("Matriz de confusión:")
println(confusion_matrix(y_pred_test_ridge, y_test))

println("\nMétricas de evaluación Ridge:")
println("Accuracy: ", round(accuracy_ridge, digits=3))
println("Precision: ", round(precision_ridge, digits=3))
println("Recall: ", round(recall_ridge, digits=3))

# Guardar métricas para comparación posterior
metrics_ridge = Dict(
    "Accuracy" => round(accuracy_ridge, digits=3),
    "Precision" => round(precision_ridge, digits=3),
    "Recall" => round(recall_ridge, digits=3)
)

# Curva ROC y AUC
println("Graficando curva ROC para Ridge...")
y_prob_ridge = MLJBase.predict(machine_ridge, X_test)
roc_ridge = MLJBase.roc_curve(y_prob_ridge, y_test)
plot(roc_ridge, xlabel="False Positive Rate", ylabel="True Positive Rate", legend=false, title="Ridge ROC Curve")

# Guardar el gráfico en un archivo
ruta_archivo = joinpath("fig", "roc_curve_ridge.png")
savefig(ruta_archivo)

auc_ridge = auc(y_prob_ridge, y_test)
println("AUC: ", round(auc_ridge, digits=3))
     
# Agregar AUC a las métricas
metrics_ridge["AUC"] = round(auc_ridge, digits=3)
     
metrics_dict["Ridge"] = metrics_ridge

roc_curves["Ridge"] = (roc_ridge, auc_ridge)
     
# Mostrar las métricas
#println("Métricas guardadas: ", metrics_dict)

# Definir y entrenar el modelo Elastic Net
println("Entrenando modelo Elastic Net...")
elastic_net_model = LogisticClassifier(lambda=0.01, gamma=0.01, penalty=:en)  # Elastic Net con L2 y L1
machine_elastic_net = machine(elastic_net_model, X_train, y_train)
StatsBase.fit!(machine_elastic_net)

# Predicciones en el conjunto de prueba
y_pred_test_en = predict_mode(machine_elastic_net, X_test)

# Evaluación del modelo
println("Evaluando el modelo Elastic Net...")
accuracy_en = MLJBase.accuracy(y_pred_test_en, y_test)
precision_en = StatisticalMeasures.precision(y_pred_test_en, y_test)
recall_en = MLJBase.recall(y_pred_test_en, y_test)

println("Matriz de confusión:")
println(confusion_matrix(y_pred_test_en, y_test))

println("\nMétricas de evaluación Elastic Net:")
println("Accuracy: ", round(accuracy_en, digits=3))
println("Precision: ", round(precision_en, digits=3))
println("Recall: ", round(recall_en, digits=3))

# Guardar métricas para comparación posterior
metrics_en = Dict(
    "Accuracy" => round(accuracy_en, digits=3),
    "Precision" => round(precision_en, digits=3),
    "Recall" => round(recall_en, digits=3)
)

# Curva ROC y AUC
println("Graficando curva ROC para Elastic Net...")
y_prob_en = MLJBase.predict(machine_elastic_net, X_test)
roc_en = MLJBase.roc_curve(y_prob_en, y_test)
plot(roc_en, xlabel="False Positive Rate", ylabel="True Positive Rate", legend=false, title="Elastic Net ROC Curve")

# Guardar el gráfico en un archivo
ruta_archivo = joinpath("fig", "roc_curve_elastic_net.png")
savefig(ruta_archivo)

auc_en = auc(y_prob_en, y_test)
println("AUC: ", round(auc_en, digits=3))

# Agregar AUC a las métricas
metrics_en["AUC"] = round(auc_en, digits=3)

metrics_dict["Elastic Net"] = metrics_en

roc_curves["Elastic Net"] = (roc_en, auc_en)

# Mostrar métricas guardadas
#println("Métricas guardadas para Elastic Net: ", metrics_en)

# Definir y entrenar el modelo Decision Tree
println("Entrenando modelo Decision Tree...")
tree_model = DecisionTreeClassifier(max_depth=3, min_samples_split=5, min_samples_leaf=2)
machine_tree = machine(tree_model, X_train, y_train)
StatsBase.fit!(machine_tree)

# Predicciones en el conjunto de prueba
y_pred_test_tree = predict_mode(machine_tree, X_test)

# Evaluación del modelo
println("Evaluando el modelo Decision Tree...")
accuracy_tree = MLJBase.accuracy(y_pred_test_tree, y_test)
precision_tree = StatisticalMeasures.precision(y_pred_test_tree, y_test)
recall_tree = MLJBase.recall(y_pred_test_tree, y_test)

println("Matriz de confusión:")
println(confusion_matrix(y_pred_test_tree, y_test))

println("\nMétricas de evaluación Decision Tree:")
println("Accuracy: ", round(accuracy_tree, digits=3))
println("Precision: ", round(precision_tree, digits=3))
println("Recall: ", round(recall_tree, digits=3))

# Guardar métricas para comparación posterior
metrics_tree = Dict(
    "Accuracy" => round(accuracy_tree, digits=3),
    "Precision" => round(precision_tree, digits=3),
    "Recall" => round(recall_tree, digits=3)
)

# Curva ROC y AUC
println("Graficando curva ROC para Decision Tree...")
y_prob_tree = MLJBase.predict(machine_tree, X_test)
roc_tree = MLJBase.roc_curve(y_prob_tree, y_test)
plot(roc_tree, xlabel="False Positive Rate", ylabel="True Positive Rate", legend=false, title="Decision Tree ROC Curve")

# Guardar el gráfico en un archivo
ruta_archivo = joinpath("fig", "roc_curve_decision_tree.png")
savefig(ruta_archivo)

auc_tree = MLJBase.auc(y_prob_tree, y_test)
println("AUC: ", round(auc_tree, digits=3))

# Agregar AUC a las métricas
metrics_tree["AUC"] = round(auc_tree, digits=3)

metrics_dict["Decision Tree"] = metrics_tree

roc_curves["Decision Tree"] = (rc_test, auc_value)

# Mostrar las métricas
#println("Métricas guardadas: ", metrics_dict)

# Definir y entrenar el modelo Random Forest
println("Entrenando modelo Random Forest...")
rf_model = RandomForestClassifier(
    n_trees=100,            # Número de árboles
    max_depth=5,            # Profundidad máxima
    min_samples_split=5,    # Mínimo de muestras para dividir un nodo
    min_samples_leaf=2      # Mínimo de muestras por hoja
)
machine_rf = machine(rf_model, X_train, y_train)
StatsBase.fit!(machine_rf)

# Predicciones en el conjunto de prueba
y_pred_test_rf = predict_mode(machine_rf, X_test)

# Evaluación del modelo
println("Evaluando el modelo Random Forest...")
accuracy_rf = MLJBase.accuracy(y_pred_test_rf, y_test)
precision_rf = StatisticalMeasures.precision(y_pred_test_rf, y_test)
recall_rf = MLJBase.recall(y_pred_test_rf, y_test)

println("Matriz de confusión:")
println(confusion_matrix(y_pred_test_rf, y_test))

println("\nMétricas de evaluación Random Forest:")
println("Accuracy: ", round(accuracy_rf, digits=3))
println("Precision: ", round(precision_rf, digits=3))
println("Recall: ", round(recall_rf, digits=3))

# Guardar métricas para comparación posterior
metrics_rf = Dict(
    "Accuracy" => round(accuracy_rf, digits=3),
    "Precision" => round(precision_rf, digits=3),
    "Recall" => round(recall_rf, digits=3)
)

# Curva ROC y AUC
println("Graficando curva ROC para Random Forest...")
y_prob_rf = MLJBase.predict(machine_rf, X_test)
roc_rf = MLJBase.roc_curve(y_prob_rf, y_test)
plot(roc_rf, xlabel="False Positive Rate", ylabel="True Positive Rate", legend=false, title="Random Forest ROC Curve")

# Guardar el gráfico en un archivo
ruta_archivo = joinpath("fig", "roc_curve_random_forest.png")
savefig(ruta_archivo)

auc_rf = MLJBase.auc(y_prob_rf, y_test)
println("AUC: ", round(auc_rf, digits=3))

# Agregar AUC a las métricas
metrics_rf["AUC"] = round(auc_rf, digits=3)

metrics_dict["Random Forest"] = metrics_rf

roc_curves["Random Forest"] = (roc_rf, auc_rf)

# Mostrar las métricas
#println("Métricas guardadas: ", metrics_dict)

KNNClassifier = @load KNNClassifier pkg=NearestNeighborModels

# Definir y entrenar el modelo Nearest Neighbors
println("Entrenando modelo Nearest Neighbors...")
knn_model = KNNClassifier(
    K=3,              # Número de vecinos
    metric=Euclidean()   # Métrica de distancia
)
machine_knn = machine(knn_model, X_train, y_train)
StatsBase.fit!(machine_knn)

# Predicciones en el conjunto de prueba
y_pred_test_knn = predict_mode(machine_knn, X_test)

# Evaluación del modelo
println("Evaluando el modelo Nearest Neighbors...")
accuracy_knn = MLJBase.accuracy(y_pred_test_knn, y_test)
precision_knn = StatisticalMeasures.precision(y_pred_test_knn, y_test)
recall_knn = MLJBase.recall(y_pred_test_knn, y_test)

println("Matriz de confusión:")
println(confusion_matrix(y_pred_test_knn, y_test))

println("\nMétricas de evaluación Nearest Neighbors:")
println("Accuracy: ", round(accuracy_knn, digits=3))
println("Precision: ", round(precision_knn, digits=3))
println("Recall: ", round(recall_knn, digits=3))

# Guardar métricas para comparación posterior
metrics_knn = Dict(
    "Accuracy" => round(accuracy_knn, digits=3),
    "Precision" => round(precision_knn, digits=3),
    "Recall" => round(recall_knn, digits=3)
)

# Curva ROC y AUC
println("Graficando curva ROC para Nearest Neighbors...")
y_prob_knn = MLJBase.predict(machine_knn, X_test)
roc_knn = MLJBase.roc_curve(y_prob_knn, y_test)
plot(roc_knn, xlabel="False Positive Rate", ylabel="True Positive Rate", legend=false, title="Nearest Neighbors ROC Curve")

# Guardar el gráfico en un archivo
ruta_archivo = joinpath("fig", "roc_curve_nearest_neighbors.png")
savefig(ruta_archivo)

auc_knn = MLJBase.auc(y_prob_knn, y_test)
println("AUC: ", round(auc_knn, digits=3))

# Agregar AUC a las métricas
metrics_knn["AUC"] = round(auc_knn, digits=3)

metrics_dict["Nearest Neighbors"] = metrics_knn

roc_curves["Nearest Neighbors"] = (roc_knn, auc_knn)

# Mostrar las métricas
#println("Métricas guardadas: ", metrics_dict)

ProbabilisticSVC = @load ProbabilisticSVC pkg=LIBSVM

# Definir y entrenar el modelo SVM con kernel lineal
println("Entrenando modelo SVM con kernel Lineal...")
svm_model = ProbabilisticSVC(
    kernel=LIBSVM.Kernel.Linear,  # Usamos kernel Radial Basis
    gamma=0.0,                    # Valor de gamma
    cost=1.0,                     # Parámetro C
    tolerance=0.001,              # Tolerancia para la convergencia
    shrinking=true                # Habilitar heurísticas de encogimiento
)

machine_svm = machine(svm_model, X_train, y_train)
StatsBase.fit!(machine_svm)

# Predicciones en el conjunto de prueba
y_pred_test_svm = MLJBase.predict_mode(machine_svm, X_test)

# Evaluación del modelo
println("Evaluando el modelo SVM...")
accuracy_svm = MLJBase.accuracy(y_pred_test_svm, y_test)
precision_svm = StatisticalMeasures.precision(y_pred_test_svm, y_test)
recall_svm = MLJBase.recall(y_pred_test_svm, y_test)

println("Matriz de confusión:")
println(confusion_matrix(y_pred_test_svm, y_test))

println("\nMétricas de evaluación SVM:")
println("Accuracy: ", round(accuracy_svm, digits=3))
println("Precision: ", round(precision_svm, digits=3))
println("Recall: ", round(recall_svm, digits=3))

# Guardar métricas para comparación posterior
metrics_svm = Dict(
    "Accuracy" => round(accuracy_svm, digits=3),
    "Precision" => round(precision_svm, digits=3),
    "Recall" => round(recall_svm, digits=3)
)

# Curva ROC y AUC para SVM

println("Graficando curva ROC para SVM lineal...")
y_prob_svm = MLJBase.predict(machine_svm, X_test)
roc_svm = MLJBase.roc_curve(y_prob_svm, y_test)
plot(roc_svm, xlabel="False Positive Rate", ylabel="True Positive Rate", legend=false, title="SVM ROC Curve")

# Guardar el gráfico en un archivo
ruta_archivo = joinpath("fig", "roc_curve_svm_lineal.png")
savefig(ruta_archivo)

auc_svm = auc(y_prob_svm, y_test)
println("AUC: ", round(auc_svm, digits=3))

# Agregar AUC a las métricas
metrics_svm["AUC"] = round(auc_svm, digits=3)

metrics_dict["SVM_lineal"] = metrics_svm

roc_curves["SVM lineal"] = (roc_svm, auc_svm)

# Mostrar las métricas
#println("Métricas guardadas: ", metrics_dict)

# Definir y entrenar el modelo SVM con kernel RBF
println("Entrenando modelo SVM con kernel RBF...")
svm_model_rbf = ProbabilisticSVC(
    kernel=LIBSVM.Kernel.RadialBasis,  # Usamos kernel Radial Basis
    gamma=0.0,                    # Valor de gamma
    cost=1.0,                     # Parámetro C
    tolerance=0.001,              # Tolerancia para la convergencia
    shrinking=true                # Habilitar heurísticas de encogimiento
)

machine_svm_rbf = machine(svm_model_rbf, X_train, y_train)
StatsBase.fit!(machine_svm_rbf)

# Predicciones en el conjunto de prueba
y_pred_test_rbf = MLJ.predict_mode(machine_svm_rbf, X_test)

# Evaluación del modelo
println("Evaluando el modelo SVM con kernel RBF...")
accuracy_rbf = accuracy(y_pred_test_rbf, y_test)
precision_rbf = StatisticalMeasures.precision(y_pred_test_rbf, y_test)
recall_rbf = recall(y_pred_test_rbf, y_test)

println("Matriz de confusión:")
println(confusion_matrix(y_pred_test_rbf, y_test))

println("\nMétricas de evaluación SVM RBF:")
println("Accuracy: ", round(accuracy_rbf, digits=3))
println("Precision: ", round(precision_rbf, digits=3))
println("Recall: ", round(recall_rbf, digits=3))

# Guardar métricas para comparación posterior
metrics_rbf = Dict(
    "Accuracy" => round(accuracy_rbf, digits=3),
    "Precision" => round(precision_rbf, digits=3),
    "Recall" => round(recall_rbf, digits=3)
)

# Curva ROC y AUC
println("Graficando curva ROC para SVM RBF...")
y_prob_rbf = MLJBase.predict(machine_svm_rbf, X_test)
roc_rbf = MLJBase.roc_curve(y_prob_rbf, y_test)
plot(roc_rbf, xlabel="False Positive Rate", ylabel="True Positive Rate", legend=false, title="SVM-RBF ROC Curve")

# Guardar el gráfico en un archivo
ruta_archivo = joinpath("fig", "roc_curve_svm_rbf.png")
savefig(ruta_archivo)

auc_rbf = auc(y_prob_rbf, y_test)
println("AUC: ", round(auc_rbf, digits=3))

# Agregar AUC a las métricas
metrics_rbf["AUC"] = round(auc_rbf, digits=3)

metrics_dict["SVM-RBF"] = metrics_rbf

roc_curves["SVM-RBF"] = (roc_rbf, auc_rbf)

# Mostrar las métricas
#println("Métricas guardadas: ", metrics_dict)

# Crear listas para las columnas del DataFrame
algorithms = collect(keys(metrics_dict))
accuracies = [metrics_dict[algo]["Accuracy"] for algo in algorithms]
precisions = [metrics_dict[algo]["Precision"] for algo in algorithms]
recalls = [metrics_dict[algo]["Recall"] for algo in algorithms]
aucs = [metrics_dict[algo]["AUC"] for algo in algorithms]

# Construir el DataFrame
metrics_df = DataFrame(
    Algorithm = algorithms,
    Accuracy = accuracies,
    Precision = precisions,
    Recall = recalls,
    AUC = aucs
)

# Mostrar el DataFrame
println(metrics_df)

# Graficar todas las curvas ROC en una sola figura
plot()
for (name, (roc, auc_value)) in roc_curves
    plot!(roc, label="$name (AUC = $(round(auc_value, digits=3)))", legend=:bottomright)
end
xlabel!("False Positive Rate")
ylabel!("True Positive Rate")
title!("ROC Curves for All Models")

# Guardar el gráfico en un archivo
ruta_archivo = joinpath("fig", "roc_curves_all_models.png")
savefig(ruta_archivo)
println("Gráfica de curvas ROC guardada en 'fig/roc_curves_all_models.png'.")
