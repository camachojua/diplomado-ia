using CSV, DataFrames, Statistics, GLMNet, DecisionTree, LIBSVM, Random, ROCAnalysis, Plots, MLBase, NearestNeighbors


# Charge de Data
df = CSV.read("Smarket.csv", DataFrame)

# Preparing Data for Regression
function clean_dataframe(df::DataFrame, valid_columns::Vector{String})
    # Seleccionar solo las columnas válidas
    df_subset = select(df, intersect(names(df), valid_columns))
    return df_subset
end
new_df = clean_dataframe(df, ["Lag1", "Lag2", "Lag3", "Lag4", "Lag5", "Volume", "Today", "Direction"])

# Hot Encoding for directions value
mapa_Direction = Dict("Up" => 1, "Down" => 0)
new_df.Direction = map(x -> mapa_Direction[string(x)], new_df.Direction)

# Preparar datos
# Dividir en entrenamiento y prueba
shuffle!(new_df) #para revolver las filas
tamano_train = Int(0.7 * nrow(new_df))
datos_train = new_df[1:tamano_train, :]
datos_test = new_df[tamano_train+1:end, :]
X = (Matrix(select(datos_train, Not(:Direction))))  # Los datos de entrada de entrenamiento
y= vec(Matrix(select(datos_train, :Direction)))  # Las etiquetas de entrenamiento (sin necesidad de convertir a Matrix)
X_test = (Matrix(select(datos_test, Not(:Direction))))  # Los datos de entrada de prueba
y_test = vec(Matrix(select(datos_test, :Direction))) # Las etiquetas de prueba (sin necesidad de convertir a Matrix)

# Crea un DataFrame con las etiquetas reales
results = DataFrame(y_test=y_test)

# 1. LASSO (alpha=1.0)
path = glmnet(X, y)
cv = glmnetcv(X, y)
mylambda = path.lambda[argmin(cv.meanloss)]
model = glmnet(X, y,lambda=[mylambda]);
q = X_test;
predictions_lasso = GLMNet.predict(model, q)
predictions_lasso = [if x < 0.5 0 else 1 end for x in predictions_lasso]
predictions_lasso = vec(predictions_lasso)
results.Lasso = predictions_lasso

# 2. Ridge (alpha=0.0)
path = glmnet(X, y, alpha=0)
cv = glmnetcv(X, y, alpha=0)
mylambda = path.lambda[argmin(cv.meanloss)]
model = glmnet(X, y, alpha=0, lambda=[mylambda]);
q = X_test;
predictions_ridge = GLMNet.predict(model, q)
predictions_ridge = [if x < 0.5 0 else 1 end for x in predictions_ridge]
predictions_ridge = vec(predictions_ridge)
results.Ridge = predictions_ridge

# 3. Elastic Net (alpha=0.5)
path = glmnet(X, y, alpha=0.5)
cv = glmnetcv(X, y, alpha=0.5)
mylambda = path.lambda[argmin(cv.meanloss)]
model = glmnet(X, y, alpha=0.5, lambda=[mylambda]);
q = X_test;
predictions_EN = GLMNet.predict(model, q)
predictions_EN = GLMNet.predict(model, q)
predictions_EN = [if x < 0.5 0 else 1 end for x in predictions_EN]
predictions_EN = vec(predictions_EN)
results.ElasticNet = predictions_EN

# 4. Decision Tree 
model = DecisionTreeClassifier(max_depth=2)
DecisionTree.fit!(model, X, y)
q = X_test;
predictions_DT = DecisionTree.predict(model, q)
predictions_DT = vec(predictions_DT)
results.DecisionTree = predictions_DT

# 5. Random Forest
model = RandomForestClassifier(n_trees=20)
DecisionTree.fit!(model, X, y)
q = X_test;
predictions_RF = DecisionTree.predict(model, q)
predictions_RF = vec(predictions_RF)
results.RandomForest = predictions_RF

# 6. Nearest Neighbor
kdtree = KDTree(X')
queries = X_test
idxs, dists = knn(kdtree, queries', 5, true)
neighbors_labels = y[hcat(idxs...)]
predictions_NN = map(i -> mean(neighbors_labels[:, i]) > 0.5 ? 1 : 0, 1:size(neighbors_labels, 2))
predictions_NN = vec(predictions_NN)
results.NearestNeighbor = predictions_NN

# 7. Support Vecror Machines (SVM)
model = svmtrain(X', y)
predictions_SVM, decision_values = svmpredict(model, X_test')
predictions_SVM = vec(predictions_SVM)
results.SupportVectorMachine = predictions_SVM

# Mostrar el DataFrame con las predicciones de cada modelo
#println(results)


function ConfusionMatrix(y_test, y_pred, name)
    confusionmatrix = MLBase.roc(y_test, y_pred)
    # Extraer valores del objeto confusionmatrix
    tp = confusionmatrix.tp  # Verdaderos Positivos
    tn = confusionmatrix.tn  # Verdaderos Negativos
    fp = confusionmatrix.fp  # Falsos Positivos
    fn = confusionmatrix.fn  # Falsos Negativos

    m_c = [fp tn; tp fn]

    for i in 1:size(m_c, 1)
        for j in 1:size(m_c, 2)
            annotate!(j, i, Plots.text(string(m_c[i, j]), :white, 14))
        end
    end

   # Coordenadas de los cuadros para las anotaciones
    rows, cols = size(m_c)
    x_coord = repeat(1:cols, inner=rows)
    y_coord = repeat(1:rows, outer=cols)


    # Texto con los valores de la matriz
    texto = vec(string.(m_c))

    # Graficar la matriz de confusión
    Plots.heatmap(
        m_c,
        title="Matriz de Confusión",
        c=:rainbow,
        xticks=(1:2, ["Positivos", "Negativos"]),
        yticks=(1:2, ["Negativos", "Positivos"]),
        colorbar=true,
        annotations=(x_coord, y_coord, texto, :white),
        size=(800, 500)
    )
    # Crear un nombre de archivo único con 'y_pred'
    y_pred_name = string("confusion_", name)  
    # Guardar la figura con un nombre dinámico basado en y_pred
    savefig("$y_pred_name.png")
end

function ROCCurve(y_test, y_pred, name)
    # Ordenar por probabilidades predichas en orden descendente
    sorted_indices = sortperm(y_pred, rev=true)
    sorted_probs = y_pred[sorted_indices]
    sorted_labels = y_test[sorted_indices]

    # Inicializar variables
    tpr = Float64[]  # Verdadero positivo rate (True Positive Rate)
    fpr = Float64[]  # Falso positivo rate (False Positive Rate)
    tp = 0
    fp = 0
    p = sum(sorted_labels)  # Total de positivos
    n = length(sorted_labels) - p  # Total de negativos

    # Calcular TPR y FPR en cada umbral
    for i in 1:length(sorted_probs)
        if sorted_labels[i] == 1
            tp += 1
        else
            fp += 1
        end
        push!(tpr, tp / p)
        push!(fpr, fp / n)
    end

    # Calcular AUC usando la regla trapezoidal
    auc = sum((tpr[2:end] + tpr[1:end-1]) .* (fpr[2:end] - fpr[1:end-1]) / 2)

    # Graficar curva ROC
    Plots.plot(
        fpr,
        tpr,
        label="Curva ROC (AUC = $(round(auc, digits=3)))",
        xlabel="FPR (Tasa de Falsos Positivos)",
        ylabel="TPR (Tasa de Verdaderos Positivos)",
        title="Curva ROC",
        legend=:bottomright,
        size=(1000, 800)
    )
    # Crear un nombre de archivo único con 'y_pred'
    y_pred_name = string("ROC_", name)  
    # Guardar la figura con un nombre dinámico basado en y_pred
    savefig("$y_pred_name.png")

end


for col_name in names(results)  # Iterar sobre los nombres de las columnas
    col = results[:, col_name]  # Seleccionar la columna
    if col_name != "y_test"  # Evitar pasar 'y_test' como predicción
        ConfusionMatrix(results.y_test, col, col_name)
        ROCCurve(results.y_test, col, col_name)
    end
end
