# Clasificación de Datos del Mercado de Valores

Este proyecto utiliza el conjunto de datos **Smarket** del libro **An Introduction to Statistical Learning (ISL)** para realizar clasificación utilizando varios algoritmos de machine learning. Los modelos entrenados incluyen:

- LASSO (Regularización L1)
- Ridge (Regularización L2)
- Elastic Net (Combinación de L1 y L2)
- Árbol de Decisión
- Random Forest
- K-Nearest Neighbors (KNN)
- Support Vector Machines (SVM)

El propósito de este proyecto es evaluar el rendimiento de diferentes modelos de clasificación en un conjunto de datos financiero, midiendo la precisión, la matriz de confusión y la Curva ROC de cada modelo.

## Requisitos

Antes de ejecutar el código, asegúrate de tener instalados los siguientes paquetes en tu entorno de Julia:

```bash
using CSV
using DataFrames
using GLM
using ScikitLearn
using StatsBase
using RDatasets
using Random
using LinearAlgebra
using StatsModels
using ROCAnalysis

Descripción del Proyecto
1. Cargar y Preparar el Conjunto de Datos
El archivo Smarket.csv contiene datos históricos del mercado de valores. Los datos se cargan y preprocesan, eliminando las columnas innecesarias y codificando la variable objetivo (Direction) como números (0 o 1), donde 1 indica un aumento en el mercado y 0 indica una caída.

2. División del Conjunto de Datos
El conjunto de datos se divide en dos partes:

Entrenamiento: 70% de los datos
Prueba: 30% de los datos
Se asegura que ambas clases (subida y bajada del mercado) estén presentes en ambos conjuntos.

3. Entrenamiento y Evaluación de Modelos
El código implementa los siguientes modelos de clasificación:

LASSO (Regularización L1)
Ridge (Regularización L2)
Elastic Net (Combinación de L1 y L2)
Árbol de Decisión
Random Forest
K-Nearest Neighbors (KNN)
Support Vector Machines (SVM)
Para cada modelo:

Se entrena el modelo con el conjunto de entrenamiento.
Se realizan predicciones en el conjunto de prueba.
Se calcula la precisión del modelo.
Se genera la matriz de confusión para analizar los aciertos y errores del modelo.
Para los modelos que generan probabilidades, se calcula y visualiza la Curva ROC.
4. Métricas de Evaluación
Precisión: Porcentaje de predicciones correctas.
Matriz de Confusión: Visualización de los aciertos y errores del modelo en términos de verdaderos positivos, falsos positivos, verdaderos negativos y falsos negativos.
Curva ROC: Visualización de la capacidad del modelo para distinguir entre las clases a medida que cambia el umbral de decisión.
