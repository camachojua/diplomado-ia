using CSV
using DataFrames
using GLM
using ScikitLearn
using StatsBase
using RDatasets
using Random
using LinearAlgebra
using StatsModels
using ROCAnalysis

# Cargar el dataset
file_path = "../dat/Smarket.csv"
smarket = CSV.read(file_path, DataFrame)

# Preparar los datos
X = Matrix(select(smarket, Not([:Year, :Direction])))  # Características
smarketlabels = smarket.Direction
smarketlabelsmap = labelmap(smarketlabels)
y = labelencode(smarketlabelsmap, smarketlabels)  # Variable objetivo (codificada)

# Dividir los datos en conjuntos de entrenamiento y prueba
function perclass_splits(y, at)
    uids = unique(y)  # Obtener las clases únicas de la variable objetivo
    keepids = []
    for ui in uids
        curids = findall(y .== ui)  # Encontrar todos los índices donde la clase sea ui
        rowids = randsubseq(curids, at)  # Seleccionar aleatoriamente un porcentaje de esos índices
        push!(keepids, rowids...)  # Agregar esos índices al conjunto de entrenamiento
    end
    return keepids
end
trainids = perclass_splits(y, 0.7)  # 70% de los datos para entrenamiento
testids = setdiff(1:length(y), trainids)  # El resto para prueba

# Definir función para calcular la precisión
findaccuracy(predictedvals, groundtruthvals) = sum(predictedvals .== groundtruthvals) / length(groundtruthvals)

# Función para calcular la Confusión Matrix
function confusion_matrix(predicted, actual)
    return StatsBase.confusionmatrix(actual, predicted)  # Devuelve la matriz de confusión
end

# Función para calcular la Curva ROC
function plot_roc_curve(y_true, y_prob)
    roc = roc_analysis(y_true, y_prob)  # Análisis ROC para la curva
    return roc
end

# 1. LASSO (Regularización L1)
lasso_model = glm(@formula(y ~ X), smarket[trainids, :], Lasso)
lasso_preds = predict(lasso_model, smarket[testids, :])  # Predicciones de LASSO
lasso_accuracy = findaccuracy(lasso_preds, smarket.Direction[testids])  # Calcular precisión
println("LASSO accuracy: $lasso_accuracy")

# Confusión Matrix para LASSO
lasso_conf_matrix = confusion_matrix(lasso_preds, smarket.Direction[testids])
println("LASSO Confusion Matrix:\n", lasso_conf_matrix)

# 2. Ridge (Regularización L2)
ridge_model = glm(@formula(y ~ X), smarket[trainids, :], Ridge)
ridge_preds = predict(ridge_model, smarket[testids, :])  # Predicciones de Ridge
ridge_accuracy = findaccuracy(ridge_preds, smarket.Direction[testids])  # Calcular precisión
println("Ridge accuracy: $ridge_accuracy")

# Confusión Matrix para Ridge
ridge_conf_matrix = confusion_matrix(ridge_preds, smarket.Direction[testids])
println("Ridge Confusion Matrix:\n", ridge_conf_matrix)

# 3. Elastic Net (Combinación de L1 y L2)
elastic_net_model = glm(@formula(y ~ X), smarket[trainids, :], ElasticNet)
elastic_net_preds = predict(elastic_net_model, smarket[testids, :])  # Predicciones de Elastic Net
elastic_net_accuracy = findaccuracy(elastic_net_preds, smarket.Direction[testids])  # Calcular precisión
println("Elastic Net accuracy: $elastic_net_accuracy")

# Confusión Matrix para Elastic Net
elastic_net_conf_matrix = confusion_matrix(elastic_net_preds, smarket.Direction[testids])
println("Elastic Net Confusion Matrix:\n", elastic_net_conf_matrix)

# 4. Árbol de Decisión
@sk_import tree: DecisionTreeClassifier
dt_model = DecisionTreeClassifier()
fit!(dt_model, X[trainids, :], y[trainids])  # Entrenar el modelo
dt_preds = predict(dt_model, X[testids, :])  # Predicciones del Árbol de Decisión
dt_accuracy = findaccuracy(dt_preds, y[testids])  # Calcular precisión
println("Decision Tree accuracy: $dt_accuracy")

# Confusión Matrix para Árbol de Decisión
dt_conf_matrix = confusion_matrix(dt_preds, y[testids])
println("Decision Tree Confusion Matrix:\n", dt_conf_matrix)

# 5. Random Forest
@sk_import ensemble: RandomForestClassifier
rf_model = RandomForestClassifier(n_estimators=100)
fit!(rf_model, X[trainids, :], y[trainids])  # Entrenar el modelo
rf_preds = predict(rf_model, X[testids, :])  # Predicciones de Random Forest
rf_accuracy = findaccuracy(rf_preds, y[testids])  # Calcular precisión
println("Random Forest accuracy: $rf_accuracy")

# Confusión Matrix para Random Forest
rf_conf_matrix = confusion_matrix(rf_preds, y[testids])
println("Random Forest Confusion Matrix:\n", rf_conf_matrix)

# 6. K-Nearest Neighbors (KNN)
@sk_import neighbors: KNeighborsClassifier
knn_model = KNeighborsClassifier(n_neighbors=5)
fit!(knn_model, X[trainids, :], y[trainids])  # Entrenar el modelo
knn_preds = predict(knn_model, X[testids, :])  # Predicciones de KNN
knn_accuracy = findaccuracy(knn_preds, y[testids])  # Calcular precisión
println("K-Nearest Neighbors accuracy: $knn_accuracy")

# Confusión Matrix para K-Nearest Neighbors
knn_conf_matrix = confusion_matrix(knn_preds, y[testids])
println("K-Nearest Neighbors Confusion Matrix:\n", knn_conf_matrix)

# 7. Support Vector Machines (SVM)
@sk_import svm: SVC
svm_model = SVC(kernel="linear")
fit!(svm_model, X[trainids, :], y[trainids])  # Entrenar el modelo
svm_preds = predict(svm_model, X[testids, :])  # Predicciones de SVM
svm_accuracy = findaccuracy(svm_preds, y[testids])  # Calcular precisión
println("SVM accuracy: $svm_accuracy")

# Confusión Matrix para SVM
svm_conf_matrix = confusion_matrix(svm_preds, y[testids])
println("SVM Confusion Matrix:\n", svm_conf_matrix)

# Curva ROC - Asumimos que se requieren las probabilidades de las predicciones para SVM, KNN y Random Forest
function get_probabilities(model, X_test)
    return ScikitLearn.predict_proba(model, X_test)  # Obtener probabilidades
end

# Para Random Forest, KNN y SVM usamos las probabilidades para generar la curva ROC
rf_probs = get_probabilities(rf_model, X[testids, :])
rf_roc = plot_roc_curve(y[testids], rf_probs)  # Generar ROC para Random Forest
println("Random Forest ROC Curve:", rf_roc)

knn_probs = get_probabilities(knn_model, X[testids, :])
knn_roc = plot_roc_curve(y[testids], knn_probs)  # Generar ROC para KNN
println("K-Nearest Neighbors ROC Curve:", knn_roc)

svm_probs = get_probabilities(svm_model, X[testids, :])
svm_roc = plot_roc_curve(y[testids], svm_probs)  # Generar ROC para SVM
println("SVM ROC Curve:", svm_roc)
