# Reporte de ejercicio 3
Hernández Vela Daniel

Para comenzar se descarga previamente el dataset, este se localizará en el directorio Exercise3/dat/Smarket.csv listo para usarse.

Para leer el archivo .csv se utiliza la función `CSV.read()` de la siguiente manera:

```julia
smarket = CSV.read("../dat/Smarket.csv", DataFrame)
```

Se utilizan nuevamente las funciones `dataShape` y `countMissing` del ejercicio 1 para corroborar que no existan datos faltantes.

Se debera realizar One Hot Encoding a la columna de etiquetas Direction.

```julia
y = map(x -> if x == "Down" 0 elseif x == "Up" 1 end, smarket.Direction)
```

Se  obtiene el DataFrame que representa a X (las variables para el entrenamiento).

```julia
X = DataFrames.select(smarket, Not(:Direction))
```

Se divide aleatoriamente en conjuntos de entrenamiento y prueba

```julia
train_indices, test_indices = partition(1:length(y), 0.7, shuffle=true)

X_train = X[train_indices, :]
y_train = y[train_indices]
X_test = X[test_indices, :]
y_test = y[test_indices]
```

Una vez preparado el dataset se procede a realizar el entrenamiento de los modelos, en general estos seguirán el mismo framework de entrenamiento y prueba:


1. Se importa el modelo y se carga.

```julia
LogisticClassifier = @load LogisticClassifier pkg=MLJLinearModels
lasso_model = LogisticClassifier(penalty=:l1)
```

2. Se crea una "máquina" `machine` que entrenará al modelo.

```julia
lasso_machine = machine(lasso_model, X_train, y_train, scitype_check_level=0)
fit!(lasso_machine)
```

3. Se obtienen las predicciones, de las cuales luego se obtendrá la matriz de confusión y la curva ROC

```julia
y_pred_lasso = MLJ.predict(lasso_machine, X_test)
y_pred_lasso_class = mode.(y_pred_lasso)

# matriz de confusion

conf_matrix_lasso = MLJ.confusion_matrix(y_pred_lasso_class, y_test)
conf_matrix_lasso

heatmap(MLJ.ConfusionMatrices.matrix(conf_matrix_lasso), xlabel="Predicted", ylabel="Actual", title="Confusion Matrix LASSO", c=:blues, xticks=(1:length(class_labels), class_labels), yticks=(1:length(class_labels), class_labels), colorbar=true, yflip=true, size=(400, 400))

# curva ROC

roc_data_lasso = roc_curve(y_pred_lasso, y_test)
fpr_lasso = roc_data_lasso[1]
tpr_lasso = roc_data_lasso[2]

plot(fpr_lasso, tpr_lasso, xlabel="False Positive Rate", ylabel="True Positive Rate", title="ROC Curve Lasso", label="Lasso Model", linewidth=2)
plot!(x -> x, linestyle=:dash, color=:black, label="Random Classifier")
```

## Análisis de resultados

Una vez obtenidas las matrices de confusión y las curvas ROC para cada modelo entrenado podemos analizar lo siguiente:

- Los modelos LASSO y Elastic Net tienen el peor rendimiento, lo cual se puede intuir debido a su simpleza, sin embargo, Ridge obtuvo resultados sorprendentemente buenos.

- Decision Tree y Random Forest tienen resultados casi perfectos, personalmente, me parece que utilizar estos modelos es lo que en ingles llaman un "overkill", es decir, utilizar modelos muy potentes para tareas relativamente sencillas.

- Neirest neighbors tuvo resultados decentes pero no perfectos, ya se considera un modelo muy eficiente, parece que necesita más esfuerzo para alcanzar resultados decentes.

- Support Vector Machine tuvo resultados apenas aceptables, dado que se considera un modelo potente es curioso observar que tuvo peor rendimiento incluso que Ridge.