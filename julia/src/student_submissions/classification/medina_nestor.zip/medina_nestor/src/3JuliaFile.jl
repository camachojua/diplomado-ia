#### Demo using the ISL Chap 4 ISL Stock Market data
#### References: 
using MLJ, RDatasets, DataFrames, CSV, StatsBase, Plots, StatsPlots, MLJLinearModels, ROCAnalysis, Random, CategoricalArrays
### Read the data
smarket = CSV.read("/Users/nmedina/Documents/UNAM/Diplomado_IA/Proyectos/HM_Diciembre/classification/\
medina_nestor/dat/Smarket.csv", DataFrame, delim=',', header=true)
@show size(smarket)
@show names(smarket)

#Since we often  want  to only show a few significant digits for the metrics etc, let's introduce a simple function to do that:
r3(x) = round(x, sigdigits=3)
r3(pi)

#Let's get a description of the data too
describe(smarket, :mean, :std, :eltype)

# println the first 5 rows of the data set
println( smarket[1:5, :])

### Preparing the data
"""
The independent variables in columns [1..8] will form the X matrix of shape [1250, 1:8].
The dependent variable is Direction. The Direction variable contains categorical two values: "Down", "Up" 
Those values need to be transformed to the numbers 0, 1, and placed in a numerical array named y to compute logit regression.

Some people call this operation **One Shot Encoding**
"""
y = map( x -> if x == "Down" 0 elseif x == "Up" 1 end, smarket.Direction)

    println(y[1:15])    
    
    X = select(smarket, Not(:Direction));

### Split into train and test
#using Random

function perclass_splits(y, at::Float64, seed::Int)
    # Set the random seed for reproducibility
    Random.seed!(seed)
    
    uids = unique(y)
    keepids = Int[]  # Preallocate as an empty integer array
    
    for ui in uids
        curids = findall(y .== ui)  # Find indices where y == ui
        n_elements = length(curids)
        num_to_select = round(Int, n_elements * at / 100)  # Calculate the number of elements to select
        
        # Randomly permute and select the first 'num_to_select' elements
        rowids = randperm(n_elements)[1:num_to_select]
        append!(keepids, curids[rowids])  # Append selected indices to keepids
    end
    
    return keepids
end

trainids = perclass_splits(y,70.0,123)
testids = setdiff(1:length(y),trainids)

println(y[trainids])    
println(y[testids]) 

### Prepare the target
"""
We will now train the data using Logistic Regression.
 The target `:Direction` has two classes: `Up` and `Down`; 
 it needs to be interpreted as a categorical object,
 and we will mark it as a _ordered factor_ to
  specify that 'Up' is positive and 'Down' negative
   (for the confusion matrix later):
"""
y = coerce(y, OrderedFactor)
classes(y[1])
## y is of type "categorical" array. The values that it contains are "Up" and "Down"
@show(typeof(y))
println(y[1:5])

#### Convert to a Vector{Float64}
#For train
# Step 1: Extract integer codes using `levelcode`
int_vector_train = levelcode.(y[trainids]).-1
# Step 2: Convert to Vector of Float64 if needed
y_train = Float64.(int_vector_train)
println(typeof(y_train))  # Output: Vector{Float64}
println(y[trainids])
println(y_train)

#For test 
# Step 1: Extract integer codes using `levelcode`
int_vector_test = levelcode.(y[testids]).-1
# Step 2: Convert to Vector of Float64 if needed
y_test = Float64.(int_vector_test)
println(typeof(y_test ))  # Output: Vector{Float64}
println(y[testids])
println(y_test)

## 
println("Class distribution: ", countmap(y_train))
println("Class distribution: ", countmap(y_test))

X2 = select(X, Not([:Year, :Today]))
# println(X2)
### Functions to fit the models
# Function to train a classifier
function train_model(model, X, y)
    classif = machine(model, X, y)  # Create MLJ machine
    fit!(classif)                   # Train the model
    return classif
end

# Function to evaluate the classifier
function evaluate_model(classif, X, y)
    ŷ = predict_mode(classif, X)          # Predict class labels
    accuracy = 1 - misclassification_rate(ŷ, y)  # Compute accuracy
    misclassification_rate_val = misclassification_rate(ŷ, y)
    cm = confusion_matrix(ŷ, y)                  # Compute confusion matrix
    return accuracy, misclassification_rate_val, cm
end

# Define a function to calculate TPR and FPR at different thresholds
function compute_roc(y_true::Vector{Int}, y_scores::Vector{Float64})
    @assert length(y_true) == length(y_scores) "y_true and y_scores must have the same length"
    @assert all(y_true .∈ [0, 1]) "y_true must only contain 0 and 1"
    
    # Get unique thresholds sorted in descending order
    thresholds = unique(sort(y_scores, rev=true))
    
    # Initialize TPR and FPR
    tpr = Float64[]  # True Positive Rate
    fpr = Float64[]  # False Positive Rate
    
    # Compute TPR and FPR for each threshold
    for thresh in thresholds
        y_pred = y_scores .>= thresh  # Binary predictions
        
        # Confusion matrix components
        tp = sum((y_pred .== 1) .& (y_true .== 1))  # True Positives
        fp = sum((y_pred .== 1) .& (y_true .== 0))  # False Positives
        fn = sum((y_pred .== 0) .& (y_true .== 1))  # False Negatives
        tn = sum((y_pred .== 0) .& (y_true .== 0))  # True Negatives
        
        # Calculate rates
        push!(tpr, tp / max(tp + fn, eps()))  # Sensitivity or Recall
        push!(fpr, fp / max(fp + tn, eps()))  # Fall-out
    end
    
    return fpr, tpr, thresholds
end

# Función para calcular curva ROC y AUC
function plot_roc_from_scratch(y_true, y_probs)
    # Ordenar las probabilidades y etiquetas
    sorted_indices = sortperm(vec(y_probs), rev=true)
    y_true_sorted = y_true[sorted_indices]
    y_true_sorted=vec(y_true_sorted)
    n_pos = sum(y_true)
    n_neg = length(y_true) - n_pos
    
    # Calcular puntos de la curva ROC
    tpr = Float64[]
    fpr = Float64[]
    tp = 0
    fp = 0
    
    push!(tpr, 0.0)
    push!(fpr, 0.0)
    
    for i in 1:length(y_true_sorted)
        if y_true_sorted[i] == 1
            tp += 1
        else
            fp += 1
        end
        push!(tpr, tp/n_pos)
        push!(fpr, fp/n_neg)
    end
    
    # Calcular AUC usando la regla del trapecio
    auc = 0.0
    for i in 1:length(fpr)-1
        auc += (fpr[i+1] - fpr[i]) * (tpr[i+1] + tpr[i]) / 2
    end
    
    #return fpr, tpr, auc
    # Plot ROC curve
    Plots.plot(fpr, tpr, 
    label="ROC Curve (AUC = $(round(auc, digits=3)))", 
    xlabel="False Positive Rate", 
    ylabel="True Positive Rate")
end

#using Plots 
# Function to compute and plot ROC curve
function compute_and_plot_roc(model, X, y)
    ŷ = MLJ.predict(classif1, X2)

    # Generate the ROC curve
    fpr, tpr, thresholds = roc_curve(ŷ, y)
    
    # Plot the ROC curve (requires Plots.jl or another plotting library)
    plot(fpr, tpr, xlabel="False Positive Rate", ylabel="True Positive Rate", title="ROC Curve", label="")
end

### Lasso
using GLMNet, RDatasets, DataFrames, MLBase, Plots, DecisionTree, Distances, NearestNeighbors, Random, LinearAlgebra, DataStructures, LIBSVM, CSV

# Convert to Vector{Int64}
int_vector = Int64.(y_train)
##Convert to matrix
X2_matrix = Matrix(X2[trainids,:])

### LASSO

# Set random seed
Random.seed!(1234)
# choose the best lambda to predict with.
path = glmnet(X2_matrix, y_train)
cv = glmnetcv(X2_matrix, y_train)
mylambda = path.lambda[argmin(cv.meanloss)]

println(mylambda)
path = glmnet(X2_matrix, y_train,lambda=[mylambda]);
### Test metrics
X2_matrix_test = Matrix(X2[testids,:])

###Predictions for test data
#q = X2[testids,:];
#q_matrix = Matrix(q)
predictions_lasso = GLMNet.predict(path,X2_matrix_test )
# Convert the predicted probabilities to class labels
ŷ = vec(predictions_lasso .> 0.5)

#println(size(ŷ))
#println(size(y_test))
# Accuracy: 1 - misclassification rate
accuracy = 1 - misclassification_rate(ŷ, y_test) 
println("Accuracy: ", accuracy)

# Misclassification rate
misclassification_rate_val = misclassification_rate(ŷ, y_test) |> r3
println("Misclassification Rate: ", misclassification_rate_val)

# Step 4: Compute the Confusion Matrix
cm = confusion_matrix(ŷ, y_test)

display(cm)

### Test ROC CURVE
predictions_lasso = GLMNet.predict(path,X2_matrix_test )
# Convert the predicted probabilities to class labels
ŷ = vec(predictions_lasso .> 0.5)
plot(plot_roc_from_scratch(y_test,ŷ))


### Ridge
#using Random
# Set random seed
Random.seed!(1234)
#We will use the same function but set alpha to zero.
# choose the best lambda to predict with.
path = glmnet(X2_matrix, y_train,alpha=0)
cv = glmnetcv(X2_matrix, y_train,alpha=0)
mylambda = path.lambda[argmin(cv.meanloss)]
println("Lambda: ",mylambda)
path_r = glmnet(X2_matrix, y_train,alpha=0,lambda=[mylambda],standardize=false);

### Test metrics
#X2_matrix_test = Matrix(X2[testids,:])
###Predictions for test data
#q = X2[testids,:];
#q_matrix = Matrix(q)
predictions_ridge= GLMNet.predict(path_r,X2_matrix_test )
# Convert the predicted probabilities to class labels
ŷ = vec(predictions_ridge .> 0.5)

#println(size(ŷ))
#println(size(y_test))
# Accuracy: 1 - misclassification rate
accuracy = 1 - misclassification_rate(ŷ, y_test) 
println("Accuracy: ", accuracy)

# Step 4: Compute the Confusion Matrix
cm = confusion_matrix(ŷ, y_test)

display(cm)

### Test ROC CURVE
predictions_ridge = GLMNet.predict(path_r,X2_matrix_test )
# Convert the predicted probabilities to class labels
ŷ = vec(predictions_ridge .> 0.5)
plot(plot_roc_from_scratch(y_test,ŷ))

### Decision Tree Classifier 
using Random

# Set random seed
Random.seed!(1234)

using DecisionTree
X2_matrix = Matrix(X2[trainids,:])

classif2 = DecisionTreeClassifier(max_depth=10, min_samples_leaf=1)

DecisionTree.fit!(classif2, X2_matrix, y[trainids])

### Test metrics

X2_matrix_test = Matrix(X2[testids,:])

# Step 3: Predict Class Labels
ŷ = DecisionTree.predict(classif2, X2_matrix_test)

# Accuracy: 1 - misclassification rate
accuracy = 1 - misclassification_rate(ŷ, y_test) 
println("Accuracy: ", accuracy)

# Step 4: Compute the Confusion Matrix
cm = confusion_matrix(ŷ, y_test)

display(cm)
# Función para hacer predicciones
function predict(model, X; threshold=0.5)
    probs = predict_proba(classif2, X)[:,2]
    return probs, (probs .>= threshold) .|> Float64  # Convertir a Bool
end

y_pred_probs_test, y_pred_test=predict(classif2, X2_matrix_test)
println(y_pred_probs_test)
print(y_pred_test)

plot(plot_roc_from_scratch(y_test, y_pred_test))

### Random forest
# Set random seed
Random.seed!(1234)
X2_matrix = Matrix(X2[trainids,:])
classif3 = RandomForestClassifier(n_trees=10)
DecisionTree.fit!(classif3, X2_matrix, y[trainids])

### Test metrics

X2_matrix_test = Matrix(X2[testids,:])

#Predict Class Labels
ŷ = DecisionTree.predict(classif3, X2_matrix_test)

# Accuracy: 1 - misclassification rate
accuracy = 1 - misclassification_rate(ŷ, y_test) 
println("Accuracy: ", accuracy)

#Compute the Confusion Matrix
cm = confusion_matrix(ŷ, y_test)

display(cm)

y_pred_probs_test, y_pred_test=predict(classif3, X2_matrix_test)
plot_roc_from_scratch(y_test, y_pred_test)

### Nearest Neighbors
using NearestNeighborModels

KNNClassifier = @load KNNClassifier

knnc = KNNClassifier(K=5)
classif4 = machine(knnc, X2[trainids,:], y[trainids])
MLJ.fit!(classif4)

## Confusion matrix and accuracy for test data
accuracy4test, misclassification_rate_val4test, cm4test=evaluate_model(classif4, X2[testids,:], y[testids])
println("The accuracy is: ", accuracy4test)
println("The misclassification rate is: " , misclassification_rate_val4test)
display(cm4test)

## ### Test roc curve
ŷ = MLJ.predict(classif4, X2[testids,:])

# Generate the ROC curve
fpr, tpr, thresholds = roc_curve(ŷ, y[testids])
    
# Plot the ROC curve (requires Plots.jl or another plotting library)
plot(fpr, tpr, xlabel="False Positive Rate", ylabel="True Positive Rate", title="ROC Curve", label="")

### Support Vector Machine
using LIBSVM      # Import the package
@load SVC pkg=LIBSVM
model = svmtrain(X2_matrix', y_train)

### Test metrics
# Step 3: Predict Class Labels
predictions_SVM_t, decision_values_t = svmpredict(model, X2_matrix_test')

# Accuracy: 1 - misclassification rate
accuracy = 1 - misclassification_rate(predictions_SVM_t, y_test) 
println("Accuracy: ", accuracy)

# Step 4: Compute the Confusion Matrix
cm = confusion_matrix(predictions_SVM_t, y_test)

display(cm)

# Let's see the ROC Curves
plot(plot_roc_from_scratch(y_test, predictions_SVM_t))

#None of the models look good 
