## EJERCICIO 5
# MAYRA ALEJANDRA SÁNCHEZ ROBLEZ
# REPORTE DE AJUSTE DE REGRESIÓN LOGÍSTICA CON FLUX

#using Pkg
#Pkg.add("CSV")
#Pkg.add("DataFrames")
#Pkg.add("StatsPlots")
#Pkg.add("CategoricalArrays")
#Pkg.add("StatsModels")
#Pkg.add("Random")
#Pkg.add("StatsBase")
#Pkg.add("Statistics")
#Pkg.add("ROCAnalysis")
#Pkg.add("Tables")
#Pkg.add("Flux")

#Pkg.add("Weave")
#Pkg.add("Markdown")

# Librerías
using CSV
using DataFrames
using StatsPlots
using CategoricalArrays
using StatsModels
using Random
using StatsBase
using Statistics
using ROCAnalysis
using Tables
using Flux

using Markdown

# Leer el archivo CSV y guardarlo en un DataFrame
df = CSV.read("C:/Users/mayra/OneDrive/Desktop/SARM/5/dat/Churn_Modelling.csv", DataFrame)

# Función que muestra las dimensiones del df
function dataShape_(df::DataFrame, file)
    println(file, "Número de filas: ", size(df)[1])
    println(file, "")
    println(file, "Número de columnas: ", size(df)[2])
end

# Función para contar valores únicos en cada columna 
function uniqueValueCounts_(df::DataFrame, file) 

    for col in names(df)
        num_unicos = length(unique(df[!, col]))
        println(file, "$col: $num_unicos")
        println(file, "")
    end
end

# Función para imprimir nombre y tipo de cada columna (dataType)
function dataType_(df::DataFrame, file)
    for col in names(df)
        try
            col_data = df[!, col]
            col_type = eltype(col_data)  # Obtiene el tipo de la columna

            # Si la columna tiene un tipo Any, hacer algo especial
            if col_type == Any
                println(file, "Columna: ", col, " - Tipo: Any (Puede ser múltiple o dinámico)")
                println(file, "")
            else
                # Si el tipo es un tipo básico, lo imprimimos
                println(file, "Columna: ", col, " - Tipo: ", col_type)
                println(file, "")
            end
        catch e
            # Si ocurre un error, lo capturamos y lo mostramos
            println(file, "Columna: ", col, " - Error al obtener el tipo: ", e)
            println(file, "")
        end
    end
end

# Función para contar los valores faltantes en cada columna y devolver el conteo
function countMissingValues_(df::DataFrame, file)
    missing_counts = Dict()  # Usa un diccionario para almacenar los resultados
    println(file, "- CONTEO DE MISSING VALUES POR COLUMNA")
    println(file, "\n")

    for col in names(df)
        # Contar los valores faltantes en la columna
        num_missing = sum(ismissing, df[!, col])  # Cuenta los valores 'missing'
        missing_counts[col] = num_missing  # Almacen el conteo en el diccionario

        println(file, "Columna: ", col, " - Valores faltantes: ", num_missing)
        println(file, "")
    end

    return missing_counts  # Devuelve el diccionario con los valores faltantes
end

# Función para calcular el porcentaje de valores faltantes en cada columna
function dataMissingPercentage_(df::DataFrame, file)
    # Primero, obtener el diccionario con los valores faltantes
    missing_counts = countMissingValues_(df, file)
    println(file, "\n")
    println(file, "- PORCENTAGE DE VALORES FALTANTES POR COLUMNA")
    println(file, "\n")

    total_rows = size(df)[1]  # Número total de filas

    for col in names(df)
        # Obtener el número de valores faltantes de la columna del diccionario
        num_missing = missing_counts[col]  # Acceder al valor desde el diccionario

        # Calcular el porcentaje de valores faltantes en la columna
        percentage_missing = (num_missing / total_rows) * 100  # Calcular porcentaje
        
        # Imprimir el resultado
        println(file, "Columna: ", col, "- Porcentaje de valores faltantes: ", round(percentage_missing, digits = 2), "%")
        println(file, "")
    end
end

# Crear una función para contar los valores únicos en Year y Direction 
function countUniqueValues_(df::DataFrame, col_names::Vector{Symbol}, suff)
    conteos = Dict{Symbol, DataFrame}() 
    for col_name in col_names
        # Contar valores únicos
        conteo = combine(groupby(df, col_name), nrow => :conteo)
        # Calcular porcentajes 
        conteo[:, :porcentaje] = 100 * conteo[:, :conteo] ./ nrow(df)
        # Guardar el DataFrame con conteos y porcentajes
        conteos[col_name] = conteo 

        # Graficar los resultados
        x = conteo[!, col_name] 
        y = conteo[!, :conteo]
        p = bar(x, y, title="Conteo de $col_name", xlabel = "Valores", ylabel = "Frecuencia", legend = false, color = :pink, size=(400, 400)) 
        savefig(p, "C:/Users/mayra/OneDrive/Desktop/SARM/5/fig/uniqueValues$suff$col_name.png")
        display(p)
    end
    return conteos
end

# Función para eliminar outliers usando el método IQR
function removeOutliersIQR!(df::DataFrame)
    # Definir las columnas que serán tratadas como categóricas
    excluir = ["Exited", "CustomerId", "Geography", "Gender", "HasCrCard", "IsActiveMember"]
    # Iterar sobre las columnas numéricas del DataFrame
    for col in names(df, Not(excluir))
        if eltype(df[!, col]) <: Real  # Solo se aplica a columnas numéricas
            # Calcular los cuartiles Q1 y Q3
            Q1 = quantile(df[!, col], 0.25)
            Q3 = quantile(df[!, col], 0.75)
            
            # Calcular el IQR (Rango Intercuartílico)
            IQR = Q3 - Q1
            
            # Definir los límites inferior y superior para los outliers
            lower_limit = Q1 - 1.5 * IQR
            upper_limit = Q3 + 1.5 * IQR
            
            # Filtrar los valores dentro del rango (eliminar outliers)
            df = df[(df[!, col] .>= lower_limit) .& (df[!, col] .<= upper_limit), :]
        end
    end
    return df
end

# Crear una función para convertir la columna Year en variables dummies 
function convertir_a_dummies(df::DataFrame, col_names::Vector{Symbol})
    for col_name in col_names
        # Convertir la columna a categórica
        df[!, col_name] = categorical(df[!, col_name])
        
        # Crear la matriz de diseño con las variables dummies
        dummies = DataFrame(Matrix(modelmatrix(Term(col_name), df)), :auto)
        
        # Obtener los nombres de las categorías
        levels = CategoricalArrays.levels(df[!, col_name])
        
        # Renombrar las columnas dummies
        for (i, name) in enumerate(names(dummies))
            rename!(dummies, name => Symbol("$col_name$(levels[i])"))
        end
        
        # Eliminar la columna original del DataFrame
        df = DataFrames.select(df, Not(col_name))
        
        # Unir las variables dummies al DataFrame
        df = hcat(df, dummies)
    end
    return df
end

# Función para dividir los datos en entrenamiento y prueba
function trainTestSplit_(df::DataFrame, porcentaje_test::Float64, file)
    # Determinar el número de filas para test
    n = nrow(df)
    n_test = round(Int, porcentaje_test * n)
    
    # Crear un índice aleatorio para dividir
    indices = shuffle(1:n)  # Mezclar los índices aleatoriamente
    indices_test = indices[1:n_test]  # Primeros índices para test
    indices_train = indices[n_test+1:end]  # El resto para entrenamiento
    
    # Crear los DataFrames de entrenamiento y prueba
    df_train = df[indices_train, :]
    df_test = df[indices_test, :]
    
    # Asegurarnos de que ambas divisiones tengan datos
    println(file, "\n")
    println(file, "Número de filas de df_train: ", nrow(df_train))
    println(file, "")
    println(file, "Número de filas de df_test: ", nrow(df_test))
    
    return df_train, df_test
end

# Función para escalar variables usando MinMaxScaler 
function minMaxScaling_(train_df::DataFrame, test_df::DataFrame)
    excluirDummy = ["Exited", "CustomerId", "Geography", "Gender", "HasCrCard", "IsActiveMember"]
    continuous_vars_train = DataFrames.select(train_df, Not(excluirDummy))
    dummy_vars_train = DataFrames.select(train_df, excluirDummy)

    continuous_vars_test = DataFrames.select(test_df, Not(excluirDummy))
    dummy_vars_test = DataFrames.select(test_df, excluirDummy)

    # Convertimos los DataFrames de variables continuas a matrices para hacer operaciones matemáticas
    X_train = Matrix(continuous_vars_train)
    X_test = Matrix(continuous_vars_test)

    # Creamos matrices vacías para los resultados escalados
    continuous_scaled_train = similar(X_train)
    continuous_scaled_test = similar(X_test)
    
    # Iteramos sobre cada columna para realizar el escalado Min-Max
    for i in 1:size(X_train, 2)  # Iteramos por columnas
        # Obtenemos el mínimo y máximo de la columna i en el conjunto de entrenamiento
        min_val = minimum(X_train[:, i])
        max_val = maximum(X_train[:, i])

        # Aplicamos el escalado Min-Max a la columna i en el conjunto de entrenamiento y prueba
        continuous_scaled_train[:, i] .= (X_train[:, i] .- min_val) ./ (max_val .- min_val)
        continuous_scaled_test[:, i] .= (X_test[:, i] .- min_val) ./ (max_val .- min_val)
    end

    # Convertimos las matrices escaladas nuevamente a DataFrames con nombres automáticos
    train_df_scaled = DataFrame(continuous_scaled_train, :auto)
    test_df_scaled = DataFrame(continuous_scaled_test, :auto)

    # Renombramos las columnas manualmente añadiendo el sufijo "_Esc"
    for i in 1:ncol(train_df_scaled)
        rename!(train_df_scaled, names(train_df_scaled)[i] => string(names(train_df)[i], "_Esc"))
    end

    for i in 1:ncol(test_df_scaled)
        rename!(test_df_scaled, names(test_df_scaled)[i] => string(names(test_df)[i], "_Esc"))
    end

    train_df_scaled = hcat(train_df_scaled, dummy_vars_train)
    test_df_scaled = hcat(test_df_scaled, dummy_vars_test)
    
    return train_df_scaled, test_df_scaled
end

# Función para mostrar y eliminar las parejas con alta correlación del DataFrame 
function deleteExplicativeHighCorrelatedVariables_(df::DataFrame, file)
    excluirDummy = ["Exited", "CustomerId", "Geography", "Gender", "HasCrCard", "IsActiveMember"]
    df1 = DataFrames.select(df, Not(excluirDummy))
    # Calcular la matriz de correlación 
    corr_matrix = cor(Matrix(df1)) 
    # Obtener los nombres de las columnas 
    col_names = names(df1) 
    # Inicializar una lista para almacenar las columnas a eliminar 
    cols_to_remove = Set{Symbol}() 
    
    # Encontrar las parejas de variables con alta correlación 
    for i in 1:length(col_names) 
        for j in (i+1):length(col_names)
            print(file, "Correlación entre $(col_names[i]) y $(col_names[j]) : $(corr_matrix[i, j])")
            println(file, "\n")
        end 
    end
    println(file, "- NINGUNA CORRELACIÓN SUPERÓ EL UMBRAL DE 0.70, POR LO QUE SE CONSERVARÁN TODAS LAS VARIABLES")
    println(file, "\n")
end

# Función que arroja una descripción más detallada del df final
function describeExtended_(df::DataFrame, file)

    resumen = describe(df)
    println(file, "CUANTILES POR COLUMNA:")
    for col in names(df) 
        if eltype(df[!, col]) <: Number 
            vals = df[!, col]
            
            q25 = quantile(vals, 0.25) 
            q50 = quantile(vals, 0.5) 
            q75 = quantile(vals, 0.75) 
            
            println(file, "\n")
            println(file, "Columna: $col")
            println(file, "")
            println(file, " 25%: $q25") 
            println(file, " 50% (Mediana): $q50") 
            println(file, " 75%: $q75") 
            println(file, "\n")
        end 
    end 
    
    return resumen 
end

# Convertir el DataFrame de describe a una tabla Markdown
function dataframeToMarkdownDescribe_(df::DataFrame)
    headers = names(df)
    # Convertir cada fila del DataFrame a un Vector de cadenas
    rows = [string.(collect(row)) for row in eachrow(df)]
    
    # Formatear la tabla en Markdown
    table_md = "| " * join(headers, " | ") * " |\n"
    table_md *= "| " * join(["-"^length(h) for h in headers], " | ") * " |\n"
    for row in rows
        table_md *= "| " * join(row, " | ") * " |\n"
    end
    return table_md
end

# Convertir el DataFrame de describe a una tabla Markdown
function dataframeToMarkdown_(df::DataFrame)
    headers = names(df)
    # Convertir cada fila del DataFrame a un Vector de cadenas
    rows = [string.(collect(row)) for row in eachrow(df)]
    # Determinar el ancho máximo de cada columna 
    col_widths = [maximum([length(header), maximum(length.(string.(df[:, i])))]) for (i, header) in enumerate(headers)]
    # Formatear la tabla en Markdown
    table_md = "| " * join([lpad(headers[i], col_widths[i]) for i in 1:length(headers)], " | ") * " |\n"
    table_md *= "| " * join([repeat("-", col_widths[i]) for i in 1:length(headers)], " | ") * " |\n"
    for row in rows
        table_md *= "| " * join([lpad(row[i], col_widths[i]) for i in 1:length(row)], " | ") * " |\n"
    end
    return table_md
end

# Función para calcular el AUC
function calculateAUC_(model, X_test, y_test, file)
    # Hacer las predicciones con el modelo
    y_pred = model(X_test)'
    y_pred = vec(Float32.(y_pred))
    y_test = vec(y_test)
    # Calcular la curva ROC y AUC
    roc_curve = ROCAnalysis.roc(y_test, y_pred)
    auc_value = auc(roc_curve)
    # Imprimir el AUC
    println(file, "\n") 
    println(file, "AUC: ", auc_value)
    println(file, "\n")      # Imprime una línea en blanco para separar
    # Graficar la curva ROC
    p = plot(roc_curve, xlabel="False Positive Rate", ylabel="True Positive Rate", title="Curva ROC", label="ROC Curve", size=(400, 400))
    display(p)
    # Guardar la imagen en un archivo
    savefig(p, "C:/Users/mayra/OneDrive/Desktop/SARM/5/fig/roc_curve_FLUX.png")
    # Matriz de Confusión
    # Clasifica las predicciones en clases utilizando un umbral de 0.5
    y_pred1 = model(X_test)' .> 0.5
    y_pred1 = vec(Float32.(y_pred1))
    # Calcula la matriz de confusión 
    true_positive = sum((y_pred1 .== 1) .& (y_test .== 1))
    true_negative = sum((y_pred1 .== 0) .& (y_test .== 0))
    false_positive = sum((y_pred1 .== 1) .& (y_test .== 0))
    false_negative = sum((y_pred1 .== 0) .& (y_test .== 1))
    
    confusion_matrix = [ true_positive false_positive; false_negative true_negative ]

    # Visualiza la matriz de confusión 
    h = heatmap(confusion_matrix, title = "Matriz de Confusión de Flux", xlabel = "Predicción", ylabel = "Verdadero", xticks = (1:2, ["Positivo", "Negativo"]), yticks = (1:2, ["Positivo", "Negativo"]), size = (400, 400)) 
    # Anota los números en el centro de cada celda 
    for i in 1:2 
        for j in 1:2 
            annotate!(i, j, text(confusion_matrix[i, j], :white, :center)) 
        end
    end
    savefig("C:/Users/mayra/OneDrive/Desktop/SARM/5/fig/confusion_matrix_Flux.png")
    display(h)
end

function logRedFLUX_(X_train, y_train, X_test, y_test, file)
    println(file, "**SE ENTRENARÁ Y HARÁN PREDICCIONES CON UN MODELO DEFINIDO, HACER GRID SEARCH COMO EN LOS OTROS EJERCICIOS NO ME FUE POSIBLE, YA QUE, TENÍA MUCHOS ERRORES Y POCA LITERATURA PARA ENCONTRAR SOLUCIONES**")
    println(file, "\n") 
    println(file, "EL MODELO ES EL SIGUIENTE:")
    println(file, "")

    model = Chain(Dense(size(X_train, 1), 64, relu),
                    Dense(64, 32, relu),
                    Dense(32, 1, Flux.sigmoid))
    loss(m, x, y) = Flux.logitbinarycrossentropy(m(x)', y)
    opt = ADAM()
    state = Flux.setup(opt, model)

    println(file, model)
    println(file, "\n") 
    println(file, "CON EL OPTIMIZADOR __ADAM__ Y LA FUNCIÓN DE PÉRDIDA:")
    println(file, "\n") 
    println(file, "Flux.logitbinarycrossentropy(m(x)', y)")
    println(file, "\n") 

    epochs = 3000
    for epoch in 1:epochs
        grads  = gradient(m -> loss(model, X_train, y_train), model)
        #Flux.train!(loss, Flux.trainable(model), [(X_train, y_train)], opt)
        Flux.Optimise.update!(state, Flux.trainable(model), grads[1])
    end
    calculateAUC_(model, X_test, y_test, file) 
end

# Crear y escribir el contenido del archivo reporte.jmd 
function crearReporte(df::DataFrame, file_path::String)

    open(file_path, "w") do file
        println(file, "# **EJERCICIO 5**")
        println(file, "## *author: MAYRA ALEJANDRA SÁNCHEZ ROBLEZ*")
        println(file, "### __title: REPORTE DE AJUSTE DE REGRESIÓN LOGÍSTICA CON FLUX")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "**SÚPER IMPORTANTE MENCIONAR QUE ES UN MAL MODELO, NECESITA DE UNA PERSONA CON MAS CONOCIMIENTOS QUE LA DECLARACIÓN QUE YO IMPLEMENTÉ, LA MÉTRICAS PARECEN BUENAS PERO EN REALIDAD ESTÁN TENIENDO INFLUENCIA DEL DESBALANCE DE LA TARGET Y DE LAS EXPLICATIVAS POCO BALANCEADAS, Y CLARO, DE MI MÉTODO PARA BALANCEARLAS. YO PREFERIRÍA HACER UNA REGRESIÓN LOGÍSTICA SIN REDES NEURONALES.**")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- NÚMERO DE FILAS Y COLUMNAS DEL DS INICIAL")
        println(file, "\n")      # Imprime una línea en blanco para separar
        dataShape_(df, file)  # Imprime número de filas y columnas
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- NÚMERO DE VALORES ÚNICOS EN CADA VARIABLE")
        println(file, "\n")      # Imprime una línea en blanco para separar
        uniqueValueCounts_(df, file)        # Función para imprimir el conteo de valores únicos por columna
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- SE ELIMINAN LAS COLUMNAS __RowNumber & Surname__ YA QUE, LA PRIMERA, UN INDEX QUE NO ES ÚTIL Y LA SEGUNDA SON LOS APELLIDOS DE LOS CLIENTES, EL CUAL ES IRRELEVANTE")
        println(file, "YA QUE, EL APELLIDO ES UNA VARIABLE QUE NO DEBERÍA INFLUIR EN LA DECISIÓN FINAL DE APROBACIÓN O RECHAZO. DEJARLAS PODRÍA AFECTAR EL USO DE MEMORIA Y LOS PRONÓSTICOS")
        select!(df, Not([:RowNumber,:Surname]))     # Eliminar las columnas de ID únicas directamente 
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- IMPRIME EL TYPE INICIAL DE CADA COLUMNA")
        println(file, "\n")      # Imprime una línea en blanco para separar
        dataType_(df, file)   # Imprime nombre y tipo de cada columna
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- TODAS LAS COLUMNAS TIENEN TYPE ADECUADO. IMPORTANTE SABER QUE LA TARGET SERÁ __Exited__")
        println(file, "\n")      # Imprime una línea en blanco para separar
        dataMissingPercentage_(df, file)    # Función que arroja el conteo de missings y el porcentaje que representan de la variable
        println(file, "\n")      # 6i8i0op'Imprime una línea en blanco para separar
        println(file, "- AL NO TENER VALORES MISSING NO SE ELIMINÓ NINGUNA COLUMNA")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- AL PARECER, TODO BIEN, PERO SE HARÁ UN ANÁLISIS DE TODAS LAS VARIABLES, PRIMERO LAS EXPLICATIVAS CATEGÓRICAS __Geography, Gender, Tenure, NumOfProducts, HasCrCard, IsActiveMember__ ANALIZANDO EL CONTEO DE VALORES ÚNICOS")
        println(file, "")      # Imprime un salto de línea simple
        resultados = countUniqueValues_(df, [:Geography, :Gender, :HasCrCard, :IsActiveMember, :Exited], "_1_")       # Función que hace un conteo de repetición de valores unicos en las variables categóricas
        println(file, "CONTEO DE REPETICIÓN DE VALORES ÚNICOS EN TODAS LAS CATEGÓRICAS, ASÍ COMO SU REPRESENTATIVIDAD EN EL DATASET EN PORCENTAJE")
        println(file, "\n")      # Imprime una línea en blanco para separar
        columns_to_process = [:Geography, :Gender, :HasCrCard, :IsActiveMember]
        # Función para iterar sobre las columnas y generar tablas Markdown para cada una
        for col_name in columns_to_process
            mdTable = dataframeToMarkdown_(resultados[col_name])    # Llamar a la función dataframeToMarkdown_ para cada columna    
            println(file, "\n")     # Imprime una línea en blanco para separar
            println(file, string(mdTable))      # Imprimir la tabla Markdown generada en el archivo
            println(file, "              .")  
            mdTable = nothing    # Eliminar el DataFrame para liberar memoria
        end
        println(file, "- AHORA UN CONTEO DE REPETICIÓN DE VALORES ÚNICOS EN LA TARGET __Exited__ , Y ASÍ ASEGURAR QUE TENDREMOS UN DATASET BALANCEADO")
        println(file, "\n")      # Imprime una línea en blanco para separar
        mdTableExited = dataframeToMarkdown_(resultados[:Exited])
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, mdTableExited)
        mdTableExited = nothing    # Eliminar el DataFrame para liberar memoria
        resultados = nothing    # Eliminar el DataFrame para liberar memoria
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- LA VARIABLE OBJETIVO ESTÁ DESBALANCEADA, POR LO QUE SE APLICARÁ UN TÉCNICA DOBLE: REDUCIR LA CLASE MAYORITARIA EN 10% Y DUPLICAR LA MINORITARIA")
        println(file, "\n")      # Imprime una línea en blanco para separar
        df_class_0 = df[df.Exited .== 0, :]       # Filtrar las filas donde Exited es 0
        rows_to_remove = sample(1:size(df_class_0, 1), 1000, replace=false)     # Seleccionar aleatoriamente 1000 filas
        df_1 = df_class_0[setdiff(1:nrow(df_class_0), rows_to_remove), :]       # Filtrar las filas que se van a eliminar
        df_class_0 = nothing    # Eliminar el DataFrame para liberar memoria
        rows_to_remove = nothing    # Eliminar el DataFrame para liberar memoria
        df_class_1 = df[df.Exited .== 1, :]   # Filtrar las filas donde Exited es 0
        rows_to_duplicate = sample(1:size(df_class_1, 1), 3000, replace=true)     # Seleccionar aleatoriamente 2000 filas
        df_class_1_duplicated = df_class_1[rows_to_duplicate, :]        # Filtrar las filas que se van a duplicar
        df_class_1_final = vcat(df_class_1, df_class_1_duplicated)      # Duplicar las filas seleccionadas (agregar esas filas duplicadas)
        df_2 = vcat(df_1, df_class_1_final)     # Unir el dataset anteior con los 2000 renglones duplicados
        df = nothing    # Eliminar el DataFrame para liberar memoria
        df_1 = nothing    # Eliminar el DataFrame para liberar memoria
        df_class_1 = nothing    # Eliminar el DataFrame para liberar memoria
        rows_to_duplicate = nothing    # Eliminar el DataFrame para liberar memoria
        df_class_1_duplicated = nothing    # Eliminar el DataFrame para liberar memoria
        df_class_1_final = nothing    # Eliminar el DataFrame para liberar memoria
        println(file, "CHECK DE VERIFICACIÓN DE BALANCEO DE LA TARGET")
        println(file, "\n")      # Imprime una línea en blanco para separar
        resultadosEx = countUniqueValues_(df_2, [:Exited], "_2_") 
        mdTableEx = dataframeToMarkdown_(resultadosEx[:Exited])
        resultadosEx = nothing    # Eliminar el DataFrame para liberar memoria
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, mdTableEx)
        println(file, "              .")
        mdTableEx = nothing    # Eliminar el DataFrame para liberar memoria
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "**LISTO, LA VARIABLE TARGET ESTÁ BALANCEADA Y ES POSIBLE CONTINUAR EL PROCESO**")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- AHORA SE DEBE DE MODIFICAR LA NATURALEZA DE ALGUNAS CATEGÓRICAS EXPLICATIVAS")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "DADO QUE NECESITAMOS VALORES NUMÉRICOS EN LAS EXPLICATIVAS, SE CAMBIAN LOS VALORES DE __Gender__ POR NUMÉRICOS __Female = 1 Y Male = 0__")
        df_2[!, :Gender] = ifelse.(df_2[!, :Gender] .== "Female", 1, 0)
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "LA VARIABLE __Geography__ TIENE 3 CATEGORÍAS Y POCA REPRESENTATIVIDAD EN DOS DE ELLAS, POR LO QUE SE UNIRÁN, EL NOMBRE DE LA NUEVA CATEGORÍA SERÁ __Spain_Or_Germany__")
        df_2[!, :Geography] .= ifelse.(df_2[!, :Geography] in ["Spain", "Germany"], "Spain_Or_Germany", df_2[!, :Geography])
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "AHORA, LA VARIABLE __Geography__ AL TENER SOLO 2 VALORES ÚNICOS, SERÁ CONVERTIDA EN DUMMY SIENDO __France = 1 y Spain_Or_Germany = 0__")
        df_2[!, :Geography] = ifelse.(df_2[!, :Geography] .== "France", 1, 0)
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- SE HACE UN CONTEO DE LA VARIABLE MODIFICADA __Geography__ PARA VERIFICAR LA DISTRIBUCIÓN")
        println(file, "")      # Imprime un salto de línea simple
        resultadosG = countUniqueValues_(df_2, [:Geography],"_3_")
        mdTableG = dataframeToMarkdown_(resultadosG[:Geography])
        resultadosG = nothing    # Eliminar el DataFrame para liberar memoria
        println(file, "\n")     # Imprime una línea en blanco para separar
        println(file, mdTableG)
        println(file, "              .")
        mdTableG = nothing    # Eliminar el DataFrame para liberar memoria
        println(file, "\n")     # Imprime una línea en blanco para separar
        println(file, "TODO BIEN, LAS COLUMNAS RESULTANTES DEL NUEVO DF SON:")
        println(file, "")      # Imprime un salto de línea simple
        println(file, names(df_2))
        println(file, "              .")
        println(file, "\n")     # Imprime una línea en blanco para separar
        println(file, "VERIFICACIÓN DE QUE LOS TYPES DE LAS VARIABLES NO SE VIERON AFECTADOS POR EL TRATAMIENTO")
        println(file, "\n")     # Imprime una línea en blanco para separar
        dataType_(df_2, file)   # Imprime nombre y tipo de cada columna
        println(file, "\n")     # Imprime una línea en blanco para separar
        println(file, "- TODO BIEN, SIGUE EL ANÁLISIS IQR PARA EVITAR ATÍPICOS EN LAS VARIABLES CONTINUAS QUE SON: __CreditScore, Balance, Ternure, NumOfProducts & EstimatedSalary__")
        println(file, "\n")      # Imprime una línea en blanco para separar
        df_3 = removeOutliersIQR!(df_2)       # Eliminar outliers usando el método IQR
        println(file, "CHECK DE DIMENSIONES, VISUALIZAR CUANTOS OUTLIERS FUERON ELIMINADOS")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "DIMENCIONES INICIALES:")
        println(file, "")       # Imprime un salto de línea simple
        dataShape_(df_2, file)  # Imprime número de filas y columnas
        println(file, "              .")
        println(file, "\n")
        println(file, "DIMENCIONES DESPUÉS DE IQR:")
        println(file, "")       # Imprime un salto de línea simple
        dataShape_(df_3, file)  # Imprime número de filas y columnas
        println(file, "\n")      # Imprime una línea en blanco para separar
        df_2 = nothing    # Eliminar el DataFrame para liberar memoria
        println(file, "              .")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "FALTA VERIFICAR SI NO CAUSÓ DESBALANCE LA ELIMINACIÓN DE OUTLIERS")
        println(file, "\n")      # Imprime una línea en blanco para separar
        resultados1 = countUniqueValues_(df_3, [:Exited], "_4_")       # Función que hace un conteo de repetición de valores unicos en las variables categóricas
        mdTableExited1 = dataframeToMarkdown_(resultados1[:Exited])
        resultados1 = nothing    # Eliminar el DataFrame para liberar memoria
        println(file, mdTableExited1)
        mdTableExited1 = nothing    # Eliminar el DataFrame para liberar memoria
        println(file, "              .")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "TODO BIEN")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- DADO QUE LA BASE YA ESTA LIMPIA, SE PROCEDE A ESCALAR VARIABLES")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- IMPORTANTE PRIMERO TENER LOS SETS DE ENTRENAMIENTO Y TEST")
        df_train, df_test = trainTestSplit_(df_3, 0.20, file)      # Dividir los datos en entrenamiento y prueba
        df_3 = nothing    # Eliminar el DataFrame para liberar memoria
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- FALTA VERIFICAR SI NO CAUSÓ DESBALANCE LA DIVISIÓN EN TRAIN Y TEST")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "PRIMERO EL TRAIN:")      # Imprime una línea en blanco para separar
        println(file, "\n")      # Imprime una línea en blanco para separar
        resultadosTrain = countUniqueValues_(df_train, [:Exited], "_5_")       # Función que hace un conteo de repetición de valores unicos en las variables categóricas
        mdTableExitedTrain = dataframeToMarkdown_(resultadosTrain[:Exited])
        println(file, mdTableExitedTrain)
        resultadosTrain = nothing    # Eliminar el DataFrame para liberar memoria
        mdTableExitedTrain = nothing    # Eliminar el DataFrame para liberar memoria
        println(file, "              .")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "Y EL TEST:")      # Imprime una línea en blanco para separar
        println(file, "\n")      # Imprime una línea en blanco para separar
        resultadosTest = countUniqueValues_(df_test, [:Exited], "_6_")       # Función que hace un conteo de repetición de valores unicos en las variables categóricas
        mdTableExitedTest = dataframeToMarkdown_(resultadosTest[:Exited])
        println(file, mdTableExitedTest)
        resultadosTest = nothing    # Eliminar el DataFrame para liberar memoria
        mdTableExitedTest = nothing    # Eliminar el DataFrame para liberar memoria
        println(file, "              .")
        println(file, "\n")      # Imprime una línea en blanco para separar
        df_2EscaladoTrain, df_2EscaladoTest = minMaxScaling_(df_train, df_test)     # Escalar variables necesarias
        df_train = nothing    # Eliminar el DataFrame para liberar memoria
        df_test = nothing    # Eliminar el DataFrame para liberar memoria
        println(file, "**TODO BIEN**")
        println(file, "")       # Imprime un salto de línea simple
        println(file, "- DESCRIPCIÓN DE LOS SETS ESCALADOS, EL DE ENTRENAMIENTO:")
        println(file, "\n")      # Imprime una línea en blanco para separar
        desEscTrain = describe(df_2EscaladoTrain)
        desEscTrain[:, [:mean, :min, :median, :max, :nmissing]] .= round.(desEscTrain[:, [:mean, :min, :median, :max, :nmissing]] , digits=4)
        mdTableTrainEsc = dataframeToMarkdownDescribe_(desEscTrain)
        println(file, mdTableTrainEsc)
        desEscTrain = nothing    # Eliminar el DataFrame para liberar memoria
        mdTableTrainEsc = nothing    # Eliminar el DataFrame para liberar memoria
        println(file, "              .")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "EL DE PRUEBA:")
        println(file, "\n")      # Imprime una línea en blanco para separar
        desEscTest = describe(df_2EscaladoTest)
        desEscTest[:, [:mean, :min, :median, :max, :nmissing]] .= round.(desEscTest[:, [:mean, :min, :median, :max, :nmissing]] , digits=4)
        mdTableTestEsc = dataframeToMarkdownDescribe_(desEscTest)
        println(file, mdTableTestEsc)
        desEscTest = nothing    # Eliminar el DataFrame para liberar memoria
        mdTableTestEsc = nothing    # Eliminar el DataFrame para liberar memoria
        println(file, "              .")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "**TODO BIEN**")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- LO SIGUIENTE ES VERIFICAR QUE NO EXISTA MULTICOLINEARIDAD ENTRE LAS EXPLICATIVAS")
        println(file, "\n")      # Imprime una línea en blanco para separar
        deleteExplicativeHighCorrelatedVariables_(df_2EscaladoTrain, file)
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "**NINGUNA VARIABLE PRESENTÓ UN RIESGO. FINALMENTE SE PROCEDE A MODELAR**")
        println(file, "\n")      # Imprime una línea en blanco para separar
        # Acomodar los sets de train y test para que puedan funcionar en el modelo
        y_train = Float32.(reshape(df_2EscaladoTrain[!, :Exited], :, 1))
        X_train = Float32.(transpose(Matrix(DataFrames.select(df_2EscaladoTrain, Not(:Exited)))))
        y_test = Float32.(reshape(df_2EscaladoTest[!, :Exited], :, 1))
        X_test = Float32.(transpose(Matrix(DataFrames.select(df_2EscaladoTest, Not(:Exited)))))
        println(file, "DADO QUE SE OBTUVIERON MATRICES T, SE VERIFICA QUE LOS SETS TENGAN LAS DIMENSIONES CORRECTAS")
        println(file, "\n")      # Imprime una línea en blanco para separar
        # Verificar dimensiones
        println(file, "Dimensiones de X_train: ", size(X_train))
        println(file, "")      # Imprime un espacio en blanco para separar
        println(file, "Dimensiones de y_train: ", size(y_train))
        println(file, "")      # Imprime un espacio en blanco para separar
        println(file, "Dimensiones de X_test: ", size(X_test))
        println(file, "")      # Imprime un espacio en blanco para separar
        println(file, "Dimensiones de y_test: ", size(y_test))
        println(file, "\n")      # Imprime un espacio en blanco para separar
        logRedFLUX_(X_train, y_train, X_test, y_test, file)
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "LA MATRIZ DE CONFUSIÓN ASÍ COMO LA CURVA ROC OBTENIDA DE LA LIBRERÍA __ROCAnalysis__ Y EL RESTO DE LAS IMÁGENES SE AÑADEN AL FINAL:")
        println(file, "\n") 
        println(file, "![IMAGEN DE LA CURVA ROC, MODELO FLUX LOGREG](../fig/roc_curve_FLUX.png)")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "![IMAGEN DE LA MATRIZ DE CONFUSIÓN, MODELO FLUX LOGREG](../fig/confusion_matrix_Flux.png)")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "\n")      # Imprime una línea en blanco para separar
        for image_name in ["Exited", "Gender", "Geography", "HasCrCard", "IsActiveMember"]
            println(file, "![IMAGEN DE DISTRIBUCIÓN INICIAL DE $image_name](../fig/uniqueValues_1_$image_name.png)")
            println(file, "\n")
        end
        println(file, "\n")
        println(file, "![IMAGEN DE DISTRIBUCIÓN DESPUÉS DE BALANCEO DE EXITED](../fig/uniqueValues_2_Exited.png)")
        println(file, "\n")
        println(file, "![IMAGEN DE DISTRIBUCIÓN DESPUÉS DE UNIÓN DE CATEGORÍAS DE GEOGRAPHY](../fig/uniqueValues_3_Geography.png)")
        println(file, "\n")
        println(file, "![IMAGEN DE DISTRIBUCIÓN DESPUÉS DE ELIMINACIÓN DE OUTLIER DE EXITED](../fig/uniqueValues_4_Exited.png)")
        println(file, "\n")
        println(file, "![IMAGEN DE DISTRIBUCIÓN EN EL CONJUNTO TRAIN DE EXITED](../fig/uniqueValues_5_Exited.png)")
        println(file, "\n")
        println(file, "![IMAGEN DE DISTRIBUCIÓN EN EL CONJUNTO TEST DE EXITED](../fig/uniqueValues_6_Exited.png)")
    end
end

crearReporte(df, "C:/Users/mayra/OneDrive/Desktop/SARM/5/report/reporteEjercicio_5.jmd")

using Weave
weave("C:/Users/mayra/OneDrive/Desktop/SARM/5/report/reporteEjercicio_5.jmd", doctype = "md2pdf")


