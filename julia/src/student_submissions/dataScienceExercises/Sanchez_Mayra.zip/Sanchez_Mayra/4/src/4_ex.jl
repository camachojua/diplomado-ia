## EJERCICIO 4
# MAYRA ALEJANDRA SÁNCHEZ ROBLEZ
# REPORTE REDUCCIÓN DE DIMENSIÓN EN IMÁGENES USANDO PCA

#using Pkg
#Pkg.add("Images")
#Pkg.add("ImageIO")
#Pkg.add("LinearAlgebra")
#Pkg.add("StatsBase")
#Pkg.add("FilePathsBase")
#Pkg.add("ColorTypes")
#Pkg.add("ImageMagick")
#Pkg.add("Markdown")
#Pkg.add("Weave")

# Librerías
using Images
using ImageIO
using LinearAlgebra
using StatsBase
using FilePathsBase
using ColorTypes
using ImageMagick
using Markdown

# Función que obtiene el número óptimo de componentes para in nivel de explicación de varianza definido
function findOptimalK_(image_path, image_name, image_folder, image_folder_r, file; threshold = 0.90)
    # Cargar la imagen
    img = Images.load(image_path)
    img_resized = imresize(img, (300, 300))
    inr = chop(image_name, tail=4)
    resized_image_name = joinpath(image_folder_r, inr * "_resized.jpg")
    save(resized_image_name, img_resized)
    img_type = eltype(img)

    if img_type <: RGB  # Si la imagen es de tipo RGB (color)
        # Convertir la imagen RGB a escala de grises usando la fórmula estándar
        img_gray = 0.2989 * float(red.(img)) .+ 0.5870 * float(green.(img)) .+ 0.1140 * float(blue.(img))
    elseif img_type <: RGBA  # Si la imagen es de tipo RGBA (con canal alfa)
        # Convertir RGBA a RGB y luego a escala de grises
        img_rgb = red.(img) .+ green.(img) .+ blue.(img)  # Ignora el canal alfa
        img_gray = 0.2989 * img_rgb .+ 0.5870 * img_rgb .+ 0.1140 * img_rgb
    elseif img_type <: Gray  # Si la imagen ya es de tipo Gray (escala de grises)
        img_gray = img  # Si la imagen ya está en escala de grises, no hacer nada
    else
        error("Tipo de imagen no soportado: $img_type")
    end

    # Convertir a dimension de matriz 2D
    X = reshape(img_gray, :, size(img_gray, 2))

    # Centrar
    X_centered = X .- mean(X, dims = 1)

    # Matriz de covarianzas
    cov_matrix = cov(X_centered)

    # Descompocisión
    eigenvalues, eigenvectors = eigen(cov_matrix)

    # Obtener explicaciones de varianza
    explained_variance = eigenvalues / sum(eigenvalues)

    # Varianza explicada acumulada
    cumulative_variance = cumsum(explained_variance)

    # Tomar los componentes que tengan la varianza acumulada deseada
    optimal_k = findfirst(cumulative_variance .>= threshold)

    return optimal_k, eigenvectors, X_centered, cumulative_variance
end

# Función para reducir dimensionalidad dados los componentes que explican la varianza deseada
function reduceDimensionality_(X_centered, eigenvectors, k)
    # Seleccionar los primeros k-componentes
    V_k = eigenvectors[:, 1:k]

    # Reducción
    X_reduced = X_centered * V_k

    return X_reduced
end

# Función para reconstruir la imagen
function reconstructImage_(X_reduced, V_k, X_mean)
    X_reconstructed = X_reduced * transpose(V_k) .+ X_mean
    return X_reconstructed
end

# Crear y escribir el contenido del archivo reporte.jmd 
function crearReporte(image_folder, image_files, reduced_images, file_path, image_folder_r)
    open(file_path, "w") do file
        println(file, "# **EJERCICIO 4**")
        println(file, "## *author: MAYRA ALEJANDRA SÁNCHEZ ROBLEZ*")
        println(file, "### __title: REPORTE DE REDUCCIÓN DE DIMENSIONALIDAD DE IMAGENES")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "EL PROCESO QUE SE SIGUE PARA CADA IMAGEN CONSISTE EN: ")
        println(file, "")      # Imprime un salto de línea simple
        println(file, "- LA PRIMERA ETAPA ES EL PROCESO MAS LARGO, COMIENZA CONVIRTIENDO A ESCALA DE GRISES LA IMAGEN")
        println(file, "")      # Imprime un salto de línea simple
        println(file, "ENSEGUIDA HACER FLAT EN UNA MATRIZ 2D LA DATA")
        println(file, "")      # Imprime un salto de línea simple
        println(file, "AHORA, OBTENER LA MATRIZ DE COVARIANZAS Y CON ELLA CALCULAR LA EIGEN DESCOMPOSICIÓN")
        println(file, "")      # Imprime un salto de línea simple
        println(file, "CON LOS EIGEN VALORES CALCULAR LA VARIANZA EXPLICADA Y LA VARIANZA EXPLICADA ACUMULADA")
        println(file, "")      # Imprime un salto de línea simple
        println(file, "PARA TERMINAR LA PRIMER PARTE, SE ELIGEN LOS K-COMPONETES QUE EXPLIQUEN EL 90% DE LA VARIANZA")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "**IMPORTANTE NOTAR QUE PARA CADA IMAGEN SE REALIZA TODO EL PROCESO, POR LO QUE CADA IMAGEN TRABAJA CON SU PROPIO VALOR DE K ÓPTIMO**")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- LA SEGUNDA ETAPA ES REDUCIR LA DIMENSIONALIDAD POR PCA")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- LA TERCER ETAPA CONSISTE EN RECONSTRUIR Y RECONVERTIR LA DATA A TIPO IMAGEN")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- FINALMENTE, LA ÚLTIMA ETAPA ES GUARDAR LA IMAGEN REDUCIDA EN ESCALA DE GRISES.")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- PARA FINES DEL REPORTE, SE CREARON REDUCCIONES DE LA IMAGEN ORIGINAL Y DE LA RESULTANTE DEL PROCESO PCA. PERO DICHAS IMÁGENES PUEDEN SER REVISADAS EN SU FORMATO SIN REDUCCIÓN EN LA CARPETA DE __fig__.")
        println(file, "\n")      # Imprime una línea en blanco para separar
        # Ejecución en loop
        for image_name in image_files

            image_path = joinpath(image_folder, image_name)
            println(file, "\n")
            println(file, "- PROCESANDO LA IMAGEN: **$image_name**")

            optimal_k, eigenvectors, X_centered, cumulative_variance = findOptimalK_(image_path, image_name, image_folder, image_folder_r, file)

            println(file, "EL VALOR ÓPTIMO DE K ES: **$optimal_k**")
            println(file, "\n")

            # Uso de la función de reducción de dimensionalidad
            X_reduced = reduceDimensionality_(X_centered, eigenvectors, optimal_k)

            # Reconstruir la imagen
            X_reconstructed = reconstructImage_(X_reduced, eigenvectors[:, 1:optimal_k], mean(X_centered, dims = 1))

            # Convertir a formato imagen para poder hacer display y save
            img_reconstructed = reshape(X_reconstructed, size(X_centered, 1), size(X_centered, 2))

            # Normalizar la data de la imagen a [0,1] para hacer display
            img_reconstructed_normalized = clamp.(img_reconstructed, 0.0, 1.0)
            
            img_reconstructed = Gray.(img_reconstructed_normalized)

            # Display a la imagen 
            Images.display(img_reconstructed)

            inrr = chop(image_name, tail=4)
            # Path para guardar la imagen
            save_path = joinpath(image_folder_r, inrr * "_reduced")
            Images.save("$save_path.jpg", img_reconstructed)

            img_reconstructed_resized = imresize(img_reconstructed, (300, 300))
            resized_img_reconstructed = joinpath(image_folder_r, inrr * "_reduced_resized.jpg")
            save(resized_img_reconstructed, img_reconstructed_resized)
        end
        # Para el pdf se utilzaron reducciones de las imagenes, tanto la original como la que fue modificada por PCA, pero las imagenes sin reducción de tamañoa pueden ser encontradas en la carpeta de resultados
        # Las originales son todas las de nombres "pexels-{1-13}.jpg" y las resultantes de PCA "pexels-{1-13}_reducen.jpg"
        for image_name in image_files
            inrr = chop(image_name, tail = 4)

            println(file, "![IMAGEN $inrr ADAPTADA PARA EL REPORTE](../fig/" * inrr * "_resized.jpg) ![IMAGEN REDUCIDA EN DIMENSIONES CON PCA ADAPTADA PARA EL REPORTE](../fig/" * inrr * "_reduced_resized.jpg)")
            println(file, "\n")
        end

    end
end

# Carpeta donde estan las imagenes
image_folder = "C:/Users/mayra/OneDrive/Desktop/SARM/4/dat/"
image_folder_r = "C:/Users/mayra/OneDrive/Desktop/SARM/4/fig/"

# Filtrar solo los archivos .jpg
image_files = filter(f -> endswith(f, ".jpg"), readdir(image_folder))

# Diccionario para guardar los resultados
reduced_images = Dict()

file_path = "C:/Users/mayra/OneDrive/Desktop/SARM/4/report/reporteEjercicio_4.jmd"


crearReporte(image_folder, image_files, reduced_images, file_path, image_folder_r)

using Weave

weave("C:/Users/mayra/OneDrive/Desktop/SARM/4/report/reporteEjercicio_4.jmd", doctype = "md2pdf")