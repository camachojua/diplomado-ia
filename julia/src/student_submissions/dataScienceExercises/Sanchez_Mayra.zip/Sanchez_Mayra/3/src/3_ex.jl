## EJERCICIO 3
# MAYRA ALEJANDRA SÁNCHEZ ROBLEZ
# REPORTE ANÁLISIS DE MODELOS DE SMARKET.CSV

# El dataset fue obtenido del link de Git siguiente:
# https://github.com/coxy1989/isl/blob/master/chapter_4/smarket.csv

#using Pkg
#Pkg.add("CSV")
#Pkg.add("DataFrames")
#Pkg.add("StatsPlots")
#Pkg.add("CategoricalArrays")
#Pkg.add("StatsModels")
#Pkg.add("Random")
#Pkg.add("StatsBase")
#Pkg.add("GLMNet")
#Pkg.add("ROCAnalysis")
#Pkg.add("DecisionTree")
#Pkg.add("Statistics")
#Pkg.add("MLJ")
#Pkg.add("MLJBase")
#Pkg.add("MLJDecisionTreeInterface")
#Pkg.add("MLJScikitLearnInterface")
#Pkg.add("ScikitLearnBase")
#Pkg.add("LIBSVM")
#Pkg.add("Tables")
#Pkg.add("Plots")
#Pkg.add("ImageIO")
#Pkg.add("Colors")
#Pkg.add("Markdown")
#Pkg.add("Weave")

# Librerías
using CSV
using DataFrames
using StatsPlots
using CategoricalArrays
using StatsModels
using Random
using StatsBase
using GLMNet
using ROCAnalysis
using DecisionTree
using Statistics
using MLJ
using MLJBase
using MLJDecisionTreeInterface
const RF = MLJDecisionTreeInterface.RandomForestClassifier
using MLJScikitLearnInterface
using ScikitLearnBase
#using MLJLIBSVMInterface
using LIBSVM
using Tables
using Plots
using ImageIO
using Colors

using Markdown

# Leer el archivo CSV y guardarlo en un DataFrame
df = CSV.read("C:/Users/mayra/OneDrive/Desktop/SARM/3/dat/smarket.csv", DataFrame)

# Función que muestra las dimensiones del df
function dataShape_(df::DataFrame, file)
    println(file, "Número de filas: ", size(df)[1])
    println(file, "")
    println(file, "Número de columnas: ", size(df)[2])
end

# Función para contar valores únicos en cada columna 
function uniqueValueCounts_(df::DataFrame, file) 

    for col in names(df)
        num_unicos = length(unique(df[!, col]))
        println(file, "$col: $num_unicos")
        println(file, "")
    end
end

# Función para imprimir nombre y tipo de cada columna (dataType)
function dataType_(df::DataFrame, file)
    for col in names(df)
        try
            col_data = df[!, col]
            col_type = eltype(col_data)  # Obtiene el tipo de la columna

            # Si la columna tiene un tipo Any, hacer algo especial
            if col_type == Any
                println(file, "Columna: ", col, " - Tipo: Any (Puede ser múltiple o dinámico)")
                println(file, "")
            else
                # Si el tipo es un tipo básico, lo imprimimos
                println(file, "Columna: ", col, " - Tipo: ", col_type)
                println(file, "")
            end
        catch e
            # Si ocurre un error, lo capturamos y lo mostramos
            println(file, "Columna: ", col, " - Error al obtener el tipo: ", e)
            println(file, "")
        end
    end
end

# Función para contar los valores faltantes en cada columna y devolver el conteo
function countMissingValues_(df::DataFrame, file)
    missing_counts = Dict()  # Usa un diccionario para almacenar los resultados
    println(file, "- CONTEO DE MISSING VALUES POR COLUMNA")
    println(file, "\n")

    for col in names(df)
        # Contar los valores faltantes en la columna
        num_missing = sum(ismissing, df[!, col])  # Cuenta los valores 'missing'
        missing_counts[col] = num_missing  # Almacen el conteo en el diccionario

        println(file, "Columna: ", col, " - Valores faltantes: ", num_missing)
        println(file, "")
    end

    return missing_counts  # Devuelve el diccionario con los valores faltantes
end

# Función para calcular el porcentaje de valores faltantes en cada columna
function dataMissingPercentage_(df::DataFrame, file)
    # Primero, obtener el diccionario con los valores faltantes
    missing_counts = countMissingValues_(df, file)
    println(file, "\n")
    println(file, "- PORCENTAGE DE VALORES FALTANTES POR COLUMNA")
    println(file, "\n")

    total_rows = size(df)[1]  # Número total de filas

    for col in names(df)
        # Obtener el número de valores faltantes de la columna del diccionario
        num_missing = missing_counts[col]  # Acceder al valor desde el diccionario

        # Calcular el porcentaje de valores faltantes en la columna
        percentage_missing = (num_missing / total_rows) * 100  # Calcular porcentaje
        
        # Imprimir el resultado
        println(file, "Columna: ", col, "- Porcentaje de valores faltantes: ", round(percentage_missing, digits = 2), "%")
        println(file, "")
    end
end

# Crear una función para contar los valores únicos en Year y Direction 
function uniqueValuesCount_(df::DataFrame, col_names::Vector{Symbol}, suff)
    conteos = Dict{Symbol, DataFrame}() 
    for col_name in col_names
        # Contar valores únicos
        conteo = combine(groupby(df, col_name), nrow => :conteo)
        # Calcular porcentajes 
        conteo[:, :porcentaje] = 100 * conteo[:, :conteo] ./ nrow(df)
        # Guardar el DataFrame con conteos y porcentajes
        conteos[col_name] = conteo 

        # Graficar los resultados 
        x = conteo[!, col_name] 
        y = conteo[!, :conteo]
        j_ = bar(x, y, title="Conteo de $col_name", xlabel = "Valores", ylabel = "Frecuencia", legend = false, color = :purple, size=(500, 400)) 
        display(j_)
        savefig("C:/Users/mayra/OneDrive/Desktop/SARM/3/fig/uniquevalues_$col_name$suff.png")
    end
    return conteos 
end

# Función para eliminar outliers usando el método IQR
function removeOutliersIQR!(df::DataFrame)
    # Definir las columnas que serán tratadas como categóricas
    excluir = ["Direction", "Year2001", "Year2002", "Year2003", "Year2004"]
    # Iterar sobre las columnas numéricas del DataFrame
    for col in names(df, Not(excluir))
        if eltype(df[!, col]) <: Real  # Solo se aplica a columnas numéricas
            # Calcular los cuartiles Q1 y Q3
            Q1 = quantile(df[!, col], 0.25)
            Q3 = quantile(df[!, col], 0.75)
            
            # Calcular el IQR (Rango Intercuartílico)
            IQR = Q3 - Q1
            
            # Definir los límites inferior y superior para los outliers
            lower_limit = Q1 - 1.5 * IQR
            upper_limit = Q3 + 1.5 * IQR
            
            # Filtrar los valores dentro del rango (eliminar outliers)
            df = df[(df[!, col] .>= lower_limit) .& (df[!, col] .<= upper_limit), :]
        end
    end
    return df
end

# Crear una función para convertir la columna Year en variables dummies 
function convertir_a_dummies(df::DataFrame, col_name::Symbol) 
    # Convertir la columna a categórica 
    df[!, col_name] = categorical(df[!, col_name]) 
    # Crear la matriz de diseño con las variables dummies 
    dummies = DataFrame(Matrix(modelmatrix(Term(col_name), df)), :auto) 
    # Obtener los nombres de las categorías 
    levels = CategoricalArrays.levels(df[!, col_name])
    # Renombrar las columnas dummies 
    for (i, name) in enumerate(names(dummies))
        rename!(dummies, name => Symbol("Year$(levels[i])"))
    end
    
    # Unir el DataFrame original (sin la columna original) con las variables dummies 
    df = DataFrames.select(df, Not(col_name)) 
    
    return hcat(df, dummies) 
end

# Función para dividir los datos en entrenamiento y prueba
function trainTestSplit_(df::DataFrame, porcentaje_test::Float64, file)
    # Determinar el número de filas para test
    n = nrow(df)
    n_test = round(Int, porcentaje_test * n)
    
    # Crear un índice aleatorio para dividir
    indices = shuffle(1:n)  # Mezclar los índices aleatoriamente
    indices_test = indices[1:n_test]  # Primeros índices para test
    indices_train = indices[n_test+1:end]  # El resto para entrenamiento
    
    # Crear los DataFrames de entrenamiento y prueba
    df_train = df[indices_train, :]
    df_test = df[indices_test, :]
    
    # Asegurarnos de que ambas divisiones tengan datos
    println(file, "\n")
    println(file, "Número de filas de df_train: ", nrow(df_train))
    println(file, "")
    println(file, "Número de filas de df_test: ", nrow(df_test))
    
    return df_train, df_test
end

# Función para escalar variables usando MinMaxScaler 
function minMaxScaling_(train_df::DataFrame, test_df::DataFrame)
    excluirDummy = ["Direction", "Year2001", "Year2002", "Year2003", "Year2004"]
    continuous_vars_train = DataFrames.select(train_df, Not(excluirDummy))
    dummy_vars_train = DataFrames.select(train_df, excluirDummy)

    continuous_vars_test = DataFrames.select(test_df, Not(excluirDummy))
    dummy_vars_test = DataFrames.select(test_df, excluirDummy)

    # Convertimos los DataFrames de variables continuas a matrices para hacer operaciones matemáticas
    X_train = Matrix(continuous_vars_train)
    X_test = Matrix(continuous_vars_test)

    # Creamos matrices vacías para los resultados escalados
    continuous_scaled_train = similar(X_train)
    continuous_scaled_test = similar(X_test)
    
    # Iteramos sobre cada columna para realizar el escalado Min-Max
    for i in 1:size(X_train, 2)  # Iteramos por columnas
        # Obtenemos el mínimo y máximo de la columna i en el conjunto de entrenamiento
        min_val = minimum(X_train[:, i])
        max_val = maximum(X_train[:, i])

        # Aplicamos el escalado Min-Max a la columna i en el conjunto de entrenamiento y prueba
        continuous_scaled_train[:, i] .= (X_train[:, i] .- min_val) ./ (max_val .- min_val)
        continuous_scaled_test[:, i] .= (X_test[:, i] .- min_val) ./ (max_val .- min_val)
    end

    # Convertimos las matrices escaladas nuevamente a DataFrames con nombres automáticos
    train_df_scaled = DataFrame(continuous_scaled_train, :auto)
    test_df_scaled = DataFrame(continuous_scaled_test, :auto)

    # Renombramos las columnas manualmente añadiendo el sufijo "_Esc"
    for i in 1:ncol(train_df_scaled)
        rename!(train_df_scaled, names(train_df_scaled)[i] => string(names(train_df)[i], "_Esc"))
    end

    for i in 1:ncol(test_df_scaled)
        rename!(test_df_scaled, names(test_df_scaled)[i] => string(names(test_df)[i], "_Esc"))
    end

    train_df_scaled = hcat(train_df_scaled, dummy_vars_train)
    test_df_scaled = hcat(test_df_scaled, dummy_vars_test)
    
    return train_df_scaled, test_df_scaled
end

# Función para mostrar y eliminar las parejas con alta correlación del DataFrame 
function deleteExplicativeHighCorrelatedVariables_(df::DataFrame, umbral::Float64, file)
    excluirDummy = ["Direction", "Year2001", "Year2002", "Year2003", "Year2004"]
    df1 = DataFrames.select(df, Not(excluirDummy))
    # Calcular la matriz de correlación 
    corr_matrix = cor(Matrix(df1)) 
    # Obtener los nombres de las columnas 
    col_names = names(df1) 
    # Inicializar una lista para almacenar las columnas a eliminar 
    cols_to_remove = Set{Symbol}() 
    
    # Encontrar las parejas de variables con alta correlación 
    for i in 1:length(col_names) 
        for j in (i+1):length(col_names) 
            if abs(corr_matrix[i, j]) >= umbral 
                println(file, "Pareja con alta correlación: $(col_names[i]) y $(col_names[j]), Correlación: $(round(corr_matrix[i, j], digits = 3))")
                push!(cols_to_remove, col_names[j]) # Marcar la segunda variable para eliminación 
            end 
        end 
    end
    # Eliminar las columnas con alta correlación del DataFrame 
    df = DataFrames.select(df, Not(collect(cols_to_remove))) 
    return df, cols_to_remove
end

# Función que arroja una descripción más detallada del df final
function describeExtended_(df::DataFrame, file)

    resumen = describe(df)
    println(file, "CUANTILES POR COLUMNA:")
    for col in names(df) 
        if eltype(df[!, col]) <: Number 
            vals = df[!, col]
            
            q25 = quantile(vals, 0.25) 
            q50 = quantile(vals, 0.5) 
            q75 = quantile(vals, 0.75) 
            
            println(file, "\n")
            println(file, "Columna: $col")
            println(file, "")
            println(file, " 25%: $q25") 
            println(file, " 50% (Mediana): $q50") 
            println(file, " 75%: $q75") 
            println(file, "\n")
        end 
    end 
    
    return resumen 
end

# Convertir el DataFrame de describe a una tabla Markdown
function dataframeToMarkdownDescribe_(df::DataFrame)
    headers = names(df)
    # Convertir cada fila del DataFrame a un Vector de cadenas
    rows = [string.(collect(row)) for row in eachrow(df)]
    
    # Formatear la tabla en Markdown
    table_md = "| " * join(headers, " | ") * " |\n"
    table_md *= "| " * join(["-"^length(h) for h in headers], " | ") * " |\n"
    for row in rows
        table_md *= "| " * join(row, " | ") * " |\n"
    end
    return table_md
end

# Convertir el DataFrame de describe a una tabla Markdown
function dataframeToMarkdown_(df::DataFrame)
    headers = names(df)
    # Convertir cada fila del DataFrame a un Vector de cadenas
    rows = [string.(collect(row)) for row in eachrow(df)]

    # Determinar el ancho máximo de cada columna 
    col_widths = map(i -> maximum([length(string(headers[i])) for headers in [headers; rows]]), 1:length(headers))
    
    # Formatear la tabla en Markdown
    table_md = "| " * join([lpad(headers[i], col_widths[i]) for i in 1:length(headers)], " | ") * " |\n"
    table_md *= "| " * join([repeat("-", col_widths[i]) for i in 1:length(headers)], " | ") * " |\n"
    for row in rows
        table_md *= "| " * join([lpad(row[i], col_widths[i]) for i in 1:length(row)], " | ") * " |\n"
    end
    return table_md
end

###################################################################################################################
###################################################################################################################

# Función para aplicar GridSearch a Lasso
function gridsearch_LassoRidge_(train_df::DataFrame, test_df::DataFrame, target_col::Symbol, lambdas::Vector{Float64}, alphas::Vector{Float64}, file)
    # Extraer la variable dependiente (target) y las características (features)
    y_train = train_df[!, target_col]  # Variable dependiente en train
    y_train = Float64.(y_train)
    X_train = DataFrames.select(train_df, Not(target_col))  # Variables independientes en train

    y_test = test_df[!, target_col]  # Variable dependiente en test
    y_test = Float64.(y_test)
    X_test = DataFrames.select(test_df, Not(target_col))  # Variables independientes en test

    # Convertir los DataFrames a matrices
    X_train_matrix = Matrix{Float64}(X_train)
    y_train_matrix = hcat(1 .- y_train, y_train)
    X_test_matrix = Matrix{Float64}(X_test)

    best_lambda = 0.0
    best_auc = 0.0
    best_fit = nothing
    best_predictions = nothing
    best_alpha = nothing

    for alpha in alphas
        for lambda in lambdas
            # Fit the model
            fit = glmnet!(X_train_matrix, y_train_matrix, GLMNet.Binomial(), alpha = alpha, lambda = [lambda])

            # Generate predictions
            predictions = GLMNet.predict(fit, X_test_matrix; outtype = :response)
            predictions_vector = vec(predictions)

            # Calculate AUC
            roc_curve = ROCAnalysis.roc(predictions_vector, y_test)
            auc_value = ROCAnalysis.auc(roc_curve)

            println(file, "\n")      # Imprime una línea en blanco para separar
            println(file, "El valor del AUC para alpha = $alpha y lambda = $lambda es: $auc_value\n") 
            println(file, "\n")      # Imprime una línea en blanco para separar

            # Update best model if current AUC is better
            if auc_value > best_auc
                best_auc = auc_value
                best_lambda = lambda
                best_fit = fit
                best_predictions = predictions_vector
                best_alpha = alpha
            end
        end
    end

    println(file, "\n")      # Imprime una línea en blanco para separar
    println(file, "\n")      # Imprime una línea en blanco para separar
    println(file, "**El mejor valor del AUC es: $best_auc para alpha = $best_alpha y para lambda = $best_lambda\n**") 
    println(file, "\n")      # Imprime una línea en blanco para separar
    println(file, "\n")      # Imprime una línea en blanco para separar
    println(file, "\n")      # Imprime una línea en blanco para separar

    best_predictions_vector = vec(best_predictions)

    # Clasifica las predicciones en clases utilizando un umbral de 0.5 
    predicted_classes = best_predictions_vector .> 0.5
    # Calcula la matriz de confusión 
    true_positive = sum((predicted_classes .== 1) .& (y_test .== 1))
    true_negative = sum((predicted_classes .== 0) .& (y_test .== 0))
    false_positive = sum((predicted_classes .== 1) .& (y_test .== 0))
    false_negative = sum((predicted_classes .== 0) .& (y_test .== 1))
    
    confusion_matrix = [ true_positive false_positive; false_negative true_negative ]

    # Determina el sufijo basado en el valor de alpha 
    suffix = "_"
    suffix_ = "__"
    suffix = best_alpha == 0.0 ? "_RIDGE" : best_alpha == 1.0 ? "_LASSO" : "_ELASTICNET"
    suffix_ = best_alpha == 0.0 ? "RIDGE" : best_alpha == 1.0 ? "LASSO" : "ELASTICNET"

    # Visualiza la matriz de confusión 
    h_ = heatmap(confusion_matrix, title = "Matriz de Confusión de $suffix_", xlabel = "Predicción", ylabel = "Verdadero", xticks = (1:2, ["Positivo", "Negativo"]), yticks = (1:2, ["Positivo", "Negativo"])), size=(600, 400) 
    # Anota los números en el centro de cada celda 
    for i in 1:2 
        for j in 1:2 
            annotate!(i, j, text(confusion_matrix[i, j], :white, :center)) 
        end
    end
    # Guarda la imagen en formato PNG 
    display(h_)
    savefig("C:/Users/mayra/OneDrive/Desktop/SARM/3/fig/confusion_matrix$suffix.png")
    
    best_roc_curve = roc(best_predictions, y_test)
    p_ = plot(best_roc_curve, title = "Curva ROC del Mejor Modelo de $suffix_", xlabel = "Tasa de Falsos Positivos", ylabel = "Tasa de Verdaderos Positivos", size=(600, 400))
    display(p_)
    savefig("C:/Users/mayra/OneDrive/Desktop/SARM/3/fig/roc_curve$suffix.png")

    return best_predictions, best_fit, best_lambda, best_alpha, best_auc
end

function gridsearch_DecisionTreeRandomForest_(train_df::DataFrame, test_df::DataFrame, target_col::Symbol, n_trees_list::Vector{Int}, max_depths::Vector{Int}, min_samples_splits::Vector{Int}, file) 
    y_train = train_df[!, target_col]  # Variable dependiente en train
    y_train = CategoricalVector(y_train)
    y_train = coerce(y_train, Multiclass)  # Convert to Multiclass
    X_train = DataFrames.select(train_df, Not(target_col))  # Variables independientes en train

    y_test = test_df[!, target_col]  # Variable dependiente en test
    y_test = CategoricalVector(y_test)
    y_test = coerce(y_test, Multiclass)  # Convert to Multiclass  
    X_test = DataFrames.select(test_df, Not(target_col))  # Variables independientes en test

    # Variables para almacenar el mejor modelo y su AUC 
    best_auc = 0.0 
    best_model = nothing
    best_n_trees = nothing
    best_max_depth = nothing 
    best_min_samples_split = nothing 
    best_predictions = nothing

    for n_trees in n_trees_list
        for max_depth in max_depths 
            for min_samples_split in min_samples_splits 
                
                # Ajusta el modelo del árbol de decisión con los valores actuales de max_depth y min_samples_split 
                forest = RF(n_trees = n_trees, max_depth = max_depth, min_samples_split = min_samples_split)
                mach = MLJ.machine(forest, X_train, y_train) 
                MLJ.fit!(mach, verbosity = 0)
            
                # Predice las clases con el modelo ajustado 
                predictions = MLJ.predict(mach, X_test)
                predictions_vector = vec(predictions)

                positive_probs = [pdf(p, 1) for p in predictions]

                y_test_ = convert(Vector{Float64}, y_test)

                # Calcula el AUC 
                roc_curve = ROCAnalysis.roc(positive_probs, y_test_) 

                auc_value = ROCAnalysis.auc(roc_curve)
                println(file, "\n")      # Imprime una línea en blanco para separar
                println(file, "El valor del AUC para n_trees = $n_trees, max_depth = $max_depth y min_samples_split = $min_samples_split es: $auc_value\n") 
                println(file, "\n")      # Imprime una línea en blanco para separar
            
                # Actualiza el mejor modelo si el AUC actual es mayor que el mejor AUC encontrado 
                if auc_value > best_auc 
                    best_auc = auc_value 
                    best_n_trees = n_trees
                    best_max_depth = max_depth 
                    best_min_samples_split = min_samples_split 
                    best_model = mach 
                    best_predictions = positive_probs 
                end
            end 
        end 
    end 
    println(file, "\n")      # Imprime una línea en blanco para separar
    println(file, "\n")      # Imprime una línea en blanco para separar
    println(file, "**El mejor valor del AUC es: $best_auc para n_trees = $best_n_trees, max_depth = $best_max_depth y min_samples_split = $best_min_samples_split\n**") 
    println(file, "\n")      # Imprime una línea en blanco para separar
    println(file, "\n")      # Imprime una línea en blanco para separar
    println(file, "\n")      # Imprime una línea en blanco para separar

    best_predictions_vector = vec(best_predictions)

    # Clasifica las predicciones en clases utilizando un umbral de 0.5 
    predicted_classes = best_predictions_vector .> 0.5
    # Calcula la matriz de confusión 
    true_positive = sum((predicted_classes .== 1) .& (y_test .== 1))
    true_negative = sum((predicted_classes .== 0) .& (y_test .== 0))
    false_positive = sum((predicted_classes .== 1) .& (y_test .== 0))
    false_negative = sum((predicted_classes .== 0) .& (y_test .== 1))
    
    confusion_matrix = [ true_positive false_positive; false_negative true_negative ]

    # Determina el sufijo basado en el valor de alpha 
    suffix = best_n_trees == 1 ? "_DECISIONTREE" : "_RANDOMFOREST"
    suffix_ = best_n_trees == 1 ? "DECISIONTREE" : "RANDOMFOREST"
    # Visualiza la matriz de confusión 
    hk = heatmap(confusion_matrix, title = "Matriz de Confusión de $suffix_", xlabel = "Predicción", ylabel = "Verdadero", xticks = (1:2, ["Positivo", "Negativo"]), yticks = (1:2, ["Positivo", "Negativo"]), size=(600, 400)) 
    # Anota los números en el centro de cada celda 
    for i in 1:2 
        for j in 1:2 
            annotate!(i, j, text(confusion_matrix[i, j], :white, :center)) 
        end
    end
    # Guarda la imagen en formato PNG 
    display(hk)
    savefig("C:/Users/mayra/OneDrive/Desktop/SARM/3/fig/confusion_matrix$suffix.png")

    y_test_ = convert(Vector{Float64}, y_test)
    best_roc_curve = ROCAnalysis.roc(best_predictions, y_test_) 
    pk = plot(best_roc_curve, title="Curva ROC del Mejor Modelo de $suffix_", xlabel = "Tasa de Falsos Positivos", ylabel = "Tasa de Verdaderos Positivos", size=(600, 400))
    display(pk)
    savefig("C:/Users/mayra/OneDrive/Desktop/SARM/3/fig/roc_curve$suffix.png")

    return best_model, best_auc, best_n_trees, best_max_depth, best_min_samples_split, best_predictions 
end

function gridsearch_KNN_(train_df::DataFrame, test_df::DataFrame, target_col::Symbol, k_values::Vector{Int}, file) 

    y_train = train_df[!, target_col]  # Variable dependiente en train
    y_train = CategoricalVector(y_train)
    y_train = coerce(y_train, Multiclass)  # Convert to Multiclass
    X_train = DataFrames.select(train_df, Not(target_col))  # Variables independientes en train

    y_test = test_df[!, target_col]  # Variable dependiente en test
    y_test = CategoricalVector(y_test)
    y_test = coerce(y_test, Multiclass)  # Convert to Multiclass  
    X_test = DataFrames.select(test_df, Not(target_col))

    # Variables para almacenar el mejor modelo y su AUC 
    best_auc = 0.0 
    best_model = nothing
    best_k = nothing
    best_preds = nothing
     
    model = MLJ.@load "KNeighborsClassifier" pkg = "MLJScikitLearnInterface" verbosity = 0
    
    for k_val in k_values 
        # Configurar el modelo con el valor de k actual 
        model_instance = model(n_neighbors = k_val) 
        # Entrenar el modelo 
        mach = MLJ.machine(model_instance, X_train, y_train) 
        MLJ.fit!(mach, verbosity = 0) # De MLJ 
        
        # Predicciones con el modelo 
        y_preds = MLJ.predict(mach, X_test)
        y_probs = [pdf(p, 1) for p in y_preds]
        y_test_ = convert(Vector{Float64}, y_test)

        # Calcular ROC y AUC 
        roc = ROCAnalysis.roc(y_probs, y_test_) # De ROCAnalysis 
        auc = ROCAnalysis.auc(roc)
        println(file, "\n") 
        println(file, "AUC del modelo con k=$k_val: $auc")
        println(file, "\n") 
        
        # Seleccionar el mejor modelo basado en el AUC 
        if auc > best_auc 
            best_auc = auc 
            best_model = mach 
            best_preds = y_probs
            best_k = k_val 
        end
    end
    println(file, "\n")      # Imprime una línea en blanco para separar
    println(file, "\n")      # Imprime una línea en blanco para separar
    println(file, "**El mejor valor del AUC es: $best_auc para n_vecinos = $best_k\n**") 
    println(file, "\n")
    println(file, "\n")      # Imprime una línea en blanco para separar
    println(file, "\n")      # Imprime una línea en blanco para separar

    best_predictions_vector = vec(best_preds)

    # Clasifica las predicciones en clases utilizando un umbral de 0.5 
    predicted_classes = best_predictions_vector .> 0.5
    # Calcula la matriz de confusión 
    true_positive = sum((predicted_classes .== 1) .& (y_test .== 1))
    true_negative = sum((predicted_classes .== 0) .& (y_test .== 0))
    false_positive = sum((predicted_classes .== 1) .& (y_test .== 0))
    false_negative = sum((predicted_classes .== 0) .& (y_test .== 1))
    
    confusion_matrix = [ true_positive false_positive; false_negative true_negative ]

    # Determina el sufijo basado en el valor de alpha 
    suffix = "_KNN"
    suffix_ = "KNN"
    # Visualiza la matriz de confusión 
    hh = heatmap(confusion_matrix, title = "Matriz de Confusión de $suffix_", xlabel = "Predicción", ylabel = "Verdadero", xticks = (1:2, ["Positivo", "Negativo"]), yticks = (1:2, ["Positivo", "Negativo"]), size=(500, 400)) 
    # Anota los números en el centro de cada celda 
    for i in 1:2 
        for j in 1:2 
            annotate!(i, j, text(confusion_matrix[i, j], :white, :center)) 
        end
    end
    # Guarda la imagen en formato PNG 
    display(hh)
    savefig("C:/Users/mayra/OneDrive/Desktop/SARM/3/fig/confusion_matrix$suffix.png")

    y_test_ = convert(Vector{Float64}, y_test)
    best_roc_curve = ROCAnalysis.roc(best_preds, y_test_) 
    pp = plot(best_roc_curve, title = "Curva ROC del Mejor Modelo de $suffix_", xlabel = "Tasa de Falsos Positivos", ylabel = "Tasa de Verdaderos Positivos", size=(500, 400))
    display(pp)
    savefig("C:/Users/mayra/OneDrive/Desktop/SARM/3/fig/roc_curve$suffix.png")
    
    return best_model, best_auc, best_k, best_preds
end

function gridsearch_SVM_(train_df::DataFrame, test_df::DataFrame, target_col::Symbol, c_values::Vector{Float64}, kernel_types::Vector{String}, file) 
    y_train = train_df[!, target_col]  # Variable dependiente en train
    y_train = CategoricalArray(y_train)
    y_train = coerce(y_train, Multiclass)  # Convert to Multiclass
    X_train = DataFrames.select(train_df, Not(target_col))  # Variables independientes en train

    y_test = test_df[!, target_col]  # Variable dependiente en test
    y_test = CategoricalArray(y_test)
    y_test = coerce(y_test, Multiclass)  # Convert to Multiclass  
    X_test = DataFrames.select(test_df, Not(target_col))

    # Variables para almacenar el mejor modelo y su AUC 
    best_auc = 0.0 
    best_model = nothing
    best_c_value = nothing
    best_kernel_type = nothing
    best_predictions = nothing
    
    # Load the SVC model 
    SVC = @load SVC pkg = "LIBSVM" verbosity = 0
    #model = MLJ.@load SVMClassifier pkg = MLJLIBSVMInterface verbosity = 0

    # Map string kernel names to LIBSVM.Kernel types 
    kernel_map = Dict( "linear" => LIBSVM.Kernel.Linear, 
                        "polynomial" => LIBSVM.Kernel.Polynomial, 
                        "rbf" => LIBSVM.Kernel.RadialBasis, 
                        "sigmoid" => LIBSVM.Kernel.Sigmoid )
                        
    for c_val in c_values 
        for kernel_ in kernel_types
            kernel1 = kernel_map[kernel_]
            
            model = SVC(kernel = kernel1, cost = c_val)
            # Entrenar el modelo 
            mach = MLJ.machine(model, X_train, y_train) 
            MLJ.fit!(mach)
            
            # Predicciones con el modelo 
            y_preds = MLJ.predict(mach, X_test)
            
            y_preds = convert(Vector{Float64}, y_preds)
            y_test_ = convert(Vector{Float64}, y_test)
            # Obtener probabilidades usando el modelo subyacente 
            # Calcular ROC y AUC 
            roc = ROCAnalysis.roc(y_preds, y_test_) # De ROCAnalysis 
            auc = ROCAnalysis.auc(roc) 
            
            println(file, "AUC del modelo con C = $c_val y kernel = $kernel_: $auc")
            println(file, "\n")      # Imprime una línea en blanco para separar

            # Seleccionar el mejor modelo basado en el AUC 
            if auc > best_auc 
                best_auc = auc 
                best_model = mach 
                best_predictions = y_preds 
                best_c_value = c_val
                best_kernel_type = kernel_
            end 
        end 
    end

    println(file, "\n")      # Imprime una línea en blanco para separar
    println(file, "\n")      # Imprime una línea en blanco para separar
    println(file, "**El mejor valor del AUC es: $best_auc para el kernel = $best_kernel_type\n**") 
    println(file, "\n")
    println(file, "\n")      # Imprime una línea en blanco para separar
    println(file, "\n")      # Imprime una línea en blanco para separar

    best_predictions_vector = vec(best_predictions)

    # Clasifica las predicciones en clases utilizando un umbral de 0.5 
    predicted_classes = best_predictions_vector .> 0.5
    # Calcula la matriz de confusión 
    true_positive = sum((predicted_classes .== 1) .& (y_test .== 1))
    true_negative = sum((predicted_classes .== 0) .& (y_test .== 0))
    false_positive = sum((predicted_classes .== 1) .& (y_test .== 0))
    false_negative = sum((predicted_classes .== 0) .& (y_test .== 1))
    
    confusion_matrix = [ true_positive false_positive; false_negative true_negative ]

    # Determina el sufijo basado en el valor de alpha 
    suffix = "_SVM"
    suffix_ = "SVM"
    # Visualiza la matriz de confusión 
    hw = heatmap(confusion_matrix, title = "Matriz de Confusión de $suffix_", xlabel = "Predicción", ylabel = "Verdadero", xticks = (1:2, ["Positivo", "Negativo"]), yticks = (1:2, ["Positivo", "Negativo"]), size=(500, 400)) 
    # Anota los números en el centro de cada celda 
    for i in 1:2 
        for j in 1:2 
            annotate!(i, j, text(confusion_matrix[i, j], :white, :center)) 
        end
    end
    # Guarda la imagen en formato PNG 
    display(hw)
    savefig("C:/Users/mayra/OneDrive/Desktop/SARM/3/fig/confusion_matrix$suffix.png")

    y_test_ = convert(Vector{Float64}, y_test)
    best_roc_curve = ROCAnalysis.roc(best_predictions, y_test_) 
    pw = plot(best_roc_curve, title = "Curva ROC del Mejor Modelo de $suffix_", xlabel = "Tasa de Falsos Positivos", ylabel = "Tasa de Verdaderos Positivos", size=(500, 400))
    display(pw)
    savefig("C:/Users/mayra/OneDrive/Desktop/SARM/3/fig/roc_curve$suffix.png")

    return best_model, best_auc, best_c_value, best_kernel_type, best_predictions
end


###################################################################################################################
###################################################################################################################

# Crear y escribir el contenido del archivo reporte.jmd 
function crearReporte(df::DataFrame, file_path::String)

    open(file_path, "w") do file
        println(file, "# **EJERCICIO 3**")
        println(file, "## *author: MAYRA ALEJANDRA SÁNCHEZ ROBLEZ*")
        println(file, "### __title: REPORTE FINAL DEL ANÁLISIS DE LA BASE MARKET.CSV__")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "**TODAS IMÁGENES SE AÑADEN AL FINAL PARA CONSERVAR UN FORMATO PRESENTABLE EN LA CREACIÓN DEL PDF, PRUEBA DE LA INESTABILIDAD DE LIBRERÍAS EN JULIA ES QUE A PESAR DE QUE TENGO NOMBRES Y SUFIJOS ESPECÍFICOS, LAS IMAGENES SE SOBREESCRIBEN MAL**")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "\n")      # Imprime una línea en blanco para separar
        # Llamar a las funciones
        println(file, "- NÚMERO DE FILAS Y COLUMNAS DEL DS INICIAL")
        println(file, "\n")      # Imprime una línea en blanco para separar
        dataShape_(df, file)  # Imprime número de filas y columnas
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- NÚMERO DE VALORES ÚNICOS EN CADA VARIABLE")
        println(file, "\n")      # Imprime una línea en blanco para separar
        uniqueValueCounts_(df, file)     # Función para imprimir el conteo de valores únicos por columna
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- SE ELIMINA LA PRIMER COLUMNA, QUE ES UN CONTEO DE FILAS Y NO SIRVE PARA EL ANÁLISIS")
        df = DataFrames.select(df, Not(1))     # Eliminar las columnas de ID únicas directamente 
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- IMPRIME EL TYPE INICIAL DE CADA COLUMNA")
        println(file, "\n")      # Imprime una línea en blanco para separar
        dataType_(df, file)   # Imprime nombre y tipo de cada columna
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- TODAS LAS COLUMNAS TIENEN TYPE ADECUADO. IMPORTANTE SABER QUE LA TARGET SERÁ __Direction__")
        println(file, "\n")      # Imprime una línea en blanco para separar
        dataMissingPercentage_(df, file)    # Función que arroja el conteo de missings y el porcentaje que representan de la variable
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- AL NO TENER VALORES MISSING NO SE ELIMINÓ NINGUNA COLUMNA")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- AL PARECER, TODO BIEN, PERO SE HARÁ UN ANÁLISIS DE TODAS LAS VARIABLES, PRIMERO LA EXPLICATIVA CATEGÓRICA __Year__ ANALIZANDO EL CONTEO DE VALORES ÚNICOS")
        println(file, "")      # Imprime un salto de línea simple
        resultados = uniqueValuesCount_(df, [:Year, :Direction], "_1")       # Función que hace un conteo de repetición de valores unicos en las variables categóricas
        println(file, "CONTEO DE REPETICIÓN DE VALORES ÚNICOS EN __Year__ , ASÍ COMO SU REPRESENTATIVIDAD EN EL DATASET EN PORCENTAJE")
        println(file, "\n")      # Imprime una línea en blanco para separar
        mdTableYear = dataframeToMarkdown_(resultados[:Year])
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, string(mdTableYear))
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- AHORA UN CONTEO DE REPETICIÓN DE VALORES ÚNICOS EN LA TARGET __Direction__ , Y ASÍ ASEGURAR QUE TENDREMOS UN DATASET BALANCEADO")
        println(file, "\n")      # Imprime una línea en blanco para separar
        mdTableDirection = dataframeToMarkdown_(resultados[:Direction])
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, string(mdTableDirection))
        println(file, "              .")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "**TODO BIEN, TENEMOS UN DATASET BALANCEADO**")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- AHORA, LA VARIABLE __Year__ AL TENER POCOS VALORES ÚNICOS (2001-2005) Y AL NO IMPLICAR UNA SERIE DE TIEMPO (DADO QUE NO VA POR FECHAS TRACKEABLES), SERÁ CONVERTIDA EN DUMMIES")
        df_1 = convertir_a_dummies(df, :Year)
        df = nothing    # Eliminar el DataFrame para liberar memoria 
        println(file, "")      # Imprime un salto de línea simple
        println(file, "LAS COLUMNAS RESULTANTES DEL NUEVO DF SON:")
        println(file, "")      # Imprime un salto de línea simple
        println(file, names(df_1))
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- CONTINUANDO, SIGUE EL ANÁLISIS IQR PARA EVITAR ATÍPICOS EN LAS COLUMNAS __Volume, Lag1, Lag2, Lag3, Lag4, Lag5, Today__")
        println(file, "\n")      # Imprime una línea en blanco para separar
        df_2 = removeOutliersIQR!(df_1)       # Eliminar outliers usando el método IQR
        println(file, "CHECK DE DIMENSIONES, VISUALIZAR CUANTOS OUTLIERS FUERON ELIMINADOS")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "DIMENCIONES INICIALES:")
        println(file, "")       # Imprime un salto de línea simple
        dataShape_(df_1, file)  # Imprime número de filas y columnas
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "DIMENCIONES DESPUÉS DE IQR:")
        println(file, "")       # Imprime un salto de línea simple
        dataShape_(df_2, file)  # Imprime número de filas y columnas
        println(file, "\n")      # Imprime una línea en blanco para separar
        df_1 = nothing    # Eliminar el DataFrame para liberar memoria
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "FALTA VERIFICAR SI NO CAUSÓ DESBALANCE LA ELIMINACIÓN DE OUTLIERS")
        println(file, "\n")      # Imprime una línea en blanco para separar
        resultados1 = uniqueValuesCount_(df_2, [:Direction], "_2")       # Función que hace un conteo de repetición de valores unicos en las variables categóricas
        mdTableDirection1 = dataframeToMarkdown_(resultados1[:Direction])
        println(file, string(mdTableDirection1))
        println(file, "              .")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "TODO BIEN")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- DADO QUE LA BASE YA ESTA LIMPIA, SE PROCEDE A ESCALAR VARIABLES")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- IMPORTANTE PRIMERO TENER LOS SETS DE ENTRENAMIENTO Y TEST")
        df_train, df_test = trainTestSplit_(df_2, 0.20, file)      # Dividir los datos en entrenamiento y prueba
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- FALTA VERIFICAR SI NO CAUSÓ DESBALANCE LA DIVISIÓN EN TRAIN Y TEST")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "PRIMERO EL TRAIN:")      # Imprime una línea en blanco para separar
        println(file, "\n")      # Imprime una línea en blanco para separar
        resultadosTrain = uniqueValuesCount_(df_train, [:Direction], "_3")       # Función que hace un conteo de repetición de valores unicos en las variables categóricas
        mdTableDirectionTrain = dataframeToMarkdown_(resultadosTrain[:Direction])
        println(file, string(mdTableDirectionTrain))
        println(file, "              .")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "Y EL TEST:")      # Imprime una línea en blanco para separar
        println(file, "\n")      # Imprime una línea en blanco para separar
        resultadosTest = uniqueValuesCount_(df_test, [:Direction], "_4")       # Función que hace un conteo de repetición de valores unicos en las variables categóricas
        mdTableDirectionTest = dataframeToMarkdown_(resultadosTest[:Direction])
        println(file, string(mdTableDirectionTest))
        println(file, "              .")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "\n")      # Imprime una línea en blanco para separar
        df_2EscaladoTrain, df_2EscaladoTest = minMaxScaling_(df_train, df_test)       # Escalar variables necesarias
        println(file, "- TODO BIEN, SE PROCEDE A VERIFICAR EL SCALING")
        println(file, "")       # Imprime un salto de línea simple
        println(file, "DESCRIPCIÓN DE LOS SETS ESCALADOS, EL DE ENTRENAMIENTO:")
        println(file, "\n")      # Imprime una línea en blanco para separar
        desEscTrain = describe(DataFrames.select(df_2EscaladoTrain, Not(:Direction)))
        desEscTrain[:, [:mean, :min, :median, :max, :nmissing]] .= round.(desEscTrain[:, [:mean, :min, :median, :max, :nmissing]] , digits=4)
        mdTableTrainEsc = dataframeToMarkdownDescribe_(desEscTrain)
        println(file, string(mdTableTrainEsc))
        println(file, "              .")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "EL DE PRUEBA:")
        println(file, "\n")      # Imprime una línea en blanco para separar
        desEscTest = describe(DataFrames.select(df_2EscaladoTest, Not(:Direction)))
        desEscTest[:, [:mean, :min, :median, :max, :nmissing]] .= round.(desEscTest[:, [:mean, :min, :median, :max, :nmissing]] , digits=4)
        mdTableTestEsc = dataframeToMarkdownDescribe_(desEscTest)
        println(file, string(mdTableTestEsc))
        println(file, "              .")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- TODO BIEN, LO SIGUIENTE ES VERIFICAR QUE NO EXISTA MULTICOLINEARIDAD ENTRE LAS EXPLICATIVAS, DADO QUE SON LAGS")
        println(file, "\n")      # Imprime una línea en blanco para separar
        df_Esc_Corr_TRAIN, cols_eliminadas = deleteExplicativeHighCorrelatedVariables_(df_2EscaladoTrain, 0.7, file)
        df_Esc_Corr_TEST = DataFrames.select(df_2EscaladoTest, Not(collect(cols_eliminadas)))
        println(file, "**NINGUNA VARIABLE PRESENTÓ UN RIESGO. FINALMENTE SE CAMBIAN LOS VALORES TARGET POR NUMÉRICOS __UP = 1 Y DOWN = 0__** Y SE PROCEDE A MODELAR")
        df_Esc_Corr_TRAIN[!, :Direction] = ifelse.(df_Esc_Corr_TRAIN[!, :Direction] .== "Up", 1, 0)  # Convierte "Up" a 1 y todo lo demás a 0
        df_Esc_Corr_TEST[!, :Direction] = ifelse.(df_Esc_Corr_TEST[!, :Direction] .== "Up", 1, 0)
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "**- PRIMERO MODELO LASSO**")
        alphas_L = [1.0]
        lambdas = [0.1, 0.01, 0.001, 0.0001]
        println(file, "\n")      # Imprime una línea en blanco para separar
        best_predictions_LASSO, best_model_LASSO, best_lambda_LASSO, best_alpha_LASSO, best_auc_LASSO = gridsearch_LassoRidge_(df_Esc_Corr_TRAIN, df_Esc_Corr_TEST, :Direction, lambdas, alphas_L, file)
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "**- SIGUE MODELO RIDGE**")
        alphas_R = [0.0]
        best_predictions_RIDGE, best_model_RIDGE, best_lambda_RIDGE, best_alpha_RIDGE, best_auc_RIDGE = gridsearch_LassoRidge_(df_Esc_Corr_TRAIN, df_Esc_Corr_TEST, :Direction, lambdas, alphas_R, file)
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "**- SIGUE MODELO ELASTIC NET**")
        alphas_EN = [0.9, 0.7, 0.5, 0.3, 0.1]
        best_predictions_ELASTICNET, best_model_ELASTICNET, best_lambda_ELASTICNET, best_alpha_ELASTICNET, best_auc_ELASTICNET = gridsearch_LassoRidge_(df_Esc_Corr_TRAIN, df_Esc_Corr_TEST, :Direction, lambdas, alphas_EN, file)
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "**- SIGUE MODELO DESICION TREE**")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "\n")      # Imprime una línea en blanco para separar
        n_trees_list_DT = [1]
        max_depths = [2, 4, 6, 8, 10, 12, 14, 16]       # Lista de valores de max_depth para probar 
        min_samples_splits = [2, 5, 10, 15, 20, 25]     # Lista de valores de min_samples_split para probar 
        best_model_DT, best_auc_DT, best_n_trees_DT, best_max_depth_DT, best_min_samples_split_DT, best_predictions_DT = gridsearch_DecisionTreeRandomForest_(df_Esc_Corr_TRAIN, df_Esc_Corr_TEST, :Direction, n_trees_list_DT, max_depths, min_samples_splits, file)
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "**- SIGUE MODELO RANDOM FOREST**")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "\n")      # Imprime una línea en blanco para separar
        n_trees_list_RF = [5, 10, 15, 25, 50, 100, 200]
        max_depths = [2, 4, 6, 8, 10, 12, 14, 16]       # Lista de valores de max_depth para probar 
        min_samples_splits = [2, 5, 10, 15, 20, 25]     # Lista de valores de min_samples_split para probar 
        best_model_RF, best_auc_RF, best_n_trees_RF, best_max_depth_RF, best_min_samples_split_RF, best_predictions_RF = gridsearch_DecisionTreeRandomForest_(df_Esc_Corr_TRAIN, df_Esc_Corr_TEST, :Direction, n_trees_list_RF, max_depths, min_samples_splits, file)
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "**- SIGUE MODELO NEAREST NEIGHBORS**")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "\n")      # Imprime una línea en blanco para separar
        k_values = [10, 9, 8, 7, 6, 5, 4, 3, 2]
        best_model_KNN, best_auc_KNN, best_k_KNN, best_preds_KNN = gridsearch_KNN_(df_Esc_Corr_TRAIN, df_Esc_Corr_TEST, :Direction, k_values, file) 
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "**- FINALMENTE EL MODELO SUPPORT VECTOR MACHINE**")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "\n")      # Imprime una línea en blanco para separar
        c_values = [10.0, 1.0, 0.5, 0.3, 0.1, 0.01, 0.001]
        kernel_types = ["linear", "polynomial", "rbf", "sigmoid"]
        #kernel_types = [LIBSVM.Kernel.Linear, LIBSVM.Kernel.Polynomial, LIBSVM.Kernel.RadialBasis, LIBSVM.Kernel.Sigmoid]
        best_model_SVM, best_auc_SVM, best_c_value_SVM, best_kernel_type_SVM, best_predictions_SVM = gridsearch_SVM_(df_Esc_Corr_TRAIN, df_Esc_Corr_TEST, :Direction, c_values, kernel_types, file)
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "              .")
        println(file, "              .")
        println(file, "              .")
        println(file, "![IMAGEN DE CONTEO DE TARGET INICIAL __Direction__](../fig/uniquevalues_Direction_1.png)")
        println(file, "              .")
        println(file, "![IMAGEN DE CONTEO DE __Year__ INICIAL ](../fig/uniquevalues_Year_1.png)")
        println(file, "              .")
        println("![IMAGEN DE VERIFICACIÓN DE BALANCE EN TARGET DESPUÉS DE ELIMINAR OUTLIERS](../fig/uniquevalues_Direction_2.png)")
        println(file, "              .")
        println(file, "![IMAGEN DE VERIFICACIÓN DE BALANCE EN TRAIN SET](../fig/uniquevalues_Direction_3.png)")
        println(file, "              .")
        println(file, "![IMAGEN DE VERIFICACIÓN DE BALANCE EN TEST SET](../fig/uniquevalues_Direction_4.png)")
        println(file, "              .")
        println(file, "\n")      # Imprime una línea en blanco para separar
        for modelo in ["RIDGE", "LASSO", "ELASTICNET", "DECISIONTREE", "RANDOMFOREST", "KNN", "SVM"]
            println(file, "![IMAGEN DE CURVA ROC DE $modelo](../fig/roc_curve_$modelo.png)")
            println(file, "\n")
            println(file, "![IMAGEN DE MATRIZ DE CONFUSIÓN DE $modelo](../fig/confusion_matrix_$modelo.png)")
            println(file, "\n")
        end
    end
end

crearReporte(df, "C:/Users/mayra/OneDrive/Desktop/SARM/3/report/reporteEjercicio_3.jmd")

using Weave
weave("C:/Users/mayra/OneDrive/Desktop/SARM/3/report/reporteEjercicio_3.jmd", doctype = "md2pdf")