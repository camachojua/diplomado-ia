## EJERCICIO 1
# MAYRA ALEJANDRA SÁNCHEZ ROBLEZ
# REPORTE FINAL DEL ANÁLISIS DE LA BASE BOTTLE.CSV

#using Pkg
#Pkg.add("CSV")
#Pkg.add("DataFrames")
#Pkg.add("StatsBase")
#Pkg.add("Plots")
#Pkg.add("CategoricalArrays")
#Pkg.add("Weave")
#Pkg.add("Markdown")

# Librerías
using CSV
using DataFrames
using StatsBase
using Statistics
using Plots
using CategoricalArrays
using Markdown

# Leer el archivo CSV y guardarlo en un DataFrame
df = CSV.read("C:/Users/mayra/OneDrive/Desktop/SARM/1/dat/bottle.csv", DataFrame)

# Función que muestra las dimensiones del df
function dataShape_(df::DataFrame, file)
    println(file, "Número de filas: ", size(df)[1])
    println(file, "")
    println(file, "Número de columnas: ", size(df)[2])
end

# Función para contar valores únicos en cada columna 
function uniqueValueCounts_(df::DataFrame, file) 

    for col in names(df)
        num_unicos = length(unique(df[!, col]))
        println(file, "$col: $num_unicos")
        println(file, "")
    end
end

# Función para imprimir nombre y tipo de cada columna (dataType)
function dataType_(df::DataFrame, file)
    for col in names(df)
        try
            col_data = df[!, col]
            col_type = eltype(col_data)  # Obtiene el tipo de la columna

            # Si la columna tiene un tipo Any, hacer algo especial
            if col_type == Any
                println(file, "Columna: ", col, " - Tipo: Any (Puede ser múltiple o dinámico)")
                println(file, "")
            else
                # Si el tipo es un tipo básico, lo imprimimos
                println(file, "Columna: ", col, " - Tipo: ", col_type)
                println(file, "")
            end
        catch e
            # Si ocurre un error, lo capturamos y lo mostramos
            println(file, "Columna: ", col, " - Error al obtener el tipo: ", e)
            println(file, "")
        end
    end
end

# Función para contar los valores faltantes en cada columna y devolver el conteo
function countMissingValues_(df::DataFrame, file)
    missing_counts = Dict()  # Usa un diccionario para almacenar los resultados
    println(file, "- CONTEO DE MISSING VALUES POR COLUMNA")
    println(file, "\n")

    for col in names(df)
        # Contar los valores faltantes en la columna
        num_missing = sum(ismissing, df[!, col])  # Cuenta los valores 'missing'
        missing_counts[col] = num_missing  # Almacen el conteo en el diccionario

        println(file, "Columna: ", col, " - Valores faltantes: ", num_missing)
        println(file, "")
    end

    return missing_counts  # Devuelve el diccionario con los valores faltantes
end

# Función para calcular el porcentaje de valores faltantes en cada columna
function dataMissingPercentage_(df::DataFrame, file)
    # Primero, obtener el diccionario con los valores faltantes
    missing_counts = countMissingValues_(df, file)
    println(file, "\n")
    println(file, "- PORCENTAGE DE VALORES FALTANTES POR COLUMNA")
    println(file, "\n")
    
    percentage_missing_dict = Dict()  # Diccionario para almacenar los porcentajes de faltantes

    total_rows = size(df)[1]  # Número total de filas

    for col in names(df)
        # Obtener el número de valores faltantes de la columna del diccionario
        num_missing = missing_counts[col]  # Acceder al valor desde el diccionario

        # Calcular el porcentaje de valores faltantes en la columna
        percentage_missing = (num_missing / total_rows) * 100  # Calcular porcentaje
        
        # Almacenar el porcentaje en el diccionario
        percentage_missing_dict[col] = percentage_missing
        
        # Imprimir el resultado
        println(file, "Columna: ", col, " - Porcentaje de valores faltantes: ", round(percentage_missing, digits = 2), "%")
        println(file, "")
    end
    
    return percentage_missing_dict  # Retorna el diccionario con los porcentajes
end

# Función para eliminar columnas con más de un 20% de valores faltantes
function deleteColumns_(df::DataFrame, threshold::Float64, file)
    columns_to_delete = []  # Lista para almacenar los nombres de las columnas a eliminar
    
    # Obtener el porcentaje de valores faltantes en cada columna usando dataMissingPercentage_
    percentage_missing_dict = dataMissingPercentage_(df, file)
    
    # Iterar sobre las columnas y sus porcentajes
    for col in names(df)
        percentage_missing = percentage_missing_dict[col]  # Obtener el porcentaje de valores faltantes de la columna
        
        # Si el porcentaje de valores faltantes supera el umbral, marcar la columna para eliminación
        if percentage_missing >= threshold
            push!(columns_to_delete, col)
        end
    end
    
    # Eliminar las columnas seleccionadas
    select!(df, Not(columns_to_delete))  # Elimina las columnas con más de 20% de valores faltantes
    println(file, "\n")
    println(file, "- SE ELIMINAN LAS COLUMNAS QUE TENGAN AL MENOS 20% DE SUS ROWS EN MISSING")
    println(file, "\n")
    println(file, "Columnas eliminadas:")
    println(file, "\n")
    println(file, columns_to_delete)

    return df
end

# Función que elimina los nulls de una variable específica asignada
function deleteRow_(df::DataFrame, columna::Symbol) 
    
    # Eliminar las filas con valores nulos en la columna especificada 
    df = dropmissing(df, columna) 

    return df 
end

# Función para convertir Sta_ID a números ordenados 
function staIDToNumeric_(df::DataFrame, col_sta_id::Symbol) 
    
    # Separar los componentes de Sta_ID 
    df[!, "Linea"] = parse.(Float64, getindex.(split.(df[!, col_sta_id], " "), 1))
    df[!, "Estacion"] = parse.(Float64, getindex.(split.(df[!, col_sta_id], " "), 2))

    # Crear una representación única basada en ambas partes 
    combinaciones_unicas = unique(zip(df.Linea, df.Estacion))
    combinacion_a_num = Dict(combinaciones_unicas .=> collect(1:length(combinaciones_unicas)))

    # Asignar los números únicos a cada combinación única 
    df[!, "Sta_ID_Num"] = [combinacion_a_num[(linea, estacion)] for (linea, estacion) in zip(df.Linea, df.Estacion)]

    # Eliminar columnas innecesarias 
    select!(df, Not([:Linea, :Estacion, :Sta_ID]))
    
    return df 
end

# Función para imputar valores faltantes con la mediana en todas las columnas numéricas
function imputeAllWithMedian!(df::DataFrame, file)
    for col in names(df)
        # Obtener los datos de la columna
        data = df[!, col]
        
        # Verificar si la columna tiene tipo `Union{Missing, T}`
        if eltype(data) <: Union{Missing, Real}
            # Extraer el tipo sin el Missing
            cleaned_data = skipmissing(data)  # Eliminar valores missing
            median_value = median(cleaned_data)  # Calcular la mediana de los valores no missing
            
            # Imputar los valores faltantes con la mediana
            df[ismissing.(data), col] .= median_value
            
            # Imprimir el resultado
            println(file, "Columna ", col, ": Imputados valores faltantes con la mediana: ", median_value)
            println(file, "")
        end
    end
    return df
end

# Función para convertir columnas con valores Missing en tipos numéricos (Int64 o Float64)
function convertMissingColumns!(df::DataFrame)
    for col in names(df)
        # Obtener el tipo de la columna
        col_type = eltype(df[!, col])

        # Si la columna es de tipo Union{Missing, Float64}, convertirla a Float64
        if col_type == Union{Missing, Float64}
            # Convertir a Float64
            df[!, col] = Float64.(df[!, col])

        # Si la columna es de tipo Union{Missing, Int64}, convertirla a Int64
        elseif col_type == Union{Missing, Int64}
            # Convertir a Int64
            df[!, col] = Int64.(df[!, col])
        end
    end
end

# Función para calcular la correlación entre todas las columnas numéricas y mostrarla como porcentaje
function calculateCorrelation_(df::DataFrame, file)
    # Excluir columnas no numéricas (si las hay)
    numerical_cols = filter(c -> eltype(df[!, c]) <: Real, names(df))  # Filtrar solo las columnas numéricas
    
    # Convertir las columnas numéricas a una matriz
    numerical_matrix = Matrix(df[:, numerical_cols])
    
    # Obtener la matriz de correlación
    correlation_matrix = cor(numerical_matrix)  # Calcular la correlación entre las columnas numéricas
    
    # Imprimir las correlaciones entre columnas de manera legible (como porcentaje)
    num_cols = size(correlation_matrix, 1)
    
    # Iterar sobre la matriz de correlación e imprimir los valores
    for i in 1:num_cols
        for j in i+1:num_cols  # Para evitar imprimir la misma correlación dos veces (matriz simétrica)
            col1 = numerical_cols[i]  # Nombre de la columna i
            col2 = numerical_cols[j]  # Nombre de la columna j
            corr_value = correlation_matrix[i, j]
            println(file, "$col1 y $col2: ", round(corr_value * 100, digits = 2), "%")  # Correlación en porcentaje
            println(file, "")
        end
    end

    # Generar el heatmap
    heatmap_plot = heatmap(correlation_matrix, 
                            xlabel = "Columnas", ylabel = "Columnas", 
                            title = "Mapa de calor de correlación", 
                            xticks = (1:length(numerical_cols), numerical_cols), 
                            yticks = (1:length(numerical_cols), numerical_cols),
                            size = (500, 600),
                            rotation = 50)

    # Mostrar el heatmap
    display(heatmap_plot)

    # Guardar el mapa de calor 
    savefig("C:/Users/mayra/OneDrive/Desktop/SARM/1/fig/correlationHeatmap.png")

end

# Función para eliminar outliers usando el método IQR
function removeOutliersIQR!(df::DataFrame)
    # Iterar sobre las columnas numéricas del DataFrame
    for col in names(df)
        if eltype(df[!, col]) <: Real  # Solo se aplica a columnas numéricas
            # Calcular los cuartiles Q1 y Q3
            Q1 = quantile(df[!, col], 0.25)
            Q3 = quantile(df[!, col], 0.75)
            
            # Calcular el IQR (Rango Intercuartílico)
            IQR = Q3 - Q1
            
            # Definir los límites inferior y superior para los outliers
            lower_limit = Q1 - 1.5 * IQR
            upper_limit = Q3 + 1.5 * IQR
            
            # Filtrar los valores dentro del rango (eliminar outliers)
            df = df[(df[!, col] .>= lower_limit) .& (df[!, col] .<= upper_limit), :]
        end
    end
    return df
end

# Función que hace una selección de variables dependiendo del coeficiente de correlación de la variable explicativa con la target
function filterWithCorrelation_(df::DataFrame, target::Symbol, threshold::Float64, file) 
    
    # Seleccionar solo las columnas numéricas 
    numericas = filter(name -> eltype(df[!, name]) <: Number, names(df)) 
    df_numerico = df[:, Symbol.(numericas)]
    
    # Calcular las correlaciones 
    correlaciones = Dict(col => cor(df_numerico[!, target], df_numerico[!, col]) for col in names(df_numerico) if col != target)
    
    # Filtrar las variables que cumplen con el umbral 
    variables_filtradas = unique([col for col in keys(correlaciones) if correlaciones[col] >= threshold])

    # Crear un nuevo DataFrame con las variables filtradas
    columnas_seleccionadas = Symbol.(vcat(target, variables_filtradas))
    columnas_seleccionadas = unique(columnas_seleccionadas)
    nuevo_df = df[:, columnas_seleccionadas]

    # Imprimir las correlaciones de las variables elegidas 
    println(file, "Correlaciones de las variables elegidas:")
    println(file, "")

    for col in variables_filtradas 
        println(file, "$col: $(correlaciones[col])")
        println(file, "")
    end
    
    return nuevo_df 
end

# Función que arroja una descripción más detallada del df final
function describeExtended_(df::DataFrame, file)

    resumen = describe(df)
    println(file, "CUANTILES POR COLUMNA:")
    for col in names(df) 
        if eltype(df[!, col]) <: Number 
            vals = df[!, col]
            
            q25 = quantile(vals, 0.25) 
            q50 = quantile(vals, 0.5) 
            q75 = quantile(vals, 0.75) 
            
            println(file, "\n")
            println(file, "Columna: $col")
            println(file, "")
            println(file, " 25%: $q25") 
            println(file, " 50% (Mediana): $q50") 
            println(file, " 75%: $q75") 
            println(file, "\n")
        end 
    end 
    
    return resumen 
end

# Convertir el DataFrame de describe a una tabla Markdown
function dataframeToMarkdown_(df)
    headers = names(df)
    # Convertir cada fila del DataFrame a un Vector de cadenas
    rows = [string.(collect(row)) for row in eachrow(df)]
    
    # Formatear la tabla en Markdown
    table_md = "| " * join(headers, " | ") * " |\n"
    table_md *= "| " * join(["-"^length(h) for h in headers], " | ") * " |\n"
    for row in rows
        table_md *= "| " * join(row, " | ") * " |\n"
    end
    return table_md
end

# Crear y escribir el contenido del archivo reporte.jmd 
function crearReporte(df::DataFrame, file_path::String)

    open(file_path, "w") do file
        println(file, "# **EJERCICIO 1**")
        println(file, "## *author: MAYRA ALEJANDRA SÁNCHEZ ROBLEZ*")
        println(file, "### __title: REPORTE FINAL DEL ANÁLISIS DE LA BASE BOTTLE.CSV__")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- NÚMERO DE FILAS Y COLUMNAS DEL DS INICIAL")
        println(file, "\n")      # Imprime una línea en blanco para separar
        dataShape_(df, file)  # Imprime número de filas y columnas
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- NÚMERO DE VALORES ÚNICOS EN CADA VARIABLE")
        println(file, "\n")      # Imprime una línea en blanco para separar
        uniqueValueCounts_(df, file)        # Función para imprimir el conteo de valores únicos por columna
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- SE ELIMINAN DOS COLUMNAS QUE SON ID'S ÚNICOS (Btl_Cnt y Depth_ID), AFECTAN EL USO DE MEMORIA Y EN ANÁLISIS")
        select!(df, Not([:Btl_Cnt, :Depth_ID]))     # Eliminar las columnas de ID únicas directamente 
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- IMPRIME EL TYPE INICIAL DE CADA COLUMNA")
        println(file, "\n")      # Imprime una línea en blanco para separar
        dataType_(df, file)   # Imprime nombre y tipo de cada columna
        println(file, "\n")      # Imprime una línea en blanco para separar
        df_1 = deleteColumns_(df, 20.0, file)     # En esta función quedaron anidados el conteo de missings en número y porcentage, y selección de columnas dados esos porcentages
        df = nothing    # Eliminar el DataFrame para liberar memoria 
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- IMPRIME EL TYPE DE CADA COLUMNA")
        println(file, "\n")      # Imprime una línea en blanco para separar
        dataType_(df_1, file)   # Imprime nombre y tipo de cada columna, nuevo DF
        println(file, "\n")      # Imprime una línea en blanco para separar
        #df_1 = deleteRow_(df_1, :Salnty) # Elimina los nulls de una columna específica (ejemplo: columna Salnty), no lo usé, la base se prestaba para una imputación sencilla
        #println()      # Imprime una línea en blanco para separar
        println(file, "- LA VARIABLE Sta_ID TIENE UN NÚMERO PEQUEÑO DE CATEGORÍAS ÚNICAS, Y DADA INVESTIGACIÓN EN INTERNET, ES CORRECTO ASUMIR QUE SUS MEDICIONES INDICAN CRECIMIENTO VERDADERO, POR LO QUE SE HACE ENCODING NUMÉRICO")
        df_11 = staIDToNumeric_(df_1, :Sta_ID)      # Modificación de variable categórica
        df_1 = nothing      # Eliminar el DataFrame para liberar memoria 
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- DADO QUE LAS VARIABLES RESTANTES TIENEN UN PORCENTAGE PEQUEÑO DE MISSINGS (<20%), Y DADO QUE CON ESTO NO SE MODIFICA LA DISTRIBUCIÓN, SE HACEN IMPUTACIÓN CON LA MEDIANA")
        println(file, "\n")      # Imprime una línea en blanco para separar
        df_2 = imputeAllWithMedian!(df_11, file)      # Imputa todos los valores faltantes con la mediana
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- CASTEO DE LOS TYPES COMPUESTOS CON MISSING, A TYPE REAL, DADO QUE LA IMPUTACIÓN FUE EXITOSA")
        convertMissingColumns!(df_2)      # conversión de columnas con Missing a type Real
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "CHECK DEL CASTEO")
        println(file, "")       # Imprime un salto de línea simple
        dataType_(df_2, file)   # Imprime nombre y tipo de cada columna, nuevo DF
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- CÁLCULO DE CORRELACIONES, PARA ESTE PUNTO TODAS LAS VARIABLES SON NUMÉRICAS")
        println(file, "\n")      # Imprime una línea en blanco para separar
        calculateCorrelation_(df_2, file)     # Calcular la correlación
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- MAPA DE CALOR DE CORRELACIONES, VIENE EN LA ÚLTIMA HOJA")
        println(file, "\n")     # Imprime una línea en blanco para separar
        println(file, "- USANDO EL MÉTODO IQR SE ELIMINAN LOS OUTLIERS DE CADA COLUMNA")
        df_3 = removeOutliersIQR!(df_2)       # Eliminar outliers usando el método IQR
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "CHECK DE DIMENSIONES, VISUALIZAR CUANTOS OUTLIERS FUERON ELIMINADOS")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "DIMENCIONES INICIALES:")
        println(file, "")       # Imprime un salto de línea simple
        dataShape_(df_2, file)  # Imprime número de filas y columnas
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "DIMENCIONES DESPUÉS DE IQR:")
        println(file, "")       # Imprime un salto de línea simple
        dataShape_(df_3, file)  # Imprime número de filas y columnas
        println(file, "\n")      # Imprime una línea en blanco para separar
        df_2 = nothing      # Eliminar el DataFrame para liberar memoria
        println(file, "- PARA HACER UNA SELECCIÓN DE VARIABLES, USAMOS LA MATRIZ DE CORRELACIÓN, AQUELLAS QUE NO TENGAN AL MENOS UN COEFICIENTE DE 0.60 CON LA TARGET SERÁN ELIMINADAS")
        println(file, "\n")      # Imprime una línea en blanco para separar
        df_4 = filterWithCorrelation_(df_3, :T_degC, 0.6, file)      # Eliminar columnas con una correlación menor que 0.6 (en valor absoluto) con 'T_degC'
        df_3 = nothing      # Eliminar el DataFrame para liberar memoria
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "CHECK DE DIMENSIONES, DF CON VARIABLES SELECCIONADAS.")
        println(file, "")       # Imprime un salto de línea simple
        dataShape_(df_4, file)  # Imprime número de filas y columnas
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- FINALMENTE, HACEMOS UN DESCRIBE DEL DF FINAL.")
        println(file, "\n")      # Imprime una línea en blanco para separar
        resumen = describeExtended_(df_4, file)     # Función para crear la descripción de la tabla
        println(file, "\n")     # Imprime una línea en blanco para separar
        println(file, "Y ESTADÍSTICOS IMPORTANTES")
        println(file, "\n")      # Imprime una línea en blanco para separar
        markdown_table = dataframeToMarkdown_(resumen)     # Convertir el resultado de describe a formato Markdown de tabla
        println(file, string(markdown_table))       # Imprimir el resultado
        println(file, "![Mapa de Calor](../fig/correlationHeatmap.png)")  # Mapa de Calor de Correlación
        CSV.write("C:/Users/mayra/OneDrive/Desktop/SARM/1/dat/dfBottleClean.csv", df_4)    # Guardar el DataFrame en un archivo CSV
    end
end

crearReporte(df, "C:/Users/mayra/OneDrive/Desktop/SARM/1/report/reporteEjercicio_1.jmd")

using Weave
weave("C:/Users/mayra/OneDrive/Desktop/SARM/1/report/reporteEjercicio_1.jmd", doctype = "md2pdf")
