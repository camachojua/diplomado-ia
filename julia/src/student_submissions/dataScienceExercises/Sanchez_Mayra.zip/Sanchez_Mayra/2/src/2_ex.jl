## EJERCICIO 2
# MAYRA ALEJANDRA SÁNCHEZ ROBLEZ
# REPORTE MODELO ÓPTIMO BASE BOTTLE.CSV

#using Pkg
#Pkg.add("CSV")
#Pkg.add("DataFrames")
#Pkg.add("Combinatorics")
#Pkg.add("GLM")
#Pkg.add("StatsModels")
#Pkg.add("Statistics")
#Pkg.add("Weave")
#Pkg.add("Markdown")
#Pkg.add("Random")

# Librerías
using CSV
using DataFrames
using Combinatorics
using StatsModels
using Statistics
using GLM
using Markdown
using Random

# Leer el archivo CSV y guardarlo en un DataFrame
df = CSV.read("C:/Users/mayra/OneDrive/Desktop/SARM/2/dat/dfBottleClean.csv", DataFrame)

# Función que muestra las dimensiones del df
function dataShape_(df::DataFrame, file)
    println(file, "Número de filas: ", size(df)[1])
    println(file, "")
    println(file, "Número de columnas: ", size(df)[2])
end

# Función para contar valores únicos en cada columna 
function uniqueValueCounts_(df::DataFrame, file) 

    for col in names(df)
        num_unicos = length(unique(df[!, col]))
        println(file, "$col: $num_unicos")
        println(file, "")
    end
end

# Función para imprimir nombre y tipo de cada columna (dataType)
function dataType_(df::DataFrame, file)
    for col in names(df)
        try
            col_data = df[!, col]
            col_type = eltype(col_data)  # Obtiene el tipo de la columna

            # Si la columna tiene un tipo Any, hacer algo especial
            if col_type == Any
                println(file, "Columna: ", col, " - Tipo: Any (Puede ser múltiple o dinámico)")
                println(file, "")
            else
                # Si el tipo es un tipo básico, lo imprimimos
                println(file, "Columna: ", col, " - Tipo: ", col_type)
                println(file, "")
            end
        catch e
            # Si ocurre un error, lo capturamos y lo mostramos
            println(file, "Columna: ", col, " - Error al obtener el tipo: ", e)
            println(file, "")
        end
    end
end

# Función que recibe un DataFrame y devuelve todas las combinaciones posibles de las columnas explicativas
function totalCombinations_(df::DataFrame, max_combinaciones::Int, file)
    # Seleccionamos las columnas explicativas (todas menos la columna Y)
    X = DataFrames.select(df, Not(:T_degC))

    # Generar todas las combinaciones posibles de 1 a max_combinaciones variables
    combinaciones = []
    for i in 1:max_combinaciones
        # Agregar las combinaciones a la lista, aplanando la estructura
        push!(combinaciones, collect(combinations(names(X), i))...)
    end

    return combinaciones  # Esto devuelve una lista plana de combinaciones
end

# Función para dividir los datos en entrenamiento y prueba
function trainTestSplit_(df::DataFrame, porcentaje_test::Float64, file)
    # Determinar el número de filas para test
    n = nrow(df)
    n_test = round(Int, porcentaje_test * n)
    
    # Crear un índice aleatorio para dividir
    indices = shuffle(1:n)  # Mezclar los índices aleatoriamente
    indices_test = indices[1:n_test]  # Primeros índices para test
    indices_train = indices[n_test+1:end]  # El resto para entrenamiento
    
    # Crear los DataFrames de entrenamiento y prueba
    df_train = df[indices_train, :]
    df_test = df[indices_test, :]
    
    # Asegurarnos de que ambas divisiones tengan datos
    println(file, "\n")
    println(file, "Número de filas de df_train: ", nrow(df_train))
    println(file, "")
    println(file, "Número de filas de df_test: ", nrow(df_test))
    
    return df_train, df_test
end

function metricMSE_(df_train::DataFrame, df_test::DataFrame, variables::Vector{String}, target::Symbol, file)
    # Convertir las variables a Symbols
    vars = Symbol.(variables)
    println(file, "\n")
    println(file, "Variables:")
    println(file, "")
    println(file, vars)
    println(file, "")

    # Crear la fórmula para el modelo usando las variables
    formula = Term(target) ~ sum(term for term in Term.(vars))

    # Extraer las variables explicativas X y la variable objetivo Y para el conjunto de entrenamiento
    X_train = df_train[:, variables]
    Y_train = df_train[!, target]

    X_test = df_test[:, variables]
    Y_test = df_test[!, target]
    
    # Ajustar el modelo de regresión lineal con los datos de entrenamiento
    model = lm(formula, df_train)

    # Obtener las predicciones sobre el conjunto de entrenamiento
    predictionsTrain = GLM.predict(model, X_train)
    # Obtener las predicciones sobre el conjunto de prueba
    predictionsTest = GLM.predict(model, X_test)

    # Calcular el MSE en el conjunto de entrenamiento
    residualsTrain = Y_train .- predictionsTrain
    mseTrain = mean(residualsTrain.^2)
    # Calcular el MSE en el conjunto de prueba
    residualsTest = Y_test .- predictionsTest
    mseTest = mean(residualsTest.^2)
    println(file, "MSE_Train:")
    println(file, "")
    println(file, mseTrain)
    println(file, "")
    println(file, "MSE_Test:")
    println(file, "")
    println(file, mseTest)
    println(file, "\n")
    
    return mseTest, mseTrain
end

function findBetterModelVariables_(df::DataFrame, target::Symbol, max_combinaciones::Int64, porcentaje_test::Float64, file)
    mejores_mse = Dict()

    println(file, "\n")
    println(file, "- PRIMERO, SE DIVIDE LA BASE EN TRAIN Y TEST (ALEATORIAMENTE 80/20), Y EVITAR EN LO POSIBLE, LA FALTA DE GENERALIZACIÓN")
    
    # Dividir los datos en entrenamiento y prueba
    df_train, df_test = trainTestSplit_(df, porcentaje_test, file)
    
    # Iterar sobre combinaciones de variables con tamaños de 1 a max_combinaciones
    combinaciones = totalCombinations_(df, max_combinaciones, file)
    println(file, "\n")
    println(file, "- SE OBTIENEN TODAS LAS POSIBLES COMBINACIONES QUE EXISTEN")
    println(file, "\n")
    println(file, "Combinaciones Posibles:")
    println(file, "")
    println(file, combinaciones)
    println(file, "\n")
    println(file, "- CON CADA UNA DE LAS COMBINACIONES SE ENTRENA UN MODELO DE REGRESIÓN, Y SE OBTIENE LA MÉTRICA MSE")
        
    for combo in combinaciones
        println(file, "\n")
        mseTest, mseTrain = metricMSE_(df_train, df_test, combo, target, file)
        println(file, "\n")
        mejores_mse[string(combo)] = mseTrain
    end

    
    # Seleccionar la combinación con el menor MSE
    mejor_combinacion = argmin(collect(values(mejores_mse)))
    mejor_combinacion_variables = collect(keys(mejores_mse))[mejor_combinacion]
    mejor_mse = mejores_mse[mejor_combinacion_variables]

    println(file, "\n")
    println(file, "- SE SELECCIONA EL MODELO CON EL MSE MAS BAJO USANDO EL SET DE ENTRENAMIENTO")
    println(file, "\n")
    println(file, "**Mejor combinación de variables:**")
    println(file, "")
    println(file, mejor_combinacion_variables)
    println(file, "\n")
    println(file, "**MSE_Train correspondiente:**")
    println(file, "")
    println(file, mejor_mse)
    println(file, "\n")
    
    return mejor_combinacion_variables, mejor_mse
end

# Crear y escribir el contenido del archivo reporte.jmd 
function crearReporte(df::DataFrame, file_path::String)

    open(file_path, "w") do file
        println(file, "# **EJERCICIO 2**")
        println(file, "## *author: MAYRA ALEJANDRA SÁNCHEZ ROBLEZ*")
        println(file, "### __title: REPORTE MODELO ÓPTIMO BASE BOTTLE.CSV__")
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "\n")      # Imprime una línea en blanco para separar
        # Llamar a las funciones
        println(file, "- NÚMERO DE FILAS Y COLUMNAS DEL DS INICIAL")
        println(file, "\n")      # Imprime una línea en blanco para separar
        dataShape_(df, file)  # Imprime número de filas y columnas
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- NÚMERO DE VALORES ÚNICOS EN CADA VARIABLE")
        println(file, "\n")      # Imprime una línea en blanco para separar
        uniqueValueCounts_(df, file)
        println(file, "\n")      # Imprime una línea en blanco para separar
        println(file, "- SE HARÁ UN GRID-SEARCH ENTRENANDO EL MODELO CON TODAS LAS POSIBLES COMBINACIONES QUE EXISTEN CON LAS 5 VARIABLES SELECCIONADAS.")
        println(file, "")      # Imprime una línea en blanco para separar
        println(file, "- NO ONVIDAR QUE LA VARIABLE TARGET ES T_degC")
        println(file, "\n")      # Imprime una línea en blanco para separar
        mejor_combinacion, mejor_mse = findBetterModelVariables_(df, :T_degC, 5, 0.20, file)     # Generar las combinaciones de las variables explicativas
    end
end

crearReporte(df, "C:/Users/mayra/OneDrive/Desktop/SARM/2/report/reporteEjercicio_2.jmd")

using Weave
weave("C:/Users/mayra/OneDrive/Desktop/SARM/2/report/reporteEjercicio_2.jmd", doctype = "md2pdf")