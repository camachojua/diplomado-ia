## EJERCICIO 6
# MAYRA ALEJANDRA SÁNCHEZ ROBLEZ
# REPORTE REPRODUCIR GRÁFICA DE ARCHIVO .py EN .jl

#using Pkg
#Pkg.add("LightGraphs")
#Pkg.add("GraphPlot")
#Pkg.add("Plots")
#Pkg.add("LinearAlgebra")


using LightGraphs
using GraphPlot
using Plots
using LinearAlgebra

# Crear el grafo geométrico aleatorio
let
    n = 200
    radius = 0.125
    G, pos = SimpleGraph(n), Dict{Int, Tuple{Float64, Float64}}()
    for i in 1:n
        pos[i] = (rand(), rand())
    end
    for i in 1:n, j in 1:i-1
        if norm(pos[i] .- pos[j]) <= radius
            add_edge!(G, i, j)
        end
    end

    # Inicializar variables para encontrar el nodo central
    dmin = Inf
    ncenter = 0

    # Encontrar el nodo central
    for (n, (x, y)) in pos
        d = (x - 0.5)^2 + (y - 0.5)^2
        if d < dmin
            ncenter = n
            dmin = d
        end
    end

    # Calcular las distancias desde el nodo central usando Dijkstra 
    dijkstra_state = dijkstra_shortest_paths(G, ncenter) 
    distances = dijkstra_state.dists # Obtener las distancias

    # Crear un array de colores basado en las distancias
    colors = [distances[v] for v in 1:n]

    # Graficar el grafo
    scatter([x for (x, y) in values(pos)], [y for (x, y) in values(pos)],
            marker_z = colors, c = :reds, ms = 5, label = "Nodos",
            legend = false, size = (1500, 1500))
    for e in edges(G)
        x1, y1 = pos[src(e)]
        x2, y2 = pos[dst(e)]
        plot!([x1, x2], [y1, y2], c = :black, alpha = 0.4)
    end

    # Agregar el nodo central con un tamaño mayor
    scatter!([pos[ncenter][1]], [pos[ncenter][2]], ms = 10, c = :blue, label = "Nodo Central")

    # Configurar los límites y ocultar los ejes
    xlims!(-0.05, 1.05)
    ylims!(-0.05, 1.05)
    plot!(legend = false, framestyle = :none)

    # Guardar la imagen
    savefig("C:/Users/mayra/OneDrive/Desktop/SARM/6/fig/random_geometric_graph.png")
end

