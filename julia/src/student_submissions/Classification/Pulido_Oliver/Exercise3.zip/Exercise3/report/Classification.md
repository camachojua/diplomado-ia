{
 "cells": [
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "# CLASIFICACIÓN"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "En éste Notebook tomaremos el Dataset \"Smarket\" que viene del libro \"An Introduction to Statistical Learning (ISLP)\" y generaremos diferentes métodos de clasificación, calcularemos la matriz de confusión de cada modelo y revisaremos sus curvas ROC\n",
    "\n",
    "\n",
    "URL del dataset: https://github.com/intro-stat-learning/ISLP/blob/main/ISLP/data/Smarket.csv"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Comenzamos cargando los paquetes necesarios "
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 202,
   "metadata": {},
   "outputs": [],
   "source": [
    "using Pkg\n",
    "#Pkg.add(\"GLMNet\")\n",
    "#Pkg.add(\"RDatasets\")\n",
    "#Pkg.add(\"MLBase\")\n",
    "#Pkg.add(\"Plots\")\n",
    "#Pkg.add(\"DecisionTree\")\n",
    "#Pkg.add(\"Distances\")\n",
    "#Pkg.add(\"NearestNeighbors\")\n",
    "#Pkg.add(\"Random\")\n",
    "#Pkg.add(\"LinearAlgebra\")\n",
    "#Pkg.add(\"DataStructures\")\n",
    "#Pkg.add(\"LIBSVM\")\n",
    "#Pkg.add(\"MLBase\")\n",
    "#Pkg.add(\"DataFrames\")\n",
    "#Pkg.add(\"CSV\")\n",
    "#Pkg.add(\"StatsBase\")\n",
    "#Pkg.add(\"Statistics\")\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 203,
   "metadata": {},
   "outputs": [],
   "source": [
    "using GLMNet\n",
    "using RDatasets\n",
    "using MLBase\n",
    "using Plots\n",
    "using DecisionTree\n",
    "using Distances\n",
    "using NearestNeighbors\n",
    "using Random\n",
    "using LinearAlgebra\n",
    "using DataStructures\n",
    "using LIBSVM\n",
    "using MLBase\n",
    "using CSV\n",
    "using DataFrames\n",
    "using StatsBase\n",
    "using Statistics"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Ahora cargamos el archivo `CSV` y lo guardamos en un Dataframe llamado `Smarket`"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 204,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div><div style = \"float: left;\"><span>1250×9 DataFrame</span></div><div style = \"float: right;\"><span style = \"font-style: italic;\">1225 rows omitted</span></div><div style = \"clear: both;\"></div></div><div class = \"data-frame\" style = \"overflow-x: scroll;\"><table class = \"data-frame\" style = \"margin-bottom: 6px;\"><thead><tr class = \"header\"><th class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">Row</th><th style = \"text-align: left;\">Year</th><th style = \"text-align: left;\">Lag1</th><th style = \"text-align: left;\">Lag2</th><th style = \"text-align: left;\">Lag3</th><th style = \"text-align: left;\">Lag4</th><th style = \"text-align: left;\">Lag5</th><th style = \"text-align: left;\">Volume</th><th style = \"text-align: left;\">Today</th><th style = \"text-align: left;\">Direction</th></tr><tr class = \"subheader headerLastRow\"><th class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\"></th><th title = \"Int64\" style = \"text-align: left;\">Int64</th><th title = \"Float64\" style = \"text-align: left;\">Float64</th><th title = \"Float64\" style = \"text-align: left;\">Float64</th><th title = \"Float64\" style = \"text-align: left;\">Float64</th><th title = \"Float64\" style = \"text-align: left;\">Float64</th><th title = \"Float64\" style = \"text-align: left;\">Float64</th><th title = \"Float64\" style = \"text-align: left;\">Float64</th><th title = \"Float64\" style = \"text-align: left;\">Float64</th><th title = \"String7\" style = \"text-align: left;\">String7</th></tr></thead><tbody><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">1</td><td style = \"text-align: right;\">2001</td><td style = \"text-align: right;\">0.381</td><td style = \"text-align: right;\">-0.192</td><td style = \"text-align: right;\">-2.624</td><td style = \"text-align: right;\">-1.055</td><td style = \"text-align: right;\">5.01</td><td style = \"text-align: right;\">1.1913</td><td style = \"text-align: right;\">0.959</td><td style = \"text-align: left;\">Up</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">2</td><td style = \"text-align: right;\">2001</td><td style = \"text-align: right;\">0.959</td><td style = \"text-align: right;\">0.381</td><td style = \"text-align: right;\">-0.192</td><td style = \"text-align: right;\">-2.624</td><td style = \"text-align: right;\">-1.055</td><td style = \"text-align: right;\">1.2965</td><td style = \"text-align: right;\">1.032</td><td style = \"text-align: left;\">Up</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">3</td><td style = \"text-align: right;\">2001</td><td style = \"text-align: right;\">1.032</td><td style = \"text-align: right;\">0.959</td><td style = \"text-align: right;\">0.381</td><td style = \"text-align: right;\">-0.192</td><td style = \"text-align: right;\">-2.624</td><td style = \"text-align: right;\">1.4112</td><td style = \"text-align: right;\">-0.623</td><td style = \"text-align: left;\">Down</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">4</td><td style = \"text-align: right;\">2001</td><td style = \"text-align: right;\">-0.623</td><td style = \"text-align: right;\">1.032</td><td style = \"text-align: right;\">0.959</td><td style = \"text-align: right;\">0.381</td><td style = \"text-align: right;\">-0.192</td><td style = \"text-align: right;\">1.276</td><td style = \"text-align: right;\">0.614</td><td style = \"text-align: left;\">Up</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">5</td><td style = \"text-align: right;\">2001</td><td style = \"text-align: right;\">0.614</td><td style = \"text-align: right;\">-0.623</td><td style = \"text-align: right;\">1.032</td><td style = \"text-align: right;\">0.959</td><td style = \"text-align: right;\">0.381</td><td style = \"text-align: right;\">1.2057</td><td style = \"text-align: right;\">0.213</td><td style = \"text-align: left;\">Up</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">6</td><td style = \"text-align: right;\">2001</td><td style = \"text-align: right;\">0.213</td><td style = \"text-align: right;\">0.614</td><td style = \"text-align: right;\">-0.623</td><td style = \"text-align: right;\">1.032</td><td style = \"text-align: right;\">0.959</td><td style = \"text-align: right;\">1.3491</td><td style = \"text-align: right;\">1.392</td><td style = \"text-align: left;\">Up</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">7</td><td style = \"text-align: right;\">2001</td><td style = \"text-align: right;\">1.392</td><td style = \"text-align: right;\">0.213</td><td style = \"text-align: right;\">0.614</td><td style = \"text-align: right;\">-0.623</td><td style = \"text-align: right;\">1.032</td><td style = \"text-align: right;\">1.445</td><td style = \"text-align: right;\">-0.403</td><td style = \"text-align: left;\">Down</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">8</td><td style = \"text-align: right;\">2001</td><td style = \"text-align: right;\">-0.403</td><td style = \"text-align: right;\">1.392</td><td style = \"text-align: right;\">0.213</td><td style = \"text-align: right;\">0.614</td><td style = \"text-align: right;\">-0.623</td><td style = \"text-align: right;\">1.4078</td><td style = \"text-align: right;\">0.027</td><td style = \"text-align: left;\">Up</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">9</td><td style = \"text-align: right;\">2001</td><td style = \"text-align: right;\">0.027</td><td style = \"text-align: right;\">-0.403</td><td style = \"text-align: right;\">1.392</td><td style = \"text-align: right;\">0.213</td><td style = \"text-align: right;\">0.614</td><td style = \"text-align: right;\">1.164</td><td style = \"text-align: right;\">1.303</td><td style = \"text-align: left;\">Up</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">10</td><td style = \"text-align: right;\">2001</td><td style = \"text-align: right;\">1.303</td><td style = \"text-align: right;\">0.027</td><td style = \"text-align: right;\">-0.403</td><td style = \"text-align: right;\">1.392</td><td style = \"text-align: right;\">0.213</td><td style = \"text-align: right;\">1.2326</td><td style = \"text-align: right;\">0.287</td><td style = \"text-align: left;\">Up</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">11</td><td style = \"text-align: right;\">2001</td><td style = \"text-align: right;\">0.287</td><td style = \"text-align: right;\">1.303</td><td style = \"text-align: right;\">0.027</td><td style = \"text-align: right;\">-0.403</td><td style = \"text-align: right;\">1.392</td><td style = \"text-align: right;\">1.309</td><td style = \"text-align: right;\">-0.498</td><td style = \"text-align: left;\">Down</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">12</td><td style = \"text-align: right;\">2001</td><td style = \"text-align: right;\">-0.498</td><td style = \"text-align: right;\">0.287</td><td style = \"text-align: right;\">1.303</td><td style = \"text-align: right;\">0.027</td><td style = \"text-align: right;\">-0.403</td><td style = \"text-align: right;\">1.258</td><td style = \"text-align: right;\">-0.189</td><td style = \"text-align: left;\">Down</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">13</td><td style = \"text-align: right;\">2001</td><td style = \"text-align: right;\">-0.189</td><td style = \"text-align: right;\">-0.498</td><td style = \"text-align: right;\">0.287</td><td style = \"text-align: right;\">1.303</td><td style = \"text-align: right;\">0.027</td><td style = \"text-align: right;\">1.098</td><td style = \"text-align: right;\">0.68</td><td style = \"text-align: left;\">Up</td></tr><tr><td style = \"text-align: right;\">&vellip;</td><td style = \"text-align: right;\">&vellip;</td><td style = \"text-align: right;\">&vellip;</td><td style = \"text-align: right;\">&vellip;</td><td style = \"text-align: right;\">&vellip;</td><td style = \"text-align: right;\">&vellip;</td><td style = \"text-align: right;\">&vellip;</td><td style = \"text-align: right;\">&vellip;</td><td style = \"text-align: right;\">&vellip;</td><td style = \"text-align: right;\">&vellip;</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">1239</td><td style = \"text-align: right;\">2005</td><td style = \"text-align: right;\">0.555</td><td style = \"text-align: right;\">0.084</td><td style = \"text-align: right;\">0.281</td><td style = \"text-align: right;\">-0.122</td><td style = \"text-align: right;\">-0.501</td><td style = \"text-align: right;\">2.39002</td><td style = \"text-align: right;\">0.419</td><td style = \"text-align: left;\">Up</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">1240</td><td style = \"text-align: right;\">2005</td><td style = \"text-align: right;\">0.419</td><td style = \"text-align: right;\">0.555</td><td style = \"text-align: right;\">0.084</td><td style = \"text-align: right;\">0.281</td><td style = \"text-align: right;\">-0.122</td><td style = \"text-align: right;\">2.14552</td><td style = \"text-align: right;\">-0.141</td><td style = \"text-align: left;\">Down</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">1241</td><td style = \"text-align: right;\">2005</td><td style = \"text-align: right;\">-0.141</td><td style = \"text-align: right;\">0.419</td><td style = \"text-align: right;\">0.555</td><td style = \"text-align: right;\">0.084</td><td style = \"text-align: right;\">0.281</td><td style = \"text-align: right;\">2.18059</td><td style = \"text-align: right;\">-0.285</td><td style = \"text-align: left;\">Down</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">1242</td><td style = \"text-align: right;\">2005</td><td style = \"text-align: right;\">-0.285</td><td style = \"text-align: right;\">-0.141</td><td style = \"text-align: right;\">0.419</td><td style = \"text-align: right;\">0.555</td><td style = \"text-align: right;\">0.084</td><td style = \"text-align: right;\">2.58419</td><td style = \"text-align: right;\">-0.584</td><td style = \"text-align: left;\">Down</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">1243</td><td style = \"text-align: right;\">2005</td><td style = \"text-align: right;\">-0.584</td><td style = \"text-align: right;\">-0.285</td><td style = \"text-align: right;\">-0.141</td><td style = \"text-align: right;\">0.419</td><td style = \"text-align: right;\">0.555</td><td style = \"text-align: right;\">2.20881</td><td style = \"text-align: right;\">-0.024</td><td style = \"text-align: left;\">Down</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">1244</td><td style = \"text-align: right;\">2005</td><td style = \"text-align: right;\">-0.024</td><td style = \"text-align: right;\">-0.584</td><td style = \"text-align: right;\">-0.285</td><td style = \"text-align: right;\">-0.141</td><td style = \"text-align: right;\">0.419</td><td style = \"text-align: right;\">1.99669</td><td style = \"text-align: right;\">0.252</td><td style = \"text-align: left;\">Up</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">1245</td><td style = \"text-align: right;\">2005</td><td style = \"text-align: right;\">0.252</td><td style = \"text-align: right;\">-0.024</td><td style = \"text-align: right;\">-0.584</td><td style = \"text-align: right;\">-0.285</td><td style = \"text-align: right;\">-0.141</td><td style = \"text-align: right;\">2.06517</td><td style = \"text-align: right;\">0.422</td><td style = \"text-align: left;\">Up</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">1246</td><td style = \"text-align: right;\">2005</td><td style = \"text-align: right;\">0.422</td><td style = \"text-align: right;\">0.252</td><td style = \"text-align: right;\">-0.024</td><td style = \"text-align: right;\">-0.584</td><td style = \"text-align: right;\">-0.285</td><td style = \"text-align: right;\">1.8885</td><td style = \"text-align: right;\">0.043</td><td style = \"text-align: left;\">Up</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">1247</td><td style = \"text-align: right;\">2005</td><td style = \"text-align: right;\">0.043</td><td style = \"text-align: right;\">0.422</td><td style = \"text-align: right;\">0.252</td><td style = \"text-align: right;\">-0.024</td><td style = \"text-align: right;\">-0.584</td><td style = \"text-align: right;\">1.28581</td><td style = \"text-align: right;\">-0.955</td><td style = \"text-align: left;\">Down</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">1248</td><td style = \"text-align: right;\">2005</td><td style = \"text-align: right;\">-0.955</td><td style = \"text-align: right;\">0.043</td><td style = \"text-align: right;\">0.422</td><td style = \"text-align: right;\">0.252</td><td style = \"text-align: right;\">-0.024</td><td style = \"text-align: right;\">1.54047</td><td style = \"text-align: right;\">0.13</td><td style = \"text-align: left;\">Up</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">1249</td><td style = \"text-align: right;\">2005</td><td style = \"text-align: right;\">0.13</td><td style = \"text-align: right;\">-0.955</td><td style = \"text-align: right;\">0.043</td><td style = \"text-align: right;\">0.422</td><td style = \"text-align: right;\">0.252</td><td style = \"text-align: right;\">1.42236</td><td style = \"text-align: right;\">-0.298</td><td style = \"text-align: left;\">Down</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">1250</td><td style = \"text-align: right;\">2005</td><td style = \"text-align: right;\">-0.298</td><td style = \"text-align: right;\">0.13</td><td style = \"text-align: right;\">-0.955</td><td style = \"text-align: right;\">0.043</td><td style = \"text-align: right;\">0.422</td><td style = \"text-align: right;\">1.38254</td><td style = \"text-align: right;\">-0.489</td><td style = \"text-align: left;\">Down</td></tr></tbody></table></div>"
      ],
      "text/latex": [
       "\\begin{tabular}{r|ccccccccc}\n",
       "\t& Year & Lag1 & Lag2 & Lag3 & Lag4 & Lag5 & Volume & Today & Direction\\\\\n",
       "\t\\hline\n",
       "\t& Int64 & Float64 & Float64 & Float64 & Float64 & Float64 & Float64 & Float64 & String7\\\\\n",
       "\t\\hline\n",
       "\t1 & 2001 & 0.381 & -0.192 & -2.624 & -1.055 & 5.01 & 1.1913 & 0.959 & Up \\\\\n",
       "\t2 & 2001 & 0.959 & 0.381 & -0.192 & -2.624 & -1.055 & 1.2965 & 1.032 & Up \\\\\n",
       "\t3 & 2001 & 1.032 & 0.959 & 0.381 & -0.192 & -2.624 & 1.4112 & -0.623 & Down \\\\\n",
       "\t4 & 2001 & -0.623 & 1.032 & 0.959 & 0.381 & -0.192 & 1.276 & 0.614 & Up \\\\\n",
       "\t5 & 2001 & 0.614 & -0.623 & 1.032 & 0.959 & 0.381 & 1.2057 & 0.213 & Up \\\\\n",
       "\t6 & 2001 & 0.213 & 0.614 & -0.623 & 1.032 & 0.959 & 1.3491 & 1.392 & Up \\\\\n",
       "\t7 & 2001 & 1.392 & 0.213 & 0.614 & -0.623 & 1.032 & 1.445 & -0.403 & Down \\\\\n",
       "\t8 & 2001 & -0.403 & 1.392 & 0.213 & 0.614 & -0.623 & 1.4078 & 0.027 & Up \\\\\n",
       "\t9 & 2001 & 0.027 & -0.403 & 1.392 & 0.213 & 0.614 & 1.164 & 1.303 & Up \\\\\n",
       "\t10 & 2001 & 1.303 & 0.027 & -0.403 & 1.392 & 0.213 & 1.2326 & 0.287 & Up \\\\\n",
       "\t11 & 2001 & 0.287 & 1.303 & 0.027 & -0.403 & 1.392 & 1.309 & -0.498 & Down \\\\\n",
       "\t12 & 2001 & -0.498 & 0.287 & 1.303 & 0.027 & -0.403 & 1.258 & -0.189 & Down \\\\\n",
       "\t13 & 2001 & -0.189 & -0.498 & 0.287 & 1.303 & 0.027 & 1.098 & 0.68 & Up \\\\\n",
       "\t14 & 2001 & 0.68 & -0.189 & -0.498 & 0.287 & 1.303 & 1.0531 & 0.701 & Up \\\\\n",
       "\t15 & 2001 & 0.701 & 0.68 & -0.189 & -0.498 & 0.287 & 1.1498 & -0.562 & Down \\\\\n",
       "\t16 & 2001 & -0.562 & 0.701 & 0.68 & -0.189 & -0.498 & 1.2953 & 0.546 & Up \\\\\n",
       "\t17 & 2001 & 0.546 & -0.562 & 0.701 & 0.68 & -0.189 & 1.1188 & -1.747 & Down \\\\\n",
       "\t18 & 2001 & -1.747 & 0.546 & -0.562 & 0.701 & 0.68 & 1.0484 & 0.359 & Up \\\\\n",
       "\t19 & 2001 & 0.359 & -1.747 & 0.546 & -0.562 & 0.701 & 1.013 & -0.151 & Down \\\\\n",
       "\t20 & 2001 & -0.151 & 0.359 & -1.747 & 0.546 & -0.562 & 1.0596 & -0.841 & Down \\\\\n",
       "\t21 & 2001 & -0.841 & -0.151 & 0.359 & -1.747 & 0.546 & 1.1583 & -0.623 & Down \\\\\n",
       "\t22 & 2001 & -0.623 & -0.841 & -0.151 & 0.359 & -1.747 & 1.1072 & -1.334 & Down \\\\\n",
       "\t23 & 2001 & -1.334 & -0.623 & -0.841 & -0.151 & 0.359 & 1.0755 & 1.183 & Up \\\\\n",
       "\t24 & 2001 & 1.183 & -1.334 & -0.623 & -0.841 & -0.151 & 1.0391 & -0.865 & Down \\\\\n",
       "\t$\\dots$ & $\\dots$ & $\\dots$ & $\\dots$ & $\\dots$ & $\\dots$ & $\\dots$ & $\\dots$ & $\\dots$ & $\\dots$ \\\\\n",
       "\\end{tabular}\n"
      ],
      "text/plain": [
       "\u001b[1m1250×9 DataFrame\u001b[0m\n",
       "\u001b[1m  Row \u001b[0m│\u001b[1m Year  \u001b[0m\u001b[1m Lag1    \u001b[0m\u001b[1m Lag2    \u001b[0m\u001b[1m Lag3    \u001b[0m\u001b[1m Lag4    \u001b[0m\u001b[1m Lag5    \u001b[0m\u001b[1m Volume  \u001b[0m\u001b[1m Today   \u001b[0m\u001b[1m \u001b[0m ⋯\n",
       "      │\u001b[90m Int64 \u001b[0m\u001b[90m Float64 \u001b[0m\u001b[90m Float64 \u001b[0m\u001b[90m Float64 \u001b[0m\u001b[90m Float64 \u001b[0m\u001b[90m Float64 \u001b[0m\u001b[90m Float64 \u001b[0m\u001b[90m Float64 \u001b[0m\u001b[90m \u001b[0m ⋯\n",
       "──────┼─────────────────────────────────────────────────────────────────────────\n",
       "    1 │  2001    0.381   -0.192   -2.624   -1.055    5.01   1.1913     0.959   ⋯\n",
       "    2 │  2001    0.959    0.381   -0.192   -2.624   -1.055  1.2965     1.032\n",
       "    3 │  2001    1.032    0.959    0.381   -0.192   -2.624  1.4112    -0.623\n",
       "    4 │  2001   -0.623    1.032    0.959    0.381   -0.192  1.276      0.614\n",
       "    5 │  2001    0.614   -0.623    1.032    0.959    0.381  1.2057     0.213   ⋯\n",
       "    6 │  2001    0.213    0.614   -0.623    1.032    0.959  1.3491     1.392\n",
       "    7 │  2001    1.392    0.213    0.614   -0.623    1.032  1.445     -0.403\n",
       "    8 │  2001   -0.403    1.392    0.213    0.614   -0.623  1.4078     0.027\n",
       "  ⋮   │   ⋮       ⋮        ⋮        ⋮        ⋮        ⋮        ⋮        ⋮      ⋱\n",
       " 1244 │  2005   -0.024   -0.584   -0.285   -0.141    0.419  1.99669    0.252   ⋯\n",
       " 1245 │  2005    0.252   -0.024   -0.584   -0.285   -0.141  2.06517    0.422\n",
       " 1246 │  2005    0.422    0.252   -0.024   -0.584   -0.285  1.8885     0.043\n",
       " 1247 │  2005    0.043    0.422    0.252   -0.024   -0.584  1.28581   -0.955\n",
       " 1248 │  2005   -0.955    0.043    0.422    0.252   -0.024  1.54047    0.13    ⋯\n",
       " 1249 │  2005    0.13    -0.955    0.043    0.422    0.252  1.42236   -0.298\n",
       " 1250 │  2005   -0.298    0.13    -0.955    0.043    0.422  1.38254   -0.489\n",
       "\u001b[36m                                                  1 column and 1235 rows omitted\u001b[0m"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "Smarket = CSV.read(\"Smarket.csv\", DataFrame)\n",
    "Smarket"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 205,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div><div style = \"float: left;\"><span>1250×9 DataFrame</span></div><div style = \"float: right;\"><span style = \"font-style: italic;\">1225 rows omitted</span></div><div style = \"clear: both;\"></div></div><div class = \"data-frame\" style = \"overflow-x: scroll;\"><table class = \"data-frame\" style = \"margin-bottom: 6px;\"><thead><tr class = \"header\"><th class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">Row</th><th style = \"text-align: left;\">Year</th><th style = \"text-align: left;\">Lag1</th><th style = \"text-align: left;\">Lag2</th><th style = \"text-align: left;\">Lag3</th><th style = \"text-align: left;\">Lag4</th><th style = \"text-align: left;\">Lag5</th><th style = \"text-align: left;\">Volume</th><th style = \"text-align: left;\">Today</th><th style = \"text-align: left;\">Direction</th></tr><tr class = \"subheader headerLastRow\"><th class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\"></th><th title = \"Int64\" style = \"text-align: left;\">Int64</th><th title = \"Float64\" style = \"text-align: left;\">Float64</th><th title = \"Float64\" style = \"text-align: left;\">Float64</th><th title = \"Float64\" style = \"text-align: left;\">Float64</th><th title = \"Float64\" style = \"text-align: left;\">Float64</th><th title = \"Float64\" style = \"text-align: left;\">Float64</th><th title = \"Float64\" style = \"text-align: left;\">Float64</th><th title = \"Float64\" style = \"text-align: left;\">Float64</th><th title = \"String7\" style = \"text-align: left;\">String7</th></tr></thead><tbody><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">1</td><td style = \"text-align: right;\">2001</td><td style = \"text-align: right;\">0.381</td><td style = \"text-align: right;\">-0.192</td><td style = \"text-align: right;\">-2.624</td><td style = \"text-align: right;\">-1.055</td><td style = \"text-align: right;\">5.01</td><td style = \"text-align: right;\">1.1913</td><td style = \"text-align: right;\">0.959</td><td style = \"text-align: left;\">Up</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">2</td><td style = \"text-align: right;\">2001</td><td style = \"text-align: right;\">0.959</td><td style = \"text-align: right;\">0.381</td><td style = \"text-align: right;\">-0.192</td><td style = \"text-align: right;\">-2.624</td><td style = \"text-align: right;\">-1.055</td><td style = \"text-align: right;\">1.2965</td><td style = \"text-align: right;\">1.032</td><td style = \"text-align: left;\">Up</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">3</td><td style = \"text-align: right;\">2001</td><td style = \"text-align: right;\">1.032</td><td style = \"text-align: right;\">0.959</td><td style = \"text-align: right;\">0.381</td><td style = \"text-align: right;\">-0.192</td><td style = \"text-align: right;\">-2.624</td><td style = \"text-align: right;\">1.4112</td><td style = \"text-align: right;\">-0.623</td><td style = \"text-align: left;\">Down</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">4</td><td style = \"text-align: right;\">2001</td><td style = \"text-align: right;\">-0.623</td><td style = \"text-align: right;\">1.032</td><td style = \"text-align: right;\">0.959</td><td style = \"text-align: right;\">0.381</td><td style = \"text-align: right;\">-0.192</td><td style = \"text-align: right;\">1.276</td><td style = \"text-align: right;\">0.614</td><td style = \"text-align: left;\">Up</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">5</td><td style = \"text-align: right;\">2001</td><td style = \"text-align: right;\">0.614</td><td style = \"text-align: right;\">-0.623</td><td style = \"text-align: right;\">1.032</td><td style = \"text-align: right;\">0.959</td><td style = \"text-align: right;\">0.381</td><td style = \"text-align: right;\">1.2057</td><td style = \"text-align: right;\">0.213</td><td style = \"text-align: left;\">Up</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">6</td><td style = \"text-align: right;\">2001</td><td style = \"text-align: right;\">0.213</td><td style = \"text-align: right;\">0.614</td><td style = \"text-align: right;\">-0.623</td><td style = \"text-align: right;\">1.032</td><td style = \"text-align: right;\">0.959</td><td style = \"text-align: right;\">1.3491</td><td style = \"text-align: right;\">1.392</td><td style = \"text-align: left;\">Up</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">7</td><td style = \"text-align: right;\">2001</td><td style = \"text-align: right;\">1.392</td><td style = \"text-align: right;\">0.213</td><td style = \"text-align: right;\">0.614</td><td style = \"text-align: right;\">-0.623</td><td style = \"text-align: right;\">1.032</td><td style = \"text-align: right;\">1.445</td><td style = \"text-align: right;\">-0.403</td><td style = \"text-align: left;\">Down</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">8</td><td style = \"text-align: right;\">2001</td><td style = \"text-align: right;\">-0.403</td><td style = \"text-align: right;\">1.392</td><td style = \"text-align: right;\">0.213</td><td style = \"text-align: right;\">0.614</td><td style = \"text-align: right;\">-0.623</td><td style = \"text-align: right;\">1.4078</td><td style = \"text-align: right;\">0.027</td><td style = \"text-align: left;\">Up</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">9</td><td style = \"text-align: right;\">2001</td><td style = \"text-align: right;\">0.027</td><td style = \"text-align: right;\">-0.403</td><td style = \"text-align: right;\">1.392</td><td style = \"text-align: right;\">0.213</td><td style = \"text-align: right;\">0.614</td><td style = \"text-align: right;\">1.164</td><td style = \"text-align: right;\">1.303</td><td style = \"text-align: left;\">Up</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">10</td><td style = \"text-align: right;\">2001</td><td style = \"text-align: right;\">1.303</td><td style = \"text-align: right;\">0.027</td><td style = \"text-align: right;\">-0.403</td><td style = \"text-align: right;\">1.392</td><td style = \"text-align: right;\">0.213</td><td style = \"text-align: right;\">1.2326</td><td style = \"text-align: right;\">0.287</td><td style = \"text-align: left;\">Up</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">11</td><td style = \"text-align: right;\">2001</td><td style = \"text-align: right;\">0.287</td><td style = \"text-align: right;\">1.303</td><td style = \"text-align: right;\">0.027</td><td style = \"text-align: right;\">-0.403</td><td style = \"text-align: right;\">1.392</td><td style = \"text-align: right;\">1.309</td><td style = \"text-align: right;\">-0.498</td><td style = \"text-align: left;\">Down</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">12</td><td style = \"text-align: right;\">2001</td><td style = \"text-align: right;\">-0.498</td><td style = \"text-align: right;\">0.287</td><td style = \"text-align: right;\">1.303</td><td style = \"text-align: right;\">0.027</td><td style = \"text-align: right;\">-0.403</td><td style = \"text-align: right;\">1.258</td><td style = \"text-align: right;\">-0.189</td><td style = \"text-align: left;\">Down</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">13</td><td style = \"text-align: right;\">2001</td><td style = \"text-align: right;\">-0.189</td><td style = \"text-align: right;\">-0.498</td><td style = \"text-align: right;\">0.287</td><td style = \"text-align: right;\">1.303</td><td style = \"text-align: right;\">0.027</td><td style = \"text-align: right;\">1.098</td><td style = \"text-align: right;\">0.68</td><td style = \"text-align: left;\">Up</td></tr><tr><td style = \"text-align: right;\">&vellip;</td><td style = \"text-align: right;\">&vellip;</td><td style = \"text-align: right;\">&vellip;</td><td style = \"text-align: right;\">&vellip;</td><td style = \"text-align: right;\">&vellip;</td><td style = \"text-align: right;\">&vellip;</td><td style = \"text-align: right;\">&vellip;</td><td style = \"text-align: right;\">&vellip;</td><td style = \"text-align: right;\">&vellip;</td><td style = \"text-align: right;\">&vellip;</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">1239</td><td style = \"text-align: right;\">2005</td><td style = \"text-align: right;\">0.555</td><td style = \"text-align: right;\">0.084</td><td style = \"text-align: right;\">0.281</td><td style = \"text-align: right;\">-0.122</td><td style = \"text-align: right;\">-0.501</td><td style = \"text-align: right;\">2.39002</td><td style = \"text-align: right;\">0.419</td><td style = \"text-align: left;\">Up</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">1240</td><td style = \"text-align: right;\">2005</td><td style = \"text-align: right;\">0.419</td><td style = \"text-align: right;\">0.555</td><td style = \"text-align: right;\">0.084</td><td style = \"text-align: right;\">0.281</td><td style = \"text-align: right;\">-0.122</td><td style = \"text-align: right;\">2.14552</td><td style = \"text-align: right;\">-0.141</td><td style = \"text-align: left;\">Down</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">1241</td><td style = \"text-align: right;\">2005</td><td style = \"text-align: right;\">-0.141</td><td style = \"text-align: right;\">0.419</td><td style = \"text-align: right;\">0.555</td><td style = \"text-align: right;\">0.084</td><td style = \"text-align: right;\">0.281</td><td style = \"text-align: right;\">2.18059</td><td style = \"text-align: right;\">-0.285</td><td style = \"text-align: left;\">Down</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">1242</td><td style = \"text-align: right;\">2005</td><td style = \"text-align: right;\">-0.285</td><td style = \"text-align: right;\">-0.141</td><td style = \"text-align: right;\">0.419</td><td style = \"text-align: right;\">0.555</td><td style = \"text-align: right;\">0.084</td><td style = \"text-align: right;\">2.58419</td><td style = \"text-align: right;\">-0.584</td><td style = \"text-align: left;\">Down</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">1243</td><td style = \"text-align: right;\">2005</td><td style = \"text-align: right;\">-0.584</td><td style = \"text-align: right;\">-0.285</td><td style = \"text-align: right;\">-0.141</td><td style = \"text-align: right;\">0.419</td><td style = \"text-align: right;\">0.555</td><td style = \"text-align: right;\">2.20881</td><td style = \"text-align: right;\">-0.024</td><td style = \"text-align: left;\">Down</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">1244</td><td style = \"text-align: right;\">2005</td><td style = \"text-align: right;\">-0.024</td><td style = \"text-align: right;\">-0.584</td><td style = \"text-align: right;\">-0.285</td><td style = \"text-align: right;\">-0.141</td><td style = \"text-align: right;\">0.419</td><td style = \"text-align: right;\">1.99669</td><td style = \"text-align: right;\">0.252</td><td style = \"text-align: left;\">Up</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">1245</td><td style = \"text-align: right;\">2005</td><td style = \"text-align: right;\">0.252</td><td style = \"text-align: right;\">-0.024</td><td style = \"text-align: right;\">-0.584</td><td style = \"text-align: right;\">-0.285</td><td style = \"text-align: right;\">-0.141</td><td style = \"text-align: right;\">2.06517</td><td style = \"text-align: right;\">0.422</td><td style = \"text-align: left;\">Up</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">1246</td><td style = \"text-align: right;\">2005</td><td style = \"text-align: right;\">0.422</td><td style = \"text-align: right;\">0.252</td><td style = \"text-align: right;\">-0.024</td><td style = \"text-align: right;\">-0.584</td><td style = \"text-align: right;\">-0.285</td><td style = \"text-align: right;\">1.8885</td><td style = \"text-align: right;\">0.043</td><td style = \"text-align: left;\">Up</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">1247</td><td style = \"text-align: right;\">2005</td><td style = \"text-align: right;\">0.043</td><td style = \"text-align: right;\">0.422</td><td style = \"text-align: right;\">0.252</td><td style = \"text-align: right;\">-0.024</td><td style = \"text-align: right;\">-0.584</td><td style = \"text-align: right;\">1.28581</td><td style = \"text-align: right;\">-0.955</td><td style = \"text-align: left;\">Down</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">1248</td><td style = \"text-align: right;\">2005</td><td style = \"text-align: right;\">-0.955</td><td style = \"text-align: right;\">0.043</td><td style = \"text-align: right;\">0.422</td><td style = \"text-align: right;\">0.252</td><td style = \"text-align: right;\">-0.024</td><td style = \"text-align: right;\">1.54047</td><td style = \"text-align: right;\">0.13</td><td style = \"text-align: left;\">Up</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">1249</td><td style = \"text-align: right;\">2005</td><td style = \"text-align: right;\">0.13</td><td style = \"text-align: right;\">-0.955</td><td style = \"text-align: right;\">0.043</td><td style = \"text-align: right;\">0.422</td><td style = \"text-align: right;\">0.252</td><td style = \"text-align: right;\">1.42236</td><td style = \"text-align: right;\">-0.298</td><td style = \"text-align: left;\">Down</td></tr><tr><td class = \"rowNumber\" style = \"font-weight: bold; text-align: right;\">1250</td><td style = \"text-align: right;\">2005</td><td style = \"text-align: right;\">-0.298</td><td style = \"text-align: right;\">0.13</td><td style = \"text-align: right;\">-0.955</td><td style = \"text-align: right;\">0.043</td><td style = \"text-align: right;\">0.422</td><td style = \"text-align: right;\">1.38254</td><td style = \"text-align: right;\">-0.489</td><td style = \"text-align: left;\">Down</td></tr></tbody></table></div>"
      ],
      "text/latex": [
       "\\begin{tabular}{r|ccccccccc}\n",
       "\t& Year & Lag1 & Lag2 & Lag3 & Lag4 & Lag5 & Volume & Today & Direction\\\\\n",
       "\t\\hline\n",
       "\t& Int64 & Float64 & Float64 & Float64 & Float64 & Float64 & Float64 & Float64 & String7\\\\\n",
       "\t\\hline\n",
       "\t1 & 2001 & 0.381 & -0.192 & -2.624 & -1.055 & 5.01 & 1.1913 & 0.959 & Up \\\\\n",
       "\t2 & 2001 & 0.959 & 0.381 & -0.192 & -2.624 & -1.055 & 1.2965 & 1.032 & Up \\\\\n",
       "\t3 & 2001 & 1.032 & 0.959 & 0.381 & -0.192 & -2.624 & 1.4112 & -0.623 & Down \\\\\n",
       "\t4 & 2001 & -0.623 & 1.032 & 0.959 & 0.381 & -0.192 & 1.276 & 0.614 & Up \\\\\n",
       "\t5 & 2001 & 0.614 & -0.623 & 1.032 & 0.959 & 0.381 & 1.2057 & 0.213 & Up \\\\\n",
       "\t6 & 2001 & 0.213 & 0.614 & -0.623 & 1.032 & 0.959 & 1.3491 & 1.392 & Up \\\\\n",
       "\t7 & 2001 & 1.392 & 0.213 & 0.614 & -0.623 & 1.032 & 1.445 & -0.403 & Down \\\\\n",
       "\t8 & 2001 & -0.403 & 1.392 & 0.213 & 0.614 & -0.623 & 1.4078 & 0.027 & Up \\\\\n",
       "\t9 & 2001 & 0.027 & -0.403 & 1.392 & 0.213 & 0.614 & 1.164 & 1.303 & Up \\\\\n",
       "\t10 & 2001 & 1.303 & 0.027 & -0.403 & 1.392 & 0.213 & 1.2326 & 0.287 & Up \\\\\n",
       "\t11 & 2001 & 0.287 & 1.303 & 0.027 & -0.403 & 1.392 & 1.309 & -0.498 & Down \\\\\n",
       "\t12 & 2001 & -0.498 & 0.287 & 1.303 & 0.027 & -0.403 & 1.258 & -0.189 & Down \\\\\n",
       "\t13 & 2001 & -0.189 & -0.498 & 0.287 & 1.303 & 0.027 & 1.098 & 0.68 & Up \\\\\n",
       "\t14 & 2001 & 0.68 & -0.189 & -0.498 & 0.287 & 1.303 & 1.0531 & 0.701 & Up \\\\\n",
       "\t15 & 2001 & 0.701 & 0.68 & -0.189 & -0.498 & 0.287 & 1.1498 & -0.562 & Down \\\\\n",
       "\t16 & 2001 & -0.562 & 0.701 & 0.68 & -0.189 & -0.498 & 1.2953 & 0.546 & Up \\\\\n",
       "\t17 & 2001 & 0.546 & -0.562 & 0.701 & 0.68 & -0.189 & 1.1188 & -1.747 & Down \\\\\n",
       "\t18 & 2001 & -1.747 & 0.546 & -0.562 & 0.701 & 0.68 & 1.0484 & 0.359 & Up \\\\\n",
       "\t19 & 2001 & 0.359 & -1.747 & 0.546 & -0.562 & 0.701 & 1.013 & -0.151 & Down \\\\\n",
       "\t20 & 2001 & -0.151 & 0.359 & -1.747 & 0.546 & -0.562 & 1.0596 & -0.841 & Down \\\\\n",
       "\t21 & 2001 & -0.841 & -0.151 & 0.359 & -1.747 & 0.546 & 1.1583 & -0.623 & Down \\\\\n",
       "\t22 & 2001 & -0.623 & -0.841 & -0.151 & 0.359 & -1.747 & 1.1072 & -1.334 & Down \\\\\n",
       "\t23 & 2001 & -1.334 & -0.623 & -0.841 & -0.151 & 0.359 & 1.0755 & 1.183 & Up \\\\\n",
       "\t24 & 2001 & 1.183 & -1.334 & -0.623 & -0.841 & -0.151 & 1.0391 & -0.865 & Down \\\\\n",
       "\t$\\dots$ & $\\dots$ & $\\dots$ & $\\dots$ & $\\dots$ & $\\dots$ & $\\dots$ & $\\dots$ & $\\dots$ & $\\dots$ \\\\\n",
       "\\end{tabular}\n"
      ],
      "text/plain": [
       "\u001b[1m1250×9 DataFrame\u001b[0m\n",
       "\u001b[1m  Row \u001b[0m│\u001b[1m Year  \u001b[0m\u001b[1m Lag1    \u001b[0m\u001b[1m Lag2    \u001b[0m\u001b[1m Lag3    \u001b[0m\u001b[1m Lag4    \u001b[0m\u001b[1m Lag5    \u001b[0m\u001b[1m Volume  \u001b[0m\u001b[1m Today   \u001b[0m\u001b[1m \u001b[0m ⋯\n",
       "      │\u001b[90m Int64 \u001b[0m\u001b[90m Float64 \u001b[0m\u001b[90m Float64 \u001b[0m\u001b[90m Float64 \u001b[0m\u001b[90m Float64 \u001b[0m\u001b[90m Float64 \u001b[0m\u001b[90m Float64 \u001b[0m\u001b[90m Float64 \u001b[0m\u001b[90m \u001b[0m ⋯\n",
       "──────┼─────────────────────────────────────────────────────────────────────────\n",
       "    1 │  2001    0.381   -0.192   -2.624   -1.055    5.01   1.1913     0.959   ⋯\n",
       "    2 │  2001    0.959    0.381   -0.192   -2.624   -1.055  1.2965     1.032\n",
       "    3 │  2001    1.032    0.959    0.381   -0.192   -2.624  1.4112    -0.623\n",
       "    4 │  2001   -0.623    1.032    0.959    0.381   -0.192  1.276      0.614\n",
       "    5 │  2001    0.614   -0.623    1.032    0.959    0.381  1.2057     0.213   ⋯\n",
       "    6 │  2001    0.213    0.614   -0.623    1.032    0.959  1.3491     1.392\n",
       "    7 │  2001    1.392    0.213    0.614   -0.623    1.032  1.445     -0.403\n",
       "    8 │  2001   -0.403    1.392    0.213    0.614   -0.623  1.4078     0.027\n",
       "  ⋮   │   ⋮       ⋮        ⋮        ⋮        ⋮        ⋮        ⋮        ⋮      ⋱\n",
       " 1244 │  2005   -0.024   -0.584   -0.285   -0.141    0.419  1.99669    0.252   ⋯\n",
       " 1245 │  2005    0.252   -0.024   -0.584   -0.285   -0.141  2.06517    0.422\n",
       " 1246 │  2005    0.422    0.252   -0.024   -0.584   -0.285  1.8885     0.043\n",
       " 1247 │  2005    0.043    0.422    0.252   -0.024   -0.584  1.28581   -0.955\n",
       " 1248 │  2005   -0.955    0.043    0.422    0.252   -0.024  1.54047    0.13    ⋯\n",
       " 1249 │  2005    0.13    -0.955    0.043    0.422    0.252  1.42236   -0.298\n",
       " 1250 │  2005   -0.298    0.13    -0.955    0.043    0.422  1.38254   -0.489\n",
       "\u001b[36m                                                  1 column and 1235 rows omitted\u001b[0m"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "df = copy(Smarket)          # Copiamos el dataframe para no alterar el original"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Veamos si existe algún dato faltante"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 206,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "false"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "any(col -> any(ismissing, col), eachcol(df))"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Vemos que no existe ningún dato faltante\n",
    "\n",
    "En el dtaframe queremos hacer una clasificación sobre `Direction`, la cuál es una variable categórica binaria, ésto lo podemos corroborar de la siguiente manera"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 207,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "2-element Vector{String7}:\n",
       " \"Up\"\n",
       " \"Down\""
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "unique(df[!,\"Direction\"])"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Vamos entonces a transformar éstas dos categorías en valores enteros\n",
    "\n",
    "Primero tomamos las etiquetas de la columna `Direction`"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 208,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "1250-element PooledArrays.PooledVector{String7, UInt32, Vector{UInt32}}:\n",
       " \"Up\"\n",
       " \"Up\"\n",
       " \"Down\"\n",
       " \"Up\"\n",
       " \"Up\"\n",
       " \"Up\"\n",
       " \"Down\"\n",
       " \"Up\"\n",
       " \"Up\"\n",
       " \"Up\"\n",
       " ⋮\n",
       " \"Down\"\n",
       " \"Down\"\n",
       " \"Up\"\n",
       " \"Up\"\n",
       " \"Up\"\n",
       " \"Down\"\n",
       " \"Up\"\n",
       " \"Down\"\n",
       " \"Down\""
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "etiquetas = df[:,9]"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Ahora las codificamos en valores enteros"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 209,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "1250-element Vector{Int64}:\n",
       " 1\n",
       " 1\n",
       " 2\n",
       " 1\n",
       " 1\n",
       " 1\n",
       " 2\n",
       " 1\n",
       " 1\n",
       " 1\n",
       " ⋮\n",
       " 2\n",
       " 2\n",
       " 1\n",
       " 1\n",
       " 1\n",
       " 2\n",
       " 1\n",
       " 2\n",
       " 2"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "et_cod = labelmap(etiquetas)\n",
    "y = labelencode(et_cod, etiquetas)"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Ahora repararemos las demás columnas de la columna categórica"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 210,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "1250×8 Matrix{Float64}:\n",
       " 2001.0   0.381  -0.192  -2.624  -1.055   5.01   1.1913    0.959\n",
       " 2001.0   0.959   0.381  -0.192  -2.624  -1.055  1.2965    1.032\n",
       " 2001.0   1.032   0.959   0.381  -0.192  -2.624  1.4112   -0.623\n",
       " 2001.0  -0.623   1.032   0.959   0.381  -0.192  1.276     0.614\n",
       " 2001.0   0.614  -0.623   1.032   0.959   0.381  1.2057    0.213\n",
       " 2001.0   0.213   0.614  -0.623   1.032   0.959  1.3491    1.392\n",
       " 2001.0   1.392   0.213   0.614  -0.623   1.032  1.445    -0.403\n",
       " 2001.0  -0.403   1.392   0.213   0.614  -0.623  1.4078    0.027\n",
       " 2001.0   0.027  -0.403   1.392   0.213   0.614  1.164     1.303\n",
       " 2001.0   1.303   0.027  -0.403   1.392   0.213  1.2326    0.287\n",
       "    ⋮                                     ⋮               \n",
       " 2005.0  -0.285  -0.141   0.419   0.555   0.084  2.58419  -0.584\n",
       " 2005.0  -0.584  -0.285  -0.141   0.419   0.555  2.20881  -0.024\n",
       " 2005.0  -0.024  -0.584  -0.285  -0.141   0.419  1.99669   0.252\n",
       " 2005.0   0.252  -0.024  -0.584  -0.285  -0.141  2.06517   0.422\n",
       " 2005.0   0.422   0.252  -0.024  -0.584  -0.285  1.8885    0.043\n",
       " 2005.0   0.043   0.422   0.252  -0.024  -0.584  1.28581  -0.955\n",
       " 2005.0  -0.955   0.043   0.422   0.252  -0.024  1.54047   0.13\n",
       " 2005.0   0.13   -0.955   0.043   0.422   0.252  1.42236  -0.298\n",
       " 2005.0  -0.298   0.13   -0.955   0.043   0.422  1.38254  -0.489"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "X = Matrix(df[:,1:8])\n",
    "X"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Crearemos un función que prepare datos de entrenamiento y datos de prueba para que podamos usarlos fácilmente en el resto de este cuaderno."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 211,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "perclass_splits (generic function with 1 method)"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "# La siguiente función selecciona aleatoriamente una fracción específica de elementos de cada clase en el vector y y devuelve los índices seleccionados\n",
    "\n",
    "function perclass_splits(y, at)\n",
    "    uids = unique(y)                                   # Obtenemos los valores únicos (clases) en el vector y\n",
    "    keepids = []                                       # Inicializamos una lista vacía para almacenar los índices seleccionados\n",
    "    for ui in uids\n",
    "        curids = findall(y .== ui)                     # Encontramos todos los índices donde la etiqueta es igual a la clase actual ui\n",
    "        rowids = randsubseq(curids, at)                # Seleccionamos aleatoriamente una fracción at de los índices actuales\n",
    "        push!(keepids, rowids...)                      # Agregamos los índices seleccionados a la lista keepids\n",
    "    end\n",
    "    return keepids                                     # Devolvemos la lista de índices seleccionados\n",
    "end"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Dividimos a y en dos conjuntos, de prueba y entrenamiento"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 212,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "388-element Vector{Any}:\n",
       "    2\n",
       "   10\n",
       "   12\n",
       "   13\n",
       "   15\n",
       "   19\n",
       "   20\n",
       "   21\n",
       "   22\n",
       "   25\n",
       "    ⋮\n",
       " 1228\n",
       " 1229\n",
       " 1234\n",
       " 1236\n",
       " 1237\n",
       " 1239\n",
       " 1242\n",
       " 1244\n",
       " 1250"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "trainids = perclass_splits(y,0.7)        # Tomando el conjunto de entrenamiento con un 70% de cada clase aleatoriamente \n",
    "testids = setdiff(1:length(y),trainids)  # Tomamos el conjunto de índices de Prueba"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Crearemos ahora una función que asignará clases (en nuestro caso son dos clases, 1 y 2) en función de los valores predichos cuando los valores predichos sean continuos."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 213,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "assign_class (generic function with 1 method)"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "assign_class(predictedvalue) = argmin(abs.(predictedvalue .- [1,2])) # Asignamos la clase al valor predicho dependiendo de su cercanía a cada clase"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Antes de generar los métodos de clasificación necesitamos una función de precisión simple que devuelva la relación entre la cantidad de observaciones clasificadas correctamente y la cantidad total de predicciones."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 214,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "findaccuracy (generic function with 1 method)"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "#La siguiente fubción nos da la proporción de predicciones correctas respecto al total de las predicciones\n",
    "findaccuracy(predictedvals,groundtruthvals) = sum(predictedvals.==groundtruthvals)/length(groundtruthvals)"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "## MÉTODOS DE CLASIFICACIÓN"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "## MÉTODO LASSO"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 215,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "Least Squares GLMNet Cross Validation\n",
       "67 models for 8 predictors in 10 folds\n",
       "Best λ 0.022 (mean loss 0.120, std 0.004)"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "path = glmnet(X[trainids,:], y[trainids]) # Tomamos los datos y etiquetas del conjunto de entrenamiento y le ajustamos una regresión\n",
    "cv = glmnetcv(X[trainids,:], y[trainids]) # Realizamos una validación cruzada para hallar el valor óptimo de lambda"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 216,
   "metadata": {},
   "outputs": [],
   "source": [
    "# Elegimos la mejor lambda para predecir\n",
    "mylambda = path.lambda[argmin(cv.meanloss)]                   # Con ésto hallamos el mejor valor de lambda hallando el menor error de predicción medio\n",
    "path = glmnet(X[trainids,:], y[trainids],lambda=[mylambda]);  # Ajustamos el modelo nuevamente con la mejor lambda"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 217,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "388×1 Matrix{Float64}:\n",
       " 1.1786688643074739\n",
       " 1.3985255625820923\n",
       " 1.538997761748157\n",
       " 1.2825474653714546\n",
       " 1.6490736657165228\n",
       " 1.5277835945878409\n",
       " 1.731409261446212\n",
       " 1.6670753551054514\n",
       " 1.8768983248682078\n",
       " 1.547555941949451\n",
       " ⋮\n",
       " 1.482631816284463\n",
       " 1.670911780712928\n",
       " 1.6310719763275943\n",
       " 1.4002962205547735\n",
       " 1.4584328239911493\n",
       " 1.3595710871830993\n",
       " 1.6555660782830217\n",
       " 1.4088544007560675\n",
       " 1.6275306603822315"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "#Vamos ahora a ajustar los datos de prueba al modelo con la lambda óptima y a hacer predicciones\n",
    "q = X[testids,:];                                 # Tomamos los datos de prueba\n",
    "predictions_lasso = GLMNet.predict(path,q)        # Hacemos predicciones sobre los datos de prueba"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Las predicciones nos dan valores entre 0 y 2, vamos ahora a medir qué tan lejos está cada predicción de las clases 1 y 2.\n",
    "\n",
    "Con ésto hacemos predicciones de clase"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 218,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "0.9845360824742269"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "predictions_lasso = assign_class.(predictions_lasso)   # Asignamos una clase 1 o 2 a cada predicción\n",
    "findaccuracy(predictions_lasso,y[testids])             # Calculamos la precisión de las predicciones en comparación con los valores reales"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "#### Matriz de Confusión"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 219,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Matriz de Confusión para LASSO:\n",
      "[202 0; 6 180]\n",
      "Matriz de Confusión Normalizada:\n",
      "[1.0 0.0; 0.03225806451612903 0.967741935483871]\n",
      "Precisión: 0.9845360824742269\n"
     ]
    }
   ],
   "source": [
    "gt = y[testids]                                                 # Tomamos los datos de prueba reales\n",
    "\n",
    "# Convertimos las predicciones a un vector\n",
    "predictions_lasso_vector = vec(predictions_lasso)               # 'vec' convierte cualquier arreglo a un vector de una sola dimensión\n",
    "\n",
    "C = confusmat(2, gt, predictions_lasso_vector)                  # Generamos matriz de confusión\n",
    "\n",
    "println(\"Matriz de Confusión para LASSO:\\n\", C)\n",
    "\n",
    "C_normalized = C ./ sum(C, dims=2)\n",
    "println(\"Matriz de Confusión Normalizada:\\n\", C_normalized)     # Normalizamos la matriz de confusión por clase\n",
    "\n",
    "# Calcular precisión a partir de la matriz de confusión:\n",
    "accuracy = sum(diag(C)) / length(gt)\n",
    "println(\"Precisión: \", accuracy)"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "#### Curva ROC"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 220,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Sensibilidad ROC: 0.9845360824742269\n",
      "Precisión ROC: 1.0\n"
     ]
    }
   ],
   "source": [
    "ROC = MLBase.roc(gt,predictions_lasso_vector)       # Calculamos los componentes de la curva ROC\n",
    "sensibilidad = recall(ROC)                          # Extraemos la Sensibilidad\n",
    "Precision = precision(ROC)                          # Vemos su Precisión\n",
    "\n",
    "println(\"Sensibilidad ROC: \", sensibilidad)\n",
    "println(\"Precisión ROC: \", Precision)"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "### MÉTODO RIDGE\n",
    "\n",
    "Usaremos la misma función pero estableceremos alfa en cero."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 221,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "0.9716494845360825"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "# Elegimos la mejor lambda para predecir\n",
    "path = glmnet(X[trainids,:], y[trainids],alpha=0);\n",
    "cv = glmnetcv(X[trainids,:], y[trainids],alpha=0)\n",
    "mylambda = path.lambda[argmin(cv.meanloss)]\n",
    "path = glmnet(X[trainids,:], y[trainids],alpha=0,lambda=[mylambda]);\n",
    "q = X[testids,:];\n",
    "predictions_ridge = GLMNet.predict(path,q)\n",
    "predictions_ridge = assign_class.(predictions_ridge)\n",
    "findaccuracy(predictions_ridge,y[testids])"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "#### Matriz de Confusión y Curva ROC"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 222,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Matriz de Confusión para RIDGE:\n",
      "[198 4; 7 179]\n",
      "Matriz de Confusión Normalizada:\n",
      "[0.9801980198019802 0.019801980198019802; 0.03763440860215054 0.9623655913978495]\n",
      "Precisión: 0.9716494845360825\n",
      "Sensibilidad ROC: 0.9716494845360825\n",
      "Precisión ROC: 1.0\n"
     ]
    }
   ],
   "source": [
    "gt = y[testids]                                                 # Tomamos los datos de prueba reales\n",
    "\n",
    "# Convertimos las predicciones a un vector\n",
    "predictions_ridge_vector = vec(predictions_ridge)               # 'vec' convierte cualquier arreglo a un vector de una sola dimensión\n",
    "\n",
    "C = confusmat(2, gt, predictions_ridge_vector)                  # Generamos matriz de confusión\n",
    "\n",
    "println(\"Matriz de Confusión para RIDGE:\\n\", C)\n",
    "\n",
    "C_normalized = C ./ sum(C, dims=2)\n",
    "println(\"Matriz de Confusión Normalizada:\\n\", C_normalized)     # Normalizamos la matriz de confusión por clase\n",
    "\n",
    "# Calcular precisión a partir de la matriz de confusión:\n",
    "accuracy = sum(diag(C)) / length(gt)\n",
    "println(\"Precisión: \", accuracy)\n",
    "\n",
    "ROC = MLBase.roc(gt,predictions_ridge_vector)                   # Calculamos los componentes de la curva ROC\n",
    "sensibilidad = recall(ROC)                                      # Extraemos la Sensibilidad\n",
    "Precision = precision(ROC)                                      # Vemos su Precisión\n",
    "\n",
    "println(\"Sensibilidad ROC: \", sensibilidad)\n",
    "println(\"Precisión ROC: \", Precision)"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "### MÉTODO ELASTIC NET (Red elástica)\n",
    "Usaremos la misma función, pero estableceremos el valor alfa en 0,5 (es la combinación de Lasso y Ridge)."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 223,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "0.9922680412371134"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "# Elegimos la mejor lambda para predecir\n",
    "path = glmnet(X[trainids,:], y[trainids],alpha=0.5);\n",
    "cv = glmnetcv(X[trainids,:], y[trainids],alpha=0.5)\n",
    "mylambda = path.lambda[argmin(cv.meanloss)]\n",
    "path = glmnet(X[trainids,:], y[trainids],alpha=0.5,lambda=[mylambda]);\n",
    "q = X[testids,:];\n",
    "predictions_EN = GLMNet.predict(path,q)\n",
    "predictions_EN = assign_class.(predictions_EN)\n",
    "findaccuracy(predictions_EN,y[testids])"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "#### Matriz de Confusión y Curva ROC"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 224,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Matriz de Confusión para ELASTIC NET:\n",
      "[202 0; 3 183]\n",
      "Matriz de Confusión Normalizada:\n",
      "[1.0 0.0; 0.016129032258064516 0.9838709677419355]\n",
      "Precisión: 0.9922680412371134\n",
      "Sensibilidad ROC: 0.9922680412371134\n",
      "Precisión ROC: 1.0\n"
     ]
    }
   ],
   "source": [
    "gt = y[testids]                                                 # Tomamos los datos de prueba reales\n",
    "\n",
    "# Convertimos las predicciones a un vector\n",
    "predictions_EN_vector = vec(predictions_EN)               # 'vec' convierte cualquier arreglo a un vector de una sola dimensión\n",
    "\n",
    "C = confusmat(2, gt, predictions_EN_vector)                  # Generamos matriz de confusión\n",
    "\n",
    "println(\"Matriz de Confusión para ELASTIC NET:\\n\", C)\n",
    "\n",
    "C_normalized = C ./ sum(C, dims=2)\n",
    "println(\"Matriz de Confusión Normalizada:\\n\", C_normalized)     # Normalizamos la matriz de confusión por clase\n",
    "\n",
    "# Calcular precisión a partir de la matriz de confusión:\n",
    "accuracy = sum(diag(C)) / length(gt)\n",
    "println(\"Precisión: \", accuracy)\n",
    "\n",
    "ROC = MLBase.roc(gt,predictions_EN_vector)                   # Calculamos los componentes de la curva ROC\n",
    "sensibilidad = recall(ROC)                                      # Extraemos la Sensibilidad\n",
    "Precision = precision(ROC)                                      # Vemos su Precisión\n",
    "\n",
    "println(\"Sensibilidad ROC: \", sensibilidad)\n",
    "println(\"Precisión ROC: \", Precision)"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "### MÉTODO DECISION TREES (Árboles de decisión)\n",
    "Para ello usaremos el paquete `DecisionTree`"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 225,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "DecisionTreeClassifier\n",
       "max_depth:                2\n",
       "min_samples_leaf:         1\n",
       "min_samples_split:        2\n",
       "min_purity_increase:      0.0\n",
       "pruning_purity_threshold: 1.0\n",
       "n_subfeatures:            0\n",
       "classes:                  [1, 2]\n",
       "root:                     Decision Tree\n",
       "Leaves: 2\n",
       "Depth:  1"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "model = DecisionTreeClassifier(max_depth=2)\n",
    "DecisionTree.fit!(model, X[trainids,:], y[trainids])"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 226,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "1.0"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "q = X[testids,:];\n",
    "predictions_DT = DecisionTree.predict(model, q)\n",
    "findaccuracy(predictions_DT,y[testids])"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "#### Matriz de Confusión y Curva ROC"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 227,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Matriz de Confusión para DECISION TREES:\n",
      "[202 0; 0 186]\n",
      "Matriz de Confusión Normalizada:\n",
      "[1.0 0.0; 0.0 1.0]\n",
      "Precisión: 1.0\n",
      "Sensibilidad ROC: 1.0\n",
      "Precisión ROC: 1.0\n"
     ]
    }
   ],
   "source": [
    "gt = y[testids]                                                 # Tomamos los datos de prueba reales\n",
    "\n",
    "# Convertimos las predicciones a un vector\n",
    "predictions_DT_vector = vec(predictions_DT)               # 'vec' convierte cualquier arreglo a un vector de una sola dimensión\n",
    "\n",
    "C = confusmat(2, gt, predictions_DT_vector)                  # Generamos matriz de confusión\n",
    "\n",
    "println(\"Matriz de Confusión para DECISION TREES:\\n\", C)\n",
    "\n",
    "C_normalized = C ./ sum(C, dims=2)\n",
    "println(\"Matriz de Confusión Normalizada:\\n\", C_normalized)     # Normalizamos la matriz de confusión por clase\n",
    "\n",
    "# Calcular precisión a partir de la matriz de confusión:\n",
    "accuracy = sum(diag(C)) / length(gt)\n",
    "println(\"Precisión: \", accuracy)\n",
    "\n",
    "ROC = MLBase.roc(gt,predictions_DT_vector)                   # Calculamos los componentes de la curva ROC\n",
    "sensibilidad = recall(ROC)                                      # Extraemos la Sensibilidad\n",
    "Precision = precision(ROC)                                      # Vemos su Precisión\n",
    "\n",
    "println(\"Sensibilidad ROC: \", sensibilidad)\n",
    "println(\"Precisión ROC: \", Precision)"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "### MÉTODO RANDOM FOREST (Bosques aleatorios)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 228,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "RandomForestClassifier\n",
       "n_trees:             20\n",
       "n_subfeatures:       -1\n",
       "partial_sampling:    0.7\n",
       "max_depth:           -1\n",
       "min_samples_leaf:    1\n",
       "min_samples_split:   2\n",
       "min_purity_increase: 0.0\n",
       "classes:             [1, 2]\n",
       "ensemble:            Ensemble of Decision Trees\n",
       "Trees:      20\n",
       "Avg Leaves: 9.75\n",
       "Avg Depth:  3.9"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "model = RandomForestClassifier(n_trees=20)\n",
    "DecisionTree.fit!(model, X[trainids,:], y[trainids])"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 229,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "1.0"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "q = X[testids,:];\n",
    "predictions_RF = DecisionTree.predict(model, q)\n",
    "findaccuracy(predictions_RF,y[testids])"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "#### Matriz de Confusión y Curva ROC"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 230,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Matriz de Confusión para RANDOM FOREST:\n",
      "[202 0; 0 186]\n",
      "Matriz de Confusión Normalizada:\n",
      "[1.0 0.0; 0.0 1.0]\n",
      "Precisión: 1.0\n",
      "Sensibilidad ROC: 1.0\n",
      "Precisión ROC: 1.0\n"
     ]
    }
   ],
   "source": [
    "gt = y[testids]                                                 # Tomamos los datos de prueba reales\n",
    "\n",
    "# Convertimos las predicciones a un vector\n",
    "predictions_RF_vector = vec(predictions_RF)               # 'vec' convierte cualquier arreglo a un vector de una sola dimensión\n",
    "\n",
    "C = confusmat(2, gt, predictions_RF_vector)                  # Generamos matriz de confusión\n",
    "\n",
    "println(\"Matriz de Confusión para RANDOM FOREST:\\n\", C)\n",
    "\n",
    "C_normalized = C ./ sum(C, dims=2)\n",
    "println(\"Matriz de Confusión Normalizada:\\n\", C_normalized)     # Normalizamos la matriz de confusión por clase\n",
    "\n",
    "# Calcular precisión a partir de la matriz de confusión:\n",
    "accuracy = sum(diag(C)) / length(gt)\n",
    "println(\"Precisión: \", accuracy)\n",
    "\n",
    "ROC = MLBase.roc(gt,predictions_RF_vector)                   # Calculamos los componentes de la curva ROC\n",
    "sensibilidad = recall(ROC)                                      # Extraemos la Sensibilidad\n",
    "Precision = precision(ROC)                                      # Vemos su Precisión\n",
    "\n",
    "println(\"Sensibilidad ROC: \", sensibilidad)\n",
    "println(\"Precisión ROC: \", Precision)"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "### MÉTODO NEAREST NEIGHBOR (Método de vecino más cercano)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 231,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "KDTree{StaticArraysCore.SVector{8, Float64}, Euclidean, Float64, StaticArraysCore.SVector{8, Float64}}\n",
       "  Number of points: 862\n",
       "  Dimensions: 8\n",
       "  Metric: Euclidean(0.0)\n",
       "  Reordered: true"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "Xtrain = X[trainids,:]\n",
    "ytrain = y[trainids]\n",
    "kdtree = KDTree(Xtrain')"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 232,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "388×8 Matrix{Float64}:\n",
       " 2001.0   0.959   0.381  -0.192  -2.624  -1.055  1.2965    1.032\n",
       " 2001.0   1.303   0.027  -0.403   1.392   0.213  1.2326    0.287\n",
       " 2001.0  -0.498   0.287   1.303   0.027  -0.403  1.258    -0.189\n",
       " 2001.0  -0.189  -0.498   0.287   1.303   0.027  1.098     0.68\n",
       " 2001.0   0.701   0.68   -0.189  -0.498   0.287  1.1498   -0.562\n",
       " 2001.0   0.359  -1.747   0.546  -0.562   0.701  1.013    -0.151\n",
       " 2001.0  -0.151   0.359  -1.747   0.546  -0.562  1.0596   -0.841\n",
       " 2001.0  -0.841  -0.151   0.359  -1.747   0.546  1.1583   -0.623\n",
       " 2001.0  -0.623  -0.841  -0.151   0.359  -1.747  1.1072   -1.334\n",
       " 2001.0  -0.865   1.183  -1.334  -0.623  -0.841  1.0752   -0.218\n",
       "    ⋮                                     ⋮               \n",
       " 2005.0  -0.851   0.209   0.347   0.508   0.527  2.0169    0.002\n",
       " 2005.0   0.002  -0.851   0.209   0.347   0.508  2.26834  -0.636\n",
       " 2005.0   0.128  -0.236   0.032   1.216  -0.636  2.11074  -0.501\n",
       " 2005.0  -0.122  -0.501   0.128  -0.236   0.032  2.1783    0.281\n",
       " 2005.0   0.281  -0.122  -0.501   0.128  -0.236  1.89629   0.084\n",
       " 2005.0   0.555   0.084   0.281  -0.122  -0.501  2.39002   0.419\n",
       " 2005.0  -0.285  -0.141   0.419   0.555   0.084  2.58419  -0.584\n",
       " 2005.0  -0.024  -0.584  -0.285  -0.141   0.419  1.99669   0.252\n",
       " 2005.0  -0.298   0.13   -0.955   0.043   0.422  1.38254  -0.489"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "queries = X[testids,:]"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 233,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "([[38, 79, 152, 552, 48], [69, 76, 73, 82, 7], [8, 483, 2, 493, 532], [74, 53, 3, 51, 84], [493, 522, 531, 14, 449], [550, 162, 555, 500, 36], [551, 52, 480, 490, 528], [497, 470, 476, 100, 491], [480, 498, 490, 553, 471], [54, 503, 37, 521, 620]  …  [859, 845, 822, 396, 793], [377, 860, 430, 446, 433], [823, 862, 786, 799, 836], [839, 818, 829, 812, 374], [413, 392, 431, 391, 422], [444, 393, 389, 820, 406], [395, 420, 437, 445, 432], [433, 859, 845, 860, 396], [799, 431, 422, 444, 860], [819, 817, 372, 835, 816]], [[1.529216139072564, 1.7944593196837866, 2.2213487456948315, 2.263330115117987, 2.3848165044715706], [0.34674809300124504, 1.2439643443443225, 1.4969185849604512, 1.6847354955600597, 1.7482995309728824], [1.077459182521547, 1.161934783023557, 1.2263588381872574, 1.3825440643972255, 1.4561827117501431], [0.971806235830991, 1.0128108214271807, 1.2995381064055027, 1.4984884684240987, 1.6030723626836065], [0.9461766484119126, 1.0270394344911982, 1.050572586735443, 1.1681300270089798, 1.3658959111147526], [1.3129472342786666, 1.4436405508297416, 1.5820647300284525, 1.6134623670851451, 1.6492610345242502], [1.3599914301200577, 1.3868971447082872, 1.5766932517138517, 1.6268711350319052, 1.7013268380884374], [1.3182528171788597, 1.3996531713249536, 1.6331550110139574, 1.7392743199392096, 1.8425634208894954], [1.3126155149166872, 1.4026103379057206, 1.80801457129084, 1.82172903857846, 1.8494758825137463], [1.4429525148112117, 1.4483351166080314, 1.616006200483154, 1.6646386995381308, 1.7362147361429692]  …  [0.7674765508469948, 0.7711259586474832, 0.8369011665065356, 0.914794319177814, 0.9170459945389872], [0.5998166594051887, 0.7743897262360857, 0.7904678503898814, 0.8102490634983789, 0.8316469809360219], [0.967966480876275, 0.9776723174970233, 1.0235423477316414, 1.0401687175165382, 1.0552306254558763], [0.9094512149642772, 0.9336886549594572, 0.9917701661675452, 1.0269405233021045, 1.070270592373723], [0.6935728152112077, 0.7872091859855296, 0.8095934446374922, 0.857606026156533, 0.8942371735171828], [0.5828314116449113, 0.6387139106047403, 0.7596993829140579, 0.7801695385619718, 0.8447474416060696], [0.7944126386205096, 0.8201659649119806, 0.865706029146153, 0.8899080347991022, 0.9380301880003649], [0.8666043113209163, 0.9304708270547766, 0.952033555080912, 1.057631383989715, 1.0889605043802095], [0.7008223971877611, 0.8787245147940279, 0.8940167177407815, 0.9203817199401562, 0.9364848607425535], [0.8294778893376243, 0.8995833658422103, 1.0993739456618028, 1.1333849153751783, 1.1991269205551178]])"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "idxs, dists = knn(kdtree, queries', 5, true)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 234,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "0.8608247422680413"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "c = ytrain[hcat(idxs...)]\n",
    "possible_labels = map(i->counter(c[:,i]),1:size(c,2))\n",
    "predictions_NN = map(i->parse(Int,string(string(argmax(possible_labels[i])))),1:size(c,2))\n",
    "findaccuracy(predictions_NN,y[testids])"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "#### Matriz de Confusión y Curva ROC"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 235,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Matriz de Confusión para NEAREST NEIGHBOR:\n",
      "[177 25; 29 157]\n",
      "Matriz de Confusión Normalizada:\n",
      "[0.8762376237623762 0.12376237623762376; 0.15591397849462366 0.8440860215053764]\n",
      "Precisión: 0.8608247422680413\n",
      "Sensibilidad ROC: 0.8608247422680413\n",
      "Precisión ROC: 1.0\n"
     ]
    }
   ],
   "source": [
    "gt = y[testids]                                                 # Tomamos los datos de prueba reales\n",
    "\n",
    "# Convertimos las predicciones a un vector\n",
    "predictions_NN_vector = vec(predictions_NN)               # 'vec' convierte cualquier arreglo a un vector de una sola dimensión\n",
    "\n",
    "C = confusmat(2, gt, predictions_NN_vector)                  # Generamos matriz de confusión\n",
    "\n",
    "println(\"Matriz de Confusión para NEAREST NEIGHBOR:\\n\", C)\n",
    "\n",
    "C_normalized = C ./ sum(C, dims=2)\n",
    "println(\"Matriz de Confusión Normalizada:\\n\", C_normalized)     # Normalizamos la matriz de confusión por clase\n",
    "\n",
    "# Calcular precisión a partir de la matriz de confusión:\n",
    "accuracy = sum(diag(C)) / length(gt)\n",
    "println(\"Precisión: \", accuracy)\n",
    "\n",
    "ROC = MLBase.roc(gt,predictions_NN_vector)                   # Calculamos los componentes de la curva ROC\n",
    "sensibilidad = recall(ROC)                                      # Extraemos la Sensibilidad\n",
    "Precision = precision(ROC)                                      # Vemos su Precisión\n",
    "\n",
    "println(\"Sensibilidad ROC: \", sensibilidad)\n",
    "println(\"Precisión ROC: \", Precision)"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "### MÉTODO SUPPORT VECTOR MACHINES (Máquinas de vectores de soporte)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 236,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "862-element Vector{Int64}:\n",
       " 1\n",
       " 1\n",
       " 1\n",
       " 1\n",
       " 1\n",
       " 1\n",
       " 1\n",
       " 1\n",
       " 1\n",
       " 1\n",
       " ⋮\n",
       " 2\n",
       " 2\n",
       " 2\n",
       " 2\n",
       " 2\n",
       " 2\n",
       " 2\n",
       " 2\n",
       " 2"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "Xtrain = X[trainids,:]\n",
    "ytrain = y[trainids]"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 237,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "LIBSVM.SVM{Int64, LIBSVM.Kernel.KERNEL}(SVC, LIBSVM.Kernel.RadialBasis, nothing, 8, 862, 2, [1, 2], Int32[1, 2], Float64[], Int32[], LIBSVM.SupportVectors{Vector{Int64}, Matrix{Float64}}(337, Int32[174, 163], [1, 1, 1, 1, 1, 1, 1, 1, 1, 1  …  2, 2, 2, 2, 2, 2, 2, 2, 2, 2], [2001.0 2001.0 … 2005.0 2005.0; 0.381 0.614 … -0.141 -0.584; … ; 1.1913 1.2057 … 2.18059 2.2088099999999997; 0.9590000000000001 0.213 … -0.285 -0.024], Int32[1, 3, 5, 12, 14, 15, 16, 18, 19, 20  …  841, 848, 851, 852, 854, 856, 857, 858, 859, 860], LIBSVM.SVMNode[LIBSVM.SVMNode(1, 2001.0), LIBSVM.SVMNode(1, 2001.0), LIBSVM.SVMNode(1, 2001.0), LIBSVM.SVMNode(1, 2001.0), LIBSVM.SVMNode(1, 2001.0), LIBSVM.SVMNode(1, 2001.0), LIBSVM.SVMNode(1, 2001.0), LIBSVM.SVMNode(1, 2001.0), LIBSVM.SVMNode(1, 2001.0), LIBSVM.SVMNode(1, 2001.0)  …  LIBSVM.SVMNode(1, 2005.0), LIBSVM.SVMNode(1, 2005.0), LIBSVM.SVMNode(1, 2005.0), LIBSVM.SVMNode(1, 2005.0), LIBSVM.SVMNode(1, 2005.0), LIBSVM.SVMNode(1, 2005.0), LIBSVM.SVMNode(1, 2005.0), LIBSVM.SVMNode(1, 2005.0), LIBSVM.SVMNode(1, 2005.0), LIBSVM.SVMNode(1, 2005.0)]), 0.0, [0.7510338443402249; 1.0; … ; -1.0; -1.0;;], Float64[], Float64[], [-0.08059715571610791], 3, 0.125, 200.0, 0.001, 1.0, 0.5, 0.1, true, false)"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "model = svmtrain(Xtrain', ytrain)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 238,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "0.9536082474226805"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "predictions_SVM, decision_values = svmpredict(model, X[testids,:]')\n",
    "findaccuracy(predictions_SVM,y[testids])"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "#### Matriz de Confusión y Curva ROC"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 239,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Matriz de Confusión para SUPPORT VECTOR MACHINES:\n",
      "[199 3; 15 171]\n",
      "Matriz de Confusión Normalizada:\n",
      "[0.9851485148514851 0.01485148514851485; 0.08064516129032258 0.9193548387096774]\n",
      "Precisión: 0.9536082474226805\n",
      "Sensibilidad ROC: 0.9536082474226805\n",
      "Precisión ROC: 1.0\n"
     ]
    }
   ],
   "source": [
    "gt = y[testids]                                                 # Tomamos los datos de prueba reales\n",
    "\n",
    "# Convertimos las predicciones a un vector\n",
    "predictions_SVM_vector = vec(predictions_SVM)               # 'vec' convierte cualquier arreglo a un vector de una sola dimensión\n",
    "\n",
    "C = confusmat(2, gt, predictions_SVM_vector)                  # Generamos matriz de confusión\n",
    "\n",
    "println(\"Matriz de Confusión para SUPPORT VECTOR MACHINES:\\n\", C)\n",
    "\n",
    "C_normalized = C ./ sum(C, dims=2)\n",
    "println(\"Matriz de Confusión Normalizada:\\n\", C_normalized)     # Normalizamos la matriz de confusión por clase\n",
    "\n",
    "# Calcular precisión a partir de la matriz de confusión:\n",
    "accuracy = sum(diag(C)) / length(gt)\n",
    "println(\"Precisión: \", accuracy)\n",
    "\n",
    "ROC = MLBase.roc(gt,predictions_SVM_vector)                   # Calculamos los componentes de la curva ROC\n",
    "sensibilidad = recall(ROC)                                      # Extraemos la Sensibilidad\n",
    "Precision = precision(ROC)                                      # Vemos su Precisión\n",
    "\n",
    "println(\"Sensibilidad ROC: \", sensibilidad)\n",
    "println(\"Precisión ROC: \", Precision)"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Veamos los resultados de todos los clasificadores"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 240,
   "metadata": {},
   "outputs": [
    {
     "data": {
      "text/plain": [
       "7×2 Matrix{Any}:\n",
       " \"lasso\"  0.984536\n",
       " \"ridge\"  0.971649\n",
       " \"EN\"     0.992268\n",
       " \"DT\"     1.0\n",
       " \"RF\"     1.0\n",
       " \"kNN\"    0.860825\n",
       " \"SVM\"    0.953608"
      ]
     },
     "metadata": {},
     "output_type": "display_data"
    }
   ],
   "source": [
    "overall_accuracies = zeros(7)\n",
    "methods = [\"lasso\",\"ridge\",\"EN\", \"DT\", \"RF\",\"kNN\", \"SVM\"]\n",
    "ytest = y[testids]\n",
    "overall_accuracies[1] = findaccuracy(predictions_lasso,ytest)\n",
    "overall_accuracies[2] = findaccuracy(predictions_ridge,ytest)\n",
    "overall_accuracies[3] = findaccuracy(predictions_EN,ytest)\n",
    "overall_accuracies[4] = findaccuracy(predictions_DT,ytest)\n",
    "overall_accuracies[5] = findaccuracy(predictions_RF,ytest)\n",
    "overall_accuracies[6] = findaccuracy(predictions_NN,ytest)\n",
    "overall_accuracies[7] = findaccuracy(predictions_SVM,ytest)\n",
    "hcat(methods, overall_accuracies)"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "NOTA:\n",
    "\n",
    "Por más que intenté no pude generar el gráfico de la curva ROC ni calcular AUC. Intenté con MLBase, con Flux, con EvalMetrics y otros, hasta intenté hacerlo a mano pero nunca entendí bien cómo manejar los umbrales  :("
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Julia 1.11.1",
   "language": "julia",
   "name": "julia-1.11"
  },
  "language_info": {
   "file_extension": ".jl",
   "mimetype": "application/julia",
   "name": "julia",
   "version": "1.11.1"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 2
}
