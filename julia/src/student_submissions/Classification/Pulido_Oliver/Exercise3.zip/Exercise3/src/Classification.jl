# ------------------------------------------------------------------ PAQUETES ------------------------------------------------------------------

using Pkg
#Pkg.add("GLMNet")
#Pkg.add("RDatasets")
#Pkg.add("MLBase")
#Pkg.add("Plots")
#Pkg.add("DecisionTree")
#Pkg.add("Distances")
#Pkg.add("NearestNeighbors")
#Pkg.add("Random")
#Pkg.add("LinearAlgebra")
#Pkg.add("DataStructures")
#Pkg.add("LIBSVM")
#Pkg.add("MLBase")
#Pkg.add("DataFrames")
#Pkg.add("CSV")
#Pkg.add("StatsBase")
#Pkg.add("Statistics")

using GLMNet
using RDatasets
using MLBase
using Plots
using DecisionTree
using Distances
using NearestNeighbors
using Random
using LinearAlgebra
using DataStructures
using LIBSVM
using MLBase
using CSV
using DataFrames
using StatsBase
using Statistics


# ------------------------------------------------------------------- DATOS --------------------------------------------------------------------

Smarket = CSV.read("Smarket.csv", DataFrame)

df = copy(Smarket)                                 # Copiamos el dataframe para no alterar el original

#any(col -> any(ismissing, col), eachcol(df))      # Verificar si existen datos faltantes
#unique(df[!,"Direction"])                         # Ver las clases de la variable categórica

# Transformación de etiquetas:

etiquetas = df[:,9]                                # Tomamos las etiquetas
et_cod = labelmap(etiquetas)                       # Las codificamos a enteros
y = labelencode(et_cod, etiquetas)

X = Matrix(df[:,1:8])                              # Separamos las características de las clases

# Selección de datos de Entrenamiento y Prueba:

# La siguiente función selecciona aleatoriamente una fracción específica de elementos de cada clase en el vector y y devuelve los índices seleccionados

function perclass_splits(y, at)
    uids = unique(y)                                   # Obtenemos los valores únicos (clases) en el vector y
    keepids = []                                       # Inicializamos una lista vacía para almacenar los índices seleccionados
    for ui in uids
        curids = findall(y .== ui)                     # Encontramos todos los índices donde la etiqueta es igual a la clase actual ui
        rowids = randsubseq(curids, at)                # Seleccionamos aleatoriamente una fracción at de los índices actuales
        push!(keepids, rowids...)                      # Agregamos los índices seleccionados a la lista keepids
    end
    return keepids                                     # Devolvemos la lista de índices seleccionados
end

trainids = perclass_splits(y,0.7)        # Tomando el conjunto de entrenamiento con un 70% de cada clase aleatoriamente 
testids = setdiff(1:length(y),trainids)  # Tomamos el conjunto de índices de Prueba

#Crearemos ahora una función que asignará clases (en nuestro caso son dos clases, 1 y 2) 
#en función de los valores predichos cuando los valores predichos sean continuos.


assign_class(predictedvalue) = argmin(abs.(predictedvalue .- [1,2])) # Asignamos la clase al valor predicho dependiendo de su cercanía a cada clase

#La siguiente fubción nos da la proporción de predicciones correctas respecto al total de las predicciones
findaccuracy(predictedvals,groundtruthvals) = sum(predictedvals.==groundtruthvals)/length(groundtruthvals)


# ---------------------------------------------------------- MÉTODOS DE CLASIFICACIÓN ----------------------------------------------------------

# ------------------------------------------------------------------- Lasso --------------------------------------------------------------------

path = glmnet(X[trainids,:], y[trainids]) # Tomamos los datos y etiquetas del conjunto de entrenamiento y le ajustamos una regresión
cv = glmnetcv(X[trainids,:], y[trainids]) # Realizamos una validación cruzada para hallar el valor óptimo de lambda

# Elegimos la mejor lambda para predecir
mylambda = path.lambda[argmin(cv.meanloss)]                   # Con ésto hallamos el mejor valor de lambda hallando el menor error de predicción medio
path = glmnet(X[trainids,:], y[trainids],lambda=[mylambda]);  # Ajustamos el modelo nuevamente con la mejor lambda

#Vamos ahora a ajustar los datos de prueba al modelo con la lambda óptima y a hacer predicciones
q = X[testids,:];                                 # Tomamos los datos de prueba
predictions_lasso = GLMNet.predict(path,q)        # Hacemos predicciones sobre los datos de prueba

predictions_lasso = assign_class.(predictions_lasso)   # Asignamos una clase 1 o 2 a cada predicción
findaccuracy(predictions_lasso,y[testids])             # Calculamos la precisión de las predicciones en comparación con los valores reales



# MATRIZ DE CONFUSIÓN Y CURVA ROC:

gt = y[testids]                                                 # Tomamos los datos de prueba reales

# Convertimos las predicciones a un vector
predictions_lasso_vector = vec(predictions_lasso)               # 'vec' convierte cualquier arreglo a un vector de una sola dimensión

C = confusmat(2, gt, predictions_lasso_vector)                  # Generamos matriz de confusión

println("Matriz de Confusión para LASSO:\n", C)

C_normalized = C ./ sum(C, dims=2)
println("Matriz de Confusión Normalizada:\n", C_normalized)     # Normalizamos la matriz de confusión por clase

# Calcular precisión a partir de la matriz de confusión:
accuracy = sum(diag(C)) / length(gt)
println("Precisión: ", accuracy)

ROC = MLBase.roc(gt,predictions_lasso_vector)       # Calculamos los componentes de la curva ROC
sensibilidad = recall(ROC)                          # Extraemos la Sensibilidad
Precision = precision(ROC)                          # Vemos su Precisión

println("Sensibilidad ROC: ", sensibilidad)
println("Precisión ROC: ", Precision)


# ------------------------------------------------------------------- RIDGE --------------------------------------------------------------------

# Elegimos la mejor lambda para predecir
path = glmnet(X[trainids,:], y[trainids],alpha=0);
cv = glmnetcv(X[trainids,:], y[trainids],alpha=0)
mylambda = path.lambda[argmin(cv.meanloss)]
path = glmnet(X[trainids,:], y[trainids],alpha=0,lambda=[mylambda]);
q = X[testids,:];
predictions_ridge = GLMNet.predict(path,q)
predictions_ridge = assign_class.(predictions_ridge)
findaccuracy(predictions_ridge,y[testids])



# MATRIZ DE CONFUSIÓN Y CURVA ROC:

gt = y[testids]                                                 # Tomamos los datos de prueba reales

# Convertimos las predicciones a un vector
predictions_ridge_vector = vec(predictions_ridge)               # 'vec' convierte cualquier arreglo a un vector de una sola dimensión

C = confusmat(2, gt, predictions_ridge_vector)                  # Generamos matriz de confusión

println("Matriz de Confusión para RIDGE:\n", C)

C_normalized = C ./ sum(C, dims=2)
println("Matriz de Confusión Normalizada:\n", C_normalized)     # Normalizamos la matriz de confusión por clase

# Calcular precisión a partir de la matriz de confusión:
accuracy = sum(diag(C)) / length(gt)
println("Precisión: ", accuracy)

ROC = MLBase.roc(gt,predictions_ridge_vector)                   # Calculamos los componentes de la curva ROC
sensibilidad = recall(ROC)                                      # Extraemos la Sensibilidad
Precision = precision(ROC)                                      # Vemos su Precisión

println("Sensibilidad ROC: ", sensibilidad)
println("Precisión ROC: ", Precision)

# ---------------------------------------------------------------- ELASTIC NET ----------------------------------------------------------------

# Elegimos la mejor lambda para predecir
path = glmnet(X[trainids,:], y[trainids],alpha=0.5);
cv = glmnetcv(X[trainids,:], y[trainids],alpha=0.5)
mylambda = path.lambda[argmin(cv.meanloss)]
path = glmnet(X[trainids,:], y[trainids],alpha=0.5,lambda=[mylambda]);
q = X[testids,:];
predictions_EN = GLMNet.predict(path,q)
predictions_EN = assign_class.(predictions_EN)
findaccuracy(predictions_EN,y[testids])


# MATRIZ DE CONFUSIÓN Y CURVA ROC:

gt = y[testids]                                                 # Tomamos los datos de prueba reales

# Convertimos las predicciones a un vector
predictions_EN_vector = vec(predictions_EN)               # 'vec' convierte cualquier arreglo a un vector de una sola dimensión

C = confusmat(2, gt, predictions_EN_vector)                  # Generamos matriz de confusión

println("Matriz de Confusión para ELASTIC NET:\n", C)

C_normalized = C ./ sum(C, dims=2)
println("Matriz de Confusión Normalizada:\n", C_normalized)     # Normalizamos la matriz de confusión por clase

# Calcular precisión a partir de la matriz de confusión:
accuracy = sum(diag(C)) / length(gt)
println("Precisión: ", accuracy)

ROC = MLBase.roc(gt,predictions_EN_vector)                   # Calculamos los componentes de la curva ROC
sensibilidad = recall(ROC)                                      # Extraemos la Sensibilidad
Precision = precision(ROC)                                      # Vemos su Precisión

println("Sensibilidad ROC: ", sensibilidad)
println("Precisión ROC: ", Precision)

# --------------------------------------------------------------- DECISION TREES ---------------------------------------------------------------

model = DecisionTreeClassifier(max_depth=2)
DecisionTree.fit!(model, X[trainids,:], y[trainids])
q = X[testids,:];
predictions_DT = DecisionTree.predict(model, q)
findaccuracy(predictions_DT,y[testids])


# MATRIZ DE CONFUSIÓN Y CURVA ROC:

gt = y[testids]                                                 # Tomamos los datos de prueba reales

# Convertimos las predicciones a un vector
predictions_DT_vector = vec(predictions_DT)               # 'vec' convierte cualquier arreglo a un vector de una sola dimensión

C = confusmat(2, gt, predictions_DT_vector)                  # Generamos matriz de confusión

println("Matriz de Confusión para DECISION TREES:\n", C)

C_normalized = C ./ sum(C, dims=2)
println("Matriz de Confusión Normalizada:\n", C_normalized)     # Normalizamos la matriz de confusión por clase

# Calcular precisión a partir de la matriz de confusión:
accuracy = sum(diag(C)) / length(gt)
println("Precisión: ", accuracy)

ROC = MLBase.roc(gt,predictions_DT_vector)                   # Calculamos los componentes de la curva ROC
sensibilidad = recall(ROC)                                      # Extraemos la Sensibilidad
Precision = precision(ROC)                                      # Vemos su Precisión

println("Sensibilidad ROC: ", sensibilidad)
println("Precisión ROC: ", Precision)

# --------------------------------------------------------------- RANDOM FOREST ----------------------------------------------------------------

model = RandomForestClassifier(n_trees=20)
DecisionTree.fit!(model, X[trainids,:], y[trainids])
q = X[testids,:];
predictions_RF = DecisionTree.predict(model, q)
findaccuracy(predictions_RF,y[testids])


# MATRIZ DE CONFUSIÓN Y CURVA ROC:

gt = y[testids]                                                 # Tomamos los datos de prueba reales

# Convertimos las predicciones a un vector
predictions_RF_vector = vec(predictions_RF)               # 'vec' convierte cualquier arreglo a un vector de una sola dimensión

C = confusmat(2, gt, predictions_RF_vector)                  # Generamos matriz de confusión

println("Matriz de Confusión para RANDOM FOREST:\n", C)

C_normalized = C ./ sum(C, dims=2)
println("Matriz de Confusión Normalizada:\n", C_normalized)     # Normalizamos la matriz de confusión por clase

# Calcular precisión a partir de la matriz de confusión:
accuracy = sum(diag(C)) / length(gt)
println("Precisión: ", accuracy)

ROC = MLBase.roc(gt,predictions_RF_vector)                   # Calculamos los componentes de la curva ROC
sensibilidad = recall(ROC)                                      # Extraemos la Sensibilidad
Precision = precision(ROC)                                      # Vemos su Precisión

println("Sensibilidad ROC: ", sensibilidad)
println("Precisión ROC: ", Precision)

# -------------------------------------------------------------- NEAREST NEIGHBORS -------------------------------------------------------------

Xtrain = X[trainids,:]
ytrain = y[trainids]
kdtree = KDTree(Xtrain')
queries = X[testids,:]
idxs, dists = knn(kdtree, queries', 5, true)
c = ytrain[hcat(idxs...)]
possible_labels = map(i->counter(c[:,i]),1:size(c,2))
predictions_NN = map(i->parse(Int,string(string(argmax(possible_labels[i])))),1:size(c,2))
findaccuracy(predictions_NN,y[testids])


# MATRIZ DE CONFUSIÓN Y CURVA ROC:

gt = y[testids]                                                 # Tomamos los datos de prueba reales

# Convertimos las predicciones a un vector
predictions_NN_vector = vec(predictions_NN)               # 'vec' convierte cualquier arreglo a un vector de una sola dimensión

C = confusmat(2, gt, predictions_NN_vector)                  # Generamos matriz de confusión

println("Matriz de Confusión para NEAREST NEIGHBOR:\n", C)

C_normalized = C ./ sum(C, dims=2)
println("Matriz de Confusión Normalizada:\n", C_normalized)     # Normalizamos la matriz de confusión por clase

# Calcular precisión a partir de la matriz de confusión:
accuracy = sum(diag(C)) / length(gt)
println("Precisión: ", accuracy)

ROC = MLBase.roc(gt,predictions_NN_vector)                   # Calculamos los componentes de la curva ROC
sensibilidad = recall(ROC)                                      # Extraemos la Sensibilidad
Precision = precision(ROC)                                      # Vemos su Precisión

println("Sensibilidad ROC: ", sensibilidad)
println("Precisión ROC: ", Precision)

# ------------------------------------------------------------ SUPPORT VECTOR MACHINES ---------------------------------------------------------

Xtrain = X[trainids,:]
ytrain = y[trainids]
model = svmtrain(Xtrain', ytrain)
predictions_SVM, decision_values = svmpredict(model, X[testids,:]')
findaccuracy(predictions_SVM,y[testids])


# MATRIZ DE CONFUSIÓN Y CURVA ROC:

gt = y[testids]                                                 # Tomamos los datos de prueba reales

# Convertimos las predicciones a un vector
predictions_SVM_vector = vec(predictions_SVM)               # 'vec' convierte cualquier arreglo a un vector de una sola dimensión

C = confusmat(2, gt, predictions_SVM_vector)                  # Generamos matriz de confusión

println("Matriz de Confusión para SUPPORT VECTOR MACHINES:\n", C)

C_normalized = C ./ sum(C, dims=2)
println("Matriz de Confusión Normalizada:\n", C_normalized)     # Normalizamos la matriz de confusión por clase

# Calcular precisión a partir de la matriz de confusión:
accuracy = sum(diag(C)) / length(gt)
println("Precisión: ", accuracy)

ROC = MLBase.roc(gt,predictions_SVM_vector)                   # Calculamos los componentes de la curva ROC
sensibilidad = recall(ROC)                                      # Extraemos la Sensibilidad
Precision = precision(ROC)                                      # Vemos su Precisión

println("Sensibilidad ROC: ", sensibilidad)
println("Precisión ROC: ", Precision)

# ----------------------------------------------------- RESULTADOS DE TODOS LOS CLASIFICADORES -------------------------------------------------

overall_accuracies = zeros(7)
methods = ["lasso","ridge","EN", "DT", "RF","kNN", "SVM"]
ytest = y[testids]
overall_accuracies[1] = findaccuracy(predictions_lasso,ytest)
overall_accuracies[2] = findaccuracy(predictions_ridge,ytest)
overall_accuracies[3] = findaccuracy(predictions_EN,ytest)
overall_accuracies[4] = findaccuracy(predictions_DT,ytest)
overall_accuracies[5] = findaccuracy(predictions_RF,ytest)
overall_accuracies[6] = findaccuracy(predictions_NN,ytest)
overall_accuracies[7] = findaccuracy(predictions_SVM,ytest)
hcat(methods, overall_accuracies)

# NOTA:

#Por más que intenté no pude generar el gráfico de la curva ROC ni calcular AUC. 
#Intenté con MLBase, con Flux, con EvalMetrics y otros, hasta intenté hacerlo a mano pero nunca entendí bien cómo manejar los umbrales  :(
