#=
Produce the plot shown below in Julia. You may use the Plots or the Makie Package.
Submit your project following the submission guidelines
Be sure that you include the code and the figure(s)

=#

#= 
import networkx as nx
import matplotlib.pyplot as plt
import numpy as np

G = nx. random_geometric_graph (200, 0.125)
# position is stored as node attribute data for random_geometric_graph
pos = nx. get_node_attributes (G, 'pos')

# find node near center (0.5,0.5)

dmin=1
ncenter=0
for n in pos: 
  x,y=pos[n]
  d=(x-0.5)**2+(y-0.5)**2
  if d<dmin:
    ncenter=n
    dmin=d

    # color by path length from node near center
p=nx.single_source_shortest_path_length (G, ncenter)


# p is a dictionary with numeric data for each node 
# Each value must be numeric

node_color = np.array(list(p.values()))  # convert to a numpy array  
nodelist = list(set(p.keys()).intersection(G.nodes()))  #  set the keys on G 

plt.figure (figsize=(8,8))
nx.draw_networkx_edges(G, pos,nodelist=[ncenter],alpha=0.4)
nx.draw_networkx_nodes(
    G, pos, 
    nodelist=nodelist, 
    node_size=80, 
    node_color=node_color, 
    cmap=plt.cm.Reds_r,
    edgecolors='black',  
    linewidths=0.5         
)
plt.xlim(-0.05,1.05) 
plt.ylim(-0.05,1.05) 
plt.axis('off')
plt.savefig('random_geometric_graph.png')
plt.show()

=#


using Pkg
#Pkg.add("Makie")
Pkg.add("LightGraphs")
Pkg.add("Random")
Pkg.add("GraphPlot")

#using Makie
using LightGraphs
using Random
using GraphPlot
using Plots
using Graphs
using LinearAlgebra
using Colors
using SparseArrays
using Random
using GraphMakie
using FileIO

# Número de nodos y el radio de conexión
n = 200
radius = 0.125

function GeometricRandomGraph(n,radius)
    points = rand(MersenneTwister(9), Float32, (2, 200))
    #points = rand(2, n) # Aleatory  2D positions for the nodes on the given interval
    G = Graphs.SimpleGraphs.SimpleGraph(n) # Create empty graph with n nodes

    for i in 1:n
        for j in i+1:n
            dist = norm(points[:, i] - points[:, j])  # Euclidean distance
            if dist < radius
                GraphPlot.add_edge!(G, i, j)
            end
        end
    end

    return G,points
end

G,points = GeometricRandomGraph(n,radius)

gplot(G)

points

#G
#typeof(G)

#gplot(G)

#N = SimpleGraph(80) 

# Encontrar el nodo más cercano al centro (0.5, 0.5)

#points = rand(2, n)
points = rand(MersenneTwister(9), Float64, (2, 200))

function NodeNearCenter(points::Matrix{Float64})
    dmin = Inf
    ncenter = 0.0
    for i in 1:n
        x, y = points[:, i]  #size(points, 2)
        d = (x - 0.5)^2 + (y - 0.5)^2  #d = norm(pos[:,i] .- center)
        if d < dmin
            ncenter = i
            dmin = d
        end
    end
    return ncenter
end 
#ncenter

graph, = Graphs.SimpleGraphs.euclidean_graph(points; cutoff=0.125)

nodecenter = NodeNearCenter(points)

G = graph

distances = GraphPlot.dijkstra_shortest_paths(G, nodecenter).dists

# Colorear los nodos según su distancia al nodo central
#node_color = [distances[i] for i in 1:GraphPlot.nv(G)]  # Obtener las distancias de todos los nodos
#node_size = 80
nodelist = 1:GraphPlot.nv(G)

points
distances

g = graph
nodesize = [Graphs.outdegree(g, v) for v in Graphs.vertices(g)]
#gplot(g, nodesize=nodesize)

# stick out large degree nodes
alphas = nodesize/maximum(nodesize)
nodefillc = [RGBA(1.0, 0.2, 0.2, i)  for i in alphas]
graphplot(g, nodefillc=nodefillc,NODESIZE=0.017, nodestrokelw = 50)


function DrawGraph(points)

    graph, = Graphs.SimpleGraphs.euclidean_graph(points; cutoff=0.125)
    centerNode = NodeNearCenter(points)
    g = graph
    nodesize = [Graphs.outdegree(g, v) for v in Graphs.vertices(g)]
    alphas = nodesize/maximum(nodesize)
    nodefillc = [RGBA(1.0, 0.2, 0.2, i)  for i in alphas]
    gplot(g , layout= spring_layout, nodefillc=nodefillc,NODESIZE=0.017, nodestrokelw = 50)

end  
points
graph = DrawGraph(points)
typeof(graph)
#save(graph,"Exercise6/fig/RandomGeoGraph.png" )
#savefig(graph, "Exercise6/fig/RandomGeoGraph.png")