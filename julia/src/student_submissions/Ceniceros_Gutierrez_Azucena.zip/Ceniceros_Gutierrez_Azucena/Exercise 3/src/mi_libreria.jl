#counts number of missing data in a given col (Column).
#column is String

module CleaningLibrary

using Statistics
using StatsBase
using DataFrames

function count_missing(dataframe,column)
   missing_count= count(x -> ismissing(x), dataframe[!, column])
    return missing_count
end


#finds missing percentage of each column
#column is String
function dataMissingPercentage(dataframe, column)
    missing_per=count_missing(dataframe, column)*100/nrow(dataframe)
    return missing_per
end

#delete all the columns which have missing percent less than given threshold
#threshold is a number between 0-100 that represents the missing % that we can accept
function deleteColumns(dataframe,threshold)
    newdf=dataframe
    deleted_cols=0
    for col in names(newdf)
        dataMissingPercentage(dataframe, "$col")
        if dataMissingPercentage(dataframe, "$col") > threshold
            col_symbol = Symbol("$col")
               newdf = select(newdf,Not([col_symbol]))
            deleted_cols+=1
        end
            
    end
    println("$deleted_cols columns were deleted from df")
    return newdf
end

#Deletes non numeric columns
function delete_nonnum_cols(dataframe)
    newdf=dataframe
    deleted_cols=0
    for col in names(newdf)
            col_values = newdf[!, col]
     if all(x -> isa(x, Union{Missing, Number}), col_values)==false  
            col_symbol = Symbol("$col")
               newdf = select(newdf,Not([col_symbol]))
            deleted_cols+=1
        end
    end
    println("$deleted_cols columns deleted from df for containing non numeric values")
    return newdf
end

#Deletes columns that cointain IDs
function delete_IDCols(dataframe)
    newdf=dataframe
    deleted_cols=0
    for col in names(newdf)
            col_values = newdf[!, col]
     if  all(x -> x == 1, diff(col_values))
            col_symbol = Symbol("$col")
               newdf = select(newdf,Not([col_symbol]))
            deleted_cols+=1
        end
    end
    println("$deleted_cols columns deleted from df for containing ID values")
    return newdf
end

#Calculates the percentage of rows that contain missing values
function missing_rows_percentage(dataframe)
    missing_rows = count(row -> any(ismissing, row), eachrow(dataframe))
    missing_percentage = (missing_rows / nrow(dataframe)) * 100
    
    return missing_percentage
end

#Drops the rows with missing values
function delete_incomplete_rows(dataframe)
    newdf = dropmissing(dataframe)
    loss_percent=nrow(newdf)*100/nrow(dataframe)
    println("$loss_percent % of rows were saved after deleting the rows with missing values")
    return newdf
end

# Deletes rows that contain the same value across the rows or have really low variance
function delete_conscols(dataframe)
    newdf=dataframe
        deleted_cols=0
    for col in names(newdf)
            col_values = newdf[!, col]
            variance = var(col_values) 
            unique_values = length(unique(col_values))  
         if variance < 1e-3 || unique_values <= 2
            col_symbol = Symbol("$col")
               newdf = select(newdf,Not([col_symbol]))
            deleted_cols+=1
        end
    end
    println("$deleted_cols columns deleted from df for containing constant values")
    return newdf
end

# Converts all rows to float64
function int_to_float(dataframe)
        newdf=dataframe
        converted_cols=0
    for col in names(newdf)    
        if all(x -> isa(x, Float64), newdf[!, col])==false 
            println("$col will be float64")
            newdf[!, col]=Float64.(newdf[!, col])
            converted_cols+=1         
        end 
    end
        println("$converted_cols columns were converted to float64")
        return newdf
end

# Deletes all the outliers from the numerical columns
function removeOutliersIQR(dataframe)
    newdf=dataframe
        for col in names(newdf)
            col_values=newdf[!,col]
            colv_sort=sort(col_values)
            Q1=quantile(colv_sort,0.25)
            Q3=quantile(colv_sort,0.75)
            IQR=Q3-Q1
            lim_inf=Q1-1.5*IQR
            lim_sup=Q3+1.5*IQR
            println("$col -> limite inferior: $lim_inf limite superior: $lim_sup")
            filter_vector=(lim_inf .<= col_values) .& (col_values .<= lim_sup) #boolean vector
            newdf = newdf[filter_vector, :]
        end
    return newdf
end


export count_missing, dataMissingPercentage, deleteColumns, delete_nonnum_cols, delete_IDCols, missing_rows_percentage, delete_incomplete_rows, delete_conscols, int_to_float, removeOutliersIQR

end