from pdfminer.high_level import extract_text


pdf_path = "/Users/rodrigozeferino/Downloads/Los-miserables.pdf"
text = extract_text(pdf_path)
with open("/Users/rodrigozeferino/Downloads/los-miserables.txt", "w", encoding="utf-8") as f:
    f.write(text)

import re
import unicodedata
text = text.lower()
text = re.sub(r"\s+", " ", text).strip()
text = re.sub(r"[^\w\s]", "", text)
def remove_accents(text):
    return ''.join(c for c in unicodedata.normalize('NFKD', text) if not unicodedata.combining(c))
text = remove_accents(text)



words = text.split()
print(f"🔹 Total de caracteres: {len(text)}")
print(f"🔹 Total de palabras: {len(words)}")
print(f"🔹 Primeras 20 palabras: {words[:20]}")

from collections import Counter
import pandas as pd

word_counts = Counter(words)
df_vocab = pd.DataFrame(word_counts.items(), columns=["Palabra", "Frecuencia"])
df_vocab = df_vocab.sort_values(by="Frecuencia", ascending=False)

df_vocab.to_csv("/Users/rodrigozeferino/Downloads/vocabulario.csv", index=False, encoding="utf-8")
print(df_vocab.head(10))  

import fastparquet 
df_vocab.to_parquet("/Users/rodrigozeferino/Downloads/vocabulario.parquet", index=False)

total_palabras = sum(df_vocab["Frecuencia"])
palabras_unicas = df_vocab.shape[0]

top_100_words = df_vocab.head(100)
bottom_100_words = df_vocab.tail(100)

with open("/Users/rodrigozeferino/Downloads/estadisticas.txt", "w", encoding="utf-8") as f:
    f.write(f"📌 Estadísticas del vocabulario de 'Los Miserables'\n")
    f.write(f"🔹 Total de palabras en el texto: {total_palabras}\n")
    f.write(f"🔹 Total de palabras únicas: {palabras_unicas}\n\n")

    f.write(f"🔝 Top 100 palabras más frecuentes:\n")
    f.write(top_100_words.to_string(index=False) + "\n\n")

    f.write(f"🔻 Top 100 palabras menos frecuentes:\n")
    f.write(bottom_100_words.to_string(index=False) + "\n")



import matplotlib.pyplot as plt

# Histograma de la distribución de frecuencias
plt.figure(figsize=(10, 5))
plt.hist(df_vocab["Frecuencia"], bins=50, log=True, color="skyblue", edgecolor="black")
plt.xlabel("Frecuencia de Palabras")
plt.ylabel("Número de Palabras")
plt.title("Distribución de la Frecuencia de las Palabras en 'Los Miserables'")
plt.grid()

plt.savefig("histograma_frecuencia.png", dpi=300)
plt.show()


import numpy as np

df_vocab["Ranking"] = np.arange(1, len(df_vocab) + 1)

plt.figure(figsize=(10, 5))
plt.plot(df_vocab["Ranking"], df_vocab["Frecuencia"], marker="o", linestyle="none", color="red")
plt.xscale("log")
plt.yscale("log")
plt.xlabel("Ranking de la Palabra")
plt.ylabel("Frecuencia")
plt.title("Ley de Zipf en 'Los Miserables'")
plt.grid()

plt.savefig("ley_zipf.png", dpi=300)
plt.show()

