using CSV
using DataFrames
using Printf 
using Statistics
using Plots
using Combinatorics
using GLM
using StatsBase
using Random

file_path = "C:/Users/Usuario/Desktop/my_dataframe.csv"  
data = CSV.read(file_path, DataFrame)

println("Primeras 10 filas del dataset:")
println(first(data, 5))

println(names(data))

println(dropmissing!(data))  


print(describe(data))

dependent_var = :T_degC  # Variable dependiente
independent_vars = Symbol.(["R_Depth", "R_SALINITY", "R_SIGMA", "R_DYNHT"])  # Convertir nombres a símboloss


# Particionar el dataset
function partition_data(data::DataFrame, train_fraction::Float64)
    n = nrow(data)
    train_size = Int(round(train_fraction * n))
    indices = shuffle(1:n)
    train_indices = indices[1:train_size]
    test_indices = indices[train_size+1:end]
    return data[train_indices, :], data[test_indices, :]
end

# Dividir en entrenamiento y prueba
train_data, test_data = partition_data(data, 0.7)

names(train_data)

# Definir una función para evaluar modelos
function evaluate_model(dependent_var::Symbol, independent_vars::Vector{Symbol}, train_data::DataFrame)
    formula = Term(dependent_var) ~ sum(Term(var) for var in independent_vars)
    model = lm(formula, train_data)
    return deviance(model), model
end

# Probar combinaciones de variables independientes
best_model = nothing
best_deviance = Inf
best_combination = nothing

for k in 1:length(independent_vars)
    for combination in combinations(independent_vars, k)
        deviance, model = evaluate_model(dependent_var, combination, train_data)
        println("Combination: $combination, Deviance: $deviance")
        if deviance < best_deviance
            best_deviance = deviance
            best_model = model
            best_combination = combination
        end
    end
end


function calculate_metrics(model, test_data, dependent_var)
    y_true = test_data[!, dependent_var]
    y_pred = predict(model, test_data)
    residuals = y_true - y_pred

    mse = mean(residuals .^ 2)  # Mean Squared Error
    rmse = sqrt(mse)  # Root Mean Squared Error
    mae = mean(abs.(residuals))  # Mean Absolute Error
    r_squared = 1 - (sum(residuals .^ 2) / sum((y_true .- mean(y_true)) .^ 2))  # R²

    return mse, rmse, mae, r_squared
end

# Calcular métricas en el conjunto de prueba
mse, rmse, mae, r_squared = calculate_metrics(best_model, test_data, dependent_var)

# Mostrar resultados
println("\nMetrics on test data:")
println("MSE: $mse")
println("RMSE: $rmse")
println("MAE: $mae")
println("R²: $r_squared")

# Mostrar el mejor modelo
println("\nBest combination: $best_combination")
println("Best deviance: $best_deviance")
println("Model summary:")
display(coeftable(best_model))

display(coeftable(best_model))


