package main

import (
	"fmt"
	"image"
	"log"
	"math"
	"strconv"

	"image/color"
	"image/png"
	"os"
	"strings"

	"gonum.org/v1/gonum/mat"

	_ "image/jpeg"
)

func main() {

	//Se define el directorio donde se van a leer las imágenes
	miDirectorio := "../dat/"

	//Se define el directorio sonde se van a colocar las imágenes procesadas
	miDirectorioSalida := "../fig/"

	//Se obtienen los archivos del directorio con que se van a trabajar
	archivos, err := obtenerArchivosJPG(miDirectorio)
	if err != nil {
		fmt.Println("Error al obtener los archivos:", err)
		return
	}

	fmt.Println("Solo se procesarán los archivos siguientes archivos (Solo JPEG o JPG):")
	fmt.Println(archivos)

	i := 0

	for _, archivo := range archivos {
		i = i + 1
		fmt.Println("Procesando archivo: ", archivo)

		//Ruta del archivo a procesar
		arcProcesar := miDirectorio + archivo

		// Se abre el archivo de imagen y se carga en memoria
		miArchivo, err := os.Open(arcProcesar)
		if err != nil {
			log.Fatal(err)
		}
		defer miArchivo.Close()

		//Se decodifica el archivo para que sea tratado como imagen
		img, _, err := image.Decode(miArchivo)
		if err != nil {
			log.Fatal(err)
		}
		fmt.Println("Archivo en memoria: ", archivo)

		//Se convierte la imagen a escala de grises

		//Se obtienen el alto y ancho de la imagen
		ancho, alto := img.Bounds().Max.X, img.Bounds().Max.Y
		//Se crea una matriz donde se va a guardar la imagen en escala de grises
		imgMatriz := mat.NewDense(alto, ancho, nil)

		for y := 0; y < alto; y++ {
			for x := 0; x < ancho; x++ {

				// Se obtienen los valores RGB de cada elemento de la matriz
				r, g, b, _ := img.At(x, y).RGBA()

				//Se aplica la fórmula NTSC de luminancia (https://en.wikipedia.org/wiki/Grayscale) y se normalizan los píxeles
				//de 0 a 1 con el valor máximo que se puede tener en un RGB (65535)
				valorEGrises := float64(0.299*float32(r)+0.587*float32(g)+0.114*float32(b)) / 65535.0

				//El valor final valorEGrises se almacena en la matriz como la intensidad en escala de grises para ese pixel
				imgMatriz.Set(y, x, valorEGrises)
			}
		}
		fmt.Println("Se ha transformado la matriz en escala de grises: ", archivo)

		//Se realiza la factorización SVD M=USVt de la matriz generada en escala de grises
		var svd mat.SVD

		//mat.SVDThin significa que solo se calculan las columnas de U y V a los valores singulares no nulos.
		//Estas matrices tienen un tamaño más pequeño de la factorización completa, pero se usa para ahorrar memoria
		//svd.Factorize(imgMatriz, mat.SVDThin)

		//mat.SVDFull significa que se calcula la matriz completa, para el tamaño reducido de imágenes no es impactante en el rendimiento
		svd.Factorize(imgMatriz, mat.SVDFull)

		fmt.Println("Se ha hecho la factorización SVD de la imagen: ", archivo)

		//Se van a hacer las imágenes 5, 50 y 100 valores singulares
		valores := []int{5, 50, 100}
		for _, k := range valores {
			fmt.Println("Procesando la imagen con K=: ", k)

			//Se obtiene la matriz U de la factorización
			U := new(mat.Dense)
			svd.UTo(U)

			//Se obtiene la matriz S de la factorización
			S := svd.Values(nil)

			//Se obtiene la matriz V de la factorización
			V := new(mat.Dense)
			svd.VTo(V)

			//Se obtienen las primeras k columnas de U y de V
			Uk := U.Slice(0, U.RawMatrix().Rows, 0, k).(*mat.Dense)
			Vk := V.Slice(0, V.RawMatrix().Rows, 0, k).(*mat.Dense)

			//Se crea la matriz diagonal con los primeros k valores
			Sk := mat.NewDense(k, k, nil)
			for i := 0; i < k; i++ {
				Sk.Set(i, i, S[i])
			}

			// Se calcula el producto de la matriz M aproximada M = Uk * Sk * Vkt

			// Primero se hace Uk * Sk
			intermediate := new(mat.Dense)
			intermediate.Mul(Uk, Sk)

			// Luego el producto anterior (Uk * Sk) * Vkt (transpuesta)
			M := new(mat.Dense)
			M.Mul(intermediate, Vk.T())

			// Se aplica el valor absoluto a cada elemento de M
			M.Apply(func(i, j int, v float64) float64 {
				return math.Abs(v)
			}, M)

			numFilas, numColumnas := M.Dims()

			//Se calcula el valor máximo y minimo de la matriz con el fin de normalizar los datos para la imagen de salida
			min, max := matrizMinMax(M)

			//Se convierte la matriz en una imagen en escala de grises, ver función para más detalles
			imgSalvada := matrizAImagen(M, numFilas, numColumnas, min, max)

			// Guardar la imagen como archivo de imagen

			//Primero se crea el archivo donde se va a guardar la imagen y se sube a memoria
			arcSalvada, err := os.Create(miDirectorioSalida + strconv.Itoa(i) + "_Aprox" + strconv.Itoa(k) + archivo)
			if err != nil {
				log.Fatalf("Error al crear el archivo: %v", err)
			}
			defer arcSalvada.Close()

			//Se coloca la imagen en el archivo donde se debe guardar
			err = png.Encode(arcSalvada, imgSalvada)
			if err != nil {
				log.Fatalf("Error al guardar la imagen: %v", err)
			}
			fmt.Println("Imagen de generada en " + miDirectorioSalida + strconv.Itoa(i) + "_Aprox" + strconv.Itoa(k) + archivo)

			//Fin del proceso

		}
		fmt.Println("Archivo procesado: ", archivo)

	}

}

func matrizMinMax(m *mat.Dense) (min, max float64) {
	//Esta función calcula el valor mínimo y el máximo de la matriz

	//Se inicializan las variables en +infinito y -infinito
	min, max = math.MaxFloat64, -math.MaxFloat64

	//Se obtienen las dimensiones de la matriz
	numFilas, numColumnas := m.Dims()

	//Se recorre toda la matriz para obtener el menor y el mayo valor
	for i := 0; i < numFilas; i++ {
		for j := 0; j < numColumnas; j++ {
			valorEvaluar := m.At(i, j)
			if valorEvaluar < min {
				min = valorEvaluar
			}
			if valorEvaluar > max {
				max = valorEvaluar
			}
		}
	}
	return min, max
}

func matrizAImagen(m *mat.Dense, rows, cols int, min, max float64) *image.Gray {
	//Esta función convierte la matriz a una imagen en escala de grises, normalizando los valores que tiene la matriz de acuerdo
	//a sus valores máximos y mínimos

	//Se crea una nueva imagen del tamaño de la matriz.
	img := image.NewGray(image.Rect(0, 0, cols, rows))

	//Como cada elemento debe estar entre 0 y 255 (porque se generan matrices en escala de grises), por ello se van a
	//normalizar los valores de la matriz, según este siguiente factor. Cada valor de la matriz se va a multiplicar
	//por este factor para que quede entre 0 y 255
	factNormalizacion := 255.0 / (max - min)

	//Se recorre la matriz completa para obtener el valor de
	for i := 0; i < rows; i++ {
		for j := 0; j < cols; j++ {
			// Normalizar el valor entre 0 y 255
			v := m.At(i, j)
			//A todos los elementos se les resta el valor mínimo para que se comience en cero la normalización
			//se les aplica el factor de normalización y finalmente se convierten a un entero de 8 bits
			elementoEscalaGrises := uint8(math.Round((v - min) * factNormalizacion))
			//Se guarda el elemento en la imagen
			img.SetGray(j, i, color.Gray{Y: elementoEscalaGrises})
		}
	}
	return img
}

func obtenerArchivosJPG(directorio string) ([]string, error) {
	var archivosValidos []string

	// Leer todos los archivos en el directorio
	archivos, err := os.ReadDir(directorio)
	if err != nil {
		return nil, err
	}

	// Filtrar archivos JPG o JPEG (sin importar si están en mayúsculas/minúsculas)
	for _, archivo := range archivos {
		if !archivo.IsDir() {
			ext := strings.ToLower(archivo.Name())
			if strings.HasSuffix(ext, ".jpg") || strings.HasSuffix(ext, ".jpeg") {
				// Agregar archivo válido al arreglo
				archivosValidos = append(archivosValidos, archivo.Name())
			}
		}
	}
	return archivosValidos, nil
}
