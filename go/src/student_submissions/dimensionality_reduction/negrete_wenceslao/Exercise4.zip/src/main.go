package main

import (
	"fmt"
	"image"
	"image/color"
	"image/jpeg"
	"log"
	"os"
	"path/filepath"
	"strings"

	"golang.org/x/image/draw"
	"gonum.org/v1/gonum/mat"
	"gonum.org/v1/gonum/stat"
)

const maxImageDimension = 1024

// readImage reads an image file, resizes if necessary, and converts it to a grayscale float matrix
func readImage(path string) (*mat.Dense, error) {
	file, err := os.Open(path)
	if err != nil {
		return nil, fmt.Errorf("error opening image: %v", err)
	}
	defer file.Close()

	img, err := jpeg.Decode(file)
	if err != nil {
		return nil, fmt.Errorf("error decoding image: %v", err)
	}

	bounds := img.Bounds()
	width, height := bounds.Max.X, bounds.Max.Y

	// Resize image if it's too large
	if width > maxImageDimension || height > maxImageDimension {
		// Calculate new dimensions while maintaining aspect ratio
		var newWidth, newHeight int
		if width > height {
			newWidth = maxImageDimension
			newHeight = int(float64(height) * float64(maxImageDimension) / float64(width))
		} else {
			newHeight = maxImageDimension
			newWidth = int(float64(width) * float64(maxImageDimension) / float64(height))
		}

		// Create new image with new dimensions
		dst := image.NewRGBA(image.Rect(0, 0, newWidth, newHeight))
		draw.CatmullRom.Scale(dst, dst.Bounds(), img, bounds, draw.Over, nil)
		img = dst
		bounds = dst.Bounds()
	}

	width, height = bounds.Max.X, bounds.Max.Y
	data := make([]float64, width*height)

	for y := 0; y < height; y++ {
		for x := 0; x < width; x++ {
			pixel := img.At(x, y)
			r, g, b, _ := pixel.RGBA()
			// Convert to grayscale using standard weights
			gray := 0.299*float64(r>>8) + 0.587*float64(g>>8) + 0.114*float64(b>>8)
			data[y*width+x] = gray
		}
	}

	return mat.NewDense(height, width, data), nil
}

// performPCA performs PCA on the input matrix and returns principal components and transformation matrix
func performPCA(data *mat.Dense, components int) (*mat.Dense, *mat.Dense, []float64) {
	rows, cols := data.Dims()
	
	// Center the data
	centered := mat.NewDense(rows, cols, nil)
	centered.Copy(data)
	
	for j := 0; j < cols; j++ {
		col := mat.Col(nil, j, data)
		mean := stat.Mean(col, nil)
		for i := 0; i < rows; i++ {
			centered.Set(i, j, centered.At(i, j)-mean)
		}
	}

	// Compute covariance matrix
	var cov mat.SymDense
	stat.CovarianceMatrix(&cov, centered, nil)

	// Compute eigenvalues and eigenvectors
	var eigen mat.EigenSym
	ok := eigen.Factorize(&cov, true)
	if !ok {
		log.Fatal("Eigendecomposition failed")
	}

	// Get eigenvalues and eigenvectors
	eigenValues := eigen.Values(nil)
	var eigenvectors mat.Dense
	eigen.VectorsTo(&eigenvectors)

	// Sort eigenvalues and corresponding eigenvectors in descending order
	for i := 0; i < len(eigenValues)-1; i++ {
		for j := i + 1; j < len(eigenValues); j++ {
			if eigenValues[j] > eigenValues[i] {
				eigenValues[i], eigenValues[j] = eigenValues[j], eigenValues[i]
				// Swap columns in eigenvectors matrix
				for k := 0; k < eigenvectors.RawMatrix().Rows; k++ {
					temp := eigenvectors.At(k, i)
					eigenvectors.Set(k, i, eigenvectors.At(k, j))
					eigenvectors.Set(k, j, temp)
				}
			}
		}
	}

	// Take only the first n components
	if components > cols {
		components = cols
	}
	
	var projection mat.Dense
	projection.Mul(centered, eigenvectors.Slice(0, cols, 0, components))

	return &projection, &eigenvectors, eigenValues
}

func main() {
	// Read all images from the images directory
	sourceDir := "../dat"
	files, err := filepath.Glob(filepath.Join(sourceDir, "*.jp*g"))
	if err != nil {
		log.Fatalf("Error reading directory: %v", err)
	}

	// Filter out already reduced images
	var originalFiles []string
	for _, file := range files {
		if !strings.HasPrefix(filepath.Base(file), "reduced_") {
			originalFiles = append(originalFiles, file)
		}
	}
	fmt.Printf("Found %d original images\n", len(originalFiles))

	// Process each image
	for _, file := range originalFiles {
		fmt.Printf("\nProcessing %s\n", file)
		
		// Read and convert image to matrix
		matrix, err := readImage(file)
		if err != nil {
			log.Printf("Error processing %s: %v\n", file, err)
			continue
		}

		rows, cols := matrix.Dims()
		fmt.Printf("Original dimensions: %dx%d = %d pixels\n", rows, cols, rows*cols)

		// Calculate number of components to keep (e.g., 20% of original dimensions)
		components := cols / 5
		projection, transform, eigenValues := performPCA(matrix, components)

		// Reconstruct the image
		var reconstructed mat.Dense
		reconstructed.Mul(projection, transform.Slice(0, cols, 0, components).T())

		// Convert back to image
		reconstructedImg := image.NewGray(image.Rect(0, 0, cols, rows))
		for y := 0; y < rows; y++ {
			for x := 0; x < cols; x++ {
				val := reconstructed.At(y, x)
				// Ensure values are in valid range [0, 255]
				if val < 0 {
					val = 0
				} else if val > 255 {
					val = 255
				}
				reconstructedImg.Set(x, y, color.Gray{Y: uint8(val)})
			}
		}

		// Save reconstructed image
		destDir := "../fig"
		outPath := filepath.Join(destDir, fmt.Sprintf("reduced_%s", filepath.Base(file)))
		outFile, err := os.Create(outPath)
		if err != nil {
			log.Printf("Error creating output file: %v\n", err)
			continue
		}
		defer outFile.Close()

		if err := jpeg.Encode(outFile, reconstructedImg, nil); err != nil {
			log.Printf("Error saving reduced image: %v\n", err)
			continue
		}
		fmt.Printf("Saved reduced image to: %s\n", outPath)

		// Calculate explained variance ratio
		totalVariance := 0.0
		for _, val := range eigenValues {
			totalVariance += val
		}

		explainedVariance := 0.0
		for i := 0; i < components; i++ {
			explainedVariance += eigenValues[i]
		}

		fmt.Printf("Reduced to %d components\n", components)
		fmt.Printf("Explained variance ratio: %.2f%%\n", (explainedVariance/totalVariance)*100)
		
		pRows, pCols := projection.Dims()
		fmt.Printf("Reduced dimensions: %dx%d = %d values\n", pRows, pCols, pRows*pCols)
		fmt.Printf("Compression ratio: %.2fx\n", float64(rows*cols)/float64(pRows*pCols))
	}
}
