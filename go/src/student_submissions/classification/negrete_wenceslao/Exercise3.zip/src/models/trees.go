package models

import (
	"math"
	"math/rand"
	"sort"
)

// TreeNode represents a node in the decision tree
type TreeNode struct {
	Feature    int
	Threshold  float64
	Left       *TreeNode
	Right      *TreeNode
	IsLeaf     bool
	Prediction bool
}

// DecisionTree implements a decision tree classifier
type DecisionTree struct {
	root         *TreeNode
	maxDepth     int
	minSamples   int
	numFeatures  int
}

// RandomForest implements a random forest classifier
type RandomForest struct {
	trees        []*DecisionTree
	numTrees     int
	maxDepth     int
	minSamples   int
	numFeatures  int
}

func NewDecisionTree(maxDepth, minSamples int) *DecisionTree {
	return &DecisionTree{
		maxDepth:    maxDepth,
		minSamples:  minSamples,
		numFeatures: 6,
	}
}

func NewRandomForest(numTrees, maxDepth, minSamples int) *RandomForest {
	return &RandomForest{
		trees:       make([]*DecisionTree, numTrees),
		numTrees:    numTrees,
		maxDepth:    maxDepth,
		minSamples:  minSamples,
		numFeatures: 6,
	}
}

// calculateGini computes the Gini impurity for a set of labels
func calculateGini(labels []bool) float64 {
	if len(labels) == 0 {
		return 0.0
	}

	upCount := 0
	for _, label := range labels {
		if label {
			upCount++
		}
	}
	
	p1 := float64(upCount) / float64(len(labels))
	p2 := 1.0 - p1
	return 1.0 - (p1*p1 + p2*p2)
}

// findBestSplit finds the best feature and threshold for splitting the data
func findBestSplit(data *Dataset, indices []int, features []int) (bestFeature int, bestThreshold float64, bestGini float64) {
	bestGini = math.MaxFloat64
	bestFeature = -1
	bestThreshold = 0.0
	
	for _, feature := range features {
		// Get all values for this feature
		values := make([]float64, len(indices))
		for i, idx := range indices {
			if feature < 5 {
				values[i] = data.Data[idx].Lags[feature]
			} else {
				values[i] = data.Data[idx].Volume
			}
		}
		
		// Sort values and try splits between each pair
		sort.Float64s(values)
		for i := 0; i < len(values)-1; i++ {
			threshold := (values[i] + values[i+1]) / 2
			
			// Split labels
			leftLabels := make([]bool, 0)
			rightLabels := make([]bool, 0)
			
			for _, idx := range indices {
				var value float64
				if feature < 5 {
					value = data.Data[idx].Lags[feature]
				} else {
					value = data.Data[idx].Volume
				}
				
				if value <= threshold {
					leftLabels = append(leftLabels, data.Data[idx].Direction)
				} else {
					rightLabels = append(rightLabels, data.Data[idx].Direction)
				}
			}
			
			// Calculate weighted Gini impurity
			gini := (float64(len(leftLabels))*calculateGini(leftLabels) +
				float64(len(rightLabels))*calculateGini(rightLabels)) / float64(len(indices))
			
			if gini < bestGini {
				bestGini = gini
				bestFeature = feature
				bestThreshold = threshold
			}
		}
	}
	
	return bestFeature, bestThreshold, bestGini
}

func (dt *DecisionTree) buildTree(data *Dataset, indices []int, depth int) *TreeNode {
	// Check stopping conditions
	if depth >= dt.maxDepth || len(indices) <= dt.minSamples {
		// Create leaf node
		upCount := 0
		for _, idx := range indices {
			if data.Data[idx].Direction {
				upCount++
			}
		}
		return &TreeNode{
			IsLeaf:     true,
			Prediction: upCount > len(indices)/2,
		}
	}
	
	// Try all features for splitting
	features := make([]int, dt.numFeatures)
	for i := range features {
		features[i] = i
	}
	
	feature, threshold, gini := findBestSplit(data, indices, features)
	
	// If no good split found, create leaf node
	if feature == -1 || gini == 0 {
		upCount := 0
		for _, idx := range indices {
			if data.Data[idx].Direction {
				upCount++
			}
		}
		return &TreeNode{
			IsLeaf:     true,
			Prediction: upCount > len(indices)/2,
		}
	}
	
	// Split data
	leftIndices := make([]int, 0)
	rightIndices := make([]int, 0)
	
	for _, idx := range indices {
		var value float64
		if feature < 5 {
			value = data.Data[idx].Lags[feature]
		} else {
			value = data.Data[idx].Volume
		}
		
		if value <= threshold {
			leftIndices = append(leftIndices, idx)
		} else {
			rightIndices = append(rightIndices, idx)
		}
	}
	
	// Create split node
	node := &TreeNode{
		Feature:   feature,
		Threshold: threshold,
		Left:      dt.buildTree(data, leftIndices, depth+1),
		Right:     dt.buildTree(data, rightIndices, depth+1),
	}
	
	return node
}

func (dt *DecisionTree) Fit(train *Dataset) {
	indices := make([]int, len(train.Data))
	for i := range indices {
		indices[i] = i
	}
	dt.root = dt.buildTree(train, indices, 0)
}

func (dt *DecisionTree) predictNode(node *TreeNode, features []float64) bool {
	if node.IsLeaf {
		return node.Prediction
	}
	
	var value float64
	if node.Feature < 5 {
		value = features[node.Feature]
	} else {
		value = features[5]
	}
	
	if value <= node.Threshold {
		return dt.predictNode(node.Left, features)
	}
	return dt.predictNode(node.Right, features)
}

func (dt *DecisionTree) Predict(features []float64) bool {
	return dt.predictNode(dt.root, features)
}

func (dt *DecisionTree) PredictProba(features []float64) float64 {
	if dt.Predict(features) {
		return 1.0
	}
	return 0.0
}

func (rf *RandomForest) Fit(train *Dataset) {
	for i := 0; i < rf.numTrees; i++ {
		// Create bootstrap sample
		indices := make([]int, len(train.Data))
		for j := range indices {
			indices[j] = rand.Intn(len(train.Data))
		}
		
		// Train tree on bootstrap sample
		tree := NewDecisionTree(rf.maxDepth, rf.minSamples)
		bootstrapData := &Dataset{
			Data: make([]DataPoint, len(indices)),
		}
		for j, idx := range indices {
			bootstrapData.Data[j] = train.Data[idx]
		}
		tree.Fit(bootstrapData)
		rf.trees[i] = tree
	}
}

func (rf *RandomForest) Predict(features []float64) bool {
	votes := 0
	for _, tree := range rf.trees {
		if tree.Predict(features) {
			votes++
		}
	}
	return votes > rf.numTrees/2
}

func (rf *RandomForest) PredictProba(features []float64) float64 {
	votes := 0
	for _, tree := range rf.trees {
		if tree.Predict(features) {
			votes++
		}
	}
	return float64(votes) / float64(rf.numTrees)
}
