package models

import (
	"math"
	"math/rand"
)

// Model interface defines common methods for all classifiers
type Model interface {
	Fit(train *Dataset)
	Predict(features []float64) bool
	PredictProba(features []float64) float64
}

// DataPoint represents a single row of market data
type DataPoint struct {
	Year      int
	Lags      [5]float64
	Volume    float64
	Today     float64
	Direction bool // true for "Up", false for "Down"
}

// Dataset holds all market data
type Dataset struct {
	Data []DataPoint
}

// ROCPoint represents a point on the ROC curve
type ROCPoint struct {
	FPR float64 // False Positive Rate
	TPR float64 // True Positive Rate
}

// Normalize standardizes features using provided means and standard deviations
func (d *Dataset) Normalize(means, stdDevs []float64) {
	if means == nil || stdDevs == nil {
		// Calculate means and standard deviations if not provided
		means = make([]float64, 6)
		stdDevs = make([]float64, 6)
		
		// Calculate means
		for _, point := range d.Data {
			for i := 0; i < 5; i++ {
				means[i] += point.Lags[i]
			}
			means[5] += point.Volume
		}
		for i := range means {
			means[i] /= float64(len(d.Data))
		}
		
		// Calculate standard deviations
		for _, point := range d.Data {
			for i := 0; i < 5; i++ {
				diff := point.Lags[i] - means[i]
				stdDevs[i] += diff * diff
			}
			diff := point.Volume - means[5]
			stdDevs[5] += diff * diff
		}
		for i := range stdDevs {
			stdDevs[i] = math.Sqrt(stdDevs[i] / float64(len(d.Data)))
			if stdDevs[i] == 0 {
				stdDevs[i] = 1 // Avoid division by zero
			}
		}
	}
	
	// Apply normalization
	for i := range d.Data {
		for j := 0; j < 5; j++ {
			d.Data[i].Lags[j] = (d.Data[i].Lags[j] - means[j]) / stdDevs[j]
		}
		d.Data[i].Volume = (d.Data[i].Volume - means[5]) / stdDevs[5]
	}
}

// SplitData splits the dataset into training and testing sets
func (d *Dataset) SplitData(trainRatio float64) (train, test *Dataset) {
	indices := make([]int, len(d.Data))
	for i := range indices {
		indices[i] = i
	}
	
	// Shuffle indices
	rand.Shuffle(len(indices), func(i, j int) {
		indices[i], indices[j] = indices[j], indices[i]
	})
	
	splitIndex := int(float64(len(d.Data)) * trainRatio)
	
	train = &Dataset{
		Data: make([]DataPoint, splitIndex),
	}
	test = &Dataset{
		Data: make([]DataPoint, len(d.Data)-splitIndex),
	}
	
	for i := 0; i < splitIndex; i++ {
		train.Data[i] = d.Data[indices[i]]
	}
	for i := splitIndex; i < len(d.Data); i++ {
		test.Data[i-splitIndex] = d.Data[indices[i]]
	}
	
	return train, test
}

// Evaluate computes accuracy and confusion matrix
func Evaluate(model Model, data *Dataset) (accuracy float64, confMatrix [2][2]int) {
	correct := 0
	for _, point := range data.Data {
		features := make([]float64, 6)
		copy(features[:5], point.Lags[:])
		features[5] = point.Volume
		
		predicted := model.Predict(features)
		if predicted == point.Direction {
			correct++
		}
		
		// Update confusion matrix
		actual := 0
		pred := 0
		if point.Direction {
			actual = 1
		}
		if predicted {
			pred = 1
		}
		confMatrix[actual][pred]++
	}
	accuracy = float64(correct) / float64(len(data.Data))
	return
}
