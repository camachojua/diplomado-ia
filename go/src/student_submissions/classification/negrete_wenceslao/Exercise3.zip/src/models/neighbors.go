package models

import (
	"math"
	"math/rand"
	"sort"
)

// KNN implements k-Nearest Neighbors classifier
type KNN struct {
	k        int
	trainX   [][]float64
	trainY   []bool
}

// Neighbor represents a data point and its distance to a query point
type Neighbor struct {
	index    int
	distance float64
}

func NewKNN(k int) *KNN {
	return &KNN{
		k: k,
	}
}

func (knn *KNN) Fit(train *Dataset) {
	numSamples := len(train.Data)
	knn.trainX = make([][]float64, numSamples)
	knn.trainY = make([]bool, numSamples)
	
	for i, point := range train.Data {
		features := make([]float64, 6)
		copy(features[:5], point.Lags[:])
		features[5] = point.Volume
		knn.trainX[i] = features
		knn.trainY[i] = point.Direction
	}
}

func (knn *KNN) findNeighbors(features []float64) []Neighbor {
	neighbors := make([]Neighbor, len(knn.trainX))
	
	// Calculate distances to all training points
	for i, trainFeatures := range knn.trainX {
		var distance float64
		for j := range features {
			diff := features[j] - trainFeatures[j]
			distance += diff * diff
		}
		distance = math.Sqrt(distance)
		neighbors[i] = Neighbor{i, distance}
	}
	
	// Sort by distance
	sort.Slice(neighbors, func(i, j int) bool {
		return neighbors[i].distance < neighbors[j].distance
	})
	
	// Return k nearest neighbors
	if knn.k < len(neighbors) {
		return neighbors[:knn.k]
	}
	return neighbors
}

func (knn *KNN) Predict(features []float64) bool {
	neighbors := knn.findNeighbors(features)
	
	// Count votes
	upVotes := 0
	for _, n := range neighbors {
		if knn.trainY[n.index] {
			upVotes++
		}
	}
	
	return upVotes > len(neighbors)/2
}

func (knn *KNN) PredictProba(features []float64) float64 {
	neighbors := knn.findNeighbors(features)
	
	upVotes := 0
	for _, n := range neighbors {
		if knn.trainY[n.index] {
			upVotes++
		}
	}
	
	return float64(upVotes) / float64(len(neighbors))
}

// SVM implements Support Vector Machine classifier using SMO algorithm
type SVM struct {
	weights    []float64
	bias      float64
	C         float64  // regularization parameter
	tolerance float64
	maxIter   int
}

func NewSVM(c float64) *SVM {
	return &SVM{
		weights:   make([]float64, 6),
		C:         c,
		tolerance: 1e-3,
		maxIter:   1000,
	}
}

func (svm *SVM) Fit(train *Dataset) {
	numSamples := len(train.Data)
	numFeatures := 6
	
	// Initialize weights and bias
	for i := range svm.weights {
		svm.weights[i] = 0
	}
	svm.bias = 0
	
	// Convert data to matrix form
	x := make([][]float64, numSamples)
	y := make([]float64, numSamples)
	for i, point := range train.Data {
		x[i] = make([]float64, numFeatures)
		copy(x[i][:5], point.Lags[:])
		x[i][5] = point.Volume
		if point.Direction {
			y[i] = 1
		} else {
			y[i] = -1
		}
	}
	
	// SMO algorithm
	alphas := make([]float64, numSamples)
	for iter := 0; iter < svm.maxIter; iter++ {
		numChanged := 0
		
		// Update alphas
		for i := 0; i < numSamples; i++ {
			// Calculate error
			var f float64
			for j := 0; j < numFeatures; j++ {
				f += svm.weights[j] * x[i][j]
			}
			f += svm.bias
			error := f - y[i]
			
			// Check KKT conditions
			if (y[i]*error < -svm.tolerance && alphas[i] < svm.C) ||
				(y[i]*error > svm.tolerance && alphas[i] > 0) {
				
				// Choose second alpha randomly
				j := i
				for j == i {
					j = rand.Intn(numSamples)
				}
				
				// Calculate error for second point
				var f2 float64
				for k := 0; k < numFeatures; k++ {
					f2 += svm.weights[k] * x[j][k]
				}
				f2 += svm.bias
				error2 := f2 - y[j]
				
				// Save old alphas
				alpha1Old := alphas[i]
				alpha2Old := alphas[j]
				
				// Calculate bounds
				var L, H float64
				if y[i] != y[j] {
					L = math.Max(0, alpha2Old-alpha1Old)
					H = math.Min(svm.C, svm.C+alpha2Old-alpha1Old)
				} else {
					L = math.Max(0, alpha1Old+alpha2Old-svm.C)
					H = math.Min(svm.C, alpha1Old+alpha2Old)
				}
				
				if L == H {
					continue
				}
				
				// Calculate eta
				var eta float64
				for k := 0; k < numFeatures; k++ {
					eta += x[i][k] * x[i][k]
					eta += x[j][k] * x[j][k]
					eta -= 2 * x[i][k] * x[j][k]
				}
				
				if eta <= 0 {
					continue
				}
				
				// Update alpha2
				alpha2New := alpha2Old + y[j]*(error-error2)/eta
				if alpha2New < L {
					alpha2New = L
				} else if alpha2New > H {
					alpha2New = H
				}
				
				if math.Abs(alpha2New-alpha2Old) < 1e-5 {
					continue
				}
				
				// Update alpha1
				alpha1New := alpha1Old + y[i]*y[j]*(alpha2Old-alpha2New)
				
				// Update weights
				for k := 0; k < numFeatures; k++ {
					svm.weights[k] += y[i]*(alpha1New-alpha1Old)*x[i][k] +
						y[j]*(alpha2New-alpha2Old)*x[j][k]
				}
				
				// Update bias
				b1 := svm.bias - error - y[i]*(alpha1New-alpha1Old)*
					dotProduct(x[i], x[i]) - y[j]*(alpha2New-alpha2Old)*
					dotProduct(x[i], x[j])
				b2 := svm.bias - error2 - y[i]*(alpha1New-alpha1Old)*
					dotProduct(x[i], x[j]) - y[j]*(alpha2New-alpha2Old)*
					dotProduct(x[j], x[j])
				
				svm.bias = (b1 + b2) / 2
				
				alphas[i] = alpha1New
				alphas[j] = alpha2New
				
				numChanged++
			}
		}
		
		if numChanged == 0 {
			break
		}
	}
}

func dotProduct(a, b []float64) float64 {
	var sum float64
	for i := range a {
		sum += a[i] * b[i]
	}
	return sum
}

func (svm *SVM) Predict(features []float64) bool {
	var f float64
	for i, w := range svm.weights {
		f += w * features[i]
	}
	f += svm.bias
	return f > 0
}

func (svm *SVM) PredictProba(features []float64) float64 {
	var f float64
	for i, w := range svm.weights {
		f += w * features[i]
	}
	f += svm.bias
	return sigmoid(f)
}
