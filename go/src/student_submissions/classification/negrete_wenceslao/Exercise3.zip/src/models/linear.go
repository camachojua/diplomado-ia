package models

import "math"

// LassoLogistic implements LASSO regression
type LassoLogistic struct {
	weights   []float64
	bias      float64
	lambda    float64
	maxIter   int
	tolerance float64
}

// RidgeLogistic implements Ridge regression
type RidgeLogistic struct {
	weights   []float64
	bias      float64
	lambda    float64
	maxIter   int
	tolerance float64
}

// ElasticNetLogistic implements Elastic Net regression
type ElasticNetLogistic struct {
	weights   []float64
	bias      float64
	lambda1   float64 // L1 regularization parameter
	lambda2   float64 // L2 regularization parameter
	maxIter   int
	tolerance float64
}

func NewLassoLogistic(lambda float64) *LassoLogistic {
	return &LassoLogistic{
		weights:   make([]float64, 6),
		lambda:    lambda,
		maxIter:   1000,
		tolerance: 1e-4,
	}
}

func NewRidgeLogistic(lambda float64) *RidgeLogistic {
	return &RidgeLogistic{
		weights:   make([]float64, 6),
		lambda:    lambda,
		maxIter:   1000,
		tolerance: 1e-4,
	}
}

func NewElasticNetLogistic(lambda1, lambda2 float64) *ElasticNetLogistic {
	return &ElasticNetLogistic{
		weights:   make([]float64, 6),
		lambda1:   lambda1,
		lambda2:   lambda2,
		maxIter:   1000,
		tolerance: 1e-4,
	}
}

func sigmoid(x float64) float64 {
	return 1.0 / (1.0 + math.Exp(-x))
}

func getFeatures(point *DataPoint) []float64 {
	features := make([]float64, 6)
	copy(features[:5], point.Lags[:])
	features[5] = point.Volume
	return features
}

func (l *LassoLogistic) Fit(train *Dataset) {
	numFeatures := 6
	numSamples := len(train.Data)
	
	// Initialize weights
	for i := range l.weights {
		l.weights[i] = 0
	}
	l.bias = 0
	
	for iter := 0; iter < l.maxIter; iter++ {
		oldWeights := make([]float64, len(l.weights))
		copy(oldWeights, l.weights)
		oldBias := l.bias
		
		// Update each weight using coordinate descent
		for j := 0; j < numFeatures; j++ {
			var gradient float64
			for i := 0; i < numSamples; i++ {
				features := getFeatures(&train.Data[i])
				prediction := l.PredictProba(features)
				label := 0.0
				if train.Data[i].Direction {
					label = 1.0
				}
				gradient += (prediction - label) * features[j]
			}
			gradient /= float64(numSamples)
			
			// LASSO update with soft thresholding
			if gradient > l.lambda {
				l.weights[j] -= gradient - l.lambda
			} else if gradient < -l.lambda {
				l.weights[j] -= gradient + l.lambda
			} else {
				l.weights[j] = 0
			}
		}
		
		// Update bias
		var biasGradient float64
		for i := 0; i < numSamples; i++ {
			features := getFeatures(&train.Data[i])
			prediction := l.PredictProba(features)
			label := 0.0
			if train.Data[i].Direction {
				label = 1.0
			}
			biasGradient += prediction - label
		}
		l.bias -= biasGradient / float64(numSamples)
		
		// Check convergence
		diff := 0.0
		for j := range l.weights {
			diff += math.Abs(l.weights[j] - oldWeights[j])
		}
		diff += math.Abs(l.bias - oldBias)
		if diff < l.tolerance {
			break
		}
	}
}

func (r *RidgeLogistic) Fit(train *Dataset) {
	numFeatures := 6
	numSamples := len(train.Data)
	
	// Initialize weights
	for i := range r.weights {
		r.weights[i] = 0
	}
	r.bias = 0
	
	for iter := 0; iter < r.maxIter; iter++ {
		oldWeights := make([]float64, len(r.weights))
		copy(oldWeights, r.weights)
		oldBias := r.bias
		
		// Update weights
		for j := 0; j < numFeatures; j++ {
			var gradient float64
			for i := 0; i < numSamples; i++ {
				features := getFeatures(&train.Data[i])
				prediction := r.PredictProba(features)
				label := 0.0
				if train.Data[i].Direction {
					label = 1.0
				}
				gradient += (prediction - label) * features[j]
			}
			gradient /= float64(numSamples)
			
			// Ridge update with L2 regularization
			r.weights[j] -= (gradient + r.lambda*r.weights[j])
		}
		
		// Update bias
		var biasGradient float64
		for i := 0; i < numSamples; i++ {
			features := getFeatures(&train.Data[i])
			prediction := r.PredictProba(features)
			label := 0.0
			if train.Data[i].Direction {
				label = 1.0
			}
			biasGradient += prediction - label
		}
		r.bias -= biasGradient / float64(numSamples)
		
		// Check convergence
		diff := 0.0
		for j := range r.weights {
			diff += math.Abs(r.weights[j] - oldWeights[j])
		}
		diff += math.Abs(r.bias - oldBias)
		if diff < r.tolerance {
			break
		}
	}
}

func (e *ElasticNetLogistic) Fit(train *Dataset) {
	numFeatures := 6
	numSamples := len(train.Data)
	
	// Initialize weights
	for i := range e.weights {
		e.weights[i] = 0
	}
	e.bias = 0
	
	for iter := 0; iter < e.maxIter; iter++ {
		oldWeights := make([]float64, len(e.weights))
		copy(oldWeights, e.weights)
		oldBias := e.bias
		
		// Update weights
		for j := 0; j < numFeatures; j++ {
			var gradient float64
			for i := 0; i < numSamples; i++ {
				features := getFeatures(&train.Data[i])
				prediction := e.PredictProba(features)
				label := 0.0
				if train.Data[i].Direction {
					label = 1.0
				}
				gradient += (prediction - label) * features[j]
			}
			gradient /= float64(numSamples)
			
			// Elastic Net update combining L1 and L2
			if gradient > e.lambda1 {
				e.weights[j] -= (gradient - e.lambda1 + e.lambda2*e.weights[j])
			} else if gradient < -e.lambda1 {
				e.weights[j] -= (gradient + e.lambda1 + e.lambda2*e.weights[j])
			} else {
				e.weights[j] = 0
			}
		}
		
		// Update bias
		var biasGradient float64
		for i := 0; i < numSamples; i++ {
			features := getFeatures(&train.Data[i])
			prediction := e.PredictProba(features)
			label := 0.0
			if train.Data[i].Direction {
				label = 1.0
			}
			biasGradient += prediction - label
		}
		e.bias -= biasGradient / float64(numSamples)
		
		// Check convergence
		diff := 0.0
		for j := range e.weights {
			diff += math.Abs(e.weights[j] - oldWeights[j])
		}
		diff += math.Abs(e.bias - oldBias)
		if diff < e.tolerance {
			break
		}
	}
}

func (l *LassoLogistic) PredictProba(features []float64) float64 {
	z := l.bias
	for i, w := range l.weights {
		z += w * features[i]
	}
	return sigmoid(z)
}

func (r *RidgeLogistic) PredictProba(features []float64) float64 {
	z := r.bias
	for i, w := range r.weights {
		z += w * features[i]
	}
	return sigmoid(z)
}

func (e *ElasticNetLogistic) PredictProba(features []float64) float64 {
	z := e.bias
	for i, w := range e.weights {
		z += w * features[i]
	}
	return sigmoid(z)
}

func (l *LassoLogistic) Predict(features []float64) bool {
	return l.PredictProba(features) >= 0.5
}

func (r *RidgeLogistic) Predict(features []float64) bool {
	return r.PredictProba(features) >= 0.5
}

func (e *ElasticNetLogistic) Predict(features []float64) bool {
	return e.PredictProba(features) >= 0.5
}
