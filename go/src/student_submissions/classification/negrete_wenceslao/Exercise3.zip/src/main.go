package main

import (
	"encoding/csv"
	"fmt"
	"log"
	"os"
	"strconv"

	"image/color"

	"diplomado.ai/classification/models"
	"gonum.org/v1/plot"
	"gonum.org/v1/plot/plotter"
	"gonum.org/v1/plot/vg"
)

// LoadData reads the CSV file and returns a Dataset
func LoadData(filename string) (*models.Dataset, error) {
	file, err := os.Open(filename)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	reader := csv.NewReader(file)
	// Skip header
	_, err = reader.Read()
	if err != nil {
		return nil, err
	}

	var dataset models.Dataset

	for {
		record, err := reader.Read()
		if err != nil {
			break
		}

		year, _ := strconv.Atoi(record[0])
		var lags [5]float64
		for i := 0; i < 5; i++ {
			lags[i], _ = strconv.ParseFloat(record[i+1], 64)
		}
		volume, _ := strconv.ParseFloat(record[6], 64)
		today, _ := strconv.ParseFloat(record[7], 64)
		direction := record[8] == "Up"

		dataPoint := models.DataPoint{
			Year:      year,
			Lags:      lags,
			Volume:    volume,
			Today:     today,
			Direction: direction,
		}

		dataset.Data = append(dataset.Data, dataPoint)
	}

	return &dataset, nil
}

// calculateROC computes ROC curve points
func calculateROC(model models.Model, data *models.Dataset) []models.ROCPoint {
	var points []models.ROCPoint
	var probas []float64
	var labels []bool
	
	// Get predictions for all points
	for _, point := range data.Data {
		features := make([]float64, 6)
		copy(features[:5], point.Lags[:])
		features[5] = point.Volume
		
		proba := model.PredictProba(features)
		probas = append(probas, proba)
		labels = append(labels, point.Direction)
	}
	
	// Add point (0,0) for threshold above max probability
	points = append(points, models.ROCPoint{FPR: 0, TPR: 0})

	// Use unique probability values as thresholds
	thresholds := make([]float64, 0)
	seen := make(map[float64]bool)
	for _, prob := range probas {
		if !seen[prob] {
			thresholds = append(thresholds, prob)
			seen[prob] = true
		}
	}

	// Sort thresholds in ascending order
	for i := 0; i < len(thresholds)-1; i++ {
		for j := i + 1; j < len(thresholds); j++ {
			if thresholds[i] > thresholds[j] {
				thresholds[i], thresholds[j] = thresholds[j], thresholds[i]
			}
		}
	}

	// Calculate points for each threshold
	lastPoint := models.ROCPoint{FPR: -1, TPR: -1} // For deduplication
	for _, threshold := range thresholds {
		tp, fp, tn, fn := 0, 0, 0, 0
		
		for i := range probas {
			predicted := probas[i] >= threshold
			if predicted && labels[i] {
				tp++
			} else if predicted && !labels[i] {
				fp++
			} else if !predicted && !labels[i] {
				tn++
			} else {
				fn++
			}
		}
		
		tpr := float64(tp) / float64(tp+fn)
		fpr := float64(fp) / float64(fp+tn)
		
		// Only add point if it's different from the last one
		if fpr != lastPoint.FPR || tpr != lastPoint.TPR {
			points = append(points, models.ROCPoint{FPR: fpr, TPR: tpr})
			lastPoint.FPR = fpr
			lastPoint.TPR = tpr
		}
	}
	
	// Add point (1,1) for threshold below min probability
	points = append(points, models.ROCPoint{FPR: 1, TPR: 1})
	
	return points
}

// generateROCPlot creates a plot of ROC curves using gonum/plot
func generateROCPlot(modelResults []struct {
	name string
	points []models.ROCPoint
}) (*plot.Plot, error) {
	p := plot.New()

	p.Title.Text = "ROC Curves Comparison"
	p.X.Label.Text = "False Positive Rate"
	p.Y.Label.Text = "True Positive Rate"
	p.X.Min = 0
	p.X.Max = 1
	p.Y.Min = 0
	p.Y.Max = 1

	// Add grid
	p.Add(plotter.NewGrid())

	// Set axis ticks
	p.X.Tick.Marker = plot.TickerFunc(func(min, max float64) []plot.Tick {
		var ticks []plot.Tick
		for i := 0.0; i <= 1.0; i += 0.1 {
			ticks = append(ticks, plot.Tick{Value: i, Label: fmt.Sprintf("%.1f", i)})
		}
		return ticks
	})
	p.Y.Tick.Marker = plot.TickerFunc(func(min, max float64) []plot.Tick {
		var ticks []plot.Tick
		for i := 0.0; i <= 1.0; i += 0.1 {
			ticks = append(ticks, plot.Tick{Value: i, Label: fmt.Sprintf("%.1f", i)})
		}
		return ticks
	})

	// Add diagonal reference line (dashed)
	refLine, err := plotter.NewLine(plotter.XYs{
		{X: 0, Y: 0},
		{X: 1, Y: 1},
	})
	if err != nil {
		return nil, err
	}
	refLine.Color = color.RGBA{R: 150, G: 150, B: 150, A: 255}
	refLine.Width = vg.Points(1)
	refLine.Dashes = []vg.Length{vg.Points(5), vg.Points(5)}
	p.Add(refLine)

	// Create a different color for each model with better contrast
	colors := []color.RGBA{
		{R: 230, G: 25, B: 75, A: 255},   // Red
		{R: 60, G: 180, B: 75, A: 255},   // Green
		{R: 0, G: 130, B: 200, A: 255},   // Blue
		{R: 245, G: 130, B: 48, A: 255},  // Orange
		{R: 145, G: 30, B: 180, A: 255},  // Purple
		{R: 70, G: 240, B: 240, A: 255},  // Cyan
		{R: 240, G: 50, B: 230, A: 255},  // Magenta
	}

	// Add lines for each model
	for i, result := range modelResults {
		xys := make(plotter.XYs, len(result.points))
		for j, point := range result.points {
			xys[j].X = point.FPR
			xys[j].Y = point.TPR
		}

		line, err := plotter.NewLine(xys)
		if err != nil {
			return nil, err
		}

		// Set color and style
		line.Color = colors[i%len(colors)]
		line.Width = vg.Points(2)

		// Add to plot
		p.Add(line)
		p.Legend.Add(result.name, line)
	}

	// Adjust legend style
	p.Legend.Top = false
	p.Legend.Left = true
	p.Legend.XOffs = vg.Points(5)
	p.Legend.YOffs = vg.Points(5)
	p.Legend.Padding = vg.Points(10)
	p.Legend.TextStyle.Font.Size = vg.Points(10)

	return p, nil
}

func main() {
	// Load data
	dataset, err := LoadData("../dat/Smarket.csv")
	if err != nil {
		log.Fatal(err)
	}

	// Split into training and testing sets
	trainData, testData := dataset.SplitData(0.7)

	// Train and evaluate all models
	classifiers := []struct {
		name  string
		model models.Model
	}{
		{"LASSO", models.NewLassoLogistic(0.01)},
		{"Ridge", models.NewRidgeLogistic(0.01)},
		{"Elastic Net", models.NewElasticNetLogistic(0.01, 0.01)},
		{"Decision Tree", models.NewDecisionTree(5, 10)},
		{"Random Forest", models.NewRandomForest(100, 5, 10)},
		{"KNN", models.NewKNN(5)},
		{"SVM", models.NewSVM(1.0)},
	}
	
	fmt.Printf("Training set size: %d, Test set size: %d\n\n", 
		len(trainData.Data), len(testData.Data))
	
	// Collect results for visualization
	var modelResults []struct {
		name string
		points []models.ROCPoint
	}

	for _, clf := range classifiers {
		fmt.Printf("Training %s...\n", clf.name)
		clf.model.Fit(trainData)
		
		accuracy, confMatrix := models.Evaluate(clf.model, testData)
		rocPoints := calculateROC(clf.model, testData)
		
		// Store results for visualization
		modelResults = append(modelResults, struct {
			name string
			points []models.ROCPoint
		}{
			name: clf.name,
			points: rocPoints,
		})
		
		fmt.Printf("\nResults for %s:\n", clf.name)
		fmt.Printf("Accuracy: %.4f\n", accuracy)
		fmt.Printf("Confusion Matrix:\n")
		fmt.Printf("[[%d %d]\n [%d %d]]\n", 
			confMatrix[0][0], confMatrix[0][1],
			confMatrix[1][0], confMatrix[1][1])
		fmt.Println()
	}

	// Generate and save the ROC curves plot
	p, err := generateROCPlot(modelResults)
	if err != nil {
		log.Fatal(err)
	}

	// Save the plot to a PNG file
	if err := p.Save(8*vg.Inch, 8*vg.Inch, "../fig/roc_curves.png"); err != nil {
		log.Fatal(err)
	}
	
	fmt.Println("ROC curves plot has been saved to roc_curves.png")
}
