# Classification Models Performance Report

## Introduction
This report presents the results of applying various classification models to predict stock market movements using the Smarket dataset. The dataset was split into training (70%) and test (30%) sets, with 875 samples for training and 375 samples for testing.

## Models Evaluated
Seven different classification models were implemented and evaluated:
1. LASSO Logistic Regression
2. Ridge Logistic Regression
3. Elastic Net Logistic Regression
4. Decision Tree
5. Random Forest
6. K-Nearest Neighbors (KNN)
7. Support Vector Machine (SVM)

## Results

### Accuracy Scores
| Model | Accuracy |
|-------|----------|
| Decision Tree | 0.5280 |
| KNN | 0.5253 |
| Random Forest | 0.5147 |
| LASSO | 0.5067 |
| Elastic Net | 0.5040 |
| SVM | 0.5040 |
| Ridge | 0.4987 |

### Confusion Matrices

#### LASSO
```
[[19 167]
 [18 171]]
```

#### Ridge
```
[[44 142]
 [46 143]]
```

#### Elastic Net
```
[[18 168]
 [18 171]]
```

#### Decision Tree
```
[[103 83]
 [94 95]]
```

#### Random Forest
```
[[62 124]
 [58 131]]
```

#### KNN
```
[[89 97]
 [81 108]]
```

#### SVM
```
[[0 186]
 [0 189]]
```

### ROC Curves Analysis
![ROC Curves](../fig/roc_curves.png)

## Analysis

1. **Overall Performance**:
   - All models show relatively por performance, with accuracies ranging from 49.87% to 52.80%
   - The Decision Tree achieved the highest accuracy at 52.80%, followed by KNN at 52.53%
   - Most models performed slightly better than random chance (50%)

2. **Model-Specific Observations**:
   - **Decision Tree**: Shows the most balanced predictions with a relatively even distribution in its confusion matrix
   - **KNN**: Demonstrates similar balanced behavior to the Decision Tree
   - **SVM**: Shows extreme bias, predicting only one class, indicating potential issues with parameter tuning
   - **Linear Models** (LASSO, Ridge, Elastic Net): Show similar performance patterns, suggesting limited linear separability in the data

3. **ROC Curve Analysis**:
   - The curves for most models stay relatively close to the diagonal line
   - The area under the curve (AUC) appears modest for all models

## Conclusions

1. The modest performance across all models suggests that predicting stock market movements using this feature set is challenging, which aligns with the efficient market hypothesis.

2. Tree-based methods (Decision Tree and Random Forest) and KNN showed slightly better performance, suggesting that local patterns might be more informative than global patterns.

3. The similar performance across different model types suggests that the predictive power of the current features might be limited.