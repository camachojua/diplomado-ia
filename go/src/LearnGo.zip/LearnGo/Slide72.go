package main

import "fmt"

func val1() bool {
	fmt.Println("val1 gets called")
	return true
}

func val2() bool {
	fmt.Println("val2 gets called")
	return false
}

func slide72() {
	if val1() && val2() {
		fmt.Println("Shouldn't print")
	}
	fmt.Println("Testing for the second time")
	if val2() && val1() {
		fmt.Println("Shouldn't print")
	}
	if val1() || val2() {
		fmt.Println("Line 24: The boolean expression is true")
	}
	if val2() || val1() {
		fmt.Println("Line 27: The boolean expression is true")
	}
}
