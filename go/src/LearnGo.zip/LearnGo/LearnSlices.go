package main

import "fmt"

func arrayToSlice(ns [30]int) ([]int, []int) {
	// var numbers = [...]int{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30}
	var divBy2 []int
	var divBy4 []int

	for _, v := range ns {

		if v%2 == 0 {
			divBy2 = append(divBy2, v)
		}
		if v%4 == 0 {
			divBy4 = append(divBy4, v)
		}
	}

	fmt.Println("there are ", len(divBy2), " numbers in divBy2")
	for i := range divBy2 {
		fmt.Print(divBy2[i], " ")
	}

	fmt.Println("\n\nthere are ", len(divBy4), " numbers in divBy4")
	for i := range divBy4 {
		fmt.Print(divBy4[i], " ")
	}

	return divBy2, divBy4
}

func compareSlices(s2, s4 []int) {

	for _, d2 := range s2 {
		for _, d4 := range s4 {
			if d2 == d4 {
				fmt.Printf("\n %d appears in both ", d2)
			}
		}
	}
	fmt.Println()
}

func reverseNumbers(ns [30]int) {

	for i, j := 0, len(ns)-1; i < j; i, j = i+1, j-1 {
		ns[i], ns[j] = ns[j], ns[i]
		fmt.Printf("i=%d, j=%d, n[%d]=%d \n", i, j, i, ns[i])
	}

	fmt.Println("After swapping")
	for i, v := range ns {
		fmt.Printf("i=%d, n[%d}=%d \n", i, i, v)
	}

}

func testSlices() {
	var numbers = [...]int{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30}

	dv2, dv4 := arrayToSlice(numbers)
	compareSlices(dv2, dv4)
	reverseNumbers(numbers)

}
