package main

import "fmt"

type myIntType int

func (a myIntType) aFunc(b, c int) int {
	a = a + (myIntType)(b+c)
	i := (int)(a) + b + c
	return i
}

func (a *myIntType) aFuncPtr(b, c int) int {
	*a = *a + (myIntType)(b+c)
	i := (int)(*a) + b + c
	return i
}

func testMethods() {
	var x myIntType
	var y int
	x = 123
	y = x.aFunc(10, 20)
	fmt.Printf("x=%d  y=%d \n", x, y)

	x = 123
	px := &x
	y = px.aFuncPtr(10, 20)
	fmt.Printf("x=%d  y=%d \n", x, y)

	fmt.Printf("done")
}
