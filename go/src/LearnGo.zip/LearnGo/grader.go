package main

import "fmt"

func g1() {
	fmt.Println("This is Grader using if / else")
	var grade = "NA"

	for score := 0; score < 100; score++ {

		if score >= 90 && score < 100 {
			grade = "A"
		} else if score >= 80 && score < 90 {
			grade = "B"
		} else if score >= 70 && score < 80 {
			grade = "C"
		} else if score >= 60 && score < 70 {
			grade = "D"
		} else if score < 60 {
			grade = "F"
		}
		fmt.Printf("score=%d   grade=%s\n", score, grade)
	}
}

func g2() {
	fmt.Println("This is Grader using switch")
	var grade = "NA"

	for score := 0; score < 100; score++ {

		switch {
		case score < 60:
			grade = "F"
		case score >= 60 && score < 70:
			grade = "D"

		case score >= 70 && score < 80:
			grade = "C"

		case score >= 80 && score < 90:
			grade = "B"
		case score >= 90 && score < 100:
			grade = "A"
		}
		fmt.Printf("score=%d   grade=%s\n", score, grade)
	}
}
