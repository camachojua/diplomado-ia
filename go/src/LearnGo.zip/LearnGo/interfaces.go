package main

import (
	"fmt"
	"math"
	"reflect"
)

//Figure is a global interface
type Figure interface {
	area() float64
	perimeter() float64
}

//Circle is a global struct
type Circle struct {
	radius float64
}

//Triangle is a global struct
type Triangle struct {
	a, b, c float64
}

//Rectangle is a global struct
type Rectangle struct {
	a, b float64
}

func (r Rectangle) area() float64 {
	return r.a * r.b
}
func (r Rectangle) perimeter() float64 {
	return 2*r.a + 2*r.b
}

func (c Circle) area() float64 {
	return math.Pi * c.radius * c.radius
}

func (c Circle) perimeter() float64 {
	return 2 * math.Pi * c.radius
}

func (t Triangle) area() float64 {
	s := (t.a + t.b + t.c) / 2.0
	q := float64((s * (s - t.a) * (s - t.b) * (s - t.c)))
	if q > 0.1 {
		return (math.Sqrt(q))
	}
	return 0.0
}

func (t Triangle) perimeter() float64 {
	return t.a + t.b + t.c
}

func calculate(f Figure) {

	var t = reflect.TypeOf(f)
	fmt.Printf("type=%s  ", t)
	fmt.Print("items in obj are ", f)
	fmt.Printf("\nArea = %f,  Perimeter=%f\n\n", f.area(), f.perimeter())
}

func testInterfaces() {

	r := Rectangle{a: 5, b: 6}
	calculate(r)

	c := Circle{radius: 5}
	calculate(c)

	var f Figure
	f = c
	calculate(f)

	f = r
	calculate(f)

}
