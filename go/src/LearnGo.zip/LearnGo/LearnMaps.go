// LearnMaps.go
package main

import "fmt"

var myMap map[string]float32
var names = [...]string{"Jeff Bezos", "Bill Gates", "Bernard Arnault", "Warren Buffett",
	"Amancio Ortega", "Mark Zuckerberg", "Larry Ellison", "Michael Bloomberg", "Larry Page"}
var worth = [...]float32{110.70, 103.50, 95.70, 79.70, 67.70, 67.60, 64.80, 56.10, 54.80}

func createMap() {
	myMap = make(map[string]float32)
	for i := 0; i < len(names); i++ {
		myMap[names[i]] = worth[i]
	}
}

func queryMap(s string) float32 {
	if val, ok := myMap[s]; ok {
		return val
	}
	return -1.0
}

func testMapCode() {
	createMap()
	for i := range names {
		fmt.Printf("%s worth is %f billions \n", names[i], queryMap(names[i]))
	}
	// test  no key condition
	fmt.Printf("%s worth is %f billions \n", "Juan Vargas", queryMap("Juan Vargas"))
}
