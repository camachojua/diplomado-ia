package main

import (
	"fmt"
)

type Vertex struct {
	X int
	Y int
}

func testVertex() {
	fmt.Println(Vertex{1, 123})
	var x = "Hello World"
	y := "Hola Amigo"

	y = "Hola Jeremy"

	fmt.Println(x)
	fmt.Println(y)
}
