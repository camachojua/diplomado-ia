package main

import (
	"fmt"
	"math"
)

func testPtrsAndRfs() {

	//	x := 123
	//	px := &x
	//	fmt.Println(x, px, *px)
	//
	//	s := "this is a string"
	//	ps := &s
	//	fmt.Println(s, ps, *ps)

	a := [...]int{1, 2, 3, 4}
	//	pa := &a
	//	pa1 := &a[1]
	//	fmt.Println(pa, &pa, *pa, pa1, *pa1, a, &a)

	var b int
	b = a[0]

	fmt.Println(&b, &a[0])

	var i int
	i = 123
	var pi *int
	pi = &i
	ri := &pi
	fmt.Println(i, pi, *pi, ri, &ri, *ri, **ri)

	j := &ri
	fmt.Println(j, *j, **j, ***j)

}

func testPointersAndReferences() {
	r := Rectangle{a: 5, b: 6}
	calculate(r)

	c := Circle{radius: 5}
	calculate(c)

	var f Figure
	f = c
	calculate(f)

	f = r
	calculate(f)
}

type fig struct {
	area, perimeter float32
}
type cir struct {
	fig    fig
	radius float32
}

func makeCir1(rad float32) *cir {
	f := new(fig)
	c := new(cir)
	f.area = 0.0
	f.perimeter = 0.0
	c.fig = *f
	c.radius = rad
	return c
}

func testFuncReturn1() {
	c1 := makeCir1(10.0)
	c2 := makeCir1(10.0)
	if c1 == c2 {
		fmt.Println(" c1 == c2")
	} else {
		fmt.Println(" c1 != c2")
	}
	if *c1 == *c2 {
		fmt.Println("*c1 == *c2")
	} else {
		fmt.Println("*c1 != *c2")
	}
	if &c1 == &c2 {
		fmt.Println("&c1 == &c2")
	} else {
		fmt.Println("&c1 != &c2")
	}
	c1a := c1
	if c1 == c1a {
		fmt.Println(" c1 == c1a")
	} else {
		fmt.Println(" c1 != c1a")
	}
	if &c1 == &c1a {
		fmt.Println("&c1 == &c1a")
	} else {
		fmt.Println("&c1 != &c1a")
	}
	c1.fig.area = math.Pi * c1.radius * c1.radius
	fmt.Printf("c1.Area=%f   c2.Area=%f  c1a.Area=%f\n", c1.fig.area, c2.fig.area, c1a.fig.area)
	fmt.Printf("done")
}

func makeCir(rad float32) cir {
	var f fig
	var c cir
	f.area = 0.0
	f.perimeter = 0.0
	c.fig = f
	c.radius = rad
	return c
}

func testFuncReturn() {
	c1 := makeCir(10.0)
	c2 := makeCir(10.0)
	if c1 == c2 {
		fmt.Println(" c1 == c2")
	} else {
		fmt.Println(" c1 != c2")
	}
	//if *c1 == *c2 { // not valid
	//	fmt.Println("*c1 == *c2")
	//} else {
	//	fmt.Println("*c1 != *c2")
	//}
	if &c1 == &c2 {
		fmt.Println("&c1 == &c2")
	} else {
		fmt.Println("&c1 != &c2")
	}
	c1a := c1
	if c1 == c1a {
		fmt.Println(" c1 == c1a")
	} else {
		fmt.Println(" c1 != c1a")
	}
	if &c1 == &c1a {
		fmt.Println("&c1 == &c1a")
	} else {
		fmt.Println("&c1 != &c1a")
	}
	c1.fig.area = math.Pi * c1.radius * c1.radius
	fmt.Printf("c1.Area=%f   c2.Area=%f  c1a.Area=%f\n", c1.fig.area, c2.fig.area, c1a.fig.area)
	fmt.Printf("done")
}

func calCirArea(c circle) {
	c.fig.area = math.Pi * c.radius * c.radius
}
func calCirPerim(c circle) {
	c.fig.perimeter = 2 * math.Pi * c.radius
}

func calCirAreaP(c *circle) {
	c.fig.area = math.Pi * c.radius * c.radius
}

func calCirPerimP(c *circle) {
	c.fig.perimeter = 2 * math.Pi * c.radius
}

func testPassingObjsToFunc() {
	var c1 circle
	c1.radius = 10
	calCirArea(c1)
	calCirPerim(c1)
	fmt.Printf("c1.Area=%f   c1.Perimeter=%f \n", c1.fig.area, c1.fig.perimeter)
	calCirAreaP(&c1)
	calCirPerimP(&c1)
	fmt.Printf("c1.Area=%f   c1.Perimeter=%f \n", c1.fig.area, c1.fig.perimeter)

	var c2 circle
	c2 = c1
	fmt.Printf("c2.Area=%f   c2.Perimeter=%f \n", c2.fig.area, c2.fig.perimeter)
	pc1 := &c1
	pc2 := &c2
	fmt.Printf("%d  %d\n", &pc1, &pc2)
	fmt.Printf("%d  %d\n", *pc1, *pc2)

	fmt.Printf("done")

}
