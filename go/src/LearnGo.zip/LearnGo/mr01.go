package main

import "fmt"

//func swap(x, y string) (string, string) {
//	return y, x
//}

// func swapz(x, y string, z int) (string, string, int) {
func swapz(x, y string, z int) {
	// return y, x, z
	fmt.Println(" What do you really want me to do, Jeremy??")
	return
	fmt.Println(" This will not be printed")

}

func testSwap() {
	// a, b, z := swapz("hello", "world", 42)
	swapz("hello", "world", 42)
	// fmt.Println(a, " ", b, " ", z+1)
}
