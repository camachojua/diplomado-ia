package main

import (
	"fmt"
	"math"
)

type figure struct {
	area, perimeter float32
}

type circle struct {
	fig    figure
	radius float32
}

type triangle struct {
	fig     figure
	a, b, c float32
}

type rectangle struct {
	fig  figure
	a, b float32
}

// circle constructor
func makeCircle(rad float32) circle {
	f := new(figure)
	c := new(circle)
	f.area = 0.0
	f.perimeter = 0.0
	c.fig = *f
	c.radius = rad
	return *c
}

// triange constructor
func makeTriangle(a, b, c float32) *triangle {
	f := new(figure)
	t := new(triangle)
	f.area = 0.0
	f.perimeter = 0.0
	t.fig = *f
	t.a = a
	t.b = b
	t.c = c
	return t
}

// rectangle constructor
func makeRectangle(a, b float32) *rectangle {
	f := new(figure)
	r := new(rectangle)
	f.area = 0.0
	f.perimeter = 0.0
	r.fig = *f
	r.a = a
	r.b = b
	return r
}

//circle methods
func (c *circle) area() {
	c.fig.area = math.Pi * c.radius * c.radius
}

func (c *circle) perimeter() {
	c.fig.perimeter = 2 * math.Pi * c.radius
}

//rectangle methods
func (r *rectangle) area() {
	r.fig.area = r.a * r.b
}

func (r *rectangle) perimeter() {
	r.fig.perimeter = 2 * (r.a + r.b)
}

//triangle methods

// heron formula to canculage triangle's area given sides a,b,c
// formula fails when internal angles are too small. In that case return 0
func (t *triangle) area() {
	s := (t.a + t.b + t.c) / 2.0
	q := float64((s * (s - t.a) * (s - t.b) * (s - t.c)))
	if q > 0.1 {
		t.fig.area = float32(math.Sqrt(q))
	} else {
		t.fig.area = 0.0
	}
}

func (t *triangle) perimeter() {
	t.fig.perimeter = t.a + t.b + t.c
}

func testFigures() {

	c := makeCircle(10.0)
	c.area()
	c.perimeter()
	fmt.Printf("Circle: Radius=%f, Area=%f, Perimeter=%f\n", c.radius, c.fig.area, c.fig.perimeter)

	r := makeRectangle(10.0, 20.0)
	r.area()
	r.perimeter()
	fmt.Printf("Rectangle: a=%f, b=%f, Area=%f, Perimeter=%f", r.a, r.b, r.fig.area, r.fig.perimeter)

}