package main

func main() {

	slide72()
	// Slide73()
	// genRand(10, 50, 100)
	// arrayToSlice()
	// testMapCode()
	// structF1()
	// testFigures()
	// testInterfaces()
	// testPtrsAndRfs()
	// testPointersAndReferences()
	// testFuncReturn()
	// testFuncReturn1()
	//testPassingObjsToFunc()
	//testMethods()
	// testArrays()
	//g1()
	//g2()
	// testSlices()
}
