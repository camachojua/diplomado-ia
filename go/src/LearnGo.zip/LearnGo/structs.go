package main

import "fmt"

type person struct {
	Name, Country string
	Worth         float32
	Age           int
	Source        string
}

var p = person{"Bill Gates", "United States", 103.5, 64, "Microsoft"}
var q = person{"Sergey Brin", "United States", 53.4, 46, "Google"}

type personSlice []person

var people = personSlice{{"Bill Gates", "United States", 103.5, 64, "Microsoft"},
	{"Sergey Brin", "USA", 53.4, 46, "Google"},
	{"Jeff Bezos", "USA", 110.70, 55, "Amazon"},
	{"Bernard Arnault", "France", 95.70, 70, "LVMH"},
	{"Warren Buffett", "USA", 79.70, 89, "Berkshire Hathaway"},
	{"Amancio Ortega", "Spain", 67.70, 83, "Zara"},
	{"Mark Zuckerberg", "USA", 67.60, 35, "Facebook"},
	{"Larry Ellison", "USA", 64.80, 75, "Oracle"},
	{"Michael Bloomberg", "USA", 56.10, 76, "Bloomberg"},
	{"Larry Page", "USA", 54.80, 46, "Alphabet Inc."},
	{"Carlos Slim", "Mexico", 54.30, 79, "América Móvil"},
	{"Sergey Brin", "USA", 53.40, 46, "Google"},
	{"Françoise Bettencourt Meyers", "France", 53.20, 66, "L'Oréal"},
	{"Steve Ballmer", "USA", 51.30, 63, "Microsoft"},
	{"Alice Walton", "USA", 50.40, 70, "Walmart"},
	{"Jim Walton", "USA", 50.40, 71, "Walmart"},
	{"S. Robson Walton", "USA", 50.20, 75, "Walmart"},
	{"Mukesh Ambani", "India", 49.70, 62, "Reliance Industries"},
	{"Charles Koch", "USA", 42.40, 84, "Koch Industries"},
	{"Jack Ma", "China", 37.80, 55, "Alibaba Group"},
	{"Ma Huateng", "China", 37.70, 48, "Tencent"},
}

func structF1() {
	p.Age++
	p.Worth += 10.0

	fmt.Printf("%s age is %d\n", p.Name, p.Age)

	sba := &q.Age
	sbs := &q.Source
	*sbs = *sbs + " + Alphabet"
	fmt.Printf("%s age is %d\n", q.Name, *sba)
	fmt.Printf("%s souce is %s\n", q.Name, *sbs)
	printPerson(&q)

	var bill = &p
	bill.Worth += 5.0
	(*bill).Age += 2

	printPerson(bill)

	ss := "Carlos Slim"
	pp := personByName(ss)
	if pp != nil {
		printPerson(pp)
	}

	ss = "Juan Vargas"
	pp = personByName(ss)
	if pp != nil {
		printPerson(pp)
	} else {
		fmt.Printf("%s is not in the array \n", ss)
	}

	ss = "Jeff Bezos"
	pp = personByName(ss)
	printPerson(pp)
}

func personByName(aName string) *person {
	for _, v := range people {
		if aName == v.Name {
			return &v
		}
	}
	return nil
}

func printPerson(p *person) {
	fmt.Printf("Name = %s,  Country=%s, Worth=%f, Age=%d, Source=%s\n", p.Name, p.Country, p.Worth, p.Age, p.Source)
}

