package main

import (
	"fmt"
	"math/rand"
	"time"
)

/*
func c1(f func(x float32) float32) {
	return func(x float32) float32 {
		return f(x)
	}
}
*/
/*
func Compose( f, g 	func(x float) float)
					func(x float) float {
	return func (x float) float {
		return f(g(x))
	}
}
*/

// squares returns a function value, which is aka a closure function.
// Squares in turn returns the next number, squared, each time it is called.
// Note that the closure maintains its own state in "x"
// so that each time it is called, x is incremented and the
// square of that value is returned. Thus x is 'hidden' within squares
func squares() func() int {
	var x int
	return func() int {
		x++
		return x * x
	}
}

func testSquares() {

	f := squares()
	fmt.Println(f()) // "1"
	fmt.Println(f()) // "2"
	fmt.Println(f()) // "3"
	fmt.Println(f()) // "4"
	fmt.Println(f()) // "5"
}

func f01(i int) {
	for j := 0; j < 5; j++ {
		fmt.Println(i, ":", j)
	}
}

func testConcSample01() {
	for i := 0; i < 5; i++ {
		go f01(i)
	}
	var input string
	fmt.Scanln(&input)
}

func f02(i int) {
	for j := 0; j < 5; j++ {
		fmt.Println(i, ":", j)
		amt := time.Duration(rand.Intn(100))
		time.Sleep(time.Millisecond * amt)
	}
}

func testConcSample02() {
	for i := 0; i < 10; i++ {
		go f02(i)
		amt := time.Duration(rand.Intn(500))
		time.Sleep(time.Millisecond * amt)
	}
	var input string
	fmt.Scanln(&input)
}

func pinger(c chan string) {
	for i := 0; ; i++ {
		c <- "ping"
		time.Sleep(time.Millisecond * 50)
	}
}

func ponger(c chan string) {
	for i := 0; ; i++ {
		c <- "pong"
		time.Sleep(time.Millisecond * 400)
	}
}

func printer(c chan string) {
	for {
		msg := <-c
		fmt.Println(msg)
		time.Sleep(time.Millisecond * 500)
	}
}

func testConcSample03() {
	// var c chan string = make(chan string) // this is deprecated
	c := make(chan string)
	go pinger(c)
	go printer(c)
	var input string
	fmt.Scanln(&input)
}

func testConcSample04() {
	c := make(chan string)
	go pinger(c)
	go ponger(c)
	go printer(c)
	var input string
	fmt.Scanln(&input)
}

func testConcSample05() {
	c1 := make(chan string)
	c2 := make(chan string)

	go func() {
		for {
			c1 <- "from 1"
			time.Sleep(time.Second * 1)
		}
	}()

	go func() {
		for {
			c2 <- "from 2"
			time.Sleep(time.Second * 3)
		}
	}()

	go func() {
		for {
			select {
			case msg1 := <-c1:
				fmt.Println(msg1)
			case msg2 := <-c2:
				fmt.Println(msg2)
			}
		}
	}()

	var input string
	fmt.Scanln(&input)
}

func testConcSample06() {
	c1 := make(chan string)
	c2 := make(chan string)

	go func() {
		for {
			c1 <- "C1F1"
			time.Sleep(time.Millisecond * 250)
		}
	}()

	go func() {
		for {
			c1 <- "C1F2"
			time.Sleep(time.Millisecond * 500)
		}
	}()

	go func() {
		for {
			c1 <- "C1F3"
			time.Sleep(time.Millisecond * 500)
		}
	}()

	go func() {
		for {
			c2 <- "C2F1"
			time.Sleep(time.Millisecond * 250)
		}
	}()

	go func() {
		for {
			c2 <- "C2F2"
			time.Sleep(time.Millisecond * 500)
		}
	}()

	go func() {
		for {
			c2 <- "C2F3"
			time.Sleep(time.Millisecond * 500)
		}
	}()

	go func() {
		for {
			select {
			case msg1 := <-c1:
				fmt.Println(msg1)
			case msg2 := <-c2:
				fmt.Println(msg2)
			}
		}
	}()

	var input string
	fmt.Scanln(&input)
}

func main() {

	fmt.Println("HERE WE GO!")
	testSquares()
	// print(Compose(sin, cos)(0.5))
	// print(c1(sin)(0.5))
	FiboTesta()
	// TestWebClock()
	// TestMultipleEcho()
	// testConcSample01()
	// testConcSample02()
	// testConcSample03()
	// testConcSample04()
	// testConcSample05()
	// testConcSample06()
}
