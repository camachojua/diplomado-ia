package main

/*++
MultipleEcho contains code taken from Chapter 8 of Donovan's GoLang Book.

The purpose of the code is to illustrate the concurrency that is available at the
net package.

To run the code

1. Ensure that function TestMultipleEcho is called from makinaKonkurencjaMain
2. Ensure that there is only one function called handleConn in the entire mk library
3. cd $HOME/code/go/src/makinaKonkurencjaMain
4. go build mkMain.go
5. ./mkMain
6. In a separate term run from any directory

		nc localhost 8000

The term where the nc command was isued will display

	hh:mm:ss

	until the program is stopped.

--*/

import (
	"bufio"
	"fmt"
	"io"
	"log"
	"net"
	"os"
	"strings"
	"time"
)

// traditional handleConn function
func handleConnTraditional(c net.Conn) {
	io.Copy(c, c) //ignore errors
	c.Close()
}

func handleConn(c net.Conn) {
	input := bufio.NewScanner(c)
	for input.Scan() {
		echo(c, input.Text(), 1*time.Second)
	}

	//ignore potential errors from input.Err()
	c.Close()
}

func mustCopy(dst io.Writer, src io.Reader) {
	if _, err := io.Copy(dst, src); err != nil {
		log.Fatal(err)
	}
}

func echo(c net.Conn, shout string, delay time.Duration) {
	fmt.Fprintln(c, "\t", strings.ToUpper(shout))
	time.Sleep(delay)
	fmt.Fprintln(c, "\t", shout)
	time.Sleep(delay)
	fmt.Fprintln(c, "\t", strings.ToLower(shout))
}

func TestMultipleEcho() {
	conn, err := net.Dial("tcp", "localhost:8000")
	if err != nil {
		log.Fatal(err)
	}
	defer conn.Close()
	go mustCopy(os.Stdout, conn)
	mustCopy(conn, os.Stdin)
}
