package main

/*++
TestWebClock contains code taken from Chapter 8 of Donovan's GoLang Book.

The purpose of the code is to illustrate the concurrency that is available at the
net package.

To run the code

1. cd $HOME/code/go/src/makinaKonkurencjaMain
2. go build mkMain.go
3. ./mkMain
4. In a separate term run from any directory

		nc localhost 8000

The term where the nc command was isued will display

	hh:mm:ss

	until the program is stopped.

--*/

import (
	"log"
	"net"
)

/*++   coment out handleConn in the TestMultipleEcho file and uncomment the code below,
	   otherwise the code will not compile.

func handleConn(c net.Conn) {
	defer c.Close()
	for {
		_, err := io.WriteString(c, time.Now().Format("15:04:05\n"))
		if err != nil {
			return // client disconneted?
		}
		time.Sleep(1 * time.Second)
	}
}
--*/

func TestWebClock() {
	listener, err := net.Listen("tcp", "localhost:8000")
	if err != nil {
		log.Fatal(err)
	}
	for {
		conn, err := listener.Accept()
		if err != nil {
			log.Print(err) // maybe connection aborted
			continue
		}
		handleConn(conn) //handle one connection at a time
	}
}
