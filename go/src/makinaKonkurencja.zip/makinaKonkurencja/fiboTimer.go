package main

import (
	"fmt"
	"time"
)

// FiboTesta is the entry point for the code in this file.
// The code creates Go Routines that print stuff and then
// engages in a long computation to calculate the Fibbonaci(45)
// the output produced illustrates the concurrent nature of the code
func FiboTesta() {
	go printDots(10 * time.Millisecond)
	go printStars(10 * time.Millisecond)
	go prCurrentTime(10 * time.Millisecond)
	const n = 45
	fibN := fib(n) // slow
	fmt.Printf("\r\n\nFibonacci(%d) = %d\n", n, fibN)
}

func prCurrentTime(delay time.Duration) {
	for {
		t := time.Now().Format("15:04:05")
		fmt.Println(t)
		time.Sleep(delay)
	}
}

func printDots(delay time.Duration) {
	for {
		for _, r := range `...` {
			fmt.Printf("\r%c", r)
			time.Sleep(delay)
		}
	}
}

func printStars(delay time.Duration) {
	for {
		for _, r := range `***` {
			fmt.Printf("\r%c", r)
			time.Sleep(delay)
		}
	}
}

func fib(x int) int {
	if x < 2 {
		return x
	}
	return fib(x-1) + fib(x-2)
}
