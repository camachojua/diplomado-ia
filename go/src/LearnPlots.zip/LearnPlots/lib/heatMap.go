package learnPlots

import (
	"fmt"
	"log" // equivalent to "import as" from python ;-)
	"math"
	"os"

	"gonum.org/v1/plot"
	"gonum.org/v1/plot/palette"
	"gonum.org/v1/plot/plotter"
	"gonum.org/v1/plot/vg"
	"gonum.org/v1/plot/vg/draw"
	"gonum.org/v1/plot/vg/vgimg"

	// "github.com/gonum/plot"
	"gonum.org/v1/gonum/mat"
)

/*
	LearnPlots stands for "Learn how to create charts, plots and data visualization stuff
	in GoLang". As the name suggests, this is a project to get a deeper dive into how to
	use the GoNum/Plot library for data visualization. Note that the code is using V1 of
	gonum/plot which is now updated via gonum.org, which I guess is a good sign of things
	moving forward

		Juan E. Vargas
		April 2018
*/

type offsetUnitGrid struct {
	XOffset, YOffset float64
	Data             mat.Matrix
}

func (g offsetUnitGrid) Dims() (c, r int) { r, c = g.Data.Dims(); return c, r }

func (g offsetUnitGrid) Z(c, r int) float64 { return g.Data.At(r, c) }

func (g offsetUnitGrid) X(c int) float64 {
	_, n := g.Data.Dims()
	if c < 0 || c >= n {
		panic("index out of range")
	}
	return float64(c) + g.XOffset
}

func (g offsetUnitGrid) Y(r int) float64 {
	m, _ := g.Data.Dims()
	if r < 0 || r >= m {
		panic("index out of range")
	}
	return float64(r) + g.YOffset
}

type integerTicks struct{}

func (integerTicks) Ticks(min, max float64) []plot.Tick {
	var t []plot.Tick
	for i := math.Trunc(min); i <= max; i++ {
		t = append(t, plot.Tick{Value: i, Label: fmt.Sprint(i)})
	}
	return t
}

func SampleHeatMap() {
	//m_old := offsetUnitGrid{
	//	// XOffset: -2,
	//	XOffset: -2,
	//	YOffset: -1,
	//	Data: mat.NewDense(4, 4, []float64{
	//		1, 2, 3, 4,
	//		5, 6, 7, 8,
	//		9, 10, 11, 12,
	//		13, 14, 15, 16,
	//	})}

	m := offsetUnitGrid{
		// XOffset: -2,
		XOffset: -1,
		YOffset: -1,
		Data: mat.NewDense(10, 10, []float64{
			100, 99, 98, 97, 96, 95, 94, 93, 92, 91,
			90, 89, 88, 87, 86, 85, 84, 83, 82, 81,
			80, 79, 78, 77, 76, 75, 74, 73, 72, 71,
			70, 69, 68, 67, 66, 65, 64, 63, 62, 61,
			60, 59, 58, 57, 56, 55, 54, 53, 52, 51,
			50, 49, 48, 47, 46, 45, 44, 43, 42, 41,
			40, 39, 38, 37, 36, 35, 34, 33, 32, 31,
			30, 29, 28, 27, 26, 25, 24, 23, 22, 21,
			20, 19, 18, 17, 16, 15, 14, 13, 12, 11,
			10, 9, 8, 7, 6, 5, 4, 3, 2, 1,
		})}

	pal := palette.Heat(100, 1)
	h := plotter.NewHeatMap(m, pal)
	h.Max = 100.0
	h.Min = 0.0

	p := plot.New()
	p.Title.Text = "Heat map"

	p.X.Tick.Marker = integerTicks{}
	p.Y.Tick.Marker = integerTicks{}

	p.Add(h)

	// Create a legend.
	l := plot.NewLegend()

	thumbs := plotter.PaletteThumbnailers(pal)

	for i := len(thumbs) - 1; i >= 0; i-- {
		t := thumbs[i]
		if i != 0 && i != len(thumbs)-1 {
			l.Add("", t)
			continue
		}
		var val float64
		switch i {
		case 0:
			val = h.Min
		case len(thumbs) - 1:
			val = h.Max
		}
		l.Add(fmt.Sprintf("%6.2f ", val), t)
	}

	p.X.Padding = 0
	p.Y.Padding = 0
	p.X.Max = 1.5
	p.Y.Max = 1.5

	img := vgimg.New(250, 175)
	dc := draw.New(img)

	l.Top = true
	// Calculate the width of the legend.
	r := l.Rectangle(dc)
	legendWidth := r.Max.X - r.Min.X
	// l.YOffs = -p.Title.Font.Extents().Height // Adjust the legend down a little.
	// l.YOffs = p.Title

	l.Draw(dc)
	dc = draw.Crop(dc, 0, -legendWidth-vg.Millimeter, 0, 0) // Make space for the legend.
	p.Draw(dc)
	w, err := os.Create("../plots/heatMap.png")
	if err != nil {
		log.Panic(err)
	}
	png := vgimg.PngCanvas{Canvas: img}
	if _, err = png.WriteTo(w); err != nil {
		log.Panic(err)
	}
}
