package learnPlots

/*
FileName: linRegWikipedia.go

As I was writing notes about linear regression for machine learning I stumbled upon the article on that
topic from wikipedia ( https://en.wikipedia.org/wiki/Linear_least_squares_(mathematics) )

I liked the article so much that I decided to write the code in GoLang to further complement the article.

*/

import (
	"image/color"

	"gonum.org/v1/plot"
	"gonum.org/v1/plot/plotter"
	"gonum.org/v1/plot/vg"
	"gonum.org/v1/plot/vg/draw"
	//"github.com/gonum/plot"
	//"github.com/gonum/plot/plotter"
	//"github.com/gonum/plot/vg"
	//"github.com/gonum/plot/vg/draw"
)

// type XYs []struct{ X, Y float64 }

func LinRegWikipedia() {

	// Create a new plot, set title and axis labels.
	p := plot.New()
	p.Title.Text = "Example from Wikipedia Linear Least Squares"
	p.X.Label.Text = "X"
	p.Y.Label.Text = "Y"

	p.Legend.Top = true
	// p.Legend.Add("sin(x)", sin)

	p.Legend.ThumbnailWidth = 0.5 * vg.Inch

	// Set the axis ranges.  Unlike other data sets,
	// functions don't set the axis ranges automatically
	// since functions don't necessarily have a
	// finite range of x and y values.
	p.X.Min = 0
	p.X.Max = 5
	p.Y.Min = 4
	p.Y.Max = 10

	// p.NominalX("1", "2", "3", "4", "5")
	// p.NominalY("4", "5", "6", "7", "8", "9", "10")

	// Draw a grid behind the data
	g := plotter.NewGrid()
	g.Vertical.Width = vg.Points(1)
	g.Vertical.Dashes = []vg.Length{vg.Points(1), vg.Points(1)}
	g.Vertical.Color = color.RGBA{R: 150, G: 150, B: 150, A: 255}
	g.Horizontal.Width = vg.Points(1)
	g.Horizontal.Dashes = []vg.Length{vg.Points(1), vg.Points(1)}
	g.Horizontal.Color = color.RGBA{R: 150, G: 150, B: 150, A: 255}
	p.Add(g)

	p.Add(g)

	n := 4
	d := genData(n)
	printXYvalues(d)

	s, err := plotter.NewScatter(d)

	if err != nil {
		panic(err)
	}
	s.GlyphStyle.Color = color.RGBA{R: 255, B: 128, A: 255}
	// s.Shape = draw.PyramidGlyph{} // draws a filled triangle
	s.Shape = draw.CircleGlyph{} // draws a filled circle
	s.Radius = 4
	p.Add(s)

	// draw line y = 3.5 + 1.4x

	l := genLine(2)
	// Make a line plotter and set its style.
	ll, err := plotter.NewLine(l)
	if err != nil {
		panic(err)
	}
	ll.LineStyle.Width = vg.Points(2)
	// ll.LineStyle.Dashes = []vg.Length{vg.Points(5), vg.Points(5)}
	ll.LineStyle.Color = color.RGBA{B: 255, A: 255}
	p.Add(ll)

	// Save the plot to a PNG file.
	if err := p.Save(4*vg.Inch, 4*vg.Inch, "../plots/linRegWikipedia.png"); err != nil {
		panic(err)
	}
}

// func genData creates the data set in the article
func genData(n int) plotter.XYs {
	pts := make(plotter.XYs, n)
	pts[0].X = 1
	pts[0].Y = 6
	pts[1].X = 2
	pts[1].Y = 5
	pts[2].X = 3
	pts[2].Y = 7
	pts[3].X = 4
	pts[3].Y = 10
	return pts
}

// func genLine creates the points for the Line in the article
func genLine(n int) plotter.XYs {
	pts := make(plotter.XYs, n)
	pts[0].X = 0
	pts[0].Y = 3.5
	//pts[1].X = -(3.5 / 1.4)
	//pts[1].Y = 0
	//pts[1].X = 0.5 / 1.4
	//pts[1].Y = 4
	pts[1].X = 5
	pts[1].Y = 10.5
	return pts
}

/*
func printXYvalues(p plotter.XYs) {
	println(" p.Len =", p.Len())
	for i := 0; i < p.Len(); i++ {
		x, y := p.XY(i)
		fmt.Printf("i= %d", i)
		fmt.Printf("  x=%6.2f", x)
		fmt.Printf("  y=%6.2f", y)
		fmt.Printf("\n")
	}
}
*/
