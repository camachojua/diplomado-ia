package learnPlots

import (
	"fmt"
	"image/color"
	"math"
	"math/rand"

	"gonum.org/v1/plot"
	"gonum.org/v1/plot/plotter"
	"gonum.org/v1/plot/vg"
	"gonum.org/v1/plot/vg/draw"
	//"github.com/gonum/plot"
	//"github.com/gonum/plot/plotter"
	//"github.com/gonum/plot/vg"
	//"github.com/gonum/plot/vg/draw"
)

// type XYs []struct{ X, Y float64 }

// Bishop_mlpl_ex1_1 has to be in capital for name to be global
func Bishop_mlpr_ex1_1() {

	// Create a new plot, set title and axis labels.
	p := plot.New()
	p.Title.Text = "Example in Section 1.1 of C. Bishop PRML Book"
	p.X.Label.Text = "X"
	p.Y.Label.Text = "Y"

	// Create a sine function, shifted and scaled to be nicely visible on the plot.
	sin := plotter.NewFunction(func(x float64) float64 { return math.Sin(x) })
	//sin.Dashes = []vg.Length{vg.Points(4), vg.Points(5)}
	//sin.Width = vg.Points(4)
	sin.Color = color.RGBA{G: 255, A: 255}

	// Add the functions and their legend entries.

	p.Add(sin)
	p.Legend.Top = true
	p.Legend.Add("sin(x)", sin)

	p.Legend.ThumbnailWidth = 0.5 * vg.Inch

	// Set the axis ranges.  Unlike other data sets,
	// functions don't set the axis ranges automatically
	// since functions don't necessarily have a
	// finite range of x and y values.
	p.X.Min = 0
	p.X.Max = 10
	p.Y.Min = -2
	p.Y.Max = +3

	rand.Seed(int64(0))
	n := 100
	linePointsData := sineRandom(n)

	printXYvalues(linePointsData)
	p.Add(sin)

	// Make a line plotter with points and set its style.
	lpLine, lpPoints, err := plotter.NewLinePoints(linePointsData)
	if err != nil {
		panic(err)
	}
	lpLine.Color = color.RGBA{G: 255, A: 255}
	// lpPoints.Shape = draw.PyramidGlyph{}
	lpPoints.Shape = draw.RingGlyph{}
	lpPoints.Color = color.RGBA{B: 255, A: 255}

	// Add the plotters to the plot, with a legend
	// entry for each
	// p.Add(lpLine, lpPoints)
	// p.Legend.Add("line points", lpLine, lpPoints)

	p.Add(lpPoints)
	p.Legend.Add("sin(x) + rand", lpPoints)

	// Save the plot to a PNG file.
	if err := p.Save(4*vg.Inch, 4*vg.Inch, "../plots/bishop_prml_ex1.1.png"); err != nil {
		panic(err)
	}
}

// sineRandom  returns a set of points that follow y = sin(2*pi*x) + random.
// math.Sin(x) + random
func sineRandom(n int) plotter.XYs {
	pts := make(plotter.XYs, n)
	for i := range pts {
		if i == 0 {
			pts[i].X = 0
		} else {
			pts[i].X = pts[i-1].X + 0.1
		}
		pts[i].Y = math.Sin(pts[i].X) - 0.25 + 0.5*rand.Float64()
	}
	return pts
}

func printXYvalues(p plotter.XYs) {
	println(" p.Len =", p.Len())
	for i := 0; i < p.Len(); i++ {
		x, y := p.XY(i)
		fmt.Printf("i= %d", i)
		fmt.Printf("  x=%6.2f", x)
		fmt.Printf("  y=%6.2f", y)
		fmt.Printf("\n")
	}
}
