package main

import (
	lp "LearnPlots/lib"
	"fmt"
)

/*
	LearnPlots stands for "Learn how to create charts and stuff in GoLang". As the name suggests,
	this is a project to get a deeper dive into how to use GoNum/Plot library for data visualization.append

		Juan E. Vargas
		April 2018
*/

func main() {
	fmt.Println("Here we GO!")

	//fmt.Println("Run Points()")
	// lp.Points()

	//fmt.Println("Run Functions()")
	//lp.Functions()

	//fmt.Println("Run LinRegWikipedia()")
	//lp.LinRegWikipedia()

	// fmt.Println("Run Bishop MLPR Example 1.1")
	// lp.Bishop_mlpr_ex1_1()

	//fmt.Println("Run Heat Map")
	//lp.SampleHeatMap()

	// fmt.Println("Run Bubbles")
	// lp.Bubbles()

	//fmt.Println("Quartile")
	// lp.Quartile()

	// fmt.Println("BoxPlot")
	//lp.BoxPlot()

	//fmt.Println("Histogram")
	// lp.Histogram()

	//fmt.Println("BarChart")
	//lp.BarChart()

	//fmt.Println("ErrPoints")
	lp.ErrPoints()

	//fmt.Println("Relabling")
	lp.Relabebling()

	fmt.Println("Done!")
}
