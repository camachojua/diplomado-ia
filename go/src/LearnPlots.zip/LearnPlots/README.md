
# LearnPlots

LearnPlots is the "V2" of a lib I am writing for a demo on the topic of learning to plot stuff in Golang.

The version of go is 1.22.4


## UPDATE 1: August 16, 2024

In preparation for the UNAM AI/Data Science Certificate, I reopened this project.  
The newer versions of Go use modules, which must be specified via a go.mod file to find where and how the libs/APIS that the code will use are located. 

$GOPATH and $GOROOT need to be defined> I do so in /etc/profile

    export PATH=$PATH:/usr/local/go/bin
    export GOROOT=/usr/local/go
    export PATH=$PATH:$GOROOT/bin
    ### export GOPATH=$HOME/code/go
    ## OR
    export GOPATH=/drv3/hm3/code/go

As I went through the update in August 16, 2024, I found that the directory original directory configuration gave problems.
Therefore I changed the configuration as folows:

The code is in a root directory, which is /drv3/hm3/code/go/src/LearnPlots  and consists of the following directories

	/drv3/hm3/code/go/src/LearnPlots/lib	contains the module and package definitions

	/drv3/hm3/code/go/src/LearnPlots/cmd	contains code that uses the module and the package.

	/drv3/hm3/code/go/src/LearnPLots/plots  contains plots produced by the code


The go.mod file was created as follows:


	cd /drv3/hm3/code/go/src/LearnPlots
	// create directories ../lib and ../cmd
	// put stuff in ../lib and in ../cmd

	cd /drv3/hm3/code/go/src/LearnPlots
	go mod init 
	go mod tidy

The content of go.mod is

```
module LearnPlots

go 1.22.6

require (
	gonum.org/v1/gonum v0.15.1
	gonum.org/v1/plot v0.14.0
)

require (
	git.sr.ht/~sbinet/gg v0.5.0 // indirect
	github.com/ajstarks/svgo v0.0.0-20211024235047-1546f124cd8b // indirect
	github.com/campoy/embedmd v1.0.0 // indirect
	github.com/go-fonts/liberation v0.3.2 // indirect
	github.com/go-latex/latex v0.0.0-20231108140139-5c1ce85aa4ea // indirect
	github.com/go-pdf/fpdf v0.9.0 // indirect
	github.com/golang/freetype v0.0.0-20170609003504-e2365dfdc4a0 // indirect
	github.com/pmezard/go-difflib v1.0.0 // indirect
	golang.org/x/exp v0.0.0-20231110203233-9a3e6036ecaa // indirect
	golang.org/x/image v0.14.0 // indirect
	golang.org/x/text v0.14.0 // indirect
)

replace learnPlots => /drv3/hm3/code/go/src/LearnPlots
```

Run from ../cmd/lpmain.go

