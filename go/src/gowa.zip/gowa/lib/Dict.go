package gowa

import (
	"encoding/xml"
	"fmt"
	"io"
	"io/ioutil"
	"os"
)

/*
Dict.Go contains functions and methods related to the Dictionary I am using to describe
the DB, its tables and so forth.

*/

// Init initializes fields in dataDict to default values

/*
	type DBDict struct {
		FileName    string   `xml:"fileName"`
		Description string   `xml:"description"`
		Directory   string   `xml:"directory"`
		Port        string   `xml:"port"`
		UserId      string   `xml:"userId"`
		UserPwd     string   `xml:"userPwd"`
		DictFile    string   `xml:"dictFile"`
		ReadMeFile  string   `xml:"readMeFile"`
		Tables      []string `xml:"tables"`
*/
func (aDD *DBDict) Init() {
	aDD.FileName = ""
	aDD.Description = ""
	aDD.Directory = ""
	aDD.Port = ""
	aDD.UserID = ""
	aDD.UserPwd = ""
}

// InitConnStr enters the conn params. Currently using /employees DB on mysql
func (aDD *DBDict) InitConnStr() {
	aDD.FileName = "/employees" // name is what MySQL will see
	aDD.Port = ":3306"
	aDD.URL = "(127.0.0.1)"
	aDD.Server = "mysql"
	aDD.Protocol = "@tcp"
	aDD.UserID = "juan"
	aDD.UserPwd = "Harbison211"
	aDD.ConnStr = aDD.UserID + ":" + aDD.UserPwd + aDD.Protocol + aDD.URL + aDD.FileName
}

// Print is a method of DataDictionary that prints out the fields in the obj
func (dd *DBDict) Print() {

	output, err := xml.MarshalIndent(dd, "  ", "    ")
	if err != nil {
		fmt.Printf("error: %v\n", err)
	}
	os.Stdout.Write(output)
}

// Write is a method of DataDictionary that writes the data dictionary into a file using  XML format
func (dd *DBDict) Write(dictFileName string) {

	// DatDir is defined in init.go

	var aDD DBDict
	aDD.FileName = "/employees"
	aDD.Description = "desc"
	aDD.Directory = "dir"
	aDD.Port = "port"
	aDD.UserID = "Juan"
	aDD.UserPwd = "Harbison211"
	aDD.DictFile = "/home/juan/Data/sql/employees/EmployeesDict.xml"

	xmlFile, err := os.Create(aDD.DictFile)
	if err != nil {
		panic(err)
	}
	defer xmlFile.Close()

	xmlWriter := io.Writer(xmlFile)

	enc := xml.NewEncoder(xmlWriter)
	enc.Indent("  ", "    ")
	if err := enc.Encode(aDD); err != nil {
		fmt.Printf("error: %v\n", err)
	}

	xmlFile.Close()
	fmt.Println("XML data written to ", xmlFile.Name())
	// os.Exit(1)
}

// Read is a method of DataDictionary that expects a fileName as argument. The method loads the file
// into the dd obj tha invoked the method
func (dd *DBDict) Read(ddFilePath string) {

	//if len(aDictFilePath) == 0 {
	//	panic("ReadDataDictionary file name is empty")
	//}

	xmlFile, err := os.Open(ddFilePath)
	if err != nil {
		fmt.Println("Error opening file:", err)
		panic("ReadDataDictionary coud not open Dict File")
	}
	defer xmlFile.Close()

	XMLdata, _ := ioutil.ReadAll(xmlFile)

	xml.Unmarshal(XMLdata, dd)

	// fmt.Println(dd.DataConfig)
}
