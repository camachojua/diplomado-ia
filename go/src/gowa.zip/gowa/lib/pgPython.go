package gowa

import (
	"fmt"
	"html/template"

	//"log"
	"net/http"
)

func PgPython(w http.ResponseWriter, r *http.Request) {
	if r.Method == "GET" {
		fmt.Println("GET before parsing")
		t, _ := template.ParseFiles(GoWaDirHtml + "PgPython.html")
		t.Execute(w, nil)
		fmt.Println("GET after parsing")
	}

	if r.Method == "POST" {

		var locStr string
		locStr = "THANK YOU. YOUR PYTHON CODE \n\n"
		fmt.Fprintf(w, locStr)

		r.ParseForm()
		pgPyCodeStr := fmt.Sprintf("%s %s ", template.HTMLEscapeString(r.Form.Get("pgpy-text")), "\n")
		fmt.Fprintf(w, pgPyCodeStr)
		fmt.Println(pgPyCodeStr)
		locStr = "\n\n PRODUCES THE FOLLOWING OUTPUT \n\n"
		fmt.Fprintf(w, locStr)
		fmt.Println(locStr)

		locStr = "\n\n ... some output here...  \n\n"
		fmt.Fprintf(w, locStr)
		fmt.Println(locStr)

	}
}
