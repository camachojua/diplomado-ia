package gowa

import (
	"fmt"
	"html/template"
	"net/http"
)

type S3Details struct {
	Fname   string
	Lname   string
	Country string
}

func Server3(w http.ResponseWriter, r *http.Request) {
	if r.Method == "GET" {
		fmt.Println("GET before parsing")
		t, _ := template.ParseFiles(GoWaDirHtml + "Server3.html")
		t.Execute(w, nil)
		fmt.Println("GET after parsing")
	}

	if r.Method == "POST" {
		r.ParseForm()
		fmt.Println("POST After parsing")
		fStr := fmt.Sprintf("You selected  \n")
		fmt.Fprintf(w, fStr)

		d := S3Details{
			Fname:   r.FormValue("fname"),
			Lname:   r.FormValue("lname"),
			Country: r.FormValue("country"),
			// do something with details
		}
		// just to ensure that data is captured within a struct
		// fmt.Fprintf(w, d.Country, d.Fname, d.Lname)
		fmt.Println("c = ", d.Country, " l = ", d.Lname, " f = ", d.Fname)
		fStr = fmt.Sprintf("%s  %s  %s \n", d.Country, d.Fname, d.Lname)
		fmt.Fprintf(w, fStr)
		fmt.Println(fStr)
		fmt.Println("POST after parsing")

	}

}
