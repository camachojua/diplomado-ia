package gowa

// https://github.com/joncalhoun/form

import (
	"fmt"
	"html/template"
	"net/http"
	// "os"
)

//"html/template"
//"net/http"

type ContactDetails struct {
	Email   string
	Subject string
	Message string
}

func ContactForm(w http.ResponseWriter, r *http.Request) {
	fmt.Println("method:", r.Method)
	if r.Method == "GET" {
		t, _ := template.ParseFiles(GoWaDirHtml + "contactform.html")
		t.Execute(w, nil)
	}
	if r.Method == "POST" {
		locStr := "POST METHOD\n"
		fmt.Fprintf(w, locStr)

		r.ParseForm()

		usrStr := fmt.Sprintf("%s %s %s", "eMail:  ", r.Form.Get("email"), "\n")
		fmt.Fprintf(w, usrStr)
		fmt.Println(usrStr)
		// fmt.Println( r.Form.Get("username"))

		subStr := fmt.Sprintf("%s %s %s", "Subject: ", r.Form.Get("subject"), "\n")
		fmt.Fprintf(w, subStr)
		fmt.Println(subStr)

		msgStr := fmt.Sprintf("%s %s %s", "Message: ", r.Form.Get("message"), "\n")
		fmt.Fprintf(w, msgStr)
		fmt.Println(msgStr)
	}

}

func OldContactForm(w http.ResponseWriter, r *http.Request) {

	fmt.Println("method:", r.Method)

	tmpl := template.Must(template.ParseFiles(GoWaDirHtml + "contactform.html"))
	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			tmpl.Execute(w, nil)
			return
		}

		details := ContactDetails{
			Email:   r.FormValue("email"),
			Subject: r.FormValue("subject"),
			Message: r.FormValue("message"),
		}

		// do something with details
		_ = details

		tmpl.Execute(w, struct{ Success bool }{true})
	})

	// dont think this is necessary
	// http.ListenAndServe(":1234", nil)
}
