package gowa

//"fmt"

func VerifyDropDown(s1 []string, s2 []string) bool {
	if s1 == nil && s2 == nil {
		return true
	}
	if s1 == nil || s2 == nil {
		return false
	}
	if len(s1) != len(s2) {
		return false
	}
	for i := range s1 {
		if s1[i] != s2[i] {
			return false
		}
	}
	return true
}

/*
func main () {
	s1:=[]string{"apple","pear","banana"} // strings in dropdownlist
	// response will come as a map as below
	m1 := map[string] []string {"fruit": {"apple", "pear", "banana"}}
	s2 := m1["fruit"]

	res := verifyDropDown ( s1, s2)
	if res {
		fmt.Println("yes")
	} else {
		fmt.Println("no")
	}
}

*/
