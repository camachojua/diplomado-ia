package gowa

import (
	//"fmt"
	"math/rand"
	"time"
)

//const charset = "abcdefghijklmnopqrstuvwxyz" +
//	"ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"

const charset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

var seededRand *rand.Rand = rand.New(
	rand.NewSource(time.Now().UnixNano()))

func StringWithCharset(length int, charset string) string {
	b := make([]byte, length)
	for i := range b {
		b[i] = charset[seededRand.Intn(len(charset))]
	}
	return string(b)
}

func String(length int) string {
	return StringWithCharset(length, charset)
}

/*
func main () {

	for i := 0; i < 100; i++ {
		fmt.Println( String(8))
	}
}
*/
