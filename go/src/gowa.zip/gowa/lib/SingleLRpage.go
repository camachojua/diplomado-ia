package gowa

import (
	"fmt"
	"html/template"
	mkcog "mkcog/mkcog/lib"

	//"log"

	"net/http"
)

//
// code runs when server receives the request  http://localhost:1234/slrp
//

func SingleVariableLR_SalesData(s string) (slope, intercept, rsquared float64,
	count int, slopeStdErr, interceptStdErr float64) {
	var dd mkcog.DataDictionary
	dd.Read("/drv3/hm3//Data/ML_Data/ISL_Data/AdvertisingDict_AllData.xml")
	//dd.Print()
	var lrm mkcog.RegressionMatrix
	lrm.Read(dd)
	var arr []float64
	if s == "Sales | TV" {
		arr = lrm.GetColAsArray(1) // TV data
	}
	if s == "Sales | Radio" {
		arr = lrm.GetColAsArray(2) // Radio data
	}
	if s == "Sales | Newspaper" {
		arr = lrm.GetColAsArray(2) // Newspaper data
	}
	arry := lrm.GetYVector()
	slope, intercept, rsq, count, slopeStdErr, interceptStdErr := mkcog.SimpleLinearRegressionFunc(arr, arry)
	fmt.Println(slope, " ", intercept, " ", rsq, " ", count, " ", slopeStdErr, " ", interceptStdErr)
	return
}

/*
Verify that user selection is one of the items from a drop down list from a form
*/
func verify_slrp(s1 string) bool {
	s2 := [...]string{"Sales | TV", "Sales | Radio", "Sales | Newspaper"}
	for _, v := range s2 {
		if v == s1 {
			return true
		}
	}
	return false
}

func SLRP(w http.ResponseWriter, r *http.Request) {
	// string Array must match items in verifyRadioButtons.html template
	// fmt.Println("method:", r.Method) //get request method
	if r.Method == "GET" {
		// fmt.Println("before parsing")
		t, _ := template.ParseFiles(GoWaDirHtml + "SingleLRpage.html")
		t.Execute(w, nil)
		// fmt.Println("after parsing")
	}
	if r.Method == "POST" {
		r.ParseForm()
		// fmt.Println("After parsing")
		item := r.Form.Get("task")
		fStr := fmt.Sprintf("%s %s %s", "You selected  ", item, "\n")
		fmt.Fprintf(w, fStr)

		if verify_slrp(item) {
			fStr := fmt.Sprintf("%s", "Input Verified \n")
			fmt.Fprintf(w, fStr)
		}
		slope, intercept, rsq, count, slopeStdErr, interceptStdErr := SingleVariableLR_SalesData(item)
		fmt.Println(slope, " ", intercept, " ", rsq, " ", count, " ", slopeStdErr, " ", interceptStdErr)
		fStr = fmt.Sprintf("%s  %s  %f  %s  %f  %s", item, "Slope=", slope, "Intercept=", intercept, "\n")
		fmt.Fprintf(w, fStr)
	}
}
