package gowa

import (
	"encoding/gob"
	"fmt"
	"math/rand"
	"net/http"
	"os"
	"strconv"
	"time"
	//"log"
	//"html/template"
	//"regexp"
	//"golang.org/x/tools/go/gcimporter15/testdata"
)

type Submission struct {
	Title  string
	From   string
	When   time.Time
	Body   []byte
	pVotes int
	nVotes int
}

var submissions = []*Submission{}

func createNsubmissions(n int) {
	for i := 0; i < n; i++ {
		var s = new(Submission) // this will be a temp var for each new submission
		s.Title = "submission_" + strconv.Itoa(i)
		s.From = "sender_" + strconv.Itoa(i*5)
		s.pVotes = rand.Intn(100)
		s.nVotes = rand.Intn(100)
		s.When = time.Now()
		submissions = append(submissions, s)
	}
}

func printSubmissions() {
	var s = new(Submission) // this will be a temp var for each new submission
	for i := 0; i < len(submissions); i++ {
		s = submissions[i]
		fmt.Println(s.Title)
		fmt.Println(s.From)
		fmt.Println(s.Body)
		fmt.Println(s.pVotes)
		fmt.Println(s.nVotes)
		fmt.Println(s.When)
	}
}

func save(filePath string, object interface{}) error {
	file, err := os.Create(filePath)
	if err == nil {
		encoder := gob.NewEncoder(file)
		encoder.Encode(object)
	}
	file.Close()
	return err
}

/*
load gets a filePath, finds and loads a question into the interface
and returns. To call is:

err = load("./s1.gob",rs)

err is nil if question is found, otherwise err is non-nil
*/
func load(filePath string, object interface{}) error {
	file, err := os.Open(filePath)

	if err != nil {
		return err
	}

	if err == nil {
		decoder := gob.NewDecoder(file)
		err = decoder.Decode(object)
	}
	file.Close()
	return err
}

/*
	Load a question or start the editing of a new one. If question is not there,
	s is empty and error is non-nil. This causes the handler to redirect request

to editHandler. Either way, the viewHandler uses the view template for rendering
*/
func viewHandler(w http.ResponseWriter, r *http.Request) {
	title := r.URL.Path[len("/view/"):]
	// s := load(title)
	// fmt.Fprintf(w, "<h1>%s</h1><div>%s</div>", s.Title, s.Body)
	fmt.Fprintf(w, "<h1>%s</h1><div>%s</div>", title, "lofas")
}

func test() {
	//createNsubmissions( 5 )
	//printSubmissions()
	var s1 = new(Submission)
	s1.From = "s1From"
	s1.Body = []byte("ut quean laxis")
	s1.nVotes = 0
	s1.pVotes = 0
	s1.Title = "s1 Title"
	s1.When = time.Now()
	err := save("./s1.gob", s1)
	if err != nil {
		fmt.Println(err)
	}

	var s2 = new(Submission)
	s2.From = "s2From"
	s2.Body = []byte("resonore fibris")
	s2.nVotes = 0
	s2.pVotes = 0
	s2.Title = "s1 Title"
	s2.When = time.Now()
	err = save("./s2.gob", s2)
	if err != nil {
		fmt.Println(err)
	}

	var rs = new(Submission)
	err = load("./s1.gob", rs)
	if err != nil {
		fmt.Println(err)
	} else {
		fmt.Println(rs.Title, "\t", rs.Title)
	}
}

func ff(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintln(w, "Hello, func ff is serving foo!")
}

/*
func main() {

	fmt.Println("Here we Go")

	h := http.NewServeMux()

	h.HandleFunc("/faa", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintln(w, "Hello, you are in foo!")
	})

	h.HandleFunc("/bar", ff )

	err := http.ListenAndServe(":9999", h)
	log.Fatal(err)
}
*/
