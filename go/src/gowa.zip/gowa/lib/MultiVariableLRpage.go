package gowa

import (
	mkcog "mkcog/mkcog/lib"
	"net/http"
	"strings"

	//"log"
	"fmt"
	"html/template"
)

//
// code runs when server receives the request  http://localhost:1233/mlrp
//

//encodeResponse gets items from the page and composes a new configData array for the DataDictionary
/*
func encodeResponse(items string) string {

	if len(items) == 0 {
		return "0,0,0,0,0"
	}

	if items == "Sales | TV" { // case 1
		return []string{"1", "X", "0", "0", "Y"}
	}
	if items[0] == "Sales | Radio" { // case 2
		return []string{"1", "0", "X", "0", "Y"}
	}
	if items[0] == "Sales | Newspaper" { // case 3
		return []string{"1", "0", "0", "X", "Y"}
	}

	if len(items) == 2 {
		if (mc.Include(items, "Sales | TV")) && (mc.Include(items, "Sales | Radio")) { // case 4
			return []string{"1", "X", "X", "0", "Y"}
		}
		if (mc.Include(items, "Sales | TV")) && (mc.Include(items, "Sales | Newspaper")) { // case 5
			return []string{"1", "X", "0", "X", "Y"}
		}
		if (mc.Include(items, "Sales | Radio")) && (mc.Include(items, "Sales | Newspaper")) { // case 6
			return []string{"1", "0", "X", "X", "Y"}
		}
	}

	if len(items) == 3 { // case 7
		if (mc.Include(items, "Sales | TV")) &&
			(mc.Include(items, "Sales | Radio")) &&
			(mc.Include(items, "Sales | Newspaper")) {
			return []string{"1", "X", "X", "X", "Y"}
		}
	}
	return []string{"0", "0", "0", "0", "0"} // this should not happen
}
*/

// DataDictionaryConfig is a func written to improve/test a web server interface for the ISLR book sales data set
func DataDictionaryConfig(items string) string {
	if items == "Sales | TV" { // case 1
		return "1,X,0,0,Y"
	}
	if items == "Sales | Radio" { // case 2
		return "1,0,X,0,Y"
	}
	if items == "Sales | Newspaper" { // case 3
		return "1,0,0,X,Y"
	}

	if strings.Contains(items, "TV") && strings.Contains(items, "Radio") && !(strings.Contains(items, "Newspaper")) { //case 4
		return "1,X,X,0,Y"
	}

	if strings.Contains(items, "TV") && strings.Contains(items, "Newspaper") && !(strings.Contains(items, "Radio")) { //case 5
		return "1,X,0,X,Y"
	}

	if strings.Contains(items, "Radio") && strings.Contains(items, "Newspaper") && !(strings.Contains(items, "TV")) { //case 6
		return "1,0,X,X,Y"
	}

	if strings.Contains(items, "TV") && strings.Contains(items, "Radio") && strings.Contains(items, "Newspaper") { //case 7
		return "1,X,X,X,Y"
	}

	return "0,0,0,0,0" // this should never happen
}

// MultipleVariableLR_SalesData gets a ddConfig string from the page, uses it to reconfig the data dictionary, and with the new
// config info launches the calculation of the betas. Thi reconfig of the dictionary is done in encodeResponse, a func internal to
// the package, because this will only work with the info from the page, which in fact comes from the ISLR book sales data
func MultipleVariableLR_SalesData(ddConfig string) []float64 {

	var dd mkcog.DataDictionary

	// Get all the advertising data
	dd.Init()
	dd.Read("/drv3/hm3/Data/ML_Data/ISL_Data/AdvertisingDict_AllData.xml")
	// dd.Print()

	ddSep := ","

	ddConfigArray := strings.Split(ddConfig, ddSep)
	dd.UpdateConfig(ddConfigArray)

	var lrm mkcog.RegressionMatrix
	lrm.Read(dd)

	lrm.LinearRegressionFunc()
	locBetas := lrm.GetBetas()
	fmt.Println("Betas=", locBetas)
	//lrm.VarianceCovarianceMatrixFunc()
	//lrm.PlotLinearRegression(dd)
	return locBetas
}

// MLRP = Simple LR Page. Name starts with Capital to export func
func MLRP(w http.ResponseWriter, r *http.Request) {
	// string Array must match items in verifyRadioButtons.html template
	items := ""
	ddConfig := ""
	fStr := ""
	fmt.Println("method:", r.Method) //get request method
	if r.Method == "GET" {
		fmt.Println("before parsing")
		t, _ := template.ParseFiles(GoWaDirHtml + "MultiVariableLRpage.html")
		t.Execute(w, nil)
		fmt.Println("after parsing")
	}
	if r.Method == "POST" {
		r.ParseForm()
		fmt.Println("After parsing")
		arItems := r.Form["task"]

		if len(arItems) == 1 {
			items = strings.Join(arItems, " ")
			ddConfig = DataDictionaryConfig(items)
		}
		if len(arItems) > 1 {
			items = strings.Join(arItems, " AND ")
			ddConfig = DataDictionaryConfig(items)
		}
		if items == "" {
			fStr = fmt.Sprintf("Please make a selection\n\n")
			fmt.Fprintf(w, fStr)
		}
		if items != "" {
			fStr = fmt.Sprintf("%s %s %s", "You selected  ", items, "\n")
			fmt.Fprintf(w, fStr)
			println(fStr, "\n")
			fStr = fmt.Sprintf("%s %s %s", "Encoded response is ", r, "\n")
			locBetas := MultipleVariableLR_SalesData(ddConfig)
			fStr = fmt.Sprintf("%s %f %s", "Betas ", locBetas, "\n")
			fmt.Fprintf(w, fStr)
		}

	}
}

/*
func main() {

	http.HandleFunc("/vcb", vcb)             // set router
	err := http.ListenAndServe(":1234", nil) // set listen port
	if err != nil {
		log.Fatal("ListenAndServe: ", err)
	}
}
*/
