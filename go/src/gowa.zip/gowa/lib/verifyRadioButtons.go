package gowa

import (
	"fmt"
	"html/template"

	//"log"
	"net/http"
)

/*
  Use GoLang to verify in server that user selection is one of the items from a drop down list from a form
*/

func Verify_rb(s1 string) bool {
	s2 := [...]string{"White", "African American", "Asian", "Native American", "Latino", "Other"}
	for _, v := range s2 {
		if v == s1 {
			return true
		}
	}
	return false
}

func Vrb(w http.ResponseWriter, r *http.Request) {
	// string Array must match items in verifyRadioButtons.html template
	fmt.Println("method:", r.Method) //get request method
	if r.Method == "GET" {
		fmt.Println("before parsing")
		t, _ := template.ParseFiles(GoWaDirHtml + "verifyRadioButtons.html")
		t.Execute(w, nil)
		fmt.Println("after parsing")
	}
	if r.Method == "POST" {
		r.ParseForm()
		fmt.Println("After parsing")
		item := r.Form.Get("race")

		fStr := fmt.Sprintf("%s %s %s", "You selected  ", item, "\n")
		fmt.Fprintf(w, fStr)

		if Verify_rb(item) {
			fStr := fmt.Sprintf("%s", "Input Verified \n")
			fmt.Fprintf(w, fStr)
		}
	}
}

/*
func main() {

	http.HandleFunc("/vrb", vrb)             // set router
	err := http.ListenAndServe(":1234", nil) // set listen port
	if err != nil {
		log.Fatal("ListenAndServe: ", err)
	}
}

*/
