package gowa

import (
	"html/template"
	"net/http"
)

//"fmt"
//"log"
//"net/http"

func Server2(w http.ResponseWriter, r *http.Request) {
	// string Array must match items in verifyRadioButtons.html template
	// fmt.Println("method:", r.Method) //get request method
	// fmt.Println("before parsing")
	t, _ := template.ParseFiles(GoWaDirHtml + "Server2.html")
	t.Execute(w, nil)
	// fmt.Println("after parsing")
}
