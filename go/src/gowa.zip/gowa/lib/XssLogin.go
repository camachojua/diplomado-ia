package gowa

import (
	"fmt"
	"html/template"

	//"log"
	"net/http"
)

func XssLogin(w http.ResponseWriter, r *http.Request) {
	fmt.Println("method:", r.Method) //get request method
	if r.Method == "GET" {
		t, _ := template.ParseFiles(GoWaDirHtml + "XssLogin.html")
		t.Execute(w, nil)
	}
	if r.Method == "POST" {

		locStr := "POST METHOD in XssLogin \n"
		fmt.Fprintf(w, locStr)

		r.ParseForm()
		usrStr := fmt.Sprintf("%s %s %s", "Username: ", template.HTMLEscapeString(r.Form.Get("username")), "\n")
		fmt.Fprintf(w, usrStr)
		fmt.Println(usrStr)
		// fmt.Println( r.Form.Get("username"))

		pwdStr := fmt.Sprintf("%s %s %s", "Password: ", template.HTMLEscapeString(r.Form.Get("password")), "\n")
		fmt.Fprintf(w, pwdStr)
		fmt.Println(pwdStr)

		t, err := template.New("bad").Parse(`{{define "T"}}Hello, {{.}}!{{end}}`)
		err = t.ExecuteTemplate(w, "T", template.HTML("<script>alert('DANGER you have been pwned')</script>\n\n"))
		if err != nil {
			fmt.Println(" bad ")
		}

		t, err = template.New("better").Parse(`{{define "TT"}}Hello, {{.}}!{{end}}`)
		err = t.ExecuteTemplate(w, "TT", template.HTMLEscapeString("<script>alert('ESCAPED MESSAGE: you have been pwned')</script>\n\n"))
		if err != nil {
			fmt.Println(" bad ")
		}

		// 	t, err = template.New("better").Parse(`{{define "TT"}}Hello, {{.}}!{{end}}`)
		// err = t.ExecuteTemplate(w, "TT", "<script>alert('you have been pwned')</script>")

		// fmt.Println( r.Form.Get("password"))

		// t.Execute(w, nil)
		// t, _ := template.ParseFiles("LoginPost.html")
	}
}

/*
func main() {
	http.HandleFunc("/", helloName)          // set router
	http.HandleFunc("/login", login)         // set router
	err := http.ListenAndServe(":1234", nil) // set listen port
	if err != nil {
		log.Fatal("ListenAndServe: ", err)
	}
}

*/
