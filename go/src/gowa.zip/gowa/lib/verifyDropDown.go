package gowa

import (
	"net/http"
	//"log"
	"fmt"
	"html/template"
)

/*
  code demonstrates how to verify the drop down list items from a form
*/

func Verify_dd(s1 string) bool {
	s2 := [...]string{"apple", "pear", "banana"}
	for _, v := range s2 {
		if v == s1 {
			return true
		}
	}
	return false
}

func Vdd(w http.ResponseWriter, r *http.Request) {
	fmt.Println("method:", r.Method) //get request method
	if r.Method == "GET" {
		fmt.Println("before parsing")
		t, _ := template.ParseFiles(GoWaDirHtml + "verifyDropDown.html")
		t.Execute(w, nil)
		fmt.Println("after parsing")
	}
	if r.Method == "POST" {

		locStr := "POST METHOD.\n"
		fmt.Fprintf(w, locStr)

		r.ParseForm()
		fmt.Println("After parsing")

		fStr := fmt.Sprintf("%s %s %s", "You selected a ", r.Form.Get("fruit"), "\n")
		fmt.Fprintf(w, fStr)

		Verify_dd(r.Form.Get("fruit"))

		fStr = fmt.Sprintf("%s ", "Verification passed \n")
		fmt.Fprintf(w, fStr)

	}
}

/*
func main() {

	http.HandleFunc("/vdd", Vdd) // set router
	err := http.ListenAndServe(":1234", nil) // set listen port
	if err != nil {
		log.Fatal("ListenAndServe: ", err)
	}
}


*/
