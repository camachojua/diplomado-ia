package gowa

import (
	"database/sql"
	"fmt"
	"html/template"
	"log"
	"net/http"

	_ "github.com/go-sql-driver/mysql"
)

/*
Sample queries
SELECT * FROM employees WHERE gender = 'F'
SELECT * FROM employees WHERE gender = 'M'
SELECT * FROM employees WHERE first_name = "Mary"
SELECT * FROM employees WHERE last_name = "Smith"

Note that queries in MySQL Workbench need to be as
SELECT * FROM employees.employees where last_name = "Facello"
// there are 244 results from query below
SELECT * FROM employees.employees where first_name = "Mary"

*/

type record struct {
	emp_no int
	dob    string
	fname  string
	lname  string
	gender []uint8
	doh    string
}

var records = []record{}

func PrRecord(r record) {
	fmt.Println(r.emp_no, r.dob, r.fname, r.lname, r.gender, r.doh)
}

func OpenDb(query string) string {

	var aDD DBDict
	aDD.Init()
	aDD.FileName = "/employees" // name is what MySQL will see
	aDD.Port = ":3306"
	aDD.URL = "(127.0.0.1)"
	aDD.Server = "mysql"
	aDD.Protocol = "@tcp"
	aDD.UserID = "juan"
	aDD.UserPwd = "Harbison@211"
	aDD.ConnStr = aDD.UserID + ":" + aDD.UserPwd + aDD.Protocol + aDD.URL + aDD.FileName

	fmt.Println("Opening DB for query")

	aDD.InitConnStr()
	db, err := sql.Open(aDD.Server, aDD.ConnStr)
	if err != nil {
		fmt.Println("Error: could not find driver, connection, or DB")
		log.Fatal(err)
	}
	// is the connection OK ?
	err = db.Ping()
	if err != nil {
		fmt.Println("There seems to be a problem opening the DB")
	}

	var str = ProcessQuery(*db, query)

	defer db.Close()
	fmt.Println("Query Execution Complete.")

	return str
}

func ProcessQuery(db sql.DB, query string) string {

	var r record
	// records := []record{}

	rows, err := db.Query(query)
	if err != nil {
		log.Fatal(err)
	}

	//  300,024 EMPLOYEES
	//  179,973 M
	//  120,051 f
	count := 0
	for rows.Next() {
		err := rows.Scan(&r.emp_no, &r.dob, &r.fname, &r.lname, &r.gender, &r.doh)
		if err != nil {
			log.Fatal(err)
		}
		if err == nil {
			records = append(records, r)
			count += 1
		}
	}
	fStr := fmt.Sprintf("There are  %d  records in Employees DB that fit your query \n", count)
	fmt.Println(fStr)

	for i := 0; i < len(records); i++ {
		PrRecord(records[i])
	}

	err = rows.Err()
	if err != nil {
		log.Fatal(err)
	}
	defer rows.Close()
	return fStr
}

func SqlQuery(w http.ResponseWriter, r *http.Request) {
	if r.Method == "GET" {
		fmt.Println("GET before parsing")
		t, _ := template.ParseFiles(GoWaDirHtml + "SqlQuery.html")
		t.Execute(w, nil)
		fmt.Println("GET after parsing")
	}

	if r.Method == "POST" {
		r.ParseForm()
		fmt.Println("POST After parsing")
		fStr := fmt.Sprintf("Your query \n")
		fmt.Fprintf(w, fStr)

		var strQuery = r.FormValue("query")
		fStr = fmt.Sprintf("%s  \n", strQuery)
		fmt.Fprintf(w, fStr)
		fmt.Println(fStr)

		fStr = fmt.Sprintf("Return the following result \n")
		fmt.Fprintf(w, fStr)

		var retStr = OpenDb(strQuery)
		fmt.Fprintf(w, retStr)

		fmt.Println("POST after parsing")

		for i := 0; i < len(records); i++ {
			fmt.Fprint(w, records[i], "\n")
		}

	}

}
