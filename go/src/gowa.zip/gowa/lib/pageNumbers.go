package gowa

import (
	"fmt"
	//"log"
	"net/http"
)

type pageNumber int

func (n pageNumber) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintf(w, "You requested page number %d\n", n)
}

/*
func main() {
	h := http.NewServeMux()

	h.Handle("/one", pageNumber(1))
	h.Handle("/1",   pageNumber(1))

	h.Handle("/two", pageNumber(2))
	h.Handle("/2",   pageNumber(2))

	h.Handle("/three", pageNumber(3))
	h.Handle("/3",     pageNumber(3))

	h.Handle("/four", pageNumber(4))
	h.Handle("/4",    pageNumber(4))

	h.Handle("/five", pageNumber(5))
	h.Handle("/5",    pageNumber(5))

	err := http.ListenAndServe(":1234", h)
	log.Fatal(err)
}

*/
