package gowa

/*
  	using code from https://cryptic.io/go-http/

	to test, from a terminal:

		curl localhost:9999/foo/bar

*/

import (
	"fmt"
	//"log"
	"net/http"
)

type helloHandler struct{}

func (h helloHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintf(w, "this is func ServeHTTP ")
	fmt.Fprintf(w, "serving helloHandler ")

	fmt.Fprintf(w, "hello, you've hit %s\n", r.URL.Path)
}

/*
func main() {
	err := http.ListenAndServe(":9999", helloHandler{})
	log.Fatal(err)
}
*/
