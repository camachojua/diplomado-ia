package gowa

/*
 File init.go contains global definitions (mostly variables and constants)
 used by gowa. Note that for the most part these are places where the code resides,
 where the data files are expected to be for upload and download, and so forth.
 Also, I am putting in a separate directory the html files.
*/



var HomeDir = "/drv3/hm3/"

var GoWaDir = HomeDir + "code/go/src/gowa/"
var GoWaDirHtml = HomeDir + "code/go/src/gowa/html/"
var GoWaDirCss = HomeDir + "code/go/src/gowa/css/"

var GoWaDataDir = HomeDir + "code/go/src/gowa/data/"
var GoWaDataDirUpload = HomeDir + "code/go/src/gowa/data/upload/"
var GoWaDataDirDownload = HomeDir + "code/go/src/gowa/data/download"

/*
The dictionaries below contain descriptions of the structures (DBs tables, etc) used to
stored the data in files. Unfortunately field names need to be exported for json/xml i/o,
which means that the names must be in UpperCase.

I opted for XML instead of JSON for the data dictionaries because the XML writing/reading
process is much simpler and the .XML files are easier to read by the human eye.
*/

// DBDict is the dictionary for the DB app
type DBDict struct {
	FileName    string   `xml:"fileName"`
	Description string   `xml:"description"`
	Directory   string   `xml:"directory"`
	Port        string   `xml:"port"`
	UserID      string   `xml:"userId"`
	UserPwd     string   `xml:"userPwd"`
	Server      string   `xml:"server"`
	Protocol    string   `xml:"protocol"`
	DictFile    string   `xml:"dictFile"`
	URL         string   `xml:"url"`
	ConnStr     string   `xml:"connStr"`
	ReadMeFile  string   `xml:"readMeFile"`
	Tables      []string `xml:"tables"`
}

// DBTableDict is the dictionary I intend to use to keep track of the tables
type DBTableDict struct {
	ReadMeFile string   `xml:"readMeFile"`
	FieldNames []string `xml:"fieldNames"`
	FieldTypes []string `xml:"fieldTypes"`
	NRowsInTab int      `xml:"nRowsInTab"`
	NColsInTab int      `xml:"nColsInTab"`
}

// EOF
