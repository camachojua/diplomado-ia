package gowa

//
// code runs when server receives the request  http://localhost:1234/vcb
//

import (
	"net/http"
	//"log"
	"fmt"
	"html/template"
)

func Verify_cb(s1 string) bool {
	s2 := [...]string{"football", "basketball", "tennis", "soccer", "rugby", "Other"}
	for _, v := range s2 {
		if v == s1 {
			return true
		}
	}
	return false
}

// name starts with Capital to export func
func Vcb(w http.ResponseWriter, r *http.Request) {
	// string Array must match items in verifyRadioButtons.html template
	fmt.Println("method:", r.Method) //get request method
	if r.Method == "GET" {
		fmt.Println("before parsing")
		t, _ := template.ParseFiles(GoWaDirHtml + "verifyCheckBoxes.html")
		t.Execute(w, nil)
		fmt.Println("after parsing")
	}
	if r.Method == "POST" {
		r.ParseForm()
		fmt.Println("After parsing")
		item := r.Form.Get("interest")
		items := r.Form["interest"]

		fStr := fmt.Sprintf("%s %s %s", "You selected  ", items, "\n")
		fmt.Fprintf(w, fStr)

		if Verify_cb(item) {
			fStr := fmt.Sprintf("%s", "Input Verified \n")
			fmt.Fprintf(w, fStr)
		}
	}
}

/*
func main() {

	http.HandleFunc("/vcb", vcb)             // set router
	err := http.ListenAndServe(":1234", nil) // set listen port
	if err != nil {
		log.Fatal("ListenAndServe: ", err)
	}
}
*/
