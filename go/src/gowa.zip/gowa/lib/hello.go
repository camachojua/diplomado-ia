package gowa

import "fmt"

func HelloGowa() {
	fmt.Printf("hello gowa 1 \n")
	fmt.Printf("hello gowa 2 \n")
	fmt.Printf("hello gowa 3 \n")
	fmt.Printf("hello gowa 4 \n")

}
