package gowa

import (
	"fmt"
	"html/template"
	"os"

	//"log"
	"net/http"
	"strings"
)

func HelloName(w http.ResponseWriter, r *http.Request) {

	folderpath, _ := os.Getwd()
	fmt.Println("Current directory path: ", folderpath)

	if r.Method == "GET" {
		fmt.Fprintf(w, "GET METHOD\n") // send data to client side

	}

	if r.Method == "POST" {
		fmt.Fprintf(w, "POST METHOD\n") // send data to client side
	}

	r.ParseForm()                   // parse arguments, you have to call this by yourself
	fmt.Println("r.Form: ", r.Form) // print form information in server side
	fmt.Println("path", r.URL.Path)
	fmt.Println("scheme", r.URL.Scheme)
	fmt.Println(r.Form["url_long"])
	for k, v := range r.Form {
		fmt.Println("key:", k)
		fmt.Println("val:", strings.Join(v, ""))
	}
	fmt.Fprintf(w, "Well hello !\n") // send data to client side
}

func Login(w http.ResponseWriter, r *http.Request) {
	fmt.Println("method:", r.Method) //get request method
	if r.Method == "GET" {
		t, _ := template.ParseFiles(GoWaDirHtml + "verifyLoginFields.html")
		t.Execute(w, nil)
	}
	if r.Method == "POST" {

		locStr := "POST METHOD\n"
		fmt.Fprintf(w, locStr)

		r.ParseForm()
		usrStr := fmt.Sprintf("%s %s %s", "Username: ", r.Form.Get("username"), "\n")
		fmt.Fprintf(w, usrStr)
		fmt.Println(usrStr)
		// fmt.Println( r.Form.Get("username"))

		pwdStr := fmt.Sprintf("%s %s %s", "Password: ", r.Form.Get("password"), "\n")
		fmt.Fprintf(w, pwdStr)
		fmt.Println(pwdStr)
		// fmt.Println( r.Form.Get("password"))

		// t.Execute(w, nil)
		// t, _ := template.ParseFiles("LoginPost.html")
	}
}

/*
func main() {
	http.HandleFunc("/", helloName)          // set router
	http.HandleFunc("/login", login)         // set router
	err := http.ListenAndServe(":1234", nil) // set listen port
	if err != nil {
		log.Fatal("ListenAndServe: ", err)
	}
}

*/
