package gowa

import (
	"fmt"
	"net/http"
	"strings"
	"time"
)

func Server4(w http.ResponseWriter, r *http.Request) {
	r.ParseForm()       // parse arguments, you have to call this by yourself
	fmt.Println(r.Form) // print form information in server side
	fmt.Println("path", r.URL.Path)
	fmt.Println("scheme", r.URL.Scheme)
	fmt.Println(r.Form["url_long"])
	for k, v := range r.Form {
		fmt.Println("key:", k)
		fmt.Println("val:", strings.Join(v, ""))
	}
	fmt.Fprintf(w, "Hello. This is server4! \n ") // send data to client side
	t := time.Now()
	fmt.Fprintf(w, "Time now is %s \n", t.Local())
}

/*
func main() {
	http.HandleFunc("/", Server4) // set router
	err := http.ListenAndServe(":1234", nil) // set listen port
	if err != nil {
		log.Fatal("ListenAndServe: ", err)
	}
}
*/
