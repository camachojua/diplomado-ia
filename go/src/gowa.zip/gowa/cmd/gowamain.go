package main

import (
	"fmt"
	gowa "gowa/lib"
	"log"
	"net/http"
	"os"
	"os/exec"
	"runtime"
)

/*
gowamain is a WebApp writing in Go. The purpose is to create a fully functional Web App that includes a web server, a client,
and access/interface to a back end storage service provided by Go Lang or a DB (MySql).

Once trhe app is running, to use it form a browser issue   http://localhost:1234

Note that this app does not provide access in the form of https:

*/

// openBrowser tries to open the URL in a browser,
// and returns whether it succeed in doing so.
func OpenBrowser(url string) bool {
	var args []string
	switch runtime.GOOS {
	case "darwin":
		args = []string{"open"}
	case "windows":
		args = []string{"cmd", "/c", "start"}
	default:
		args = []string{"xdg-open"}
	}
	cmd := exec.Command(args[0], append(args[1:], url)...)
	return cmd.Start() == nil
}

// code will run from browser http://localhost:1234/
func main() {

	// launch an instance of the Chrome Browser at port 1234
	var url = "http://localhost:1234"
	OpenBrowser(url)

	fmt.Println(" here we ... go!")
	fmt.Printf("Process ID   %d  ", os.Getpid())

	// code below is needed to add .css styles into the html files
	http.Handle(gowa.GoWaDirCss,
		http.StripPrefix(gowa.GoWaDirCss,
			http.FileServer(http.Dir(gowa.GoWaDirCss))))

	http.HandleFunc("/", gowa.Gowa)                   // set router
	http.HandleFunc("/pgPython", gowa.PgPython)       // set router
	http.HandleFunc("/hello", gowa.HelloName)         // set router
	http.HandleFunc("/login", gowa.Login)             // set router
	http.HandleFunc("/sqlquery", gowa.SqlQuery)       // set router
	http.HandleFunc("/server2", gowa.Server2)         // set router
	http.HandleFunc("/server3", gowa.Server3)         // set router
	http.HandleFunc("/server4", gowa.Server4)         // set router
	http.HandleFunc("/server5", gowa.Server5)         // set router
	http.HandleFunc("/XssLogin", gowa.XssLogin)       // set router
	http.HandleFunc("/vrb", gowa.Vrb)                 // set router
	http.HandleFunc("/vdd", gowa.Vdd)                 // set router
	http.HandleFunc("/vcb", gowa.Vcb)                 // set router
	http.HandleFunc("/contactform", gowa.ContactForm) // set router

	// do not use these two until mkcog is added to this app
	http.HandleFunc("/slrp", gowa.SLRP) // SLRP = Simple LR Page
	http.HandleFunc("/mlrp", gowa.MLRP) // MLRP = Multi-variable LR Page

	http.HandleFunc("/upload", gowa.UploadFile) // set router

	err := http.ListenAndServe(":1234", nil) // listen at port 1234
	if err != nil {
		log.Fatal("ListenAndServe: ", err)
	}

	fmt.Println("DONE")

}
