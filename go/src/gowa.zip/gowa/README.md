
# Go WA


gowa is the "V2" of a lib I am writing for a demo on the topic of writing web apps in Golang.
The version of go is 1.22.4


The code is written in the Go language. It uses the Http pkg that has existed from the start of Go
I wrote the first version of this code, which I named "GoWa" sometime around 2018.

## UPDATE 1: June 19, 2024

In preparation for the UNAM AI/Data Science Certificate, I reopened this project.  
The newer versions of Go use modules. The go.mod file specifies where and how the libs/APIS 
that the code will use are located. That said, I still believe that it is a good idea to keep
 $GOPATH and $GOROOT defined in /etc/profile

    export PATH=$PATH:/usr/local/go/bin
    export GOROOT=/usr/local/go
    export PATH=$PATH:$GOROOT/bin
    ### export GOPATH=$HOME/code/go
    ## OR
    export GOPATH=/drv3/hm3/code/go

As I went through the update in June 19, 2024, I found that the directory original directory configuration gave problems.
Therefore I changed the configuration as folows:

The code is in a root directory, which is /drv3/hm3/code/go/src/gowa and consists of the following directories

	/drv3/hm3/code/go/src/gowa/lib	contains the module and package definitions

	/drv3/hm3/code/go/src/gowa/cmd	contains code that uses the module and the package.

	/drv3/hm3/code/go/src/gowa/html contains the html files used by gowa

	/drv3/hm3/code/go/src/gowa/css contains css (style sheets) used by gowa

	/drv3/hm3/code/go/src/gowa/data contains data used by gowa


The code in /drv3/hm3/code/go/src/cmd/gowamain.go uses the code defined in ../lib. 
The change in name to gowa is to be consistent with the Go languagbe naming conventions, wherein names of packages and modules
are in lowercase, but functions and variables to be exported as globals are in uppercase


The go.mod file was created as follows:

	cd /drv3/hm3/code/go/src/gowa
	// create directories ../lib and ../cmd
	// put stuff in ../lib and in ../cmd

	cd /drv3/hm3/code/go/src/gowa
	go mod init gowa
	go mod tidy

Run from ../cmd/gowagmain.go

## UPDATE 2: NOTE ABOUT launch.json

This code runs the code from a browser, defined at http://localhost:1233

When the code runs from VSC, a message appears warning that lauch.json must be modified as to remove
the lines where 'host' and 'port' are defined. Also, note that while the code is running, a separate
server is used to monitor the execution and do the debugging. That server is defned as 'dlv dap server'


## UPDATE 3

The first test of the new gowa and gowamain I ran went well. The code had no references to mkcog.
When I added a reference to mkcog, I had to redefine go.mod and go.sum.


## UPDATE 4

I had to issue the line below to get the mkcog lib into gowa

go get mkcog/mkcog/lib@v0.0.0


The go.mod with the mkcog reference looks like:

```
module gowa

go 1.22.4

require (
	github.com/go-sql-driver/mysql v1.8.1
	github.com/gorilla/sessions v1.3.0
)

require (
	filippo.io/edwards25519 v1.1.0 // indirect
	git.sr.ht/~sbinet/gg v0.5.0 // indirect
	github.com/ajstarks/svgo v0.0.0-20211024235047-1546f124cd8b // indirect
	github.com/campoy/embedmd v1.0.0 // indirect
	github.com/go-fonts/liberation v0.3.2 // indirect
	github.com/go-latex/latex v0.0.0-20231108140139-5c1ce85aa4ea // indirect
	github.com/go-pdf/fpdf v0.9.0 // indirect
	github.com/golang/freetype v0.0.0-20170609003504-e2365dfdc4a0 // indirect
	github.com/gorilla/securecookie v1.1.2 // indirect
	github.com/pmezard/go-difflib v1.0.0 // indirect
	golang.org/x/image v0.14.0 // indirect
	golang.org/x/text v0.14.0 // indirect
	gonum.org/v1/gonum v0.15.0 // indirect
	gonum.org/v1/plot v0.14.0 // indirect
)

require mkcog/mkcog v0.0.0

replace mkcog/mkcog => /drv3/hm3/code/go/src/mkcog

```
